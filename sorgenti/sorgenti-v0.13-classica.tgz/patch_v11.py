#!/usr/bin/env python3
# v0.11: Il grande viaggio (capitolo 4) collegato al menu, alle novità e al guardaroba
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH11 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
rep('d:"Oltre le isole conosciute, verso un mare che sulle carte non c\'è ancora.",st:"In programma"}',
    'd:"Oltre le isole conosciute, verso un mare che sulle carte non c\'è ancora. Sei mari da attraversare, una nave fantasma e una stella da seguire. Dal menu iniziale: «Il grande viaggio (prova)».",st:"Bozza giocabile"}')
rep('<button id="bCap4" class="lnk">Assalto al galeone (prova)</button>',
    '<button id="bCap4" class="lnk">Assalto al galeone (prova)</button><span>·</span><button id="bCap5" class="lnk">Il grande viaggio (prova)</button>')
rep("  $('bCap4').onclick=",
    "  $('bCap5').onclick=()=>{__go('#w5');location.reload()};\n  $('bCap4').onclick=")
rep("  {id:'h_corona',k:'hat',n:'Corona del Re dei Mari'",
    "  {id:'h_viagg',k:'hat',n:'Berretto del navigatore',hint:'Arriva al faro nel Grande viaggio.',own:()=>{try{return localStorage.getItem('sm_c5done')==='1'}catch(e){return false}},spec:{hat:'cap',hatc:'#2c4a6a'}},\n  {id:'h_corona',k:'hat',n:'Corona del Re dei Mari'")
rep("  // cappellini del pappagallo\n",
    "  {id:'o_viagg',k:'out',n:'Cappotto del navigatore',hint:'Arriva al faro nel Grande viaggio.',own:()=>{try{return localStorage.getItem('sm_c5done')==='1'}catch(e){return false}},spec:{coat:'#2c4a6a',coat2:'#1a2f47',pants:'#2a3140',shirt:'#efe6c8',boots:1,trim:'#e8c860',sash:'#d9c070'}},\n  // cappellini del pappagallo\n")
rep("const CHANGELOG=[\n","""const CHANGELOG=[
  {v:"0.11",d:"7 nov 2026",t:"Il grande viaggio (bozza)",n:[
    "Capitolo 4: «Il grande viaggio». Dal menu iniziale, «Il grande viaggio (prova)»; dal Capitolo 3 si arriva anche dalla schermata finale con «Continua: Il grande viaggio». Una traversata verso ovest, con la nave e il pappagallo, in sei mari uno diverso dall'altro.",
    "Mare di Calvara: si salpa dalla costa, con le ultime pattuglie da seminare. Mare dei Sargassi: acqua piatta e alghe che frenano la nave; il pulsante «Voga!» dà una spinta a remi. Mare delle Tempeste: pioggia, vortici che tirano e fulmini segnalati da un cerchio sull'acqua, da evitare. Mare di Nebbia: si vede a pochi passi, ci si orienta con le boe accese e il pulsante «Perlustra» del pappagallo. Mare dei Relitti: notte, una nave fantasma che ti segue e il relitto del Gabbiano con il diario di Ferro. Mare della Stella: una stella bassa da seguire fino al faro.",
    "Qui lo scafo non affonda: se arrivi a zero riparti dall'ultimo punto di controllo con lo scafo pieno. Le casse di legno che galleggiano riparano un cuore. Si salva da solo a ogni zona e si può riprendere da dove eri.",
    "La nave fantasma «Il Gabbiano» non si può colpire né affondare: si semina. Cambia musica e luce di zona in zona; di notte la scia della nave brilla.",
    "Il faro con il molo, Giacomo che aspetta e l'ultima scena. Alla fine una schermata con il tuo viaggio e un indizio su dove portare la nave dopo.",
    "Guardaroba: dopo il faro si sbloccano il Berretto del navigatore e il Cappotto del navigatore.",
    "Le scritte del Capitolo 4 per ora sono solo in italiano (le altre lingue arrivano dopo)."
  ]},
""")
open(P,'w',encoding='utf8').write(src)
print('patch11 ok')
