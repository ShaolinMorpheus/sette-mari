const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('D','m');s.tutDone=1;s.built={zattera:1};s.es={plot_zattera:{st:2,p:1}};localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(2000);
console.log(await p.evaluate(()=>{const P=Pirati;const e=P.EID.plot_zattera;let o='fp '+JSON.stringify(e.fp)+' st'+e.st+' away'+e.away+'\n';
 for(let y=26;y<37;y++){let r=y+' ';for(let x=48;x<64;x++){const t=P.tileInfo(x,y);r+=(t.sea?'~':t.free?'.':'#')}o+=r+'\n'}return o}));
await b.close()})();
