const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:1100,height:620}});const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
console.log(await p.evaluate(()=>typeof Ch3+' '+typeof Ch4));
// make galleon spawn & disable & board
const r=await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.t=400;C.p.x=3000;C.p.y=3000;for(let i=0;i<5;i++)Ch3.step(.1);
 const g=C.ships.find(s=>s.type==='galeone');C.pris=2;g.x=C.p.x+200;g.y=C.p.y;g.hull=14;
 // hits
 for(let i=0;i<20;i++){C.balls.push({x:g.x,y:g.y,vx:0,vy:0,t:0,life:5,own:C.p});Ch3.step(.05)}
 const o=[g.hull,g.disabled,g.dead];Ch3.step(.05);document.getElementById('c3bd').click&&0;
 o.push(getComputedStyle(document.getElementById('c3bd')).display);return o});
console.log(JSON.stringify(r));
await p.evaluate(()=>Ch3.board());await p.waitForTimeout(2500);
console.log(p.url().slice(-6),errs);
await p.waitForTimeout(6000);
console.log(await p.evaluate(()=>typeof Ch3+' '+typeof Ch4+' '+(window.Ch4&&Ch4.K.cell)+' '+(window.Ch4&&Ch4.K.fol.map(f=>f.who).join())),errs);
await p.screenshot({path:'cb.png'});
// finish: take silver and leave
const r2=await p.evaluate(()=>{const K=Ch4.K;K.silver=6;K.hold=true;const ex=K.objs.find(q=>q.id==='exit');Ch4.P.x=ex.x;Ch4.P.y=ex.y+10;Ch4.step(.02);ex.use();return 1});
await p.waitForTimeout(14000);
console.log(p.url().slice(-5),await p.evaluate(()=>typeof Ch3+' '+(document.querySelector('#endCard h2')&&document.querySelector('#endCard h2').textContent)),errs);
await p.screenshot({path:'cc.png'});await b.close()})()
