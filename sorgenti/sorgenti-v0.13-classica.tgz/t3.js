const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));p.on('console',m=>{if(m.type()==='error'&&!/googleapis|ERR_|Failed to load/.test(m.text()))console.log('CON',m.text())});
await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;localStorage.setItem(P.saveKey(),JSON.stringify(P.Ch2.convert(P.newState('Davide','m'))));P.startContinue('',null)});
await p.waitForTimeout(1200);
const clr=async()=>{for(let k=0;k<4;k++){await p.evaluate(async()=>{for(let i=0;i<120&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,30))}});await p.waitForTimeout(500)}};
const ev=(f,a)=>p.evaluate(f,a);
await clr();
// reachability from spawn
console.log('reach',await ev(()=>{const P=Pirati;P.tp(24.6,31.2);const o={};for(const id of['mast','lt_knife','lt_pg0','lt_pg1','lt_pg2','lt_pg3','lt_east','cave','nave','clue0','clue1','clue2','npc_ferro','npc_nives','npc_gnocco','npc_tito','lookout','plot_falo','plot_capanna','plot_banco','plot_zattera','c2stall']){const e=P.EID[id];o[id]=P.standOK(e)}return JSON.stringify(o)}));
// side quests
await ev(()=>{Pirati.Story.onDrink();Pirati.S.built.falo=1;Pirati.S.built.capanna=1;Pirati.Story.onGain()});await clr();
await ev(()=>{const C=Pirati.Ch2;for(const w of['nives','gnocco','tito'])C.st().met[w]=1;Pirati.S.q.c3={st:'done',gi:1,p:0};Pirati.S.q.c4={st:'done',gi:1,p:0};Pirati.S.q.c5={st:'done',gi:1,p:0};Pirati.S.q.c6={st:'done',gi:2,p:0};Pirati.S.q.c7={st:'done',gi:1,p:0};Pirati.S.q.c8={st:'active',gi:0,p:0};Object.assign(Pirati.S.res,{arrosto:9,pietra:9,rottami:9,pesce:5,bacche:5,coco:5,molluschi:5,legna:9,corda:9})});
await p.waitForTimeout(3500);await clr();
console.log('quests',await ev(()=>Object.keys(Pirati.S.q).join(',')));
// n3 knife, n8 pages, n5 clues via real loot pathway
await ev(()=>{const e=Pirati.EID.lt_knife;Pirati.tp(e.tx+.5,e.ty+1.5);Pirati.go('lt_knife')});
await p.waitForTimeout(4500);await clr();console.log('knife',await ev(()=>[Pirati.S.c2.knife,Pirati.EID.lt_knife.got]));
await ev(()=>Pirati.Ch2.talk(Pirati.EID.npc_tito));await clr();
for(let i=0;i<3;i++){await ev(i=>Pirati.Ch2.look(Pirati.EID['clue'+i]),i);await clr()}
console.log('clues',await ev(()=>Pirati.S.c2.clues));
await ev(()=>Pirati.Ch2.talk(Pirati.EID.npc_tito));await clr();
for(let i=0;i<4;i++){await ev(i=>Pirati.Ch2.onLoot(Pirati.EID['lt_pg'+i]),i);await clr()}
await ev(()=>Pirati.Ch2.talk(Pirati.EID.npc_gnocco));await clr();
await p.waitForTimeout(800);await clr();
console.log('after side',await ev(()=>Object.keys(Pirati.S.q).map(k=>k+':'+Pirati.S.q[k].st[0]+Pirati.S.q[k].gi).join(' ')+' | '+JSON.stringify(Pirati.S.c2.ch)));
// thieves
await ev(()=>{Pirati.S.tod=23;Pirati.tp(60,30);Pirati.fast(1)});
let found=false;
for(let i=0;i<60&&!found;i++){await p.waitForTimeout(1000);found=await ev(()=>Pirati.E.some(e=>e.type==='thief'&&!e.gone&&!e.flee))}
console.log('thief spawned',found);
if(found){await p.screenshot({path:'t3_thief.png'});
 await ev(()=>{const e=Pirati.E.find(e=>e.type==='thief'&&!e.gone);Pirati.Ch2.scare(e)});console.log('scared',await ev(()=>Pirati.S.c2.scared))}
// cook
await ev(()=>{Pirati.S.vit.h=20;Pirati.Ch2.openCook()});await p.waitForTimeout(300);await p.screenshot({path:'t3_cook.png'});
await ev(()=>document.querySelector('[data-g="brodo"]').click());console.log('hunger',await ev(()=>Pirati.S.vit.h));
// endings
for(const k of['ferro','ferro2','all','solo']){
 await ev(k=>{Pirati.S.flags.ch2end=0;const c=Pirati.Ch2.st();c.trust.tito=k==='ferro2'?8:2;c.ch.note=1;c.trust.ferro=k==='all'?8:2;Pirati.Ch2.ending(k==='ferro2'?'ferro':k)},k);await clr();await p.waitForTimeout(1200);
 console.log(k,await ev(()=>({e:Pirati.S.flags.ch2end,t:document.querySelector('#endCard h2').textContent})));
 await ev(()=>document.getElementById('eGo').click());
}
await b.close()})();
