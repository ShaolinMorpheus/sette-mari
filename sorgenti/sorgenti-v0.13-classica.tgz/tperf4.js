const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();
for(const f of ['/home/claude/sette-mari/www/index.html','/home/claude/out/index_final.html']){
const p=await (await b.newContext({viewport:{width:1280,height:600}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:0,t:0}))}catch(e){}});
await p.goto('file://'+f+'#w4');await p.waitForTimeout(2500);
const r=await p.evaluate(()=>new Promise(res=>{const ts=[];let l=performance.now(),n=0;function f(t){ts.push(t-l);l=t;if(++n<240)requestAnimationFrame(f);else{ts.shift();ts.sort((a,b)=>a-b);res([ts[ts.length>>1],ts[(ts.length*.93)|0],ts[ts.length-1]])}}requestAnimationFrame(f)}));
console.log(f.split('/').slice(-3).join('/'),r.map(x=>+x.toFixed(1)),er.length);await p.close()}
await b.close()})();
