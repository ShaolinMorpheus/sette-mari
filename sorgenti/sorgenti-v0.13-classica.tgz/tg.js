const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/galeone_giocabile.html');await p.waitForTimeout(3500);
console.log(await p.evaluate(()=>[location.hash,document.body.className]),er);await p.screenshot({path:'gg.png'});await b.close()})();
