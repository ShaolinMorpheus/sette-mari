#!/usr/bin/env python3
# v0.12m (D3): festa al campo ogni cinque giorni (fuoco grande, musica, pentolone comune; premio: fiducia)
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH25 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:100].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
NEW=open('/home/claude/work/new25.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")
# il tick del capitolo 2 controlla l'invito alla festa
rep("Ch2.npcAI(dt);\n  // riunione serale","Ch2.npcAI(dt);\n  try{FE.tick(dt)}catch(e){console.error('festa',e)}\n  // riunione serale")
# i fuggiaschi saltellano a tempo e, la sera della festa, vanno tutti al fuoco
rep("drawChar(g,e.x,e.y,o);\n  npcLabel(g,e,near);","drawChar(g,e.x,e.y-FE.hop(e,t),o);\n  npcLabel(g,e,near);")
rep("const s0=eve&&Math.random()<.85?","const s0=eve&&Math.random()<(FE.on()?1:.85)?")
# fuoco più grande e più scintille; luce calda più larga; note musicali
rep("  drawFlame(g,0,-5,t,1.3);","  drawFlame(g,0,-5,t,1.3*(FE.on()?1.4:1));")
rep("  for(let i=0;i<8;i++){const p=(t*.5+i*.137)%1,x=Math.sin(i*5.1+t*1.4)*15*p+(i-4)*2.2","  for(let i=0,NS=FE.on()?22:8;i<NS;i++){const p=(t*.5+i*.137)%1,x=Math.sin(i*5.1+t*1.4)*15*p+(i-4)*2.2")
rep("lights.push([FIX.smoke[0]*TS,FIX.smoke[1]*TS+20,180,.6,true]);","lights.push([FIX.smoke[0]*TS,FIX.smoke[1]*TS+20,180,.6,true]);\n    if(FE.on()){const p_=FE.pos();lights.push([p_[0],p_[1]+10,340,.95,true])}")
rep("drawExWarn(g,t);drawShelterZone(g,t);","drawExWarn(g,t);drawShelterZone(g,t);try{FE.draw(g,t)}catch(e){}")
# musica della festa
rep("  sea:{beat:.6,den:.7,","  festa:{festa:1,beat:.26,den:0,vol:.06,prog:[[62,66,69]],ext:[74],low:0},\n  sea:{beat:.6,den:.7,")
rep("  if(P.mode==='raft')return'sea';\n  if(isNight())return'night';","  if(P.mode==='raft')return'sea';\n  if(WORLD===2&&FE.music())return'festa';\n  if(isNight())return'night';")
rep("    const m=MUS[musicMood()],t=AU.nextT,b=AU.beat,ch=m.prog[((b/4)|0)%m.prog.length];","    const m=MUS[musicMood()],t=AU.nextT,b=AU.beat,ch=m.prog[((b/4)|0)%m.prog.length];\n    if(m.festa){festaTick(t,b);AU.nextT+=m.beat;AU.beat++;continue}")
# scheda del campo (Menu): prossima festa
rep("  h+='<p>La nave: albero '+ok(p.mast)","  h+='<p class=\"sm\">Festa al campo: ogni cinque giorni, la sera, al falò (musica e una zuppa con i raccolti dell\\'orto). Prossima: '+FE.nextTxt()+(c.fest&&c.fest.n?' · feste vissute: '+c.fest.n:'')+'.</p>';\n  h+='<p>La nave: albero '+ok(p.mast)")
# esporta per i test
rep("window.Pirati={photo:PHO,YD,","window.Pirati={photo:PHO,YD,FE,")
# registro delle novità
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Festa al campo: sull'isola dei Fuggiaschi, ogni cinque giorni (5, 10, 15…) alla sera, dalle 19, il falò si fa grande, parte la musica e tutti si radunano. Avvicinati al fuoco: Gnocco ti invita a mettere tre raccolti dell'orto nel pentolone per una zuppa per tutto il campo. Il premio è fiducia con tutti (doppia con la zuppa), un po' di energia e punti esperienza. In Menu › Il campo trovi quando è la prossima. Nuovi traguardi: «Ospite del campo» e «Anima della festa».",
''')
open(P,'w',encoding='utf8').write(src)
print('patch25 ok')
