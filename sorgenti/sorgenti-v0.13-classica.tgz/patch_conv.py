s=open('ch3_inject.js').read()
def rep(o,n,c=1):
    global s
    if s.count(o)!=c: print('FAIL',s.count(o),o[:80]); raise SystemExit(1)
    s=s.replace(o,n)
# alert rule
rep("if(s.type==='scorta'&&!s.alert&&C.plan&&!C.plan.div&&dp<1300*C.plan.detect)s.alert=true;","if((s.type==='scorta'||s.type==='galeone')&&s.conv&&!s.alert&&dp<850)alertConvoy();")
rep("function alertConvoy(){for(const s of C.ships)if(s.conv&&s.type==='scorta'&&!s.dead)s.alert=true;if(!C.notes.alert){C.notes.alert=1;toast('<b>Ferro:</b> «Le scorte ci hanno visti. Colpitele per prime!»')}}",
"function alertConvoy(){for(const s of C.ships)if(s.conv&&(s.type==='scorta'||s.type==='galeone')&&!s.dead)s.alert=true;if(!C.notes.alert){C.notes.alert=1;toast('<b>Tito:</b> «Ci hanno visti! Le scorte e il galeone aprono il fuoco!»')}}")
# hostile block
a=s.index("      if(s.hostile||s.alert){\n        const want=");b=s.index("      }else{\n        if(!s.wp||Math.hypot(s.wp[0]-s.x,s.wp[1]-s.y)<150)s.wp=randSea();\n        steerTo(s,s.wp[0],s.wp[1],dt,1);s.hd=avoid(s,s.hd);moveShip(s,dt,sp0.spd*.5")
s=s[:a]+'''      if(s.hostile||s.alert){
        const want=Math.atan2(p.y-s.y,p.x-s.x);
        if(!s.orb||(s.orbT-=dt)<=0){s.orb=Math.sign(angD(s.hd,want))||1;s.orbT=9}
        const D=420,k=dp>D+120?.55:dp<D-90?1.55:1,des=want+s.orb*(Math.PI/2)*k;
        const d=angD(s.hd,des);s.hd+=cl(d,-1,1)*.9*dt;s.hd=avoid(s,s.hd);
        moveShip(s,dt,sp0.spd*(dp>D+120?.85:.6)*windK(s.hd));
        for(const sd of[-1,1]){
          const sa=s.hd+(sd>0?Math.PI/2:-Math.PI/2),toP=Math.atan2(p.y-s.y,p.x-s.x);
          if(dp<640&&Math.abs(angD(sa,toP))<.75&&s.cd<=0&&(sd<0?s.cdL:s.cdR)<=0){fire(s,sd);s.cd=rr(2.2,3.8)}
        }
'''+s[b:]
# galeone fires
rep("      }\n    }\n  }\n  sepAll(dt);collide(dt);","""      }
    }else if(s.type==='galeone'&&s.alert){
      for(const sd of[-1,1]){
        const sa=s.hd+(sd>0?Math.PI/2:-Math.PI/2),toP=Math.atan2(p.y-s.y,p.x-s.x);
        if(dp<660&&Math.abs(angD(sa,toP))<.8&&s.cd<=0&&(sd<0?s.cdL:s.cdR)<=0){fire(s,sd);s.cd=rr(2.4,3.8)}
      }
    }
  }
  sepAll(dt);collide(dt);""")
# convoy formation
a=s.index("function convoy(dt){");b=s.index("function nearBoard(){")
s=s[:a]+'''function convoy(dt){
  const conv=C.ships.filter(s=>s.conv&&!s.dead&&!s.ally);
  const ld=conv.find(s=>s.type==='galeone');
  for(const s of conv){
    if(s.type==='scorta'&&s.alert)continue;
    if(s.disabled){s.v*=.97;continue}
    if(ld&&s!==ld&&s.slot){
      const c=Math.cos(ld.hd),n=Math.sin(ld.hd),tx=ld.x+c*s.slot[0]-n*s.slot[1],ty=ld.y+n*s.slot[0]+c*s.slot[1],d=Math.hypot(tx-s.x,ty-s.y);
      const want=d>140?Math.atan2(ty-s.y,tx-s.x):ld.hd,dd=angD(s.hd,want);
      s.hd+=cl(dd,-1,1)*Math.min(Math.abs(dd)*2.4,.9)*dt;s.hd=avoid(s,s.hd);
      moveShip(s,dt,cl(Math.max(40,ld.v)+d*.6,0,130));continue}
    const sp0=SPEC[s.type],tg=ROUTE[Math.min(s.prog,ROUTE.length-1)];
    if(Math.hypot(tg[0]-s.x,tg[1]-s.y)<160){s.prog++;if(s.prog>=ROUTE.length){s.dead=true;s.escaped=true;C.escapes++;continue}}
    const t2=ROUTE[Math.min(s.prog,ROUTE.length-1)];
    steerTo(s,t2[0],t2[1],dt,1);
    s.hd=avoid(s,s.hd);
    moveShip(s,dt,(s.hit?72:52));
  }
}
'''+s[b:]
# spawn convoy
a=s.index("function spawnConvoy(){");b=s.index("function findSea(x,y)")
s=s[:a]+'''function spawnConvoy(){
  C.convoy=true;
  const q=routePos(1500),c=Math.cos(q.hd),n=Math.sin(q.hd);
  for(const[t,slot]of[['galeone',[0,0]],['prigionieri',[-300,0]],['scorta',[330,0]],['scorta',[0,-250]],['scorta',[0,250]],['scorta',[-620,0]]]){
    const o={conv:true,prog:q.i,slot};if(t==='galeone'){o.hull=14;o.max=14}
    const s=mkShip(t,q.x+c*slot[0]-n*slot[1],q.y+n*slot[0]+c*slot[1],q.hd,o);C.ships.push(s)}
  sfx('quest');toast('Tito: «Capitano! Il galeone spagnolo con la scorta: arriva da est!»',6000);
}
'''+s[b:]
rep("const n=s.type==='galeone'?4:","const n=s.type==='galeone'?8:")
rep("const sil=C.silver>=8,","const sil=C.silver>=6,")
# enemies list
rep("[[44,58],[46,30],[78,56],[80,30],[108,62],[104,28],[64,80],[128,80]]","[[44,58],[46,30],[80,30],[108,62],[64,80]]")
rep("[[75,42],[100,58],[114,36],[84,70]]","[[60,42],[75,44],[100,58],[114,36],[84,70],[50,72],[100,16],[126,50],[70,20],[110,80]]")
# kills threshold 5
rep("(C.kills>=3||C.t>260)","(C.kills>=5||C.t>330)")
rep("Math.min(C.kills,3)+'/3)","Math.min(C.kills,5)+'/5)")
rep("Quando ne hai affondate tre arriva il convoglio da est. Affonda i galeoni e raccogli","Quando ne hai affondate cinque arriva da est il galeone spagnolo, con la scorta tutta attorno. Affondalo e raccogli")
rep("Sulla nave con la bandiera bianca ci sono Pip e Dodo: non affondarla!","Dietro di lui c'è la nave con la bandiera bianca: ci sono Pip e Dodo, non affondarla!")
# route clearance
rep("for(const R of[6,5,4,3,2]){","for(const R of[12,10,8,6,5,4,3,2]){")
open('ch3_inject.js','w').write(s)
m=open('mk_ch3.py').read()
m=m.replace("[34,31,3.5,3],[72,32,3,2.5]].map(SC3)","].map(SC3)").replace("[90,28,4,4],].map(SC3)","].map(SC3)")
open('mk_ch3.py','w').write(m)
