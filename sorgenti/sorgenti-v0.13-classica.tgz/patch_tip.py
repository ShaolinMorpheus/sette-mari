import json
p='base_index.html';s=open(p,encoding='utf8').read()
anchor="document.addEventListener('click',e=>{const c=e.target.closest&&e.target.closest('#res .chip');if(c&&S&&c.dataset.r)UI.toast(RNAME[c.dataset.r]+': '+(RWHERE[c.dataset.r]||''),3600)});\n"
assert s.count(anchor)==1
code=anchor+r'''/* toccando un simbolo (risorse, sete, fame, pulsanti, scambi…) compare un'etichetta con il suo nome */
const ICON_NAME={drop:'Sete: acqua',eat:'Fame: cibo',book:'Diario e missioni',gear:'Menu',sun:'Giorno',moon:'Notte',hammer:'Costruzione',flag:'Obiettivo',check:'Fatto',axe:'Ascia',pick:'Piccone',hand:'Interagisci',fish:'Pesca',eye:'Esamina',fire:'Fuoco',bed:'Riposo',raft:'Zattera',talk:'Parla',rain:'Pioggia',bolt:'Fulmine',torch:'Torcia',net:'Rete',up:'Muoviti'};
(function(){
  let tipEl=null,tipT=0;
  const htmlOf=n=>{while(n&&n.offsetWidth===undefined)n=n.parentElement;return n};
  function tipName(t){
    const sv=t.closest('svg.ic'),btn=t.closest('.sbtn,.rbtn,.vrow,.chip,.cost,.tk');
    let key=null;
    const use=(sv||btn&&btn.querySelector('svg.ic'));
    if(use){const u=use.querySelector('use');const h=u&&(u.getAttribute('href')||u.getAttribute('xlink:href'));if(h&&h.indexOf('#i-')===0)key=h.slice(3)}
    if(key){
      if(RNAME[key])return RNAME[key];
      if(btn&&btn.id==='torchb')return 'Torcia: accendi o spegni';
      if(btn&&btn.id==='fishb')return 'Pesce arrosto: mangia';
      if(btn&&(btn.id==='drink'))return 'Noce di cocco: bevi';
      if(btn&&btn.id==='eat')return 'Cibo: mangia';
      if(ICON_NAME[key])return ICON_NAME[key];
    }
    const cm=t.closest('canvas.ic');if(cm&&cm.title)return cm.title;
    return null;
  }
  document.addEventListener('click',e=>{
    if(!S||!e.target||!e.target.closest)return;
    const t=e.target;
    if(t.closest('#res .chip,.cost[data-k],#act,#joy,#joyGhost,.kk,#mini,#tutN,#tutS,#dlgChoices'))return;
    const name=tipName(t);if(!name)return;
    const anchor=htmlOf(t.closest('.sbtn,.rbtn,.vrow,.chip,.cost,.tk,svg.ic,canvas.ic'));if(!anchor)return;
    const inModal=anchor.closest('.modal'),host=inModal?htmlOf(anchor.offsetParent)||$('app'):$('app');
    let x=0,y=0,n=anchor;while(n&&n!==host){x+=n.offsetLeft;y+=n.offsetTop;n=n.offsetParent}
    if(n!==host){return}
    if(tipEl&&tipEl.parentNode)tipEl.remove();clearTimeout(tipT);
    const d=document.createElement('div');d.className='tipx';d.textContent=name;host.appendChild(d);
    const w=d.offsetWidth,hw=host.clientWidth||9999,cx=Math.max(w/2+4,Math.min(hw-w/2-4,x+anchor.offsetWidth/2));
    d.style.left=cx+'px';
    if(y<40){d.style.top=(y+anchor.offsetHeight+8)+'px';d.style.transform='translateX(-50%)'}else{d.style.top=(y-8)+'px'}
    tipEl=d;sfx('tap');tipT=setTimeout(()=>{d.classList.add('out');setTimeout(()=>{if(d.parentNode)d.remove()},400)},1900);
  },true);
})();
'''
s=s.replace(anchor,code)
css=".tipx{position:absolute;z-index:99999;transform:translate(-50%,-100%);background:#3a2412;color:#ffeccc;border:2px solid #d9a95e;border-radius:10px;padding:5px 11px;font:800 14px Nunito,Arial,sans-serif;white-space:nowrap;pointer-events:none;box-shadow:0 4px 12px rgba(0,0,0,.5);animation:tipin .15s ease-out}.tipx.out{opacity:0;transition:opacity .4s}@keyframes tipin{from{opacity:0;margin-top:5px}to{opacity:1;margin-top:0}}\n"
a2="body.incave #mini,body.inhut #mini{display:none}"
assert s.count(a2)==1
s=s.replace(a2,a2+"\n"+css)
rows=[[v,v if False else v] for v in []]
tr={"Sete: acqua":["Thirst: water","Durst: Wasser","Sed: agua","Soif : eau"],"Fame: cibo":["Hunger: food","Hunger: Essen","Hambre: comida","Faim : nourriture"],"Diario e missioni":["Journal and quests","Tagebuch und Aufgaben","Diario y misiones","Journal et quêtes"],"Menu":["Menu","Menü","Menú","Menu"],"Giorno":["Day","Tag","Día","Jour"],"Notte":["Night","Nacht","Noche","Nuit"],"Costruzione":["Building","Bauen","Construcción","Construction"],"Obiettivo":["Goal","Ziel","Objetivo","Objectif"],"Fatto":["Done","Erledigt","Hecho","Fait"],"Ascia":["Axe","Axt","Hacha","Hache"],"Piccone":["Pickaxe","Spitzhacke","Pico","Pioche"],"Interagisci":["Interact","Interagieren","Interactuar","Interagir"],"Pesca":["Fishing","Angeln","Pesca","Pêche"],"Esamina":["Examine","Untersuchen","Examinar","Examiner"],"Fuoco":["Fire","Feuer","Fuego","Feu"],"Riposo":["Rest","Ruhe","Descanso","Repos"],"Zattera":["Raft","Floß","Balsa","Radeau"],"Parla":["Talk","Sprechen","Hablar","Parler"],"Pioggia":["Rain","Regen","Lluvia","Pluie"],"Fulmine":["Lightning","Blitz","Rayo","Éclair"],"Torcia":["Torch","Fackel","Antorcha","Torche"],"Rete":["Net","Netz","Red","Filet"],"Muoviti":["Move","Bewegen","Moverse","Bouger"],"Torcia: accendi o spegni":["Torch: switch on or off","Fackel: an- oder ausschalten","Antorcha: encender o apagar","Torche : allumer ou éteindre"],"Pesce arrosto: mangia":["Roast fish: eat","Gebratener Fisch: essen","Pescado asado: comer","Poisson grillé : manger"],"Noce di cocco: bevi":["Coconut: drink","Kokosnuss: trinken","Coco: beber","Noix de coco : boire"],"Cibo: mangia":["Food: eat","Essen: essen","Comida: comer","Nourriture : manger"]}
i=s.index('var PACK=');arr,end=json.JSONDecoder().raw_decode(s[i+9:]);have={r[0] for r in arr}
for k,v in tr.items():
    if k not in have: arr.append([k]+v)
s=s[:i]+'var PACK='+json.dumps(arr,ensure_ascii=False)+s[i+9+end:]
open(p,'w',encoding='utf8').write(s)
print('ok')
