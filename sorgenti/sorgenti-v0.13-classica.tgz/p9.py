p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:70],s.count(a))
    s=s.replace(a,b)
# ---- minimap NPC marks
rep("    else if(e.type==='bottle'&&!e.got&&S.flags.sawBottle&&FOG[tIdx(e.tx,e.ty)]){g.fillStyle='#fff';g.fillRect(mxw(e.x)-1.5,myw(e.y)-1.5,3,3)}\n  }",
"""    else if(e.type==='bottle'&&!e.got&&S.flags.sawBottle&&FOG[tIdx(e.tx,e.ty)]){g.fillStyle='#fff';g.fillRect(mxw(e.x)-1.5,myw(e.y)-1.5,3,3)}
    else if(e.type==='npc'&&WORLD===2){const m=Ch2.npcMark(e);if(m){let x=mxw(e.x),y=myw(e.y);const dd=hyp(x-cxm,y-cym),lim=R-9;if(dd>lim){x=cxm+(x-cxm)/dd*lim;y=cym+(y-cym)/dd*lim}
      g.fillStyle=m==='!'?'#ffd23a':'#fff';g.strokeStyle='#2a1a0e';g.lineWidth=1.6;g.beginPath();g.arc(x,y,6,0,7);g.fill();g.stroke();g.fillStyle='#2a1a0e';g.font='800 10px Nunito,Arial,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(m,x,y+.5)}}
  }""")
# ---- big map: skip secret kinds, world2 labels + npc marks, parrot scout pointer
rep("else if(e.type==='loot'&&e.kind!==9&&!(e.id&&","else if(e.type==='loot'&&e.kind!==9&&e.kind!==10&&e.kind!==11&&!(e.id&&")
rep("  const rp=raftPos();if(rp&&seen(rp.x/TS,rp.y/TS)){dot(X(rp.x),Y(rp.y),4.5,'#c9955a');lab('Zattera',X(rp.x),Y(rp.y)-13,'#ffd9a0')}\n  if(S.mapMark)","""  const rp=raftPos();if(rp&&seen(rp.x/TS,rp.y/TS)){dot(X(rp.x),Y(rp.y),4.5,'#c9955a');lab('Zattera',X(rp.x),Y(rp.y)-13,'#ffd9a0')}
  if(WORLD===2){
    if(seen(CP.x/TS,CP.y/TS)){dot(X(CP.x),Y(CP.y),4.5,'#ffd9a0');lab('Campo',X(CP.x),Y(CP.y)-13,'#ffd9a0')}
    if(seen(CV2.ship[0],CV2.ship[1])){dot(X(CV2.ship[0]*TS),Y(CV2.ship[1]*TS),4.5,'#ffe27a');lab('La nave',X(CV2.ship[0]*TS),Y(CV2.ship[1]*TS)-13,'#ffe27a')}
    for(const e of E)if(e.type==='npc'){const m=Ch2.npcMark(e);if(m){const x=X(e.x),y=Y(e.y);g.fillStyle=m==='!'?'#ffd23a':'#fff';g.strokeStyle='#2a1a0e';g.lineWidth=2;g.beginPath();g.arc(x,y,8,0,7);g.fill();g.stroke();g.fillStyle='#2a1a0e';g.font='800 12px Nunito,Arial,sans-serif';g.fillText(m,x,y+.5)}}
  }
  // dove è andato Biscotto a guardare
  if(S.flags.parrot&&PQ.mark&&isInter(PQ.mark)&&RT-PQ.markT<240){
    const x=X(PQ.mark.x),y=Y(PQ.mark.y),t=performance.now()/1000,r=9+Math.sin(t*4)*2;
    g.strokeStyle='#ff5a3a';g.lineWidth=2.4;g.beginPath();g.arc(x,y,r,0,7);g.stroke();
    g.fillStyle='#e2402a';g.strokeStyle='#fff';g.lineWidth=1.6;g.beginPath();g.arc(x,y,5,0,7);g.fill();g.stroke();
    lab(pn('Biscotto')+' è stato qui',x,y-18,'#ffb89a');
  }
  if(S.mapMark)""")
rep("  SC.e=c.e;SC.t=0;PQ.scoutCd=170+Math.random()*90;","  SC.e=c.e;SC.t=0;PQ.scoutCd=170+Math.random()*90;PQ.mark=c.e;PQ.markT=RT;")
rep('"Tocca la mappa per mettere o togliere una bandierina rossa. Quadrati dorati: casse e forzieri da aprire; grigi: già aperti. Si vede solo ciò che hai esplorato."','"Tocca la mappa per mettere o togliere una bandierina rossa. Quadrati dorati: casse e forzieri da aprire; grigi: già aperti. Il cerchio rosso indica dove è andato il pappagallo a guardare. Si vede solo ciò che hai esplorato."')
# ---- prune exemption
rep("(ty==='loot'&&e.kind===8&&e.id!=='lt_east')){","(ty==='loot'&&e.kind===8&&!/^lt_(east|isle[A-D]|hill)/.test(e.id||''))){")
# ---- treasure chests
rep("   const ec=fr(83,29,4);","""   [[CV2.islets[0],'A'],[CV2.islets[1],'B'],[CV2.islets[2],'C'],[CV2.islets[3],'D']].forEach(([q,k])=>{const f=fr(q[0],q[1],4);ent({id:'lt_isle'+k,type:'loot',kind:8,x:(f[0]+.5)*TS,y:(f[1]+.8)*TS,tx:f[0],ty:f[1],got:false,label:'Cassa'})});
   {const f=fr(76.5,18.2,4);ent({id:'lt_hill',type:'loot',kind:8,x:(f[0]+.5)*TS,y:(f[1]+.8)*TS,tx:f[0],ty:f[1],got:false,label:'Cassa'})}
   const ec=fr(83,29,4);""")
rep("Ch2.onLoot=function(e){\n  const c=C();","""Ch2.TRE={lt_isleA:[{legna:6,corda:4},"Una cassa mezza sepolta sulla sabbia dell'isoletta. Legna asciutta e corda buona: i vecchi fuggiaschi sapevano nascondere le cose."],lt_isleB:[{tela:3,rottami:4},"Sotto un cumulo di alghe secche: tela per vele e rottami ben tenuti."],lt_isleC:[{pietra:6,corda:3},"Una cassa da cava, pesante: pietre squadrate e un rotolo di corda."],lt_isleD:[{arrosto:3,coco:4},"Cibo conservato in una cassa sigillata con la cera. Ancora buono!"],lt_hill:[{tela:2,rottami:3,pietra:3},"In cima alla collina, sotto una roccia piatta: tela, rottami e pietre. Qualcuno ci teneva a tornare a prenderla."]};
Ch2.onLoot=function(e){
  const c=C();
  if(e.id&&Ch2.TRE[e.id]){
    const [cst,tx]=Ch2.TRE[e.id];c.tre=(c.tre||0)+1;
    for(const k in cst)gain(k,cst[k],e.x,e.y-20,true);
    UI.dlg([D('hero',tx),D('hero',"Tesori ritrovati: "+c.tre+"/5.")],()=>{UI.syncObj();checkAll()});return true}""")
# n9 quest
rep("n8:{kind:'side',title:\"Il diario di J.\"","""n9:{kind:'side',title:"I tesori dei Fuggiaschi",blurb:"Si dice che i vecchi abitanti abbiano nascosto casse sulle isolette e in cima alla collina.",avail:()=>qDone('c5'),
  goals:[{k:'flag',done:()=>(C().tre||0)>=5,txt:()=>"Trova le casse nascoste ("+Math.min(5,C().tre||0)+"/5): quattro isolette e la collina a nord-est",hint:"Le isolette si raggiungono con la zattera (ai quattro angoli della mappa). Biscotto può indicarti dove guardare: apri la mappa grande."}],
  onDone(){UI.dlg([D('hero',"Cinque casse. I vecchi fuggiaschi avevano più fiducia nel mare che nelle persone."),D('biscotto',"Cra! Ricchi! Quasi!")],()=>{gain('tela',3,P.x,P.y);gain('corda',4,P.x,P.y-20);S.phats=S.phats||{};const m=PHATS.find(h=>!S.phats[h.id]);if(m){S.phats[m.id]=1;UI.banner('Cappellino per il pappagallo',m.n)}})}},
n8:{kind:'side',title:"Il diario di J.\"""".replace('J."','J."') if False else "n8:{kind:'side',title:\"Il diario di J.\"")
open(p,'w',encoding='utf8').write(s)
