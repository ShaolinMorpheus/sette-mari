const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}
console.log(await p.evaluate(()=>Pirati.E.filter(e=>Math.hypot(e.x-57.4*44,e.y-30.2*44)<300&&e.type!=='tree'&&e.type!=='pine').map(e=>[e.id,e.type,e.spr||'',Math.round(e.x/44*10)/10,Math.round(e.y/44*10)/10].join(':')).join('\n')));
await p.evaluate(()=>{Pirati.S.tod=19.6;Pirati.P.x=57.4*44;Pirati.P.y=32*44;Pirati.cam.x=Pirati.P.x;Pirati.cam.y=Pirati.P.y-40});await p.waitForTimeout(1500);await p.screenshot({path:'camp0.png'});
console.log(er);await b.close()})();
