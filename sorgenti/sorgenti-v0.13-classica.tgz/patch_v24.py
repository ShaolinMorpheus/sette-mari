#!/usr/bin/env python3
# v0.12l (D2): equipaggio visibile sulla Sirena (finale del Capitolo 2, schermata Nave, mare)
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH24 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:100].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
NEW=open('/home/claude/work/new24.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")
# finale del Capitolo 2: chi è a bordo si vede sul ponte della nave
rep("g.save();g.translate(sx,sy);g.rotate(Math.sin(t*1.05)*.05);drawSp(g,spr,0,0,sc);g.restore();",
    "g.save();g.translate(sx,sy);g.rotate(Math.sin(t*1.05)*.05);drawSp(g,spr,0,0,sc);try{YD.crewCine(g,k,CINE.step,sc,t)}catch(e){}g.restore();")
# nel caso lo stato di gioco non sia disponibile in mare, ricordiamo l'equipaggio a parte
rep("c.cineSeen=1;c.endings[k]=1;S.flags.ch2end=k;sfx('quest');","c.cineSeen=1;c.endings[k]=1;S.flags.ch2end=k;try{localStorage.setItem('sm_crew',k)}catch(_){}sfx('quest');")
# esporta il modulo nave per i test
rep("window.Pirati={photo:PHO,","window.Pirati={photo:PHO,YD,")
# registro delle novità
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "L'equipaggio si vede sulla Sirena: chi hai portato con te al finale del Capitolo 2 (Ferro al timone, Nives alle vele, Tito sulle sartie, Gnocco col pentolone) compare sul ponte nel filmato di partenza, nella schermata «Aspetto della nave» e, in miniatura, durante le battaglie in mare. Il capitano ha il suo cappello e il suo abito.",
''')
open(P,'w',encoding='utf8').write(src)
print('patch24 ok')
