const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();
await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(3000);
const r=await p.evaluate(()=>{const o=[];for(let y=0;y<60;y++){let s='';for(let x=0;x<99;x++){const t=Pirati.tileInfo(x,y);s+=t.sea?'~':t.walk?'#':'.'}o.push(s)}return o.join('\n')});
console.log(r);await b.close()})();
