const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1600,height:900},deviceScaleFactor:1})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.removeItem('sm_c34')}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2500);
await p.evaluate(()=>{const K=Ch4.K;K.fol.concat(K.stay).forEach(f=>{f.x=-999;f.y=-999});Ch4.tp(20,9);Ch4.cam.uz=.6;K.routesT=40;K.alarm=true;K.say=[];K.sayT=0;document.getElementById('c4say').style.display='none'});
await p.waitForTimeout(900);await p.screenshot({path:'alarm.png'});console.log(er);await b.close()})();
