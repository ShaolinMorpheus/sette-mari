/* ====== NOVITÀ v0.11.2 (D5): la grotta buia sul lato roccioso della prima isola ======
   Un'apertura nella roccia accanto alla cava. Dentro è buio pesto anche di giorno: serve la torcia, che nella grotta si può accendere a ogni ora.
   Tre sale, una pozza, cristalli, pipistrelli e, in fondo, una cassa con l'Elmetto da minatore per il guardaroba.
   Riusa il motore della grotta della Baia (mappa interna, luci, pipistrelli): cambiano solo la pianta, l'ingresso e il premio. */
const CV1P=[46.8,19.4];                 // ingresso della grotta (tile): sul lato sud del rilievo roccioso, vicino alla cava
function cave1Grid(){
  const G=[];for(let y=0;y<CV_H;y++)G.push(new Array(CV_W).fill(0));
  const ell=(cx,cy,rx,ry,v)=>{for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){const dx=(x+.5-cx)/rx,dy=(y+.5-cy)/ry;if(dx*dx+dy*dy<=1)G[y][x]=v==null?1:v}};
  const cor=(x0,y0,x1,y1,w)=>{const n=Math.ceil(Math.hypot(x1-x0,y1-y0)*3);for(let i=0;i<=n;i++){const t=i/n;ell(x0+(x1-x0)*t,y0+(y1-y0)*t,w,w,1)}};
  cor(4.3,10.8,4.3,8.8,1.5);ell(5,7.9,3.8,2);                  // ingresso e prima sala
  cor(7.6,7.2,10.4,6,1.25);ell(12.8,5.2,4.4,2.5);              // corridoio e sala di mezzo
  cor(16.4,4.4,18.4,3.3,1.2);ell(20,3.2,3.4,2.1);              // corridoio e sala del tesoro
  cor(13.5,7.4,15.6,9,1.1);ell(17.6,9,2.7,1.35);               // ramo senza uscita, con i cristalli
  cor(2.8,7,2.2,4.6,1.1);ell(2.6,3.6,2,1.4);                   // nicchia a nord-ovest
  ell(13.1,5.7,1.5,.8,2);                                      // pozza nella sala di mezzo
  for(let x=0;x<CV_W;x++)G[0][x]=0;for(let y=0;y<CV_H;y++){G[y][0]=0;G[y][CV_W-1]=0}
  return G;
}
function cave1Build(){
  const G=cave1Grid();CVX={G,cr:[],st:[],bats:[],drops:[],rings:[],fade:0,hint:0,dripT:3,batSay:0};
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){const i=tIdx(CV_X0+x,CV_Y0+y);walkT[i]=G[y][x]===1?1:0}
  const r=mulberry(777);
  const wallN=(x,y)=>G[y-1]&&G[y-1][x]===0;
  const roost=[];
  for(let y=1;y<CV_H;y++)for(let x=1;x<CV_W-1;x++){
    if(G[y][x]!==1||!wallN(x,y))continue;
    roost.push([x,y]);
    if(r()<.26)CVX.st.push({x:(CV_X0+x+.2+r()*.6)*TS,y:(CV_Y0+y+.35+r()*.2)*TS,s:.7+r()*.7,k:r()<.3?1:0});
  }
  [[13.6,3.4],[10.3,6.9],[16.9,8.8],[18.9,9.5],[5.9,6.1],[2.4,3.3],[22.6,4.7],[19.4,1.9],[8.6,2.5]].forEach(p=>{const x=Math.floor(p[0]),y=Math.floor(p[1]);if(G[y]&&G[y][x]===1)CVX.cr.push({x:(CV_X0+p[0])*TS,y:(CV_Y0+p[1])*TS,h:r()})});
  const rr=roost.slice();for(let i=rr.length-1;i>0;i--){const j=(r()*(i+1))|0;[rr[i],rr[j]]=[rr[j],rr[i]]}
  const used=[];for(const q of rr){if(CVX.bats.length>=4)break;if(used.some(u=>Math.hypot(u[0]-q[0],u[1]-q[1])<5)||Math.hypot(q[0]-4.3,q[1]-9.5)<5.5)continue;used.push(q);
    const hx=(CV_X0+q[0]+.5)*TS,hy=(CV_Y0+q[1]+.1)*TS;CVX.bats.push({hx,hy,x:hx,y:hy,st:0,t:0,ph:r()*6,cd:0,wx:hx,wy:hy,dur:0,vx:0,vy:0})}
  ent({id:'cavex',type:'deco',spr:'cavex',x:(CV_X0+4.3)*TS,y:(CV_Y0+10.3)*TS,inter:'look',hitw:170,hith:80,label:'Uscita'});
  [[7.7,8.9],[12.2,3.5],[22.3,4.7]].forEach((q,i)=>ent({id:'cvbr'+i,type:'deco',spr:'cvbraz',bi:i,x:(CV_X0+q[0])*TS,y:(CV_Y0+q[1])*TS,inter:'look',hitw:90,hith:90,label:'Braciere'}));
  ent({id:'cvskel',type:'deco',spr:'cvskel',x:(CV_X0+3.6)*TS,y:(CV_Y0+4.1)*TS,inter:'look',hitw:100,hith:80,label:'Scheletro'});
  ent({id:'cvsm',type:'deco',spr:'cvsm',x:(CV_X0+2.0)*TS,y:(CV_Y0+4.0)*TS,inter:'look',hitw:80,hith:70,label:'Cassetta'});
  ent({id:'cvchest',type:'deco',spr:'cvchest',x:(CV_X0+20.3)*TS,y:(CV_Y0+3.4)*TS,inter:'look',hitw:120,hith:80,label:'Cassa'});
}
function cave1Place(deco){
  const f=nearestFree(Math.floor(CV1P[0]),Math.floor(CV1P[1]),4)||[Math.floor(CV1P[0]),Math.floor(CV1P[1])];
  CV1P[0]=f[0];CV1P[1]=f[1];
  deco('cave1','cave1',f[0]+.5,f[1]+.95,[f[0]-1,f[1],3,1],{hitw:150,hith:100,inter:'look',label:'Grotta buia'});
  cave1Build();
}
/* ---- disegno ---- */
function drawCave1(g,e,t){
  g.save();g.translate(e.x,e.y);shadow(g,0,4,64,12,.32);
  // roccia attorno all'apertura
  g.fillStyle='#716a5f';g.beginPath();g.moveTo(-62,3);g.lineTo(-60,-44);g.quadraticCurveTo(-56,-92,0,-96);g.quadraticCurveTo(56,-92,60,-44);g.lineTo(62,3);g.closePath();g.fill();g.strokeStyle='#2c2823';g.lineWidth=2.4;g.stroke();
  g.fillStyle='#8c8478';for(const[a,b,rx,ry]of[[-46,-30,17,11],[46,-34,15,10],[-30,-76,16,10],[32,-74,15,9],[0,-90,14,7],[-52,-62,11,8],[52,-62,11,8]]){g.beginPath();g.ellipse(a,b,rx,ry,0,0,7);g.fill();g.strokeStyle='rgba(40,34,28,.55)';g.lineWidth=1.3;g.stroke()}
  g.fillStyle='rgba(255,255,255,.08)';g.beginPath();g.ellipse(-20,-84,30,6,-.1,0,7);g.fill();
  // il buio dentro
  const q=g.createRadialGradient(0,-30,4,0,-30,46);q.addColorStop(0,'#020202');q.addColorStop(.7,'#0c0a09');q.addColorStop(1,'#1c1814');
  g.fillStyle=q;g.beginPath();g.moveTo(-31,3);g.lineTo(-31,-44);g.quadraticCurveTo(-29,-74,0,-76);g.quadraticCurveTo(29,-74,31,-44);g.lineTo(31,3);g.closePath();g.fill();
  // travi di legno: due montanti e un architrave, come nelle vecchie gallerie della cava
  g.fillStyle='#6a4524';g.strokeStyle='#2a180a';g.lineWidth=2;
  g.fillRect(-39,-66,10,70);g.strokeRect(-39,-66,10,70);g.fillRect(29,-66,10,70);g.strokeRect(29,-66,10,70);
  g.fillRect(-44,-76,88,11);g.strokeRect(-44,-76,88,11);
  g.strokeStyle='rgba(20,10,4,.45)';g.lineWidth=1;for(const x of[-34,34]){g.beginPath();g.moveTo(x-2,-50);g.lineTo(x+2,-38);g.moveTo(x+2,-24);g.lineTo(x-2,-12);g.stroke()}
  // lanterna spenta, appesa all'architrave
  g.strokeStyle='#2a180a';g.lineWidth=1.6;g.beginPath();g.moveTo(22,-65);g.lineTo(22,-58);g.stroke();
  g.fillStyle='#3a3a40';g.fillRect(17,-58,10,13);g.strokeRect(17,-58,10,13);g.fillStyle='rgba(200,190,150,.28)';g.fillRect(19,-56,6,9);
  // ciuffi d'erba e muschio ai piedi
  g.fillStyle='rgba(100,150,70,.75)';for(let i=0;i<7;i++){g.beginPath();g.ellipse(-60+i*20,-3,9,4,0,0,7);g.fill()}
  // un soffio d'aria fredda esce dal buio
  for(let k=0;k<3;k++){const u=(t*.22+k/3)%1;g.strokeStyle='rgba(210,225,235,'+(.18*(1-u))+')';g.lineWidth=3;g.beginPath();g.moveTo(-14,-10-u*34);g.quadraticCurveTo(0,-16-u*34,14,-10-u*34);g.stroke()}
  g.restore();
}
function drawCvChest(g,e,t){
  const open=!!(S&&S.flags&&S.flags.cavehat);
  g.save();g.translate(e.x,e.y);shadow(g,0,5,34,10,.45);
  g.fillStyle='#6a4524';g.strokeStyle='#241408';g.lineWidth=2.2;g.fillRect(-25,-21,50,25);g.strokeRect(-25,-21,50,25);
  g.fillStyle='#caa23a';g.fillRect(-25,-11,50,4);g.fillRect(-19,-21,5,25);g.fillRect(14,-21,5,25);
  if(!open){
    g.fillStyle='#7d5229';g.beginPath();g.moveTo(-25,-21);g.quadraticCurveTo(0,-49,25,-21);g.closePath();g.fill();g.stroke();
    g.fillStyle='#caa23a';g.fillRect(-19,-34,5,13);g.fillRect(14,-34,5,13);g.fillRect(-4,-27,8,10);g.strokeRect(-4,-27,8,10);
    g.fillStyle='#2a180a';g.beginPath();g.arc(0,-22,1.6,0,7);g.fill();
    twinkle(g,20,-44,t,8,e.x,'#ffe27a')
  }else{
    g.fillStyle='#1a0e06';g.fillRect(-23,-21,46,6);
    g.fillStyle='#5e3c1c';g.beginPath();g.moveTo(-25,-21);g.lineTo(-22,-46);g.quadraticCurveTo(0,-54,22,-46);g.lineTo(25,-21);g.closePath();g.fill();g.stroke();
    g.fillStyle='#caa23a';g.fillRect(-17,-44,5,22);g.fillRect(12,-44,5,22)
  }
  g.restore();
}
const cvLit=()=>(S&&S.flags&&S.flags.cvB)|0;
const cvAll=()=>cvLit()===7;
function drawCvBraz(g,e,t){
  const on=!!(cvLit()&(1<<e.bi));
  g.save();g.translate(e.x,e.y);shadow(g,0,4,26,8,.4);
  g.fillStyle='#3a3026';g.strokeStyle='#14100a';g.lineWidth=2;
  g.beginPath();g.moveTo(-5,4);g.lineTo(-11,-12);g.lineTo(11,-12);g.lineTo(5,4);g.closePath();g.fill();g.stroke();
  g.fillStyle='#5a4a38';g.fillRect(-14,-17,28,6);g.strokeRect(-14,-17,28,6);
  if(on){
    const f=1+.12*Math.sin(t*11+e.bi)+.07*Math.sin(t*17);
    for(const[c,w,h]of[['#e0501a',9,26],['#ff9a2a',6,19],['#ffe27a',3.5,11]]){g.fillStyle=c;g.beginPath();g.moveTo(-w,-17);g.quadraticCurveTo(-w*.8,-17-h*.5*f,Math.sin(t*7+e.bi)*2,-17-h*f);g.quadraticCurveTo(w*.8,-17-h*.5*f,w,-17);g.closePath();g.fill()}
  }else{g.fillStyle='#1c1612';g.beginPath();g.ellipse(0,-17,10,3,0,0,7);g.fill();g.fillStyle='#4a3c30';g.fillRect(-5,-19,3,2);g.fillRect(2,-19,3,2)}
  g.restore();
}
function drawCvSm(g,e,t){
  const open=!!(S.flags&&S.flags.cave1Small);
  g.save();g.translate(e.x,e.y);shadow(g,0,4,22,7,.4);
  g.fillStyle='#5a3a1c';g.strokeStyle='#201006';g.lineWidth=2;g.fillRect(-14,-12,28,15);g.strokeRect(-14,-12,28,15);
  g.fillStyle='#b8902e';g.fillRect(-14,-6,28,3);
  if(!open){g.fillStyle='#6b4524';g.beginPath();g.moveTo(-14,-12);g.quadraticCurveTo(0,-28,14,-12);g.closePath();g.fill();g.stroke()}
  else{g.fillStyle='#120a04';g.fillRect(-12,-12,24,4);g.fillStyle='#5e3c1c';g.beginPath();g.moveTo(-14,-12);g.lineTo(-12,-27);g.lineTo(12,-27);g.lineTo(14,-12);g.closePath();g.fill();g.stroke()}
  g.restore();
}
function cave1Sp(g,e,t){
  if(e.spr==='cvbraz'){drawCvBraz(g,e,t);return true}
  if(e.spr==='cvskel'){drawCvSkel(g,e,t);return true}
  if(e.spr==='cvsm'){drawCvSm(g,e,t);return true}
  return false;
}
function cave1Lights(L,t,vx0,vy0,vx1,vy1){
  if(WORLD!==1)return;
  for(const e of E){if(e.spr!=='cvbraz'||!(cvLit()&(1<<e.bi)))continue;
    if(e.x>vx0-300&&e.x<vx1+300&&e.y>vy0-300&&e.y<vy1+300)L.push([e.x,e.y-26,190,.95,true,[255,150,60]])}
}
function cave1Braz(e){
  const m=1<<e.bi;
  if(cvLit()&m){UI.toast('Il braciere è già acceso.');return}
  if(!(S.up&&S.up.torch&&S.torchOn)){
    if(S.up&&S.up.torch)UI.dlg([D('hero',"Un braciere di ferro con carbone vecchio. Con la torcia accesa potrei dargli fuoco.")]);
    else UI.dlg([D('hero',"Un braciere pieno di carbone. Mi serve una torcia per accenderlo.")]);
    return;
  }
  S.flags.cvB=cvLit()|m;sfx('torch');sparkBurst&&sparkBurst(e.x,e.y-30,10);
  const n=[1,2,4].filter(b=>S.flags.cvB&b).length;
  if(S.flags.cvB===7){sfx('quest');UI.toast('Un clac profondo nella roccia: il lucchetto della cassa si è sbloccato!',5200)}
  else UI.toast('Braciere acceso ('+n+'/3).',2600);
  saveGame(true);
}
function cave1Skel(){
  UI.dlg([D('hero',"Un vecchio contrabbandiere, seduto contro la parete da chissà quanto tempo. Stringe un biglietto ingiallito."),
    D('hero',"«Il bottino sta dove il buio è più fitto. Tre fuochi lo sveglieranno, e solo allora la cassa si aprirà. Chi arriva dopo di me, abbia cura del mio cappello.»")]);
}
function cave1Small(){
  if(S.flags.cave1Small){UI.dlg([D('hero',"La cassetta è vuota. Grazie, vecchio amico.")]);return}
  S.flags.cave1Small=1;sfx('ok');
  UI.dlg([D('hero',"Nella cassetta del vecchio contrabbandiere: un po' di rottami buoni e qualche attrezzo ancora lucido.")],()=>{try{gain('rottami',5,P.x,P.y-40);addXp(15);float(P.x,P.y-80,'+15 XP','#ffe27a')}catch(e){}saveGame(true)});
}
/* ---- interazione, avvisi ---- */
function cave1Chest(){
  if(S.flags.cavehat){UI.dlg([D('hero',"La cassa è vuota: il tricorno ormai è mio. Che fiuto, per una grotta!")]);return}
  if(!cvAll()){const n=[1,2,4].filter(b=>cvLit()&b).length;UI.dlg([D('hero',"La cassa è chiusa con un grosso lucchetto, e da dentro la roccia si sente un meccanismo fermo. Forse i bracieri della grotta c'entrano ("+n+"/3 accesi).")]);return}
  S.flags.cavehat=1;sfx('quest');
  const L=[D('hero',"Il lucchetto scatta e il coperchio si alza. Dentro, su un panno di velluto rosso: un tricorno nero col bordo dorato, il cappello di un vero contrabbandiere!")];
  if(S.flags.parrot)L.push(D('biscotto',"Cra! Un tricorno! Adesso sì che sembri un pirata come si deve."));
  UI.dlg(L,()=>{try{addXp(30);float(P.x,P.y-80,'+30 XP','#ffe27a')}catch(e){}try{wardCheck()}catch(e){}saveGame(true)});
}
function cave1Try(){
  if(S.up&&S.up.torch){caveEnter();return}
  if(S.flags.parrot)say(PAR,"Cra! Là dentro è buio pesto. Prima ci vuole una torcia: si costruisce al Banco da lavoro!",5);
  else UI.dlg([D('hero',"Un buco nella roccia, nero come la pece. Senza una torcia non vedrei nemmeno i miei piedi."),D('hero',"Magari al Banco da lavoro posso costruirne una.")]);
}
function cave1Look(e){
  if(e.id==='cave1'){cave1Try();return true}
  if(e.id==='cavex'){caveExit();return true}
  if(e.id==='cvchest'){cave1Chest();return true}
  if(e.id&&e.id.indexOf('cvbr')===0){cave1Braz(e);return true}
  if(e.id==='cvskel'){cave1Skel();return true}
  if(e.id==='cvsm'){cave1Small();return true}
  return false
}
let c1T=0;
function cave1Tick(dt){
  if(WORLD!==1||!S||!S.live)return;
  c1T-=dt;if(c1T>0)return;c1T=2;
  if(S.up&&S.up.torch&&!S.flags.cave1Hint&&S.flags.parrot&&!inCave()&&!UI.dlgOpen()&&!P.act&&P.mode!=='raft'){
    S.flags.cave1Hint=1;say(PAR,"Cra! Ora che hai la torcia: vicino alla cava c'è una grotta buia. Chissà cosa nasconde!",6)
  }
}
/* ---- il premio: Elmetto da minatore (guardaroba) ---- */
NVH.miner=(g,hy,hr,hc,back,sp_,dk)=>{
  const c1=hc||'#e0b020';
  g.fillStyle=c1;g.beginPath();g.arc(0,hy-3,hr+1,Math.PI,Math.PI*2);g.closePath();g.fill();g.strokeStyle='rgba(60,36,6,.78)';g.lineWidth=1.3;g.stroke();
  g.fillStyle=dk(c1,.82);g.beginPath();g.ellipse(0,hy-3,hr+3.4,2.1,0,0,Math.PI);g.fill();g.stroke();
  g.strokeStyle=dk(c1,1.25);g.lineWidth=1.7;g.lineCap='round';g.beginPath();g.moveTo(0,hy-hr-3.4);g.lineTo(0,hy-4.6);g.stroke();
  if(!back){
    g.fillStyle='rgba(255,240,170,.38)';g.beginPath();g.arc(0,hy-8.6,5.6,0,7);g.fill();
    g.fillStyle='#4a4f58';g.beginPath();g.arc(0,hy-8.6,3,0,7);g.fill();g.strokeStyle='#22262c';g.lineWidth=.9;g.stroke();
    g.fillStyle='#fff6c0';g.beginPath();g.arc(0,hy-8.6,1.7,0,7);g.fill();
  }
};
NV3.SCH.miner=(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.arc(x,y-3.2,6.9,Math.PI,0);g.closePath();g.fill();g.stroke();g.beginPath();g.ellipse(x,y-3,9.6,1.9,0,0,Math.PI);g.fill();g.stroke();g.fillStyle='#fff6c0';g.beginPath();g.arc(x,y-6.6,1.7,0,7);g.fill();g.stroke()};
{
  const it={id:'h_minat',k:'hat',n:'Tricorno del contrabbandiere',hint:'Nella grotta buia vicino alla cava: accendi i tre bracieri (serve la torcia) e apri la cassa.',own:()=>!!(S&&S.flags&&S.flags.cavehat),spec:{hat:'tricorn',hatc:'#1e222c',trim:'#d4a83a'}};
  if(!WEAR.some(x=>x.id===it.id)){WEAR.push(it);WRH[it.id]=it.spec}
  NV3.AC.push({id:'grotta1',n:'Speleologo',d:'Trova la cassa nella grotta buia vicino alla cava.',ok:()=>!!(S&&S.flags&&S.flags.cavehat)});
}
NVDX.cave1=drawCave1;NVDX.cvchest=NVDX.cvbraz=NVDX.cvskel=NVDX.cvsm=()=>{};   // la cassa si vede solo dentro la grotta (la disegna renderCave)
