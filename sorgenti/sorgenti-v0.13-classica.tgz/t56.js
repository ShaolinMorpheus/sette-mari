const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1000,height:460},locale:'it-IT'})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(3500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(500,200);await p.waitForTimeout(400)}
await p.waitForTimeout(4000);await p.screenshot({path:'isl1.png'});
await p.waitForTimeout(6000);await p.screenshot({path:'isl2.png'});
// timing frame
const fps=await p.evaluate(()=>new Promise(r=>{let n=0,t0=performance.now();function f(){n++;if(performance.now()-t0>2000)r(n/2);else requestAnimationFrame(f)}f()}));
console.log('fps',fps,er);await b.close()})()
