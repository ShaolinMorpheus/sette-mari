const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1000,height:480}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(6000);
await p.evaluate(()=>{const C=Ch3.C;C.tut=null;document.querySelectorAll('.modal,#c3tut').forEach(e=>{});const pl=C.p;
 C.ships=C.ships.filter(s=>false);const g=Ch3.mkShip('galeone',pl.x+500,pl.y-60,Math.PI*.9,{});g.disabled=true;g.alert=true;C.ships.push(g);
 const pt=Ch3.mkShip('pattuglia',pl.x+250,pl.y+220,Math.PI,{});pt.v=140;C.ships.push(pt);pl.v=120;for(let i=0;i<90;i++){pl.v=120;Ch3.step(1/30)}});
await p.waitForTimeout(600);await p.screenshot({path:'sea.png'});console.log(er);await b.close()})()
