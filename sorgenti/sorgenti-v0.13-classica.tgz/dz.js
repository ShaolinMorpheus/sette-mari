function dzrr(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}
function dz_plank(g,x,y,w,h,c,line){g.fillStyle=c;g.fillRect(x,y,w,h);g.strokeStyle=line;g.lineWidth=1.6;g.strokeRect(x,y,w,h)}
function dz_coins(g,cx,cy,rx,ry,glow){
  if(glow){const gr=g.createRadialGradient(cx,cy-10,4,cx,cy-10,rx*1.3);gr.addColorStop(0,'rgba(255,230,120,.8)');gr.addColorStop(1,'rgba(255,230,120,0)');g.fillStyle=gr;g.fillRect(cx-rx*1.4,cy-rx*1.4,rx*2.8,rx*2.2)}
  g.fillStyle='#d9a21f';g.beginPath();g.ellipse(cx,cy,rx,ry,0,0,7);g.fill();
  for(let i=0;i<14;i++){const a=i*2.4,r=(i%5)/5;const x=cx+Math.cos(a)*rx*.8*r,y=cy-4+Math.sin(a)*ry*.6*r-(i%3)*2;g.fillStyle=i%2?'#ffd75a':'#f2b92c';g.beginPath();g.ellipse(x,y,7,4.2,0,0,7);g.fill();g.strokeStyle='#8a5a0e';g.lineWidth=1;g.stroke()}
  g.fillStyle='#e04a3a';g.beginPath();g.arc(cx+rx*.3,cy-12,5,0,7);g.fill();g.strokeStyle='#6a1a12';g.stroke();
}
function dz_slat(g,x,y,w,h,c){g.fillStyle=c;g.fillRect(x,y,w,h);g.strokeStyle='#2a1508';g.lineWidth=1.6;g.strokeRect(x,y,w,h)}
function dz_chestA(g,open,pl){pl=pl||{body:'#8a5428',lid:'#a06232',band:'#4d4d55',bs:'#202026'};
  const x=36,y=92,w=148,h=56;
  if(open){
    // retro del coperchio alzato
    g.save();g.fillStyle='#4a2a14';dzrr(g,x+6,22,w-12,52,10);g.fill();g.strokeStyle='#2a1508';g.lineWidth=2.2;g.stroke();
    g.fillStyle='#6a3d1e';dzrr(g,x+14,30,w-28,36,6);g.fill();
    g.strokeStyle='#3a3a40';g.lineWidth=5;g.beginPath();g.moveTo(x+36,22);g.lineTo(x+36,74);g.moveTo(x+w-36,22);g.lineTo(x+w-36,74);g.stroke();g.restore();
  }
  dz_plank(g,x,y,w,h,pl.body,'#2a1508');
  for(let i=1;i<4;i++){g.strokeStyle='rgba(42,21,8,.45)';g.beginPath();g.moveTo(x,y+i*h/4);g.lineTo(x+w,y+i*h/4);g.stroke()}
  g.fillStyle=pl.band;g.strokeStyle=pl.bs;g.lineWidth=1.6;
  for(const bx of[x+14,x+w-30]){g.fillRect(bx,y,16,h);g.strokeRect(bx,y,16,h)}
  if(open){
    g.fillStyle='#3a2010';g.fillRect(x+4,y-8,w-8,10);dz_coins(g,110,y-4,w/2-12,14,true);
    g.fillStyle=pl.body;g.fillRect(x,y+2,w,8);g.strokeStyle='#2a1508';g.strokeRect(x,y+2,w,8);
  }else{
    g.fillStyle=pl.lid;dzrr(g,x-2,56,w+4,38,16);g.fill();g.strokeStyle='#2a1508';g.lineWidth=2.2;g.stroke();
    g.fillStyle=pl.band;for(const bx of[x+14,x+w-30]){g.fillRect(bx,58,16,36);g.strokeStyle=pl.bs;g.strokeRect(bx,58,16,36)}
    g.fillStyle='#e4b02a';dzrr(g,100,84,20,22,4);g.fill();g.strokeStyle='#6a4a08';g.lineWidth=1.8;g.stroke();
    g.fillStyle='#4a3004';g.beginPath();g.arc(110,92,2.6,0,7);g.fill();g.fillRect(109,92,2,7);
  }
}
function dz_crateA(g,open){   // la cassa semplice di assi con la X
  if(open){g.fillStyle='#3a2210';g.fillRect(x,y,w,h);
    g.fillStyle='#c9a85a';for(let i=0;i<10;i++){g.fillRect(x+6+i*10,y+4+(i%3)*3,8,3)}   // paglia
    g.fillStyle='#a02a22';g.fillRect(x+16,y-4,26,16);g.fillStyle='#d9a21f';g.beginPath();g.arc(x+70,y+4,9,0,7);g.fill();
    g.save();g.translate(x+w-4,y-6);g.rotate(.5);dz_slat(g,0,0,34,10,'#9a6a38');g.restore()}
  dz_slat(g,x,open?y+22:y,w,open?h-22:h,'#a8743c');
  const yy=open?y+22:y,hh=open?h-22:h;
  for(let i=1;i<4;i++){g.strokeStyle='rgba(42,21,8,.45)';g.beginPath();g.moveTo(x,yy+i*hh/4);g.lineTo(x+w,yy+i*hh/4);g.stroke()}
  dz_slat(g,x,yy,10,hh,'#7a4e26');dz_slat(g,x+w-10,yy,10,hh,'#7a4e26');
  if(!open){g.strokeStyle='#5a3418';g.lineWidth=7;g.beginPath();g.moveTo(x+10,y+8);g.lineTo(x+w-10,y+h-8);g.moveTo(x+w-10,y+8);g.lineTo(x+10,y+h-8);g.stroke();g.strokeStyle='#2a1508';g.lineWidth=1.4;g.stroke()}
}
