const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
 const out=[];
 for(const [hash,name] of [['#w3','mare'],['#w4','galeone']]){
  const ctx=await b.newContext({viewport:{width:915,height:412},deviceScaleFactor:2,hasTouch:true});
  const p=await ctx.newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
  await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:0,t:0}));
    localStorage.setItem('sm_look',JSON.stringify({hat:'h_cuoco',out:'o_gent',def:'h_tri'}));localStorage.setItem('sm_gal','1')}catch(e){}});
  await p.goto('file:///home/claude/out/index_final.html'+hash);await p.waitForTimeout(3500);
  const r=await p.evaluate(()=>{try{const sp=window.Pirati&&window.Pirati.farm?window.Pirati.farm.heroSpec():null;return {hasP:!!window.Pirati,spec:sp&&{hat:sp.hat,coat:sp.coat},w:window.__W3,w4:window.__W4}}catch(e){return {err:String(e)}}});
  out.push([name,JSON.stringify(r),JSON.stringify(er)]);
  await p.screenshot({path:'aud/look_'+name+'.png'});
  await ctx.close();
 }
 console.log(out.map(x=>x.join(' | ')).join('\n'));
 await b.close()})();
