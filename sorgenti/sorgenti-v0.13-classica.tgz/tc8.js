const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}
await p.evaluate(()=>{Pirati.S.q.c8={st:'done',gi:3};Pirati.Ch2.st().parts.rudder=1;Pirati.saveGame()});
await p.reload();await p.waitForTimeout(2500);await p.click('#bCont');await p.waitForTimeout(3500);
console.log(await p.evaluate(()=>[Pirati.Ch2.st().parts.rudder,Pirati.Ch2.st().cvMig]));
await p.evaluate(()=>{const e=Pirati.EID.cave;Pirati.P.x=e.x;Pirati.P.y=e.y+70});await p.waitForTimeout(400);
for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(1200);
console.log('inside',await p.evaluate(()=>Pirati.cave.inside()));
// take rudder, then second time reload shouldn't reset
await p.evaluate(()=>{const r=Pirati.EID.cvrudder;Pirati.P.x=r.x-30;Pirati.P.y=r.y+10});await p.waitForTimeout(300);
for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.act());for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}
console.log('taken',await p.evaluate(()=>Pirati.Ch2.st().parts.rudder));
await p.evaluate(()=>Pirati.saveGame());await p.reload();await p.waitForTimeout(2500);await p.click('#bCont');await p.waitForTimeout(3000);
console.log('after reload',await p.evaluate(()=>Pirati.Ch2.st().parts.rudder));
console.log(er);await b.close()})();
