const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:700,height:260}});
await p.setContent('<body style="margin:0;background:#6a9a3a"><canvas id=c width=700 height=260></canvas></body>');
await p.evaluate(()=>{const g=document.getElementById('c').getContext('2d');g.fillStyle='#7a9a48';g.fillRect(0,0,700,260);g.scale(3,3);
 for(const [ox,e] of [[60,{k:0}],[170,{k:1}]]){g.save();g.translate(ox,40);
  const dr=e.k===1?-1:1;for(let i=0;i<5;i++){
      g.save();g.translate((-30+i*15)*dr,i%2?5:-4);g.rotate(dr*Math.PI/2+(i%2?.2:-.2)*dr);g.scale(1.05,1.05);g.globalAlpha=1-i*.12;
      const pr=(ox,oy,col)=>{g.fillStyle=col;g.beginPath();g.moveTo(ox,oy+4.2);g.bezierCurveTo(ox-6.2,oy+4,ox-6.4,oy-.2,ox-3,oy-1.4);g.quadraticCurveTo(ox,oy-2.4,ox+3,oy-1.4);g.bezierCurveTo(ox+6.4,oy-.2,ox+6.2,oy+4,ox,oy+4.2);g.fill();
        for(const[tx,ty,ta]of[[-5.3,-3.6,-.5],[-1.9,-6,-.12],[1.9,-6,.12],[5.3,-3.6,.5]]){g.beginPath();g.ellipse(ox+tx,oy+ty,1.6,2.1,ta,0,7);g.fill()}};
      pr(.5,.7,'rgba(255,238,200,.32)');pr(0,0,'rgba(54,34,17,.7)');g.restore()}
  g.restore()}});
await p.screenshot({path:'aud/paw_test.png'});await b.close()})();
