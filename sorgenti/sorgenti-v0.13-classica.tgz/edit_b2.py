import sys
P='/home/claude/work/ch3_inject.js'
s=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global s
    n=s.count(old)
    if n!=cnt:
        print('B2 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    s=s.replace(old,new)

# 1) nuovo tipo di nave: brigantino viola
rep("masts:[.38,-.3],mh:132,cannons:0}\n};",
    "masts:[.38,-.3],mh:132,cannons:0},\n  brigantino:{L:78,W:23,hull:3,spd:172,name:'Brigantino',hc:'#4e3a6c',dk:'#241a38',trim:'#e6d3a0',sail:['#e2c6ff','#8f5fd0'],emb:'#ffe08a',masts:[.3,-.22],mh:128,cannons:2}\n};")

# 2) affondamento: il brigantino non conta come pattuglia e dà una statistica a parte
rep("if(s.hull<=0){s.dead=true;s.sinking=true;C.kills++;if(s.type!=='mercante')C.ekills=(C.ekills||0)+1;if(s.type==='pattuglia'||s.type==='scorta'||s.type==='galeone'){try{YD.stat('kills');yAnn(2600)}catch(e){}}sink(s);",
    "if(s.hull<=0){s.dead=true;s.sinking=true;const bg=s.type==='brigantino';if(!bg)C.kills++;if(s.type!=='mercante'&&!bg)C.ekills=(C.ekills||0)+1;if(bg){try{YD.stat('brig');yAnn(2600)}catch(e){}}if(s.type==='pattuglia'||s.type==='scorta'||s.type==='galeone'){try{YD.stat('kills');yAnn(2600)}catch(e){}}sink(s);")
rep("  const n=s.type==='galeone'?8:s.type==='mercante'?1:s.type==='scorta'?1:0;\n  for(let i=0;i<n;i++)C.crates.push({x:s.x+rr(-60,60),y:s.y+rr(-50,50),t:rr(0,9),v:s.type==='galeone'?'silver':'food'});",
    "  const bg=s.type==='brigantino',n=s.type==='galeone'?8:bg?3:s.type==='mercante'?1:s.type==='scorta'?1:0;\n  for(let i=0;i<n;i++)C.crates.push({x:s.x+rr(-60,60),y:s.y+rr(-50,50),t:rr(0,9),v:(s.type==='galeone'||bg)?'silver':'food',opt:bg});")
rep("""toast(s.type==='galeone'?"Galeone affondato: casse d'argento in acqua!":'Nave affondata.');""",
    """toast(s.type==='galeone'?"Galeone affondato: casse d'argento in acqua!":bg?"Brigantino affondato: 3 casse d'argento in acqua!":'Nave affondata.');""")

# 3) newRun: punti d'interesse
rep("\n}\nfunction objVis(dt){","\n  if(!VOY)poiPlace();\n}\nfunction objVis(dt){")

# 4) battute di Biscotto
rep("'Lo scafo regge, ma non è eterno. In porto il carpentiere ripara tutto.'\n];",
    "'Lo scafo regge, ma non è eterno. In porto il carpentiere ripara tutto.',\n 'Le bottiglie in mare hanno sempre dentro qualcosa. Di solito una mappa. A volte un calzino.',\n 'Nella nebbia nessuno ti vede. Nemmeno io, ma io vedo poco comunque.',\n 'Il brigantino viola è veloce, ma anche lui si stanca. Pazienza, capitano.'\n];")

# 5) suggerimenti di Biscotto sui nuovi punti
rep("  if(windK(p.hd)<.8)return 'Il vento è contro: gira di lato e le vele ti ringrazieranno.';",
"""  {const P0=C.poi;
   if(P0&&!C.tut){
     if(C.map)return 'La mappa segna una spiaggia '+dirName(C.map.x-p.x,C.map.y-p.y)+': segui la freccia color pergamena!';
     const bt=P0.bottles[0];if(bt&&Math.hypot(bt.x-p.x,bt.y-p.y)<1800)return 'Cra! Una bottiglia in acqua '+dirName(bt.x-p.x,bt.y-p.y)+'. Prendila!';
     const ch=P0.chests.find(c=>!c.open&&c.k==='chest'&&Math.hypot(c.x-p.x,c.y-p.y)<1800);if(ch)return 'Vedo un forziere sulla spiaggia '+dirName(ch.x-p.x,ch.y-p.y)+'. Avvicinati con la nave!';
     if(P0.cove&&p.hull<p.max*.75)return 'C\\'è una cala tranquilla '+dirName(P0.cove.x-p.x,P0.cove.y-p.y)+': lì lo scafo si ripara da solo.'}}
  if(windK(p.hd)<.8)return 'Il vento è contro: gira di lato e le vele ti ringrazieranno.';""")

# 6) step: poiStep, brigantino, nebbia, fine missione
rep("  if(!C.tut&&!VOY)convoy(dt);","  if(!C.tut&&!VOY){convoy(dt);poiStep(dt)}")
rep("    if(s.type==='fantasma'){voyGhostAI(s,dt,dp);continue}","    if(s.type==='fantasma'){voyGhostAI(s,dt,dp);continue}\n    if(s.type==='brigantino'){brigAI(s,dt,dp);continue}")
rep("dp<(s.free?560:330)*(C.plan?C.plan.detect:1)){","dp<(s.free?560:330)*(C.plan?C.plan.detect:1)*(C.inFog?.35:1)){")
rep("      if((s.type==='pattuglia'||s.free)&&s.hostile&&dp>(s.hit?1600:(s.free?900:620)))s.hostile=false;",
    "      if((s.type==='pattuglia'||s.free)&&s.hostile&&dp>(s.hit?1600:(s.free?900:620)))s.hostile=false;\n      if(C.inFog&&(s.type==='pattuglia'||s.free)&&s.hostile&&dp>(s.hit?560:320))s.hostile=false;")
rep("&&gal.length===0&&C.crates.length===0)endRun('completo');","&&gal.length===0&&!C.crates.some(c=>!c.opt))endRun('completo');")

# 7) disegno
rep("s.type==='mercante'?'#e8e0c8':s.ally?'#b9f0b0':'#ffb0a0'","s.type==='mercante'?'#e8e0c8':s.type==='brigantino'?'#e2c4ff':s.ally?'#b9f0b0':'#ffb0a0'")
rep("  // casse\n  for(const c of C.crates){const x=c.x,y=c.y+Math.sin(c.t*2)*3;","  poiDraw(g,t);\n  // casse\n  for(const c of C.crates){const x=c.x,y=c.y+Math.sin(c.t*2)*3;")
rep("    else if(q.k==='chip'){g.fillStyle='rgba(120,80,40,'+a+')';g.fillRect(q.x,q.y,4,4)}}",
    "    else if(q.k==='chip'){g.fillStyle='rgba(120,80,40,'+a+')';g.fillRect(q.x,q.y,4,4)}\n    else if(q.k==='heal'){g.fillStyle='rgba(160,255,196,'+a+')';g.strokeStyle='rgba(20,90,50,'+a*.8+')';g.lineWidth=2;g.beginPath();g.moveTo(q.x-3,q.y-9);g.lineTo(q.x+3,q.y-9);g.lineTo(q.x+3,q.y-3);g.lineTo(q.x+9,q.y-3);g.lineTo(q.x+9,q.y+3);g.lineTo(q.x+3,q.y+3);g.lineTo(q.x+3,q.y+9);g.lineTo(q.x-3,q.y+9);g.lineTo(q.x-3,q.y+3);g.lineTo(q.x-9,q.y+3);g.lineTo(q.x-9,q.y-3);g.lineTo(q.x-3,q.y-3);g.closePath();g.fill();g.stroke()}}")
rep("g.ellipse(pt[0],pt[1]+10,320,150,0,0,7);g.stroke();g.restore();}\n}","g.ellipse(pt[0],pt[1]+10,320,150,0,0,7);g.stroke();g.restore();}\n  poiFog(g,t);\n}")

# 8) overlay, minimappa
rep("(s.type==='prigionieri'&&!s.ally&&!C.tut)?'p':s===near?'e':0;","(s.type==='prigionieri'&&!s.ally&&!C.tut)?'p':(s.type==='brigantino'&&!C.tut&&Math.hypot(s.x-C.p.x,s.y-C.p.y)<2800)?'b':s===near?'e':0;")
rep("kd==='t'?'#7be3ff':kd==='p'?'#ffffff':kd==='e'?'#ff8a7a':'#ffd23a'","kd==='t'?'#7be3ff':kd==='p'?'#ffffff':kd==='e'?'#ff8a7a':kd==='b'?'#c79cff':'#ffd23a'")
rep("  // lato illuminato verso i nemici + ricarica\n","  if(!VOY)poiOverlay(g,w,h);\n  // lato illuminato verso i nemici + ricarica\n")
rep("  for(const s of C.ships){if(s.dead)continue;const x=(s.x-p.x)*sc,y=(s.y-p.y)*sc;c.fillStyle=s.ally?'#8fe08a':s.type==='prigionieri'?'#fff':s.type==='galeone'?'#ffd23a':s.type==='mercante'?'#d8c8a0':'#ff6a5a';",
    "  if(!VOY)poiMini(c,p,sc);\n  for(const s of C.ships){if(s.dead)continue;const x=(s.x-p.x)*sc,y=(s.y-p.y)*sc;c.fillStyle=s.ally?'#8fe08a':s.type==='prigionieri'?'#fff':s.type==='galeone'?'#ffd23a':s.type==='mercante'?'#d8c8a0':s.type==='brigantino'?'#c79cff':'#ff6a5a';")

# 9) dopo il galeone: niente più punti d'interesse
rep("C.ships=C.ships.filter(s=>s.ally);C.crates=[];C.balls=[];C.pend=[];","C.ships=C.ships.filter(s=>s.ally);C.crates=[];C.balls=[];C.pend=[];C.poi=null;C.brig=null;C.map=null;")

# 10) blocco di codice nuovo, prima di step
blk=open('/home/claude/work/b2_block.js',encoding='utf8').read()
rep("/* ---------------- passo ---------------- */",blk+"\n/* ---------------- passo ---------------- */")

# 11) esportazione per i test
rep("window.Ch3={voy:voyAPI,","window.Ch3={b2:{poiPlace,spawnBrig,spawnBottle,takeBottle,openChest,beachSpot,poiSpot,brigAI,poiStep},voy:voyAPI,")

open(P,'w',encoding='utf8').write(s)
print('b2 ok')
