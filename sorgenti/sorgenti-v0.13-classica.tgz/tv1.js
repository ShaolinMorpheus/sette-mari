const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.built={falo:1,capanna:1,banco:1,zattera:1};for(const id of['falo','capanna','banco','zattera']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}S.res.legna=50;S.res.pietra=20;S.res.corda=1;S.res.rottami=5;S.flags.sailed=1});
 // hut
 await p.evaluate(()=>Pirati.hut.enter());await p.waitForTimeout(1500);
 await p.evaluate(()=>{const P=Pirati.P;P.x=(Pirati.hut.X0+22)*44;P.y=(Pirati.hut.Y0+4.5)*44;});await p.waitForTimeout(800);
 await p.screenshot({path:'aud/hut_pic.png'});
 await p.evaluate(()=>Pirati.hut.exit());await p.waitForTimeout(800);
 // workbench w/ missing rope
 await p.evaluate(()=>Pirati.UI.openUpgrades());await p.waitForTimeout(500);
 await p.evaluate(()=>{const s=document.getElementById('sheet');const e=[...document.querySelectorAll('#sheet h3')].find(h=>/orto/i.test(h.textContent));e&&e.scrollIntoView()});await p.waitForTimeout(300);
 await p.screenshot({path:'aud/wb_orto.png'});
 console.log('ERR',JSON.stringify(errs));await b.close()})();
