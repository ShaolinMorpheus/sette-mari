const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
const r=await p.evaluate(()=>{const P=Pirati;const o=[];console.log;const t0=P.tileInfo(20,49);const rows=[];
 const ents={};for(const e of P.E){if(e.fp){for(let j=0;j<e.fp[3];j++)for(let i=0;i<e.fp[2];i++)ents[(e.fp[0]+i)+','+(e.fp[1]+j)]=e.type+':'+(e.id||'')}}
 for(let y=36;y<=60;y++){let s=String(y).padStart(2)+' ';for(let x=6;x<=36;x++){const t=P.tileInfo(x,y);const en=ents[x+','+y];s+=en?(en.startsWith('deco')?'D':en[0].toUpperCase()):(t.walk?'.':(t.water?'~':'#'))}rows.push(s)}
 return {keys:Object.keys(t0),rows,ps:[P.P.x/44,P.P.y/44]}});
console.log(r.keys.join(','),r.ps);console.log(r.rows.join('\n'));await b.close()})();
