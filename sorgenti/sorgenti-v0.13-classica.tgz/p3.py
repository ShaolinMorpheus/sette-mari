p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:60],s.count(a))
    s=s.replace(a,b)
code=r'''
/* ====== CAPITOLO 2: scenografia, personaggi, fiducia, scambi, missioni, finali ====== */
Ch2.decor=function(deco){
  const tent=(id,x,y,flip,big)=>deco(id,'tent',x,y,[Math.floor(x)-1,Math.floor(y-.2),2,1],{nohit:1,flip:!!flip,k:big?1.18:1});
  tent('c2t0',58.2,26.4,0,1);tent('c2t1',53.6,28.6,1);tent('c2t2',54.2,33.4,0);tent('c2t3',62.8,27.6,1);tent('c2t4',63.6,33,0);tent('c2t5',50.6,31.4,1);
  deco('c2flag','bandiera',60.2,26.6,null,{nohit:1,k:1});
  deco('c2stall','banco',62,30.6,[61,30,2,1],{nohit:1,k:.95,label:'Bancarella di Nives'});
  deco('c2b0','barrel0',60.4,30.9,[60,30,1,1],{nohit:1});deco('c2b1','barrel1',56.2,32,[56,31,1,1],{nohit:1});
  deco('c2cr0','crate',57.1,27.4,[57,26,1,1],{nohit:1});deco('c2cr1','crate',64.8,30.6,[64,30,1,1],{nohit:1});
  deco('c2coil','coil',55.2,27.7,null,{nohit:1});
  deco('c2boat','rowboat',66.4,35.4,null,{nohit:1,flip:true});
  deco('c2cannon','cannon',52.6,25.6,null,{nohit:1});
  // la cala della nave
  deco('nave','wreck',CV2.ship[0],CV2.ship[1],[Math.floor(CV2.ship[0])-3,Math.floor(CV2.ship[1])-1,7,2],{k:.95,hitw:230,hith:130,label:'La nave dei Fuggiaschi',inter:'look',flip:true});
  deco('c2sc0','scaf',CV2.ship[0]-5,CV2.ship[1]+1.4,null,{nohit:1});
};
'''
rep("const QDEF={",code+"\nconst QDEF={")
open(p,'w',encoding='utf8').write(s)
