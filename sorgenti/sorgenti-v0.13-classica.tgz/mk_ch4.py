import re,sys
src=open('w/index.html').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt: print('PATCH FAIL',n,old[:70]); sys.exit(1)
    src=src.replace(old,new)
rep("if(window.__W2)return 2;","if(window.__W4)return 4;if(window.__W2)return 2;")
rep("const TS=44, MW=99, MH=60,","const TS=44, MW=WORLD===4?72:99, MH=WORLD===4?46:60,")
rep("const BLOBS=WORLD===2?BLOBS_2:BLOBS_1;","const BLOBS=WORLD===4?[]:WORLD===2?BLOBS_2:BLOBS_1;")
rep("const BEACH=WORLD===2?","const BEACH=WORLD===4?[]:WORLD===2?")
rep("const POND=WORLD===2?","const POND=WORLD===4?{x:1.5,y:1.5,rx:.2,ry:.2}:WORLD===2?")
rep("const C0=WORLD===2?","const C0=WORLD===4?{x:30,y:23}:WORLD===2?")
rep("const PATHS=WORLD===2?","const PATHS=WORLD===4?[]:WORLD===2?")
rep("const MESA=WORLD===2?","const MESA=WORLD===4?{x:-40,y:-40,rx:1,ry:1,h:1}:WORLD===2?")
rep("const MESA_PTS=WORLD===2?[]:","const MESA_PTS=WORLD!==1?[]:")
rep("const FIX=WORLD===2?FIX_2:FIX_1;","""const FIX_4=Object.assign({},FIX_2,{spawn:[30,23],sign:[-60,-60],wreck:[-60,-60],plots:{falo:{tx:1,ty:1,w:1,h:1},capanna:{tx:1,ty:1,w:1,h:1},banco:{tx:1,ty:1,w:1,h:1},zattera:{tx:1,ty:1,w:1,h:1}},lookout:[-50,-50],quarry:[-60,-60],boulders:[],raftLaunch:[22,30],smoke:[-60,-60],isl1:[-60,-60],isl2:[-60,-60],bottles:[]});
const FIX=WORLD===4?FIX_4:WORLD===2?FIX_2:FIX_1;""")
rep("  if(WORLD===2)return exclTile2(tx,ty);","  if(WORLD===4)return false;\n  if(WORLD===2)return exclTile2(tx,ty);")
rep("  if(WORLD===2)return genWorld2();","  if(WORLD===4)return genWorld4();\n  if(WORLD===2)return genWorld2();")
gw4=r"""function genWorld4(){
  for(const id in FIX.plots){const f=FIX.plots[id];
    const e=ent({id:'plot_'+id,type:'plot',pid:id,x:(f.tx+f.w/2)*TS,y:(f.ty+f.h)*TS-2,tx:f.tx,ty:f.ty,tw:f.w,th:f.h,st:0,prog:0});
    addBlock(e,f.tx,f.ty,f.w,f.h);delBlock(e);
  }
  ent({id:'wparrot',type:'wparrot',x:-999,y:-999,alt:90,got:false});
  ent({id:'mraft',type:'mraft',x:-999,y:-999,hd:0});
  FIX.crabN=0;
}
"""
rep("function genWorld2(){",gw4+"function genWorld2(){")
rep("if(!dl.open){if(!P.cl)updatePlayer(dt);updateTime(dt);updateVitals(dt);updateWeather(dt);updateChallenge(dt);Story.tick(dt)}","if(!dl.open){if(WORLD===4){Ch4.step(dt)}else{if(!P.cl)updatePlayer(dt);updateTime(dt);updateVitals(dt);updateWeather(dt);updateChallenge(dt);Story.tick(dt)}}")
rep("  computeTarget();\n  drawTargetRing(g,t);\n","  computeTarget();\n  drawTargetRing(g,t);\n  if(WORLD===4)Ch4.drawFloor(g,t);\n")
rep("      case'npc':drawNpc(g,e,t);break;","      case'npc':drawNpc(g,e,t);break;\n      case'c4':Ch4.drawEnt(g,e,t);break;")
rep("  drawWParrot(g,EID.wparrot,t);\n","  drawWParrot(g,EID.wparrot,t);\n  if(WORLD===4)Ch4.drawTop(g,t);\n")
rep("  initInput();initStart();syncPause();\n","  initInput();initStart();syncPause();\n  if(WORLD===4)Ch4.boot();\n")
rep("function saveGame(quiet){\n  if(!S||!S.live)return;","function saveGame(quiet){\n  if(WORLD===4||!S||!S.live)return;")
rep("  if(!S||!S.live)return'day';\n","  if(!S||!S.live)return'day';\n  if(WORLD===4)return'night';\n")

rep("  sea:{beat:.6,den:.7,","  assault:{assault:1,beat:.21,den:0,vol:.07,prog:[[57,60,64]],ext:[69],low:0},\n  sea:{beat:.6,den:.7,")
rep("  if(WORLD===4)return'night';\n","  if(WORLD===4)return'assault';\n")
rep("    const m=MUS[musicMood()],t=AU.nextT,b=AU.beat,ch=m.prog[((b/4)|0)%m.prog.length];","    const m=MUS[musicMood()],t=AU.nextT,b=AU.beat,ch=m.prog[((b/4)|0)%m.prog.length];\n    if(m.assault){assaultTick(t,b);AU.nextT+=m.beat;AU.beat++;continue}")
rep("function auMusicTick(){","""function mDrum(t,kind){
  const c=AU.ctx;
  if(kind==='k'){const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.setValueAtTime(130,t);o.frequency.exponentialRampToValueAtTime(42,t+.16);g.gain.setValueAtTime(.34,t);g.gain.exponentialRampToValueAtTime(.001,t+.22);o.connect(g);g.connect(AU.mbus);o.start(t);o.stop(t+.25);return}
  if(!AU._nb){const n=c.sampleRate*.3,b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;AU._nb=b}
  const s=c.createBufferSource();s.buffer=AU._nb;const f=c.createBiquadFilter(),g=c.createGain();
  if(kind==='s'){f.type='bandpass';f.frequency.value=1800;f.Q.value=.7;g.gain.setValueAtTime(.30,t);g.gain.exponentialRampToValueAtTime(.001,t+.16)}
  else{f.type='highpass';f.frequency.value=6500;g.gain.setValueAtTime(.07,t);g.gain.exponentialRampToValueAtTime(.001,t+.05)}
  s.connect(f);f.connect(g);g.connect(AU.mbus);s.start(t);s.stop(t+.2)}
const AS_CH={Am:[57,60,64],F:[53,57,60],G:[55,59,62],C:[48,52,55],E:[52,56,59]};
const AS_SEQ=['Am','Am','F','G','Am','Am','F','E','C','G','Am','Am','F','G','E','E'];
const AS_MEL=[[76,0,76,77,76,72,69,0],[72,0,74,72,69,0,0,0],[77,0,77,79,77,74,72,0],[74,0,76,74,71,0,67,0],[76,0,76,77,79,77,76,72],[81,0,79,76,72,0,76,0],[77,76,74,72,74,72,69,0],[71,0,74,76,80,0,0,0],
 [79,0,79,76,72,0,76,0],[74,0,74,71,67,0,71,0],[72,0,76,0,81,0,79,76],[76,0,72,0,69,0,0,0],[77,0,81,0,84,0,81,77],[79,0,83,0,86,0,83,79],[76,0,80,0,83,0,80,76],[81,0,0,0,0,0,0,0]];
function assaultTick(t,b){
  const st=b%8,bar=((b/8)|0)%16,ch=AS_CH[AS_SEQ[bar]],v=.075,sect=bar>=8;
  if(st===0)mPad(t,ch,8*.21*1.05,v*.5);
  const root=ch[0]-12;
  if(st===0||st===4)mNote(t,root,.34,v*1.5,'triangle');
  if(st===2||st===6)mNote(t,root+7,.2,v*.9,'triangle');
  if(st===0||st===4||(sect&&st===3))mDrum(t,'k');
  if(st===2||st===6)mDrum(t,'s');
  if(sect||st%2===0)mDrum(t,'h');
  if(st%2===1)mNote(t,ch[(st>>1)%3]+12,.16,v*.45,'sine');
  const m=AS_MEL[bar][st];
  if(m){let len=1;while(st+len<8&&!AS_MEL[bar][st+len])len++;const d=len*.21*.95;
    mNote(t,m,Math.min(d,.7),v*1.25,'triangle');mNote(t,m+12,Math.min(d,.5),v*.3,'square')}
}
function auMusicTick(){""")
rep("cv.addEventListener('wheel',e=>{e.preventDefault();cam.uz=","cv.addEventListener('wheel',e=>{e.preventDefault();if(WORLD===4)return;cam.uz=")
rep("  if(k==='+'||k==='='){cam.uz=","  if(WORLD!==4&&(k==='+'||k==='=')){cam.uz=")
rep("  if(k==='-'||k==='_'){cam.uz=","  if(WORLD!==4&&(k==='-'||k==='_')){cam.uz=")
inj=open('ch4_inject.js').read()
src=src.replace("<head>","<head><script>window.__W4=1;</script>",1)
tail="\n})();\n</script>"
k=src.rindex(tail)
src=src[:k]+"\n"+inj+tail+src[k+len(tail):]
open('/home/claude/out/nave_spagnola.html','w').write(src)
print('ok',len(src))
