const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:900,height:420},deviceScaleFactor:2.5});const p=await ctx.newPage();
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(2500);
await p.click('#bNew').catch(()=>{});for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(200)}
await p.evaluate(()=>{Pirati.joy&&Pirati.joy(1,0)});
const r=await p.evaluate(()=>new Promise(res=>{const d=[];let l=performance.now();const f=()=>{const n=performance.now();d.push(n-l);l=n;if(d.length<150)requestAnimationFrame(f);else{d.sort((a,b)=>a-b);res([d[75],d[140],d[149]])}};requestAnimationFrame(f)}));
console.log('median,p93,max frame ms',r);await p.screenshot({path:'w3.png'});await b.close()})();
