const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
await p.evaluate(()=>{Pirati.hut.enter();Pirati.saveGame()});await p.waitForTimeout(500);
await p.reload();await p.waitForTimeout(2500);await p.click('#bCont').catch(()=>{});await p.waitForTimeout(3500);
console.log(await p.evaluate(()=>[Pirati.hut.inside(),Pirati.P.x/44,Pirati.P.y/44]));
// tempesta dentro
await p.evaluate(()=>{Pirati.S.wx={k:'storm',t:60}});await p.waitForTimeout(3000);
console.log(await p.evaluate(()=>[Pirati.S.vit.t,Pirati.S.vit.h]));
await p.screenshot({path:'hut_storm.png'});
// uscita e controllo posizione fuori
await p.evaluate(()=>Pirati.hut.exit());await p.waitForTimeout(800);
console.log(await p.evaluate(()=>[Pirati.hut.inside(),Pirati.P.x/44,Pirati.P.y/44]));
console.log(er);await b.close()})();
