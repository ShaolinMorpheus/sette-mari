const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1200);
const r=await p.evaluate(()=>{const C=Ch4,K=C.K,P=C.P,o=[];K.inv=999;
 const [g,f]=K.duels[0];o.push(g.who,g.friend,f.who,f.friend);
 C.tp(20,11);P.x=f.x+50;P.y=f.y;K.fdx=-1;K.fdy=0;
 for(let i=0;i<3;i++){K.atk=0;C.atk();for(let j=0;j<20;j++)C.step(1/30)}
 o.push(f.ko,f.duel,g.ko,g.hp);
 P.x=g.x+50;P.y=g.y;K.fdx=-1;
 for(let i=0;i<3;i++){K.atk=0;C.atk();for(let j=0;j<20;j++)C.step(1/30)}
 o.push(g.ko>0,f.duel,f.ally,K.stay.length);for(let j=0;j<300;j++)C.step(1/30);o.push(Math.round(f.x),Math.round(f.y));return o});
console.log(JSON.stringify(r),errs);await b.close()})()
