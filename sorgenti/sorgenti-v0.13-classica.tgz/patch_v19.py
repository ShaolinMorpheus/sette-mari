#!/usr/bin/env python3
# v0.12g (A3): pesce aurora (leggendario), fungo lunare, spaventapasseri col cappello, Traguardi, tasto «Salta»
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH19 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:100].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)

# ---------- pesce aurora ----------
rep("const FISH_RAR=['Comune','Non comune','Raro','Rarissimo'];","const FISH_RAR=['Comune','Non comune','Raro','Rarissimo','Leggendario'];")
rep('''  {id:'luna',n:'Pesce luna',r:3,w:3,night:1,moon:1,d:"Una leggenda dei mari: sale solo con la luna piena.",h:"Di notte, con la luna piena."}\n];''',
'''  {id:'luna',n:'Pesce luna',r:3,w:3,night:1,moon:1,d:"Una leggenda dei mari: sale solo con la luna piena.",h:"Di notte, con la luna piena."},
  {id:'aurora',n:'Pesce aurora',r:4,w:24,night:1,moon:1,rainOnly:1,d:"Dicono che brilli come un'aurora sul mare. Sale solo quando la luna è piena e la pioggia accarezza l'acqua.",h:"Solo di notte, con la luna piena e la pioggia."}\n];''')
rep("    if(f.moon&&moonK()<.75)x=0;\n","    if(f.moon&&moonK()<.75)x=0;\n    if(f.rainOnly&&!rainy)x=0;\n")
rep("luna:{c:['#e8eef2','#9fb0bc'],a:.75,b:1.0,st:'#6e8494'}}[id]","luna:{c:['#e8eef2','#9fb0bc'],a:.75,b:1.0,st:'#6e8494'},aurora:{c:['#c9b6ff','#3d2f9a'],a:1.0,b:.82,st:'#8a6aff'}}[id]")
rep("if(id==='luna'){g.strokeStyle='rgba(110,130,145,.7)';g.lineWidth=1.6;for(let k=1;k<4;k++){g.beginPath();g.ellipse(cx,cy,rx*k/4,ry*k/4,0,0,7);g.stroke()}}",
    "if(id==='luna'){g.strokeStyle='rgba(110,130,145,.7)';g.lineWidth=1.6;for(let k=1;k<4;k++){g.beginPath();g.ellipse(cx,cy,rx*k/4,ry*k/4,0,0,7);g.stroke()}}\n  if(id==='aurora'){const cl=['rgba(120,255,210,.6)','rgba(255,150,230,.55)','rgba(150,170,255,.6)','rgba(255,240,150,.5)','rgba(120,255,210,.5)'];for(let k=0;k<5;k++){g.fillStyle=cl[k];g.beginPath();g.ellipse(cx-28+k*14,cy+(k%2?6:-7),7,ry*1.5,.5,0,7);g.fill()}}")
rep("  if(id==='lanterna'){g.strokeStyle='#ffe27a';",
    "  if(id==='aurora'){g.fillStyle='#fff';for(const[sx,sy,sr]of[[10,12,2],[112,16,1.6],[100,64,2.2],[18,66,1.5],[64,8,1.4],[122,42,1.3]]){g.beginPath();g.arc(sx,sy,sr,0,7);g.fill()}g.strokeStyle='rgba(255,255,255,.9)';g.lineWidth=1.2;for(const[sx,sy]of[[10,12],[100,64]]){g.beginPath();g.moveTo(sx-5,sy);g.lineTo(sx+5,sy);g.moveTo(sx,sy-5);g.lineTo(sx,sy+5);g.stroke()}}\n  if(id==='lanterna'){g.strokeStyle='#ffe27a';")

# ---------- fungo lunare ----------
rep("const RES=['legna','pietra','corda','tela','rottami','coco','bacche','molluschi','pesce','arrosto','semi','patata','zucca','ananas','pescesec','fruttasec'];",
    "const RES=['legna','pietra','corda','tela','rottami','coco','bacche','molluschi','pesce','arrosto','semi','patata','zucca','ananas','pescesec','fruttasec','fungo'];")
rep("pescesec:'Pesce secco',fruttasec:'Frutta secca'};","pescesec:'Pesce secco',fruttasec:'Frutta secca',fungo:'Fungo lunare'};")
rep("fruttasec:\"Si prepara nell'essiccatore con bacche o ananas: non va a male.\"};","fruttasec:\"Si prepara nell'essiccatore con bacche o ananas: non va a male.\",fungo:\"Cresce nell'orto, ma solo di notte: con la luna piena è più veloce. Serve per la Zuppa di luna di Gnocco.\"};")
rep("pescesec:12,fruttasec:12};","pescesec:12,fruttasec:12,fungo:6};")
rep("  ananas:{n:'Ananas',t:480,y:1,need:8}\n};\nconst GC_ORDER=['patata','zucca','ananas'];",
    "  ananas:{n:'Ananas',t:480,y:1,need:8},\n  fungo:{n:'Fungo lunare',t:420,y:1,need:12,night:1}\n};\nconst GC_ORDER=['patata','zucca','ananas','fungo'];")
rep("if(g&&g.pl&&hasFarm('orto')){const r=rain?2.4:1;for(const p of g.pl)if(p&&GC[p.c]&&p.p<GC[p.c].t)p.p=Math.min(GC[p.c].t,p.p+sec*r)}",
    "if(g&&g.pl&&hasFarm('orto')){const r=rain?2.4:1;for(const p of g.pl)if(p&&GC[p.c]&&p.p<GC[p.c].t)p.p=Math.min(GC[p.c].t,p.p+sec*r*(GC[p.c].night&&typeof NV3!=='undefined'?NV3.nf(sleepy):1))}")
rep("+'</span>'+(isRain()?' (la pioggia aiuta)':'')+'</p>';","+'</span>'+(isRain()?' (la pioggia aiuta)':'')+(C.night?' · cresce solo di notte, più in fretta con la luna piena':'')+'</p>';")
rep('<symbol id="i-fruttasec"','<symbol id="i-fungo" viewBox="0 0 24 24"><path d="M12 3C6.5 3 3.2 7 3.2 11.4c0 1 .8 1.6 1.8 1.6h14c1 0 1.8-.6 1.8-1.6C20.8 7 17.5 3 12 3z" fill="#6aa8ff" stroke="#1c2f6a" stroke-width="1.3"/><circle cx="8.5" cy="8.4" r="1.6" fill="#d8ecff"/><circle cx="14.2" cy="6.8" r="1.2" fill="#d8ecff"/><circle cx="16" cy="10.2" r="1" fill="#d8ecff"/><path d="M9.2 13h5.6l-.8 7.4c-.1.9-.8 1.5-1.8 1.5h-.4c-1 0-1.7-.6-1.8-1.5z" fill="#efe6c8" stroke="#1c2f6a" stroke-width="1.3"/></symbol><symbol id="i-fruttasec"')

# disegno del fungo (altrimenti verrebbe disegnato come un ananas) e luce notturna
rep("  }else{   // ananas\n","  }else if(c==='fungo'){NV3.fungoDraw(g,st,f,t,sw)}else{   // ananas\n")
rep("    for(const e of E)if(e.type==='deco'&&e.spr==='nv_lant')lights.push([e.x+15,e.y-68,150,.8,true]);\n","    for(const e of E)if(e.type==='deco'&&e.spr==='nv_lant')lights.push([e.x+15,e.y-68,150,.8,true]);\n    for(const e of E)if(e.type==='cdeco'&&e.k==='orto'&&typeof NV3!=='undefined')NV3.fungoLights(e,lights);\n")
# ---------- spaventapasseri col cappello ----------
rep("    g.fillStyle='#222836';g.beginPath();g.moveTo(sx-11,sb-44);g.quadraticCurveTo(sx-9,sb-52,sx-4,sb-51);g.quadraticCurveTo(sx,sb-55,sx+4,sb-51);g.quadraticCurveTo(sx+9,sb-52,sx+11,sb-44);g.quadraticCurveTo(sx,sb-41,sx-11,sb-44);g.fill();g.stroke();",
    "    if(!(typeof NV3!=='undefined'&&NV3.schDraw(g,sx,sb-41))){g.fillStyle='#222836';g.beginPath();g.moveTo(sx-11,sb-44);g.quadraticCurveTo(sx-9,sb-52,sx-4,sb-51);g.quadraticCurveTo(sx,sb-55,sx+4,sb-51);g.quadraticCurveTo(sx+9,sb-52,sx+11,sb-44);g.quadraticCurveTo(sx,sb-41,sx-11,sb-44);g.fill();g.stroke()}")
rep("    h+='<div class=\"row\"><button class=\"btn\" id=\"shNo\">Chiudi</button></div>';\n    sheetFor(h,c=>{\n      c.querySelectorAll('[data-pl]')",
    "    h+=(typeof NV3!=='undefined'?NV3.schRow():'');\n    h+='<div class=\"row\"><button class=\"btn\" id=\"shNo\">Chiudi</button></div>';\n    sheetFor(h,c=>{\n      if(typeof NV3!=='undefined')NV3.schWire(c,draw);\n      c.querySelectorAll('[data-pl]')")

# ---------- esportazione per i test + codice nuovo ----------
rep("get NV2(){return typeof NV2!=='undefined'?NV2:null},","get NV2(){return typeof NV2!=='undefined'?NV2:null},get NV3(){return typeof NV3!=='undefined'?NV3:null},")
NEW=open('/home/claude/work/new19.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")

# ---------- registro delle novità ----------
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Pesce aurora: un pesce leggendario che si pesca solo di notte, con la luna piena e la pioggia. Il registro dei pesci ora ha 9 specie.",
    "Fungo lunare: una nuova coltura dell'orto che cresce solo di notte (più in fretta con la luna piena). Serve per la «Zuppa di luna» di Gnocco.",
    "Lo spaventapasseri può indossare uno dei tuoi cappelli: scegli dall'orto.",
    "Traguardi: nel Diario, scheda Raccolta, trovi 30 piccole imprese. Ognuna regala esperienza.",
    "Tasto «Salta» sui dialoghi che hai già letto (non compare quando devi scegliere una risposta).",
''')
open(P,'w',encoding='utf8').write(src)
print('patch19 ok')
