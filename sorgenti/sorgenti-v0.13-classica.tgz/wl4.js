const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:844,height:390},hasTouch:true,isMobile:true})).newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
const run=async(x0,y0,dx,dy,ms)=>p.evaluate(async([x0,y0,dx,dy,ms])=>{
 Pirati.tp(x0,y0);await new Promise(r=>setTimeout(r,300));
 const cv=document.querySelector('canvas'),j=document.getElementById('joy').getBoundingClientRect(),cx=j.left+j.width/2,cy=j.top+j.height/2;
 const ev=(t,x,y)=>cv.dispatchEvent(new PointerEvent(t,{pointerId:5,clientX:x,clientY:y,bubbles:true,pointerType:'touch'}));
 ev('pointerdown',cx,cy);ev('pointermove',cx+dx*45,cy+dy*45);await new Promise(r=>setTimeout(r,ms));ev('pointerup',cx,cy);
 return [+(Pirati.P.x/44).toFixed(2),+(Pirati.P.y/44).toFixed(2)]},[x0,y0,dx,dy,ms]);
for(const [x0,y0,dx,dy] of [[16.2,46.7,0,1],[16.2,46.7,-1,0],[15.5,46.7,0,1],[14.5,47,0,1],[16.2,46.7,1,0],[24.5,47,0,1],[24.5,47,-1,0]])console.log([x0,y0,dx,dy],JSON.stringify(await run(x0,y0,dx,dy,1800)));
await b.close()})();
