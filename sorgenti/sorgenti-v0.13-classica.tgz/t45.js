const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/sette-mari/www/_t.html');await p.waitForTimeout(1500);await p.click('#bNew');await p.waitForTimeout(3000);
const d=await p.evaluate(()=>{const s=__t.SP.banco;const c=document.createElement('canvas');c.width=s.w*3;c.height=s.h*3;const g=c.getContext('2d');g.fillStyle='#7aa84a';g.fillRect(0,0,c.width,c.height);g.scale(3,3);g.drawImage(s.c,0,0,s.w,s.h);return c.toDataURL()});
require('fs').writeFileSync('banco.png',Buffer.from(d.split(',')[1],'base64'));console.log(er);await b.close()})()
