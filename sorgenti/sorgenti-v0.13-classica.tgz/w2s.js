const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>Pirati.startNew('T','m'));
for(let i=0;i<10;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(300)}
const spots=JSON.parse(process.argv[2]);let n=0;
for(const [x,y,name] of spots){
 await p.evaluate(async([x,y])=>{Pirati.S.tod=12;Pirati.S.wx={k:'clear',t:900};Pirati.tp(x,y);for(let i=0;i<60&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,50))}},[x,y]);
 await p.waitForTimeout(900);await p.evaluate(async()=>{for(let i=0;i<60&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,50))}});await p.waitForTimeout(300);
 await p.screenshot({path:'w2_'+name+'.png'});}
await b.close()})();
