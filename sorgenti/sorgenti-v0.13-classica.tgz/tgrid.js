const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1200,height:700}})).newPage();
await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({silver:0,pris:0,hull:10,max:10,kills:0,t:0}))}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2500);
const r=await p.evaluate(()=>{const K=Ch4.K;Ch4.setDeck(0,35,3.95,true);const f=Ch4.bfsFrom(Ch4.P.x,Ch4.P.y),W=Ch4.MW,OX=Ch4.OX,OY=Ch4.OY;
 const g=[];for(let y=10;y<=18;y++){let row=String(y).padStart(2)+' ';for(let x=18;x<=34;x++){const v=f[(x+OX)+(y+OY)*W];row+=v>=0?'.':'#'}g.push(row)}
 const pr=Ch4.DECKS[0].props.filter(e=>e.gx>=18&&e.gx<=34&&e.gy>=10).map(e=>e.kind+'@'+e.gx+','+e.gy+' '+e.gw+'x'+e.gh);
 return g.join('\n')+'\n'+pr.join(' ')});
console.log(r);await b.close()})();
