/* ====== v0.12q: collisioni di casse/barili/forzieri, scheletro realistico ====== */
const BK={t:0};
const BKS=['barrel0','barrel1','crate','coil'];
function blkSync(dt){
  if(!(WORLD===1||WORLD===2)||!S||!S.live)return;
  BK.t-=dt;if(BK.t>0)return;BK.t=.4;
  const px=Math.floor(P.x/TS),py=Math.floor((P.y-2)/TS);
  for(const e of E){
    if(!(e.type==='loot'||(e.type==='deco'&&BKS.includes(e.spr))))continue;
    if(e.hid||e.inRoom||(e.got&&!sprOf(e))){if(e.bk&&e.blocked){if(e.bkfull){insetT[tIdx(e.fp[0],e.fp[1])]++;e.bkfull=0}delBlock(e)}continue}   // aperti restano solidi
    if(e.blocked||e.fp)continue;
    const tx=e.type==='loot'&&e.tx!=null?e.tx:Math.floor(e.x/TS),ty=e.type==='loot'&&e.ty!=null?e.ty:Math.floor((e.y-9)/TS);   // il corpo sta sopra la linea di base
    if(!inMap(tx,ty)||!walkT[tIdx(tx,ty)]||(tx===px&&ty===py))continue;
    if(huReg(tx,ty)||((tx>=CV_X0&&tx<CV_X0+CV_W&&ty>=CV_Y0&&ty<CV_Y0+CV_H)))continue;
    addBlock(e,tx,ty,1,1);e.bk=1;if(isInset(e)&&insetT[tIdx(tx,ty)]>0){insetT[tIdx(tx,ty)]--;e.bkfull=1}
  }
  obrBuild();
}
function drawCvSkel(g,e,t){
  const B1='#efe5c8',B2='#c9bd98',B3='#8e8466',L='#2a2418';
  const bone=(x1,y1,x2,y2,w)=>{g.lineCap='round';g.strokeStyle=L;g.lineWidth=w+2.2;g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke();g.strokeStyle=B2;g.lineWidth=w;g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke();g.strokeStyle=B1;g.lineWidth=w*.45;g.beginPath();g.moveTo(x1-.6,y1-.6);g.lineTo(x2-.6,y2-.6);g.stroke()};
  const knob=(x,y,r)=>{g.fillStyle=B1;g.strokeStyle=L;g.lineWidth=1.2;g.beginPath();g.arc(x,y,r,0,7);g.fill();g.stroke()};
  g.save();g.translate(e.x,e.y);
  shadow(g,0,4,34,9,.45);
  // stoffa strappata di giubba dietro le costole
  g.fillStyle='#2c3a44';g.strokeStyle='#10171c';g.lineWidth=1.4;
  g.beginPath();g.moveTo(-17,-46);g.quadraticCurveTo(-21,-30,-15,-17);g.lineTo(-11,-12);g.lineTo(-7,-17);g.lineTo(-3,-11);g.lineTo(2,-16);g.lineTo(7,-10);g.lineTo(12,-17);g.quadraticCurveTo(20,-31,16,-46);g.closePath();g.fill();g.stroke();
  g.fillStyle='rgba(0,0,0,.35)';g.fillRect(-12,-44,24,26);
  // gambe stese verso chi guarda
  bone(-5,-15,-15,-2,4.2);bone(5,-15,14,-1,4.2);
  bone(-15,-2,-24,10,3.6);bone(14,-1,23,11,3.6);
  knob(-15,-2,3.1);knob(14,-1,3.1);
  // stivali consumati
  g.fillStyle='#3a2a1c';g.strokeStyle=L;g.lineWidth=1.6;
  g.beginPath();g.moveTo(-28,6);g.lineTo(-20,6);g.lineTo(-19,15);g.lineTo(-31,14);g.closePath();g.fill();g.stroke();
  g.beginPath();g.moveTo(19,7);g.lineTo(27,7);g.lineTo(29,16);g.lineTo(17,15);g.closePath();g.fill();g.stroke();
  // bacino
  g.fillStyle=B2;g.strokeStyle=L;g.lineWidth=1.6;g.beginPath();g.ellipse(0,-15,12,6,0,0,7);g.fill();g.stroke();
  g.fillStyle='rgba(20,14,6,.7)';g.beginPath();g.ellipse(-4.5,-15,2.6,2.2,0,0,7);g.fill();g.beginPath();g.ellipse(4.5,-15,2.6,2.2,0,0,7);g.fill();
  // colonna vertebrale
  for(let i=0;i<8;i++){g.fillStyle=i%2?B2:B1;g.strokeStyle=L;g.lineWidth=1;g.beginPath();g.roundRect(-2.6,-20-i*3.3,5.2,3,1.2);g.fill();g.stroke()}
  // costole
  for(let i=0;i<5;i++){const y=-26-i*4.4,w=14-Math.abs(i-1.6)*1.4;
    for(const s of[-1,1]){
      g.strokeStyle=L;g.lineWidth=4;g.beginPath();g.moveTo(s*2,y);g.quadraticCurveTo(s*w,y-3.5,s*(w-3),y+4);g.stroke();
      g.strokeStyle=i%2?B2:B1;g.lineWidth=2.1;g.beginPath();g.moveTo(s*2,y);g.quadraticCurveTo(s*w,y-3.5,s*(w-3),y+4);g.stroke()}}
  g.strokeStyle=B2;g.lineWidth=3;g.beginPath();g.moveTo(0,-30);g.lineTo(0,-44);g.stroke();     // sterno
  // clavicole + braccia
  bone(-2,-46,-14,-44,3);bone(2,-46,14,-44,3);
  bone(-14,-44,-21,-31,3.4);bone(-21,-31,-12,-21,3);knob(-21,-31,2.6);
  bone(14,-44,20,-30,3.4);bone(20,-30,17,-17,3);knob(20,-30,2.6);
  // biglietto stretto nella mano sinistra
  g.save();g.translate(-12,-20);g.rotate(-.25);g.fillStyle='#eadcb4';g.strokeStyle='#5a4a2c';g.lineWidth=1.2;g.fillRect(-6,-4,12,9);g.strokeRect(-6,-4,12,9);
  g.strokeStyle='#7a6a48';g.lineWidth=.8;for(let k=0;k<3;k++){g.beginPath();g.moveTo(-4,-2+k*3);g.lineTo(4,-2+k*3);g.stroke()}g.restore();
  for(const[x,y]of[[-12,-19],[-9,-17],[17,-17],[20,-15],[15,-15]])knob(x,y,1.5);   // dita
  // teschio
  g.save();g.translate(0,-54);g.rotate(.1);
  const gr=g.createRadialGradient(-3,-4,1,0,0,11);gr.addColorStop(0,'#f6eed6');gr.addColorStop(.7,B1);gr.addColorStop(1,B3);
  g.fillStyle=gr;g.strokeStyle=L;g.lineWidth=1.8;g.beginPath();g.ellipse(0,0,9.5,9,0,0,7);g.fill();g.stroke();
  g.beginPath();g.roundRect(-5.5,5,11,6,2);g.fillStyle=B2;g.fill();g.stroke();                       // mandibola
  g.strokeStyle='#4a4028';g.lineWidth=.9;for(let k=-4;k<=4;k+=2){g.beginPath();g.moveTo(k,5.6);g.lineTo(k,10.4);g.stroke()}
  g.fillStyle='#0d0a06';g.beginPath();g.ellipse(-3.8,-.6,2.9,3.3,-.1,0,7);g.fill();g.beginPath();g.ellipse(3.8,-.6,2.9,3.3,.1,0,7);g.fill();   // orbite
  g.beginPath();g.moveTo(0,2.6);g.lineTo(-1.8,6);g.lineTo(1.8,6);g.closePath();g.fill();                                                          // naso
  g.strokeStyle='rgba(60,48,26,.8)';g.lineWidth=.9;g.beginPath();g.moveTo(3,-8.4);g.lineTo(5.4,-4.5);g.lineTo(4.2,-2);g.stroke();                  // crepa
  // bandana slavata
  g.fillStyle='#7a2a30';g.strokeStyle='#2c0c10';g.lineWidth=1.2;
  g.beginPath();g.moveTo(-9.4,-3.6);g.quadraticCurveTo(0,-13,9.4,-3.6);g.lineTo(8.6,-1);g.quadraticCurveTo(0,-9,-8.6,-1);g.closePath();g.fill();g.stroke();
  g.beginPath();g.moveTo(8.8,-3);g.lineTo(14,-1);g.lineTo(11.5,1.8);g.lineTo(13.5,5.5);g.lineTo(8.4,.5);g.closePath();g.fill();g.stroke();
  g.restore();
  // ossa sparse e polvere
  g.fillStyle=B2;g.strokeStyle=L;g.lineWidth=1;
  g.save();g.translate(-27,-1);g.rotate(.5);g.fillRect(-5,-1.2,10,2.4);g.strokeRect(-5,-1.2,10,2.4);g.restore();
  g.save();g.translate(27,3);g.rotate(-.3);g.fillRect(-4,-1.2,8,2.4);g.strokeRect(-4,-1.2,8,2.4);g.restore();
  g.restore();
}

/* collisione che segue la sagoma vera dell'oggetto (il corpo sta sopra la linea di base, non nel riquadro sotto) */
const OBR=[];
function sprOf(e){
  try{
    if(e.type==='deco')return e.spr==='barrel0'?SP.barrel[0]:e.spr==='barrel1'?SP.barrel[1]:e.spr==='crate'?SP.crate:e.spr==='coil'?SP.coil:null;
    if(e.type==='loot'){
      if(e.kind===9||e.kind===10||e.kind===11||(e.id&&e.id.indexOf('lt_rare')===0))return null;
      if(e.id==='lt_flint')return SP.barrel[1];if(e.id==='lt_line'||e.kind===8)return SP.crate;
      return SP.chest[e.kind]&&SP.chest[e.kind][0];
    }
  }catch(x){}
  return null;
}
function obrBuild(){
  OBR.length=0;
  for(const e of E){
    if(!e.bk||e.hid)continue;
    const s=sprOf(e);if(!s)continue;
    const cx=e.x-s.ax+s.w/2,hw=s.w*.4,dp=Math.min(s.h*.6,36);
    const o={x0:cx-hw,x1:cx+hw,y0:e.y-dp,y1:e.y+2,e};
    if(P.x>o.x0-12&&P.x<o.x1+12&&P.y>o.y0-12&&P.y<o.y1+12)continue;   // se ci sei già dentro, esci prima
    OBR.push(o);
  }
}
/* ---- vibrazione: indizi, tesori, missioni (si spegne dal menu) ---- */
const HAP={on:(()=>{try{return localStorage.getItem('sm_vib')!=='0'}catch(e){return true}})(),t:0};
function buzz(p){
  if(!HAP.on)return false;const n=Date.now();if(n-HAP.t<110)return true;HAP.t=n;
  try{
    const C=window.Capacitor,PL=C&&C.Plugins,arr=Array.isArray(p)?p:[p];
    if(PL&&PL.Haptics&&PL.Haptics.vibrate){let d=0;arr.forEach((v,i)=>{if(i%2===0)setTimeout(()=>{try{PL.Haptics.vibrate({duration:v})}catch(e){}},d);d+=v});return true}
    if(navigator.vibrate)return navigator.vibrate(arr)!==false;
  }catch(e){}
  return false;
}
{const HP={quest:[40,60,40],relic:[30,50,30,50,70],cra:[18,50,18],ok:12,no:[22],thud:24,thunder:[70,40,90],hammer:14,chop:18,mine:18};
 const o=sfx;sfx=function(n){try{const v=HP[n];if(v)buzz(v)}catch(e){}return o.apply(this,arguments)}}
