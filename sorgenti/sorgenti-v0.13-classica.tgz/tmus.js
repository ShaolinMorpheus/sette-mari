const {chromium}=require('playwright');(async()=>{const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.removeItem('sm_c34')}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2500);
const r=await p.evaluate(async()=>{const out=[];try{Ch4.auInit();}catch(e){out.push('auInit '+e.message)}
 await new Promise(r=>setTimeout(r,600));out.push(['ctx',Ch4.AU.ctx&&Ch4.AU.ctx.state,'mus',Ch4.AU.mus,'mood',Ch4.mood()]);
 let n=0;
 for(const dk of[0,1,2])for(const lv of[0,1,2]){window.__c4m={deck:dk,lvl:lv};for(let b=0;b<64;b++){try{Ch4.mtick(Ch4.AU.ctx.currentTime+.05+b*.01,b);n++}catch(e){out.push('ERR dk'+dk+' lv'+lv+' b'+b+' '+e.message);break}}}
 out.push(['tick ok',n]);
 // vero ciclo musicale per 3 secondi in ciascun livello
 for(const lv of[0,1,2]){window.__c4m={deck:0,lvl:lv};await new Promise(r=>setTimeout(r,1500))}
 return out});
console.log(JSON.stringify(r));console.log(er);await b.close()})();
