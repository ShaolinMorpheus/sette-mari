import json
s=open('base_index.html',encoding='utf8').read()
def rep(a,b):
    global s
    assert s.count(a)==1,(s.count(a),a[:80]);s=s.replace(a,b)
# 1. stella dei venti
rep("const PAL_FUG={sail:['#d3e6ec','#5f93a8'],flag:'#22344c',emblem:'claw',","const PAL_FUG={sail:['#d3e6ec','#5f93a8'],flag:'#22344c',emblem:'wind',")
rep("  }else{\n    g.strokeStyle='#7a1a10';g.lineWidth=6;g.lineCap='round';\n    g.beginPath();g.arc(-9,0,13,","""  }else if(type==='wind'){
    g.strokeStyle='#1f3550';g.lineWidth=2.2;g.beginPath();g.arc(0,0,23,0,7);g.stroke();
    const star=(r1,r2,n,rot,col)=>{g.fillStyle=col;g.beginPath();for(let i=0;i<n*2;i++){const a=i/(n*2)*Math.PI*2+rot,r=i%2?r2:r1;i?g.lineTo(Math.cos(a)*r,Math.sin(a)*r):g.moveTo(Math.cos(a)*r,Math.sin(a)*r)}g.closePath();g.fill()};
    star(22,4.2,4,-Math.PI/2,'#1f3550');star(14,3.4,4,-Math.PI/4,'#8c1d18');
    g.fillStyle='#f7efd8';g.beginPath();g.arc(0,0,2.8,0,7);g.fill();
  }else{
    g.strokeStyle='#7a1a10';g.lineWidth=6;g.lineCap='round';
    g.beginPath();g.arc(-9,0,13,""")
# 2. tenda nuova
a=s.index("function mkTent(){");b=s.index("function mkRowboat(){")
tent="""function mkTent(){
  return sp(128,106,g=>{
    shadowEll(g,62,98,58,9,.32);
    const A=[60,10],L=[6,95],M=[78,101],R=[121,88];
    const lerp=(p,q,k)=>[p[0]+(q[0]-p[0])*k,p[1]+(q[1]-p[1])*k];
    // corde e picchetti
    g.strokeStyle='#8a7048';g.lineWidth=1.3;g.lineCap='round';
    for(const[x1,y1,x2,y2]of[[33,53,12,102],[104,50,124,98]]){g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke();g.strokeStyle='#4a3420';g.lineWidth=2.4;g.beginPath();g.moveTo(x2-2,y2-4);g.lineTo(x2+1,y2+1);g.stroke();g.strokeStyle='#8a7048';g.lineWidth=1.3}
    // faccia destra, in ombra
    const face=(p0,p1,n,cA,cB,shade)=>{
      for(let i=0;i<n;i++){const e0=lerp(p0,p1,i/n),e1=lerp(p0,p1,(i+1)/n);g.fillStyle=i%2?cA:cB;g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(e0[0],e0[1]);g.lineTo(e1[0],e1[1]);g.closePath();g.fill()}
      g.save();g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(p0[0],p0[1]);g.lineTo(p1[0],p1[1]);g.closePath();g.clip();
      const q=g.createLinearGradient(A[0],A[1],(p0[0]+p1[0])/2,(p0[1]+p1[1])/2);q.addColorStop(0,'rgba(255,230,190,'+shade[0]+')');q.addColorStop(1,'rgba(20,6,2,'+shade[1]+')');g.fillStyle=q;g.fillRect(0,0,128,106);
      g.strokeStyle='rgba(50,18,10,.55)';g.lineWidth=1;for(let i=1;i<n;i++){const e=lerp(p0,p1,i/n);g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(e[0],e[1]);g.stroke()}
      g.restore()};
    face(M,R,5,'#b49f78','#8a2c20',[.0,.38]);
    // toppa cucita
    g.save();g.translate(100,72);g.rotate(.5);g.fillStyle='#d9c8a0';g.fillRect(-7,-6,14,12);g.strokeStyle='#5a4426';g.lineWidth=1;g.strokeRect(-7,-6,14,12);g.setLineDash([2,2]);g.strokeRect(-5,-4,10,8);g.restore();
    // faccia frontale, illuminata
    face(L,M,6,'#f4e8cc','#cf4a32',[.18,.1]);
    // porta aperta con due lembi legati
    const Pl=lerp(L,M,.30),Pr=lerp(L,M,.62),T=[A[0]-14,A[1]+42];
    g.fillStyle='#1b0d08';g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(Pl[0]+3,Pl[1]+1);g.lineTo(Pr[0],Pr[1]+1);g.closePath();g.fill();
    const ig=g.createLinearGradient(0,T[1],0,Pl[1]);ig.addColorStop(0,'rgba(0,0,0,.85)');ig.addColorStop(1,'rgba(70,40,20,.5)');g.fillStyle=ig;g.fill();
    g.fillStyle='#cf4a32';g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(Pl[0]-9,Pl[1]+1);g.lineTo(Pl[0]+3,Pl[1]+1);g.closePath();g.fill();g.strokeStyle='#3a1610';g.lineWidth=1.3;g.stroke();
    g.fillStyle='#f4e8cc';g.beginPath();g.moveTo(T[0],T[1]);g.lineTo(Pr[0]-1,Pr[1]+1);g.lineTo(Pr[0]+10,Pr[1]+1);g.closePath();g.fill();g.stroke();
    g.strokeStyle='#6b4a28';g.lineWidth=2;const k1=lerp([T[0],T[1]],[Pl[0]-3,Pl[1]],.55),k2=lerp([T[0],T[1]],[Pr[0]+4,Pr[1]],.55);g.beginPath();g.arc(k1[0],k1[1],2.6,0,7);g.stroke();g.beginPath();g.arc(k2[0],k2[1],2.6,0,7);g.stroke();
    // contorni
    g.strokeStyle='#3a1610';g.lineWidth=1.7;g.lineJoin='round';
    g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(L[0],L[1]);g.lineTo(M[0],M[1]);g.lineTo(R[0],R[1]);g.closePath();g.stroke();
    g.beginPath();g.moveTo(A[0],A[1]);g.lineTo(M[0],M[1]);g.stroke();
    // orlo a festoni
    g.strokeStyle='rgba(58,22,16,.7)';g.lineWidth=1.2;
    for(const[p0,p1,n]of[[L,M,9],[M,R,6]]){for(let i=0;i<n;i++){const e0=lerp(p0,p1,i/n),e1=lerp(p0,p1,(i+1)/n);g.beginPath();g.moveTo(e0[0],e0[1]-2.5);g.quadraticCurveTo((e0[0]+e1[0])/2,(e0[1]+e1[1])/2+1.5,e1[0],e1[1]-2.5);g.stroke()}}
    // polvere alla base
    const dg=g.createLinearGradient(0,82,0,102);dg.addColorStop(0,'rgba(90,60,30,0)');dg.addColorStop(1,'rgba(90,60,30,.35)');g.fillStyle=dg;g.beginPath();g.moveTo(L[0],L[1]);g.lineTo(M[0],M[1]);g.lineTo(R[0],R[1]);g.lineTo(R[0],R[1]-14);g.lineTo(M[0],M[1]-14);g.lineTo(L[0],L[1]-14);g.closePath();g.fill();
    // asta e bandierina
    g.strokeStyle='#3a2210';g.lineWidth=3;g.beginPath();g.moveTo(A[0],A[1]+1);g.lineTo(A[0],1);g.stroke();
    g.fillStyle='#cf4a32';g.beginPath();g.moveTo(A[0],2);g.quadraticCurveTo(A[0]+9,1,A[0]+15,5);g.quadraticCurveTo(A[0]+8,7,A[0],9);g.closePath();g.fill();g.strokeStyle='#3a1610';g.lineWidth=1;g.stroke();
  },62,98);
}
"""
s=s[:a]+tent+s[b:]
# 3. fuoco del campo
rep("function drawSmoke(g,x,y,t,n,sc,col){","""function drawCampFire(g,t){
  const sg=g.createRadialGradient(0,2,4,0,2,46);sg.addColorStop(0,'rgba(18,10,5,.7)');sg.addColorStop(1,'rgba(18,10,5,0)');g.fillStyle=sg;g.beginPath();g.ellipse(0,2,46,18,0,0,7);g.fill();
  const N=11,st=[];for(let i=0;i<N;i++){const a=i/N*Math.PI*2+.25;st.push([Math.cos(a)*31,Math.sin(a)*12+2,Math.sin(a),i])}
  const stone=o=>{const[x,y,,i]=o,rx=8+(i%3)*1.4,ry=5.2+(i%2)*.8;
    g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(x+1,y+3,rx,ry*.7,0,0,7);g.fill();
    const q=g.createLinearGradient(x,y-ry,x,y+ry);q.addColorStop(0,'#b9b4a8');q.addColorStop(1,'#6d695f');g.fillStyle=q;g.beginPath();g.ellipse(x,y-1,rx,ry,0,0,7);g.fill();
    g.strokeStyle='#38352f';g.lineWidth=1.3;g.stroke();g.fillStyle='rgba(255,255,255,.28)';g.beginPath();g.ellipse(x-2,y-3,rx*.5,ry*.35,0,0,7);g.fill();
    g.fillStyle='rgba(255,110,40,'+(.18+.08*Math.sin(t*9+i))+')';g.beginPath();g.ellipse(x*.9,y,rx*.8,ry*.6,0,0,7);g.fill()};
  for(const o of st)if(o[2]<0)stone(o);
  // letto di braci
  const pl=.8+.2*Math.sin(t*7);
  const eg=g.createRadialGradient(0,0,2,0,0,26);eg.addColorStop(0,'rgba(255,200,90,'+.9*pl+')');eg.addColorStop(.5,'rgba(230,80,20,'+.65*pl+')');eg.addColorStop(1,'rgba(120,30,10,0)');g.fillStyle=eg;g.beginPath();g.ellipse(0,1,27,10.5,0,0,7);g.fill();
  // ciocchi incrociati con le punte carbonizzate
  const log=(x1,y1,x2,y2,w)=>{g.lineCap='round';g.strokeStyle='#2a170c';g.lineWidth=w+2.4;g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke();g.strokeStyle='#76502c';g.lineWidth=w;g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke();g.strokeStyle='rgba(255,210,150,.35)';g.lineWidth=1.6;g.beginPath();g.moveTo(x1+1,y1-w*.25);g.lineTo(x2+1,y2-w*.25);g.stroke();
    g.fillStyle='#1c0f08';g.beginPath();g.arc(x2,y2,w*.55,0,7);g.fill();g.fillStyle='#c4502a';g.beginPath();g.arc(x2,y2,w*.28,0,7);g.fill()};
  log(-22,7,6,-5,8);log(22,6,-6,-5,8);log(-9,9,13,0,7);
  // fiamme: una principale e quattro lingue
  drawFlame(g,0,-5,t,1.3);
  for(let i=0;i<4;i++)drawFlame(g,[-13,-6,7,14][i],-3-(i%2)*2,t+i*1.9,.52+((i*37)%5)*.04);
  g.save();g.globalCompositeOperation='lighter';const hg=g.createRadialGradient(0,-8,2,0,-8,64);hg.addColorStop(0,'rgba(255,170,70,'+.22*pl+')');hg.addColorStop(1,'rgba(255,120,30,0)');g.fillStyle=hg;g.fillRect(-70,-74,140,140);g.restore();
  for(const o of st)if(o[2]>=0)stone(o);
  // scintille
  for(let i=0;i<8;i++){const p=(t*.5+i*.137)%1,x=Math.sin(i*5.1+t*1.4)*15*p+(i-4)*2.2,y=-16-p*70;g.fillStyle='rgba(255,'+(190+((i*29)%50))+',110,'+(1-p)+')';g.beginPath();g.arc(x,y,.7+(1-p)*1.5,0,7);g.fill()}
}
function drawSmoke(g,x,y,t,n,sc,col){""")
rep("if(smN){g.save();g.translate(FIX.smoke[0]*TS,FIX.smoke[1]*TS);shadow(g,0,2,26,8,.3);drawFlame(g,0,-4,t,1.05);g.restore()}","if(smN){g.save();g.translate(FIX.smoke[0]*TS,FIX.smoke[1]*TS);drawCampFire(g,t);g.restore()}")
rep("landing:[-60,-60],smoke:[58.4,30],","landing:[-60,-60],smoke:[58.5,30.5],")
# 4. decor interattivo
rep("  const tent=(id,x,y,flip,big)=>deco(id,'tent',x,y,[Math.floor(x)-1,Math.floor(y-.2),2,1],{nohit:1,flip:!!flip,k:big?1.18:1});","  const tent=(id,x,y,flip,big)=>deco(id,'tent',x,y,[Math.floor(x)-1,Math.floor(y-.2),2,1],{inter:'look',hitw:110,hith:90,label:'Tenda',flip:!!flip,k:big?1.18:1});")
rep("  deco('c2flag','bandiera',60.2,26.6,null,{nohit:1,k:1});","  deco('c2flag','bandiera',60.2,26.6,null,{nohit:1,k:1});\n  deco('c2fire','cfire',58.5,30.7,[58,30,1,1],{inter:'look',hitw:110,hith:50,label:'Il fuoco del campo'});")
# 5. look
rep("Ch2.look=function(e){\n  const c=C();\n","""Ch2.TENT={c2t0:["La tenda di Ferro: branda tirata a lucido, una mappa arrotolata e nemmeno una piega fuori posto.","ferro"],c2t1:["La tenda di Tito: tre coperte, briciole di pane e un angolo da cui si vede tutto il campo. Per caso, dice lui.","tito"],c2t2:["La tenda di Gnocco: profuma di cipolla e di cenere. Un mestolo dorme sul cuscino.","gnocco"],c2t3:["La tenda di Nives: chiodi in ordine di grandezza, due martelli e un cartello: «Non toccare».","nives"],c2t4:["Una tenda di scorte: sacchi, corde e odore di tela cerata. Qui dentro non dorme nessuno.",null]};
Ch2.look=function(e){
  const c=C();
  if(Ch2.TENT[e.id]){
    const T=Ch2.TENT[e.id];c.tentSeen=c.tentSeen||{};
    if(!c.tentSeen[e.id]){c.tentSeen[e.id]=1;sfx('ok');addXp(6);float(P.x,P.y-80,'+6 XP','#ffe27a')}
    UI.dlg([D('hero',T[0])]);return true}
  if(e.id==='c2fire'){
    c.fireDay=c.fireDay||{};
    let best=null,bd=1e9;for(const n of E)if(n.type==='npc'){const d=hyp(n.x-P.x,n.y-P.y);if(d<bd&&d<7*TS){bd=d;best=n}}
    if(!best){UI.dlg([D('hero',"Il fuoco del campo. Brace, scintille e silenzio.")]);return true}
    const w=best.who,L=Ch2.SAY.sit[w]||[],ln=L.length?L[(Math.random()*L.length)|0]:"...";
    const first=c.fireDay[w]!==S.day;c.fireDay[w]=S.day;
    UI.dlg([D('hero',"Mi siedo un momento accanto al fuoco del campo."),D(w,ln)],()=>{if(first)Ch2.addTrust(w,1)});return true}
""")
rep("case'deco':if(e.id==='cave')return{l:'Entra',i:'hand'};","case'deco':if(e.id==='c2fire')return{l:'Scaldati',i:'fire'};if(e.id==='cave')return{l:'Entra',i:'hand'};")
rows=[
["La tenda di Ferro: branda tirata a lucido, una mappa arrotolata e nemmeno una piega fuori posto.","Ferro's tent: a bunk made to perfection, a rolled-up map and not a single crease out of place.","Ferros Zelt: blitzblank gemachte Pritsche, eine aufgerollte Karte und keine einzige Falte am falschen Platz.","La tienda de Ferro: litera impecable, un mapa enrollado y ni una arruga fuera de su sitio.","La tente de Ferro : une couchette impeccable, une carte enroulée et pas un pli de travers."],
["La tenda di Tito: tre coperte, briciole di pane e un angolo da cui si vede tutto il campo. Per caso, dice lui.","Tito's tent: three blankets, bread crumbs and a corner with a view of the whole camp. By chance, he says.","Titos Zelt: drei Decken, Brotkrumen und eine Ecke mit Blick aufs ganze Lager. Zufällig, sagt er.","La tienda de Tito: tres mantas, migas de pan y un rincón desde donde se ve todo el campamento. Por casualidad, dice él.","La tente de Tito : trois couvertures, des miettes de pain et un coin d'où l'on voit tout le camp. Par hasard, dit-il."],
["La tenda di Gnocco: profuma di cipolla e di cenere. Un mestolo dorme sul cuscino.","Gnocco's tent: it smells of onion and ash. A ladle sleeps on the pillow.","Gnoccos Zelt: es riecht nach Zwiebeln und Asche. Eine Kelle schläft auf dem Kissen.","La tienda de Gnocco: huele a cebolla y ceniza. Un cucharón duerme sobre la almohada.","La tente de Gnocco : elle sent l'oignon et la cendre. Une louche dort sur l'oreiller."],
["La tenda di Nives: chiodi in ordine di grandezza, due martelli e un cartello: «Non toccare».","Nives's tent: nails sorted by size, two hammers and a sign: “Do not touch”.","Nives' Zelt: Nägel nach Größe sortiert, zwei Hämmer und ein Schild: „Nicht anfassen“.","La tienda de Nives: clavos ordenados por tamaño, dos martillos y un cartel: «No tocar».","La tente de Nives : des clous rangés par taille, deux marteaux et un panneau : « Ne pas toucher »."],
["Una tenda di scorte: sacchi, corde e odore di tela cerata. Qui dentro non dorme nessuno.","A supply tent: sacks, ropes and the smell of oilcloth. Nobody sleeps in here.","Ein Vorratszelt: Säcke, Seile und der Geruch von Wachstuch. Hier schläft niemand.","Una tienda de provisiones: sacos, cuerdas y olor a lona encerada. Aquí no duerme nadie.","Une tente de provisions : sacs, cordes et odeur de toile cirée. Personne n'y dort."],
["Il fuoco del campo. Brace, scintille e silenzio.","The camp fire. Embers, sparks and silence.","Das Lagerfeuer. Glut, Funken und Stille.","La hoguera del campamento. Brasas, chispas y silencio.","Le feu du camp. Braises, étincelles et silence."],
["Mi siedo un momento accanto al fuoco del campo.","I sit for a moment by the camp fire.","Ich setze mich kurz ans Lagerfeuer.","Me siento un momento junto a la hoguera del campamento.","Je m'assois un instant près du feu du camp."],
["Tenda","Tent","Zelt","Tienda","Tente"],
["Scaldati","Warm up","Aufwärmen","Calentarse","Se réchauffer"],
["Il fuoco del campo","The camp fire","Das Lagerfeuer","La hoguera del campamento","Le feu du camp"],
]
i=s.index('var PACK=');dec=json.JSONDecoder();arr,end=dec.raw_decode(s[i+len('var PACK='):]);arr+=rows
s=s[:i]+'var PACK='+json.dumps(arr,ensure_ascii=False)+s[i+len('var PACK=')+end:]
rep('    "Ladri notturni: basta avvicinarsi','    "Campo dei Fuggiaschi: tende ridisegnate (tela a spicchi, lembi legati, corde, bandierina), falò vero con cerchio di sassi, ciocchi, braci e scintille. Ora sono interattivi: puoi guardare dentro ogni tenda (la prima volta dà un po\' di esperienza) e scaldarti al fuoco ascoltando chi è vicino (una volta al giorno dà fiducia). Il simbolo sulla vela della nave è la stella dei venti.",\n    "Ladri notturni: basta avvicinarsi')
open('base_index.html','w',encoding='utf8').write(s)
print('ok')
