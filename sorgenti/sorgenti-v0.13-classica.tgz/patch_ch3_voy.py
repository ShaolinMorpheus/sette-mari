#!/usr/bin/env python3
# aggancia il Grande viaggio (modulo ch5_inject.js, inserito al marker // @@VOY@@) al motore navale del Convoglio
import sys
P='/home/claude/work/ch3_inject.js'
s=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global s
    n=s.count(old)
    if n!=cnt:
        print('FAIL (%d, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    s=s.replace(old,new)
rep("const ROUTE=(function(){","const ROUTE=VOY?[[0,0],[1,1]]:(function(){")
rep("emb:'#888',masts:[.4,0,-.36],mh:160,cannons:2}\n};",
    "emb:'#888',masts:[.4,0,-.36],mh:160,cannons:2},\n  fantasma:{L:112,W:34,hull:6,spd:104,name:'Il Gabbiano',hc:'#52706c',dk:'#27403e',trim:'#a8e0d0',sail:['#d6efe8','#9cc4ba'],emb:'#9fe8d0',masts:[.4,0,-.34],mh:158,cannons:4}\n};")
rep("function hurt(s,n){\n  if(s.dead)return;","function hurt(s,n){\n  if(s.dead)return;\n  if(s.type==='fantasma'){voyGhostHit(s,n);return}")
rep("  const tv=(go?SAILSPD[C.sail]:0)*windK(p.hd)*(p.disabled?0:1)*(1-.03*Math.min(C.silver,10));",
    "  let tv=(go?SAILSPD[C.sail]:0)*windK(p.hd)*(p.disabled?0:1)*(1-.03*Math.min(C.silver,10));\n  if(VOY)tv=voyTv(tv,go,dt);")
rep("  if(p.hull<=1&&!p.gunsOut){","  if(!VOY&&p.hull<=1&&!p.gunsOut){")
rep("  if(Math.hypot(p.x-pt[0],p.y-pt[1])<320&&p.hull<p.max){p.hull=Math.min(p.max,p.hull+dt*.8)","  if(!VOY&&Math.hypot(p.x-pt[0],p.y-pt[1])<320&&p.hull<p.max){p.hull=Math.min(p.max,p.hull+dt*.8)")
rep("  if(!C.tut)convoy(dt);","  if(!C.tut&&!VOY)convoy(dt);")
rep("    const dp=Math.hypot(p.x-s.x,p.y-s.y);\n    if((s.type==='scorta'","    const dp=Math.hypot(p.x-s.x,p.y-s.y);\n    if(s.type==='fantasma'){voyGhostAI(s,dt,dp);continue}\n    if((s.type==='scorta'")
rep("p.hull=Math.min(p.max,p.hull+.5);sfx('pick')","p.hull=Math.min(p.max,p.hull+(VOY?1:.5));sfx('pick')")
rep("    if(C.easy){p.hull=p.max;const q=TPp(24.5,31);","    if(VOY){voyRespawn()}else if(C.easy){p.hull=p.max;const q=TPp(24.5,31);")
rep("  // storia\n","  if(VOY){voyStep(dt)}else{\n  // storia\n")
rep("  tutStep();\n  hud();","  }\n  tutStep();\n  hud();")
rep("function drawShip(g,e,t){\n  const s=e.s,sp0=SPEC[s.type];",
    "function drawShip(g,e,t){\n  const s=e.s;\n  if(s.type==='fantasma'){g.save();g.globalCompositeOperation='lighter';const gl=g.createRadialGradient(s.x,s.y,10,s.x,s.y,190);gl.addColorStop(0,'rgba(120,255,220,.20)');gl.addColorStop(1,'rgba(120,255,220,0)');g.fillStyle=gl;g.fillRect(s.x-190,s.y-190,380,380);g.restore();g.save();g.globalAlpha=Math.max(0,(.5+.14*Math.sin(t*2+s.seed))*(1-(s.fade||0)));drawShip0(g,e,t);g.restore();return}\n  drawShip0(g,e,t)\n}\nfunction drawShip0(g,e,t){\n  const s=e.s,sp0=SPEC[s.type];")
rep("  drawPier(g,t);\n  {const pts=galPath();","  if(!VOY)drawPier(g,t);\n  {const pts=galPath();")
rep("function galPath(){return C?ROUTE.slice():null}","function galPath(){return C&&!VOY?ROUTE.slice():null}")
rep("  // zona del porto\n  const pt=TPp(21,30);g.save();g.strokeStyle='rgba(255,230,150,'","  if(VOY)voyFx(g,t);\n  // zona del porto\n  const pt=TPp(21,30);if(!VOY){g.save();g.strokeStyle='rgba(255,230,150,'")
rep("g.ellipse(pt[0],pt[1]+10,320,150,0,0,7);g.stroke();g.restore();\n}","g.ellipse(pt[0],pt[1]+10,320,150,0,0,7);g.stroke();g.restore();}\n}")
rep("  {const l=litSide();C.lit=l;const b=$('c3fire');","  if(VOY)voyHud();\n  {const l=litSide();C.lit=l;const b=$('c3fire');")
rep("  const g=o.getContext('2d');g.clearRect(0,0,w,h);\n","  const g=o.getContext('2d');g.clearRect(0,0,w,h);\n  if(VOY)voyOverlay(g,w,h);\n")
rep("  {const pt0=TPp(21,30),px=pt0[0],py=pt0[1];","  if(!VOY){const pt0=TPp(21,30),px=pt0[0],py=pt0[1];")
rep("  c.rotate(p.hd);c.fillStyle='#fff';c.beginPath();c.moveTo(10,0)","  if(VOY)voyMini(c,p,sc);\n  c.rotate(p.hd);c.fillStyle='#fff';c.beginPath();c.moveTo(10,0)")
rep("  cam.uz=.7;\n  newRun(true,PLAN0);sailUI();","  cam.uz=.7;\n  if(VOY){voyBoot();return}\n  newRun(true,PLAN0);sailUI();")
rep("function battleTick(){\n  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running'||!C)return;","function battleTick(){\n  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running'||!C)return;\n  if(VOY){voyMusic();return}")
rep("function parHint(){\n  const p=C.p;","function parHint(){\n  if(VOY)return voyHint();\n  const p=C.p;")
rep("parSay(h||pick(QUIPS),5600)","parSay(h||pick(VOY?VQUIPS:QUIPS),5600)")
rep('<button class="bt" id="c3bd">Abborda!</button>','<button class="bt" id="c3bd">Abborda!</button>\n<button class="bt" id="c3act" style="display:none"></button>')
rep("press($('c3fire'),pf);press($('c3bd'),board);","press($('c3fire'),pf);press($('c3bd'),board);press($('c3act'),()=>{if(VOY)voyAct()});")
rep("body.w3 #trow{left:auto!important;right:12px;top:8px}","body.w3 #trow{left:auto!important;right:12px;top:8px}\n#c3act{left:180px;right:auto;bottom:26px;width:84px;height:84px;font-size:15px;background:radial-gradient(circle at 35% 30%,#d4f4ff,#3aa6cf)}\nbody[data-hand=left] #c3fire{left:auto;right:76px}\nbody[data-hand=left] #c3act{left:auto;right:180px}\n#c3act[disabled]{filter:grayscale(.6) brightness(.85)}\n#c3zn{position:absolute;left:50%;transform:translateX(-50%);top:8px;max-width:34%;text-align:center;white-space:nowrap;font-size:13px}")
rep("window.Ch3={mkShip,onScr,","// @@VOY@@\nwindow.Ch3={voy:voyAPI,drawFloor:voyFloor,mkShip,onScr,")
rep("  {const h=document.createElement('button');h.className='lnk';h.textContent='Torna al gioco';",
    "  if(key<=2){const nb=document.createElement('button');nb.className='btn gold';nb.textContent='Continua: Il grande viaggio';nb.style.cssText='display:block;margin:10px auto 0';nb.onclick=()=>{try{localStorage.setItem('sm_c5',JSON.stringify({fresh:1,silver:C.silver,hull:8}))}catch(e){}try{__go('#w5')}catch(e){}location.reload()};$('endCard').appendChild(nb)}\n  {const h=document.createElement('button');h.className='lnk';h.textContent='Torna al gioco';")
rep("if(s===C.p){if(s.hull<=1)s.gunsOut=true;else if(s.hull>=s.max*.25)s.gunsOut=false;","if(s===C.p){if(!VOY&&s.hull<=1)s.gunsOut=true;else if(s.hull>=s.max*.25)s.gunsOut=false;")
rep("  s.hull-=n;s.flash=.2;\n  if(s.hull<=0){s.dead=true;","  s.hull-=n;s.flash=.2;\n  if(s===C.p&&s.hull<=0){s.hull=0;return}\n  if(s.hull<=0){s.dead=true;")
rep("const pierAt=(x,y)=>x>22.9*T","const pierAt=(x,y)=>!VOY&&x>22.9*T")
# scivolamento lungo la costa (niente piu' "muri": la nave striscia invece di piantarsi)
rep("  else if(shipOK(s,s.x,ny,s.hd))s.y=ny;\n  else{\n","  else if(shipOK(s,s.x,ny,s.hd))s.y=ny;\n  else if(VOY&&s===C.p&&voySlide(s,dt)){}\n  else{\n")
open(P,'w',encoding='utf8').write(s)
print('ok')
