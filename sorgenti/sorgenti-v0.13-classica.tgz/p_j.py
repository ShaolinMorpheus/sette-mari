f='base_index.html';s=open(f,encoding='utf-8').read()
def rep(a,b):
    global s
    assert s.count(a)==1,a[:60];s=s.replace(a,b)
# m8 bottle goal
rep("""   {k:'flag',done:()=>!!S.flags.compass,txt:"Apri la cassetta di ottone",hint:"È accanto alla tenda.",mark:()=>pt(EID.lt_old,60)}],
  onDone(){startQuest('m9')}},""","""   {k:'flag',done:()=>!!S.flags.compass,txt:"Apri la cassetta di ottone",hint:"È accanto alla tenda.",mark:()=>pt(EID.lt_old,60)},
   {k:'flag',done:()=>S.stat.bottles>=2,txt:()=>"Trova i messaggi in bottiglia: "+Math.min(2,S.stat.bottles)+"/2 (sull'isola ce ne sono 4)",hint:"Le bottiglie luccicano sulle spiagge. Chi le ha lasciate voleva essere letto: ogni messaggio dà un indizio.",mark:()=>pt(nearestE(['bottle'],b=>!b.got),50)}],
  onDone(){UI.dlg([D('hero',"Due messaggi, una sola mano: J. Qualcuno ha vissuto qui prima di me, e voleva essere trovato."),D('hero',"Li ritrovo sempre nel Diario, in «Archivio».")],()=>startQuest('m9'))}},""")
# bottle read
rep("""  UI.dlg([D('hero',BOTTLES[i%4])],()=>{UI.syncObj();checkAll()});
};""","""  S.flags.bread=S.flags.bread||{};S.flags.bread[i%4]=1;const n=Object.keys(S.flags.bread).length;
  UI.dlg([D('hero',"Un messaggio in bottiglia ("+n+"/4)."),D('hero',BOTTLES[i%4])],()=>{UI.syncObj();checkAll();
    if(S.flags.parrot&&n<4)setTimeout(()=>{if(!UI.dlgOpen()){say(PAR,n<2?"Cra! Ce ne sono altri. Cerca dove luccica!":"Cra! Ne manca ancora qualcuno. Io dico: spiagge!",4.2);sfx('cra')}},900)});
};""")
# pages
rep("""    const T=["«Sirena, giorno 3.""","""    const T=Ch2.PG;if(0)var _x=["«Sirena, giorno 3.""")
rep("""    sfx('ok');UI.dlg([D('hero',"Pagina "+(c.pages)+"/4 del diario di J."),D('hero',T[i%4])],()=>checkAll());return true}""","""    c.pgread=c.pgread||{};c.pgread[i%4]=1;
    if(i%4===1){try{const ce=EID.cave;if(ce)revealAll(Math.max(0,Math.floor(ce.x/TS)-9),Math.max(0,Math.floor(ce.y/TS)-9),Math.floor(ce.x/TS)+9,Math.floor(ce.y/TS)+9)}catch(_){}}
    sfx('ok');UI.dlg([D('hero',"Pagina "+(c.pages)+"/4 del diario di J."),D('hero',T[i%4]),D('hero',Ch2.PGCLUE[i%4]),D('biscotto',c.pages<4?"Cra! Cerca le altre pagine: la storia è a pezzi!":"Cra! Tutta la storia, finalmente!")],()=>checkAll());return true}""")
rep("Ch2.ENDS={","""Ch2.PG=["«Sirena, giorno 3. Il capitano sono io, ma è l'equipaggio che tiene a galla la barca. Non dimenticarlo, Giacomo.»","«Ho incontrato un uomo, Ferro, sull'isola grande. Dice di essere l'unico sopravvissuto del suo equipaggio. I conti non tornano: la sua nave aveva trenta uomini.»","«Ferro conta i posti, non le persone. Ho visto il suo quaderno: otto posti, nove nomi. Ha cancellato quelli che non gli servono.»","«Se leggi questo, sono già in mare. Sulla Sirena c'è ancora posto. Cerca la stella bassa a ovest e non dire a Ferro dove vai. — Giacomo M.»"];
Ch2.PGCLUE=["Indizio: chi ha costruito la nave sa dove sono finiti i pezzi. Tito li vede, anche se non lo ammette.","Indizio: Ferro nasconde ciò che gli serve in una grotta a sud-ovest del campo. Ora la zona è segnata sulla mappa.","Indizio: Nives sa cucire le vele meglio di chiunque. Ha solo bisogno di tela e fiducia.","Indizio: di notte, a ovest, c'è una stella bassa. È la rotta di J."];
Ch2.ENDS={""")
# quest j1
rep("n8:{kind:'side',title:\"Il diario di J.\"","""j1:{kind:'main',title:"Chi era J.?",blurb:"Le bottiglie e le pagine hanno la stessa mano. Qualcuno ha lasciato la verità in pezzi.",
  goals:[{k:'flag',done:()=>(C().pages||0)>=2,txt:()=>"Trova almeno 2 pagine del diario di J. ("+Math.min(2,C().pages||0)+"/2, in tutto sono 4)",hint:"Brillano di giorno e di notte in punti lontani dell'isola grande. Ogni pagina dà un indizio, e il pappagallo ti aiuta.",mark:()=>{const e=nearestE(['loot'],l=>l.kind===11&&!l.got);return pt(e,50)}}],
  onDone(){UI.dlg([D('hero',"Giacomo Marrone, capitano della Sirena. Lo stesso J. delle bottiglie."),D('hero',"Ferro lo conosceva. E ha deciso chi poteva salire a bordo, e chi no.")],()=>startQuest('c8'))}},
n8:{kind:'side',title:"Il diario di J.\"""")
rep("""  onDone(){UI.dlg([D('hero',"Cade con un tonfo che si sente in tutta l'isola. Il pezzo più grande è andato."),D('hero',"Restano il timone e le vele.")],()=>startQuest('c8'))}},""","""  onDone(){UI.dlg([D('hero',"Cade con un tonfo che si sente in tutta l'isola. Il pezzo più grande è andato."),D('hero',"Restano il timone e le vele.")],()=>startQuest('j1'))}},""")
# finale variants
rep("  c.endings=c.endings||{};\n  UI.cine(L,k,","""  {const pg=c.pages||0;
   L.push(pg>=4?D('hero',"Ho tutte le pagine di Giacomo. So chi era, so cosa ha fatto Ferro. Qualunque rotta prenda, la porterò come una promessa."):pg>=2?D('hero',"Di Giacomo ho solo qualche pagina. Il resto resterà un mistero, in mare."):D('hero',"Chi era J.? Non lo so davvero. Resterà un nome su una bottiglia."))}
  c.endings=c.endings||{};
  UI.cine(L,k,""")
# archivio
rep("  if(jTab==='r')return Extra.collectionHtml();","""  if(jTab==='a'){
    const br=(S.flags&&S.flags.bread)||{},pr=(WORLD===2||S.c2)?((S.c2&&S.c2.pgread)||{}):{};
    let h='<h3>Messaggi in bottiglia ('+Object.keys(br).length+'/4)</h3>';
    for(let i=0;i<4;i++)h+='<p class="sm">'+(br[i]?uEsc(BOTTLES[i]):'— non ancora trovato —')+'</p>';
    if(S.c2||WORLD===2){h+='<h3>Pagine del diario di J. ('+Object.keys(pr).length+'/4)</h3>';for(let i=0;i<4;i++)h+='<p class="sm">'+(pr[i]?uEsc(Ch2.PG[i]):'— non ancora trovata —')+'</p>'}
    return h}
  if(jTab==='r')return Extra.collectionHtml();""")
rep("[['q','Missioni'],['s','Stagione 1'],['r','Raccolta'],['n','Novità']]","[['q','Missioni'],['s','Stagione 1'],['r','Raccolta'],['a','Archivio'],['n','Novità']]")
rep('  {v:"0.8",d:"3 nov 2026",t:"Capitolo 3: Il Convoglio (bozza)",n:[','  {v:"0.8",d:"3 nov 2026",t:"Capitolo 3: Il Convoglio (bozza)",n:[\n    "Messaggi e pagine come storia principale: nel Capitolo 1 «Il campo abbandonato» chiede 2 messaggi in bottiglia su 4; nel Capitolo 2 nasce la tappa «Chi era J.?» (almeno 2 pagine su 4). Ogni messaggio dà un indizio, il pappagallo ti incoraggia, il finale cambia in base alle pagine lette. Nuovo Diario → Archivio per rileggerli.",')
open(f,'w',encoding='utf-8').write(s)
