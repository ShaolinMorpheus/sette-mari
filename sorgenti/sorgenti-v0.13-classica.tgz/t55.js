const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420},locale:'it-IT'})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/sette-mari/www/_t.html');await p.waitForTimeout(3500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(400)}
await p.waitForTimeout(3000);
await p.evaluate(()=>{__t.UI.showOverview(()=>{})});await p.waitForTimeout(1500);
await p.screenshot({path:'ov.png'});
console.log(await p.evaluate(()=>[...document.querySelectorAll('body *')].filter(e=>e.children.length===0&&e.textContent.trim()&&e.getBoundingClientRect().left<60&&e.getBoundingClientRect().top>250&&getComputedStyle(e).visibility!=='hidden'&&e.offsetParent).map(e=>e.id+'|'+e.className+'|'+e.textContent.slice(0,30))),er);await b.close()})()
