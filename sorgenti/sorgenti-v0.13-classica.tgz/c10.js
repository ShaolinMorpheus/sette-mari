const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:900,height:480}});const p=await ctx.newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
const U='file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html';
await p.goto(U);await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.screenshot({path:'slot0.png'});
// slot 2: new game
await p.click('#slotSeg button[data-s="2"]');
console.log('bCont hidden',await p.evaluate(()=>document.getElementById('bCont').hidden));
await p.fill('#inName','Due');
await p.evaluate(()=>{Pirati.startNew('Due','m')});
await p.waitForTimeout(500);
await p.evaluate(()=>{Pirati.S.day=5});
await p.evaluate(()=>{localStorage.setItem('sette-mari-pref','x')});
const keys=await p.evaluate(async()=>{ // force save
 try{document.getElementById('menuBtn')&&0}catch(e){}
 return Object.keys(localStorage)});
console.log(keys);
await p.reload();await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready);
console.log('slot after reload',await p.evaluate(()=>[...document.querySelectorAll('#slotSeg button')].map(b=>b.textContent+(b.classList.contains('on')?'*':''))));
await p.click('#slotSeg button[data-s="1"]');
console.log('s1 bCont hidden',await p.evaluate(()=>document.getElementById('bCont').hidden));
await p.evaluate(()=>{localStorage.setItem('sette-mari-text','2');});
await p.reload();await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready);
console.log('body class',await p.evaluate(()=>document.body.className));
await p.screenshot({path:'slot1.png'});
await b.close()})();
