/* ====== NOVITÀ v0.12g (A3): pesce aurora, fungo lunare, spaventapasseri col cappello, Traguardi, tasto «Salta» ====== */
const NV3={};

/* ---- tasto «Salta» sui dialoghi già letti (mai quelli con scelte) ---- */
NV3.seen=(()=>{try{return new Set(JSON.parse(localStorage.getItem('sm_seen')||'[]'))}catch(e){return new Set()}})();
NV3.hash=s=>{let h=5381;for(let i=0;i<s.length;i++)h=((h<<5)+h+s.charCodeAt(i))|0;return(h>>>0).toString(36)};
NV3.saveSeen=()=>{try{localStorage.setItem('sm_seen',JSON.stringify([...NV3.seen].slice(-700)))}catch(e){}};
NV3.skBtn=null;
NV3.skMk=function(){
  if(NV3.skBtn&&NV3.skBtn.isConnected)return NV3.skBtn;
  const box=document.getElementById('dlgBox');if(!box)return null;
  const b=document.createElement('button');b.id='dlgSkip';b.type='button';b.textContent='Salta ▸▸';
  b.style.cssText='position:absolute;right:10px;top:-34px;z-index:3;font:700 13px/1 system-ui,sans-serif;padding:8px 13px;border-radius:14px;border:2px solid #4a2c14;background:#f4e3b2;color:#3a2410;box-shadow:0 2px 6px rgba(0,0,0,.4);display:none;cursor:pointer';
  b.addEventListener('pointerdown',ev=>ev.stopPropagation());
  b.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();NV3.skip()});
  box.appendChild(b);NV3.skBtn=b;return b;
};
NV3.skShow=function(){const b=NV3.skMk();if(b)b.style.display=dl.sk?'block':'none'};
NV3.skInit=function(lines){
  const ls=(lines||[]).filter(Boolean);
  const key=NV3.hash(ls.map(l=>(l.w||'')+':'+(l.t||'')).join('¶'));
  const ok=ls.length>=2&&!ls.some(l=>l.choices);
  dl.sk=(ok&&NV3.seen.has(key))?key:null;
  if(ok&&!NV3.seen.has(key)){NV3.seen.add(key);NV3.saveSeen()}
  NV3.skShow();
};
NV3.skip=function(){if(!dl.open||!dl.sk)return;dl.q.length=0;dl.sk=null;NV3.skShow();dlgClose()};
{const _d0=UI.dlg;UI.dlg=function(lines,cb){const was=dl.open;_d0.call(UI,lines,cb);if(!was&&dl.open){try{NV3.skInit(lines)}catch(e){}}}}

/* ---- Traguardi ---- */
NV3.ach=()=>{const nv=NV.st();return nv.ach=nv.ach||{}};
{
  const st=k=>((S&&S.stat&&S.stat[k])||0);
  const ls1=k=>{try{return localStorage.getItem(k)==='1'}catch(e){return false}};
  NV3.AC=[
    {id:'ch1',n:'Sopravvissuto',d:'Concludi il Capitolo 1.',ok:()=>!!S.flags.ch1},
    {id:'ch2',n:'Capitano della Baia',d:'Concludi il Capitolo 2.',ok:()=>!!S.flags.ch2end},
    {id:'gal',n:'Assalto riuscito',d:'Concludi la battaglia al galeone.',ok:()=>ls1('sm_gal')},
    {id:'voy',n:'Fino al faro',d:'Arriva al faro nel Grande viaggio.',ok:()=>ls1('sm_c5done')},
    {id:'chop',n:'Boscaiolo',d:'Taglia 25 alberi.',v:()=>st('chopped'),m:25},
    {id:'stone',n:'Spaccapietre',d:'Spacca 20 rocce.',v:()=>st('stone'),m:20},
    {id:'forage',n:'Raccoglitore',d:'Raccogli bacche, molluschi e fibre 30 volte.',v:()=>st('forage'),m:30},
    {id:'bott',n:'Messaggi nel mare',d:'Trova 5 bottiglie.',v:()=>st('bottles'),m:5},
    {id:'crab',n:'Amico dei granchi',d:'Cattura 5 granchi.',v:()=>st('crabs'),m:5},
    {id:'built',n:'Mastro costruttore',d:'Costruisci 6 cose per il tuo campo.',v:()=>st('built'),m:6},
    {id:'chest',n:'Cacciatore di tesori',d:'Apri 6 casse.',v:()=>S.cOpen||0,m:6},
    {id:'relic',n:'Memoria del Cormorano',d:"Trova tutte le reliquie dell'equipaggio.",v:()=>relicCount(),m:RELICS.length},
    {id:'fish10',n:'Canna in mano',d:'Pesca 10 volte.',v:()=>st('fish'),m:10},
    {id:'fish50',n:'Maestro della lenza',d:'Pesca 50 volte.',v:()=>st('fish'),m:50},
    {id:'spec5',n:'Registro aperto',d:'Pesca 5 specie diverse.',v:()=>fishCount(),m:5},
    {id:'aurora',n:'La leggenda del mare',d:'Pesca il pesce aurora.',ok:()=>!!(S.fish&&S.fish.aurora)},
    {id:'orto5',n:'Pollice verde',d:"Raccogli 5 volte nell'orto.",v:()=>(S.gard&&S.gard.harv)||0,m:5},
    {id:'fungo',n:'Luce nel buio',d:'Fai crescere un fungo lunare.',ok:()=>!!NV.st().fgSeen||(S.res.fungo||0)>0},
    {id:'cook3',n:'Cuoco di bordo',d:'Cucina 3 ricette diverse al falò.',v:()=>Object.keys(S.rec||{}).length,m:3},
    {id:'dry3',n:'Dispensa del naufrago',d:"Essicca cibo 3 volte.",v:()=>(S.dry&&S.dry.done)||0,m:3},
    {id:'d7',n:"Una settimana sull'isola",d:'Resisti 7 giorni.',v:()=>S.day||1,m:7},
    {id:'d30',n:'Vecchio lupo di mare',d:'Resisti 30 giorni.',v:()=>S.day||1,m:30},
    {id:'lv5',n:'Marinaio',d:'Raggiungi il livello 5.',ok:()=>NV.lvOk(5)},
    {id:'lv10',n:'Navigatore',d:'Raggiungi il livello 10.',ok:()=>NV.lvOk(10)},
    {id:'coll',n:'Collezionista',d:'Metti 12 oggetti nel Quaderno.',v:()=>NV.total(),m:12},
    {id:'ward',n:'Elegante naufrago',d:'Possiedi 10 capi nel guardaroba.',v:()=>Object.keys(S.wown||{}).length,m:10},
    {id:'amici',n:'Un campo di amici',d:'Porta tutti i personaggi della Baia a 3 cuori.',ok:()=>{const c=Ch2.st();return['ferro','nives','tito','gnocco'].every(w=>((c.trust||{})[w]||0)>=6)}},
    {id:'cuore',n:'Cuore pieno',d:'Porta un personaggio della Baia a 5 cuori.',ok:()=>Object.values(Ch2.st().trust||{}).some(v=>v>=10)},
    {id:'segreti',n:'Segreti condivisi',d:'Vivi 4 scene di amicizia alla Baia.',v:()=>Object.keys(NV2.cp().fr).length,m:4},
    {id:'misura',n:'Su misura',d:'Fatti cucire un abito o un cappello da Nives.',ok:()=>{const s=NV2.cp().sew;return!!(s.out||s.hat)}}
  ];
  for(const x of NV3.AC)if(x.v&&!x.ok){const q=x;q.ok=()=>q.v()>=q.m}
}
NV3.q=[];NV3.qT=-99;NV3._t=0;
NV3.isOk=x=>{try{return!!x.ok()}catch(e){return false}};
NV3.tick=function(dt){
  if(!S||!S.live||PAUSED)return;
  NV3._t+=dt;if(NV3._t<1)return;NV3._t=0;
  const nv=NV.st();
  if((S.res.fungo||0)>0&&!nv.fgSeen)nv.fgSeen=1;
  const a=NV3.ach();
  if(!nv.achInit){      // salvataggi già avviati: i traguardi già raggiunti vengono segnati in silenzio
    nv.achInit=1;let n=0;
    for(const x of NV3.AC)if(NV3.isOk(x)){a[x.id]=S.day||1;n++}
    if(n>0)setTimeout(()=>{try{UI.toast('Nel Diario, scheda Raccolta, trovi i Traguardi: ne hai già '+n+'!')}catch(e){}},2500);
    return;
  }
  for(const x of NV3.AC)if(!a[x.id]&&NV3.isOk(x)){a[x.id]=S.day||1;NV3.q.push(x)}
  if(NV3.q.length&&!UI.dlgOpen()&&RT-NV3.qT>3.6){
    NV3.qT=RT;const x=NV3.q.shift();addXp(10);
    UI.banner('Traguardo',x.n+'\n'+x.d);sfx('quest');
  }
};
{const _t0=NV.tick;NV.tick=function(dt){_t0.call(NV,dt);try{NV3.tick(dt)}catch(err){frameErr(err)}}}
NV3.achHtml=function(){
  const a=NV3.ach(),n=NV3.AC.filter(x=>a[x.id]).length;
  let h='<h3>Traguardi · '+n+'/'+NV3.AC.length+'</h3><p class="sm">Piccole imprese da ricordare. Ognuna regala un po\' di esperienza.</p><ul class="wl">';
  for(const x of NV3.AC){
    const ok=!!a[x.id];let p='';
    if(!ok&&x.v){try{p=' ('+Math.min(x.v(),x.m)+'/'+x.m+')'}catch(e){}}
    h+='<li><b>'+(ok?'✔ ':'🔒 ')+uEsc(x.n)+'</b>'+uEsc(x.d)+p+'</li>';
  }
  return h+'</ul>';
};
{const _c1=Extra.collectionHtml;Extra.collectionHtml=function(){let t='';try{t=NV3.achHtml()}catch(e){}return _c1()+t}}

/* ---- fungo lunare: cresce solo di notte, più in fretta con la luna piena ---- */
NV3.nf=function(sleepy){
  const dark=skyLight(S.tod).dark>.3;
  if(!(dark||sleepy))return 0;
  return moonK()>=.75?2:1;
};
Ch2.GN.push({id:'zuppal',n:"Zuppa di luna",d:"La ricetta segreta di Gnocco: il fungo lunare dà una luce dolce, e la zuppa un'energia che dura a lungo. Sazia molto e rallenta la sete.",cost:{fungo:1,molluschi:2,pesce:1},h:90,t:45,buff:600,bres:600,
  gate:()=>(((S.gard&&S.gard.harv)||0)>=GC.fungo.need)||!!NV.st().fgSeen});

/* ---- lo spaventapasseri può indossare uno dei tuoi cappelli ---- */
NV3.SCH={
  bandana:(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.arc(x,y-1,6.8,Math.PI*1.04,Math.PI*1.96);g.quadraticCurveTo(x,y-3.6,x-6.6,y-1.6);g.fill();g.stroke();g.beginPath();g.moveTo(x+6,y-3);g.lineTo(x+11.5,y-.6);g.lineTo(x+7,y+1.6);g.closePath();g.fill();g.stroke()},
  tricorn:(g,x,y,c,tr)=>{g.fillStyle=c;g.beginPath();g.moveTo(x-12,y-3);g.quadraticCurveTo(x-10,y-11,x-6,y-10);g.quadraticCurveTo(x-2,y-14,x,y-11);g.quadraticCurveTo(x+2,y-14,x+6,y-10);g.quadraticCurveTo(x+10,y-11,x+12,y-3);g.quadraticCurveTo(x,y,x-12,y-3);g.fill();g.stroke();g.strokeStyle=tr||'#e0b13a';g.lineWidth=1.4;g.beginPath();g.moveTo(x-11.5,y-3);g.quadraticCurveTo(x,y,x+11.5,y-3);g.stroke()},
  straw:(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.ellipse(x,y-4,12.5,3.4,0,0,7);g.fill();g.stroke();g.beginPath();g.moveTo(x-6.5,y-4.5);g.quadraticCurveTo(x-6,y-12.5,x,y-12.5);g.quadraticCurveTo(x+6,y-12.5,x+6.5,y-4.5);g.closePath();g.fill();g.stroke();g.fillStyle='#b8452e';g.fillRect(x-6.2,y-7.2,12.4,2)},
  cap:(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.arc(x,y-3.4,6.8,Math.PI,0);g.closePath();g.fill();g.stroke();g.beginPath();g.ellipse(x+5.4,y-3,6,1.9,.1,0,7);g.fill();g.stroke()},
  chef:(g,x,y)=>{g.fillStyle='#f6f2e8';g.beginPath();g.arc(x-4,y-11,4,0,7);g.arc(x+4,y-11,4,0,7);g.arc(x,y-13.6,4.4,0,7);g.fill();g.fillRect(x-6.4,y-10,12.8,6.4);g.strokeRect(x-6.4,y-10,12.8,6.4)},
  turban:(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.ellipse(x,y-6,8,6.2,0,0,7);g.fill();g.stroke();g.strokeStyle='rgba(0,0,0,.35)';g.beginPath();g.moveTo(x-6,y-4);g.quadraticCurveTo(x,y-9,x+6,y-6);g.moveTo(x-5,y-8);g.quadraticCurveTo(x,y-12,x+6,y-9);g.stroke();g.fillStyle='#e8c24a';g.beginPath();g.arc(x,y-5,1.4,0,7);g.fill()},
  morion:(g,x,y)=>{g.fillStyle='#9aa4b0';g.beginPath();g.arc(x,y-3,6.8,Math.PI,0);g.closePath();g.fill();g.stroke();g.beginPath();g.ellipse(x,y-3,11,2.2,0,0,7);g.fill();g.stroke();g.fillStyle='#7a8490';g.beginPath();g.moveTo(x-1.4,y-9.6);g.lineTo(x,y-14.6);g.lineTo(x+1.4,y-9.6);g.closePath();g.fill();g.stroke()},
  crown:(g,x,y)=>{g.fillStyle='#e8c24a';g.beginPath();g.moveTo(x-6.4,y-3);g.lineTo(x-7.2,y-10);g.lineTo(x-3.4,y-6.6);g.lineTo(x,y-11.6);g.lineTo(x+3.4,y-6.6);g.lineTo(x+7.2,y-10);g.lineTo(x+6.4,y-3);g.closePath();g.fill();g.stroke();g.fillStyle='#d8412f';g.beginPath();g.arc(x,y-5.4,1.1,0,7);g.fill()},
  shells:(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.arc(x,y-2,6.6,Math.PI*1.05,Math.PI*1.95);g.closePath();g.fill();g.stroke();for(const d of[-4,0,4]){g.fillStyle='#fff4e0';g.beginPath();g.arc(x+d,y-7.4+Math.abs(d)*.25,2,Math.PI,0);g.closePath();g.fill();g.stroke()}},
  plume:(g,x,y,c)=>{NV3.SCH.cap(g,x,y,'#6a4a2a');g.fillStyle=c;g.beginPath();g.moveTo(x+3,y-8);g.quadraticCurveTo(x+13,y-16,x+10.5,y-2);g.quadraticCurveTo(x+7,y-8,x+3,y-8);g.fill();g.stroke()},
  guardia:(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.moveTo(x-6.8,y-3.6);g.lineTo(x-5.8,y-9.6);g.quadraticCurveTo(x,y-11.4,x+5.8,y-9.6);g.lineTo(x+6.8,y-3.6);g.closePath();g.fill();g.stroke();g.beginPath();g.ellipse(x,y-3.8,7.8,2.4,0,0,7);g.fill();g.stroke();g.fillStyle='#e8c24a';g.beginPath();g.arc(x,y-7,1.3,0,7);g.fill()},
  goggles:(g,x,y,c)=>{NV3.SCH.cap(g,x,y,c);g.fillStyle='#cfe6f2';for(const d of[-3,3]){g.beginPath();g.arc(x+d,y-6.8,2.1,0,7);g.fill();g.stroke()}},
  beanie:(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.arc(x,y-3,6.8,Math.PI,0);g.closePath();g.fill();g.stroke();g.fillStyle='#f4f0e6';g.fillRect(x-6.8,y-5.4,13.6,2.6);g.strokeRect(x-6.8,y-5.4,13.6,2.6);g.beginPath();g.arc(x,y-10.6,2.2,0,7);g.fill();g.stroke()},
  sou:(g,x,y,c)=>{g.fillStyle=c;g.beginPath();g.moveTo(x-7,y-3);g.quadraticCurveTo(x-7,y-11.4,x,y-11.4);g.quadraticCurveTo(x+7,y-11.4,x+7,y-3);g.quadraticCurveTo(x+11.5,y+1,x+10,y+3.4);g.quadraticCurveTo(x,y,x-7,y-3);g.closePath();g.fill();g.stroke()}
};
NV3.schList=()=>[null].concat(WEAR.filter(w=>w.k==='hat'&&S.wown&&S.wown[w.id]).map(w=>w.id));
NV3.schName=id=>{if(!id)return'cappello scuro (originale)';const w=WEAR.find(x=>x.id===id);return w?w.n:'?'};
NV3.schRow=function(){
  let nm='';try{nm=NV3.schName(NV.st().sch)}catch(e){return''}
  return'<div class="upg"><h3>Lo spaventapasseri</h3><p class="sm">Porta: <b>'+uEsc(nm)+'</b>. Può indossare uno dei tuoi cappelli.</p><button class="btn" id="schBtn">Cambia cappello</button></div>';
};
NV3.schWire=function(c,draw){
  const b=c.querySelector('#schBtn');if(!b)return;
  b.onclick=()=>{const L=NV3.schList(),nv=NV.st();let i=L.indexOf(nv.sch||null);if(i<0)i=0;nv.sch=L[(i+1)%L.length]||null;sfx('pick');draw()};
};
NV3.schDraw=function(g,x,y){
  try{
    const id=NV.st().sch;if(!id||!(S.wown&&S.wown[id]))return false;
    const w=WEAR.find(q=>q.id===id);if(!w)return false;
    const sp=(w.spec&&w.spec.hat)?w.spec:{hat:'tricorn',hatc:'#222836',trim:'#e0b13a'};
    const f=NV3.SCH[sp.hat]||NV3.SCH.cap;
    g.save();g.strokeStyle='#2a1508';g.lineWidth=1;f(g,x,y,sp.hatc||'#8a6a3a',sp.trim);g.restore();
    return true;
  }catch(e){return false}
};

/* ---- il fungo lunare nell'orto: disegno e bagliore notturno ---- */
NV3.fungoDraw=function(g,st,f,t,sw){
  const dark=(typeof S!=='undefined'&&S)?skyLight(S.tod).dark:0;
  g.strokeStyle='#1c2f6a';g.lineWidth=.9;
  if(st===0){g.fillStyle='#efe6c8';g.fillRect(-.9,-3,1.8,3);g.fillStyle='#8ab8ff';g.beginPath();g.arc(0,-3.4,1.7,Math.PI,0);g.closePath();g.fill();g.stroke();return}
  const r=st===1?3.2:st===2?4.8:6.6,h=st===1?4:st===2?6:8.6;
  if(st===3){const gl=g.createRadialGradient(0,-h,1,0,-h,19);gl.addColorStop(0,'rgba(130,195,255,'+(.3+.45*dark).toFixed(2)+')');gl.addColorStop(1,'rgba(130,195,255,0)');g.fillStyle=gl;g.beginPath();g.arc(0,-h,19,0,7);g.fill()}
  g.fillStyle='#efe6c8';g.beginPath();g.moveTo(-r*.3,0);g.lineTo(-r*.22,-h);g.lineTo(r*.22,-h);g.lineTo(r*.3,0);g.closePath();g.fill();g.stroke();
  g.fillStyle=st===3?'#6aa8ff':'#86b4f0';g.beginPath();g.ellipse(0,-h,r,r*.78,0,Math.PI,0);g.closePath();g.fill();g.stroke();
  if(st>=2){const a=st===3?.75+.25*Math.sin(t*2.2):.8;g.fillStyle='rgba(216,236,255,'+a.toFixed(2)+')';
    for(const[dx,dy,q]of[[-.45,.35,.2],[.4,.5,.16],[.02,.18,.14]]){g.beginPath();g.arc(dx*r,-h-dy*r,Math.max(.8,q*r),0,7);g.fill()}}
};
NV3.fungoLights=function(e,lights){
  const gd=S&&S.gard;if(!gd||!gd.pl)return;
  if(skyLight(S.tod).dark<.25)return;
  for(let i=0;i<4;i++){
    const p=gd.pl[i];if(!p||p.c!=='fungo'||!GC.fungo)continue;
    const f=Math.min(1,p.p/GC.fungo.t);if(f<.55)continue;
    const bx=-60+(i%2)*65,by=-44+((i/2)|0)*27;
    for(const dx of[14,43])lights.push([e.x+bx+dx,e.y+by+4,f>=1?78:52,f>=1?.55:.3,true]);
  }
};
