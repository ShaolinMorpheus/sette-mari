const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
const r=await p.evaluate(()=>{const P=Pirati;let walk=0,reach=0,free=0;const MW=99,MH=60;
 for(let y=0;y<MH;y++)for(let x=0;x<MW;x++){const t=P.tileInfo(x,y);if(t.walk)walk++;if(t.free)free++;if(P.reachable(x,y))reach++}
 // ascii map of reach
 let rows=[];for(let y=0;y<MH;y+=1){let s='';for(let x=0;x<MW;x++){const t=P.tileInfo(x,y);s+=t.sea?'~':!t.walk?'.':P.reachable(x,y)?(t.block?'#':'o'):'x'}rows.push(s)}
 return{walk,free,reach,rows}});
console.log(r.walk,r.free,r.reach);console.log(r.rows.join('\n'));
await b.close()})();
