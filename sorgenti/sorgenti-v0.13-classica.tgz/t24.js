const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
const r=await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.t=400;for(let i=0;i<5;i++)Ch3.step(.1);const g=C.ships.find(s=>s.type==='galeone');if(!g)return 'nogal';
 C.p.x=g.x-500;C.p.y=g.y;Ch3.step(.05);return [C.convoy,g.prog]});
await p.waitForTimeout(600);await p.screenshot({path:'c3d.png'});
const r2=await p.evaluate(()=>{const C=Ch3.C;const g=C.ships.find(s=>s.type==='galeone');C.p.hull=9999;C.p.max=9999;let n=0;while(!C.over&&n<40000){Ch3.step(.05);n++;C.p.x=-9999+0;C.p.x=3000;C.p.y=3000;if(C.p.dead)break}return [C.over,n,C.escapes,g&&g.dead,document.querySelector('#endCard h2')&&document.querySelector('#endCard h2').textContent]});
console.log(JSON.stringify(r),JSON.stringify(r2),errs);await b.close()})()
