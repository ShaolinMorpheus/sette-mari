#!/usr/bin/env python3
# v0.9: orto, essiccatore, guardaroba, copia stabile, voce «App per Android» tolta
import sys,re
src=open('/home/claude/work/base_index.pre_v09.html',encoding='utf8').read()
farm=open('/home/claude/work/farm_ward.js',encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)

# ---------- risorse nuove ----------
rep("function heroSpec(){\n  const f=window.__hero==='f',base=f?CH.hero_f:CH.hero_m;","function heroSpec_old(){\n  const f=window.__hero==='f',base=f?CH.hero_f:CH.hero_m;")
rep("const RES=['legna','pietra','corda','tela','rottami','coco','bacche','molluschi','pesce','arrosto'];",
    "const RES=['legna','pietra','corda','tela','rottami','coco','bacche','molluschi','pesce','arrosto','semi','patata','zucca','ananas','pescesec','fruttasec'];")
rep("pesce:'Pesce crudo',arrosto:'Pesce arrosto'};",
    "pesce:'Pesce crudo',arrosto:'Pesce arrosto',semi:'Semi',patata:'Patate dolci',zucca:'Zucche',ananas:'Ananas',pescesec:'Pesce secco',fruttasec:'Frutta secca'};")
rep('arrosto:"Si cucina il pesce crudo sul falò."};',
    'arrosto:"Si cucina il pesce crudo sul falò.",semi:"Li trovi costruendo l\'orto, e ogni raccolto ne restituisce almeno uno.",patata:"Cresce nell\'orto: pianta un seme e aspetta.",zucca:"Cresce nell\'orto, dopo qualche raccolto.",ananas:"Cresce nell\'orto, dopo diversi raccolti.",pescesec:"Si prepara nell\'essiccatore con il pesce crudo: non va a male.",fruttasec:"Si prepara nell\'essiccatore con bacche o ananas: non va a male."};')
rep("coco:{h:12,t:18,n:'una noce di cocco'}};",
    "coco:{h:12,t:18,n:'una noce di cocco'},patata:{h:24,t:0,n:'una patata dolce'},zucca:{h:20,t:6,n:'una zucca'},ananas:{h:16,t:24,n:'un ananas'},pescesec:{h:46,t:0,n:'pesce secco'},fruttasec:{h:26,t:4,n:'frutta secca'}};\nconst EATK=['molluschi','bacche','coco','patata','zucca','ananas','fruttasec'];")
rep("const RCAP0={molluschi:12,bacche:12,coco:10,pesce:8,arrosto:8};",
    "const RCAP0={molluschi:12,bacche:12,coco:10,pesce:8,arrosto:8,semi:12,patata:10,zucca:8,ananas:6,pescesec:12,fruttasec:12};")
# mangiare
rep("  for(const k of['molluschi','bacche','coco'])if(S.res[k]>0)return eatFood(k);\n  if(S.res.arrosto>0||S.res.pesce>0)return eatFish();",
    "  for(const k of EATK)if(S.res[k]>0)return eatFood(k);\n  if(S.res.arrosto>0||S.res.pesce>0||S.res.pescesec>0)return eatFish();")
rep("const k=S.res.arrosto>0?'arrosto':S.res.pesce>0?'pesce':null;","const k=S.res.arrosto>0?'arrosto':S.res.pesce>0?'pesce':S.res.pescesec>0?'pescesec':null;")
rep("  const nf=S.res.molluschi+S.res.bacche+S.res.coco;","  const nf=EATK.reduce((a,k)=>a+(S.res[k]||0),0);")
rep("{const cp=rcap('molluschi')+rcap('bacche')+rcap('coco');$('eatN')","{const cp=EATK.reduce((a,k)=>a+rcap(k),0);$('eatN')")
rep("cooked=S.res.arrosto>0,nfish=S.res.arrosto+S.res.pesce;","cooked=S.res.arrosto>0,nfish=S.res.arrosto+S.res.pesce+(S.res.pescesec||0);")
rep("const h='#i-'+(cooked?'arrosto':'pesce');","const fk=cooked?'arrosto':S.res.pesce>0?'pesce':'pescesec',h='#i-'+fk;")
rep("{const cp=rcap('pesce')+rcap('arrosto');$('fishN')","{const cp=rcap('pesce')+rcap('arrosto')+rcap('pescesec');$('fishN')")
rep("fb.setAttribute('aria-label',cooked?'Mangia pesce arrosto (+'+FOOD.arrosto.h+' fame)':'Mangia pesce crudo (+'+FOOD.pesce.h+' fame)');",
    "fb.setAttribute('aria-label','Mangia '+FOOD[fk].n+' (+'+FOOD[fk].h+' fame)');")

# ---------- ricette ----------
rep("cost:{arrosto:1,molluschi:2,coco:1,bacche:1},h:80,t:35,buff:420,bres:420}\n];",
    "cost:{arrosto:1,molluschi:2,coco:1,bacche:1},h:80,t:35,buff:420,bres:420},\n"
    "  {id:'patate',n:\"Patate dolci alla brace\",d:\"Cotte sotto la cenere: dolci, morbide e molto sazianti.\",cost:{patata:2,legna:1},h:54,t:0},\n"
    "  {id:'zuppazucca',n:\"Zuppa di zucca\",d:\"Cremosa, con latte di cocco. Ti dà energia per cinque minuti.\",cost:{zucca:1,coco:1},h:50,t:26,buff:300},\n"
    "  {id:'ananasbr',n:\"Ananas caramellato\",d:\"Ananas arrostito sul fuoco: la sete scende più lenta per sei minuti.\",cost:{ananas:1,legna:1},h:34,t:28,bres:360},\n"
    "  {id:'spezzatino',n:\"Spezzatino del naufrago\",d:\"Pesce secco, patate e zucca in pentola: il pasto più ricco dell'isola. Energia e sete lenta per otto minuti.\",cost:{pescesec:2,patata:1,zucca:1},h:96,t:20,buff:480,bres:480}\n];")

# ---------- cappellini del pappagallo ----------
rep("{id:'monocolo',n:'Monocolo',ic:'🧐'}];",
    "{id:'monocolo',n:'Monocolo',ic:'🧐'},{id:'tricorno',n:'Tricorno pirata',ic:'🎩'},{id:'paglia',n:'Cappello di paglia',ic:'👒'},{id:'fiore',n:'Fiore di ibisco',ic:'🌺'},{id:'corona',n:\"Coroncina d'oro\",ic:'👑'}];")

# ---------- decorazioni del campo: orto ed essiccatore ----------
rep("cost:{legna:2,rottami:1},cnt:1,at:[[-1.4,4.4]]}\n];",
    "cost:{legna:2,rottami:1},cnt:1,at:[[-1.4,4.4]]},\n"
    "  {k:'orto',n:\"L'orto\",d:\"Quattro zolle recintate con lo spaventapasseri: pianta i semi e raccogli cibo che cresce mentre esplori. La pioggia lo fa crescere più in fretta.\",cost:{legna:10,corda:4,pietra:3},cnt:1,alt:[[7.6,2.2],[0,8.2],[7.6,7],[-7.6,6.8],[-7.6,1.4],[7.6,-3.8],[-7.6,-3.6],[0,-8]]},\n"
    "  {k:'essic',n:\"L'essiccatore\",d:\"Un telaio di legno al sole: pesce e bacche seccano e diventano scorte che non vanno a male. Con la pioggia si ferma.\",cost:{legna:8,corda:4,rottami:1},cnt:1,alt:[[7.6,-3.6],[-7.6,-3.6],[7.6,1.2],[-7.6,1.4],[0,-8],[0,8.2],[7.6,7],[-7.6,6.8]]}\n];")
rep("function campTile(dx,dy){","function campTile(dx,dy,fp){")
rep("    if(tall.some(e=>hyp((e.tx!=null?e.tx+.5:e.x/TS)-(tx+.5),(e.ty!=null?e.ty+.5:e.y/TS)-(ty+.5))<(e.type==='plot'?2.8:e.type==='cdeco'?3.4:1.7)))continue;",
    "    if(fp){let bad=false;for(let j=1-fp[1];j<=0&&!bad;j++)for(let i=-fp[0];i<=fp[0];i++){const x=tx+i,y=ty+j;if(!freeT(x,y)||seaT[tIdx(x,y)]||elevT[tIdx(x,y)]<WL+.1){bad=true;break}}if(bad)continue}\n"
    "    if(tall.some(e=>hyp((e.tx!=null?e.tx+.5:e.x/TS)-(tx+.5),(e.ty!=null?e.ty+.5:e.y/TS)-(ty+.5))<(e.type==='plot'?2.8:e.type==='cdeco'?3.4:1.7)+(fp?.7:0)))continue;")
rep("function campBuild(d){\n  S.camp=S.camp||[];const placed=[];\n",
    "function campBuild(d){\n  S.camp=S.camp||[];const placed=[];\n  if(d.alt){const f=EID.plot_falo,cx=f?f.fp[0]+.5:FIX.camp[0],cy=f?f.fp[1]+.5:FIX.camp[1];let bt=null,bd=1e9;for(const a of d.alt){const t=campTile(a[0],a[1],[1,2]);if(!t)continue;const dv=hyp(t[0]+.5-(cx+a[0]),t[1]+.5-(cy+a[1]));if(dv<=2.6){bt=t;break}if(dv<bd){bd=dv;bt=t}}if(bt){campAdd(d.k,bt[0],bt[1]);S.camp.push({k:d.k,tx:bt[0],ty:bt[1]});return 1}return 0}\n")
# interazione con le nuove costruzioni
rep("case'cdeco':return e.k==='amaca'||e.k==='tavolo'||e.k==='cartello';","case'cdeco':return e.k==='amaca'||e.k==='tavolo'||e.k==='cartello'||e.k==='orto'||e.k==='essic';")
rep("case'cdeco':return e.k==='amaca'?{l:'Riposa',i:'bed'}:e.k==='tavolo'?","case'cdeco':return e.k==='orto'?{l:'Orto',i:'hand'}:e.k==='essic'?{l:'Essiccatore',i:'hand'}:e.k==='amaca'?{l:'Riposa',i:'bed'}:e.k==='tavolo'?")
rep("    case'cdeco':\n      if(e.k==='amaca'){UI.nap();return}","    case'cdeco':\n      if(e.k==='orto'){UI.openGarden();return}\n      if(e.k==='essic'){UI.openDryer();return}\n      if(e.k==='amaca'){UI.nap();return}")
rep("const reachLimit=e=>(REACHK[e.type]||1.7)*TS;","const reachLimit=e=>(e.type==='cdeco'&&(e.k==='orto'||e.k==='essic')?2.5:(REACHK[e.type]||1.7))*TS;")
# disegno
rep("    g.font='800 11px Nunito,Arial,sans-serif';g.fillText(nm,0,-42);\n  }\n  g.restore();\n}\nconst RAFTSAIL=",
    "    g.font='800 11px Nunito,Arial,sans-serif';g.fillText(nm,0,-42);\n  }else if(e.k==='orto'){drawOrto(g,e,t)}\n  else if(e.k==='essic'){drawEssic(g,e,t)}\n  g.restore();\n}\nconst RAFTSAIL=")
# modulo principale (prima del banco da lavoro)
rep("UI.openUpgrades=function(){\n  if(!S.built.banco)", farm+"\nUI.openUpgrades=function(){\n  if(!S.built.banco)")
# costruzione dal banco
rep("payRes(d.cost);sfx('hammer');sparkBurst(P.x,P.y-40,12);addXp(10);UI.sync();UI.banner('Campo migliorato',d.n);",
    "payRes(d.cost);sfx('hammer');sparkBurst(P.x,P.y-40,12);addXp(10);UI.sync();UI.banner('Campo migliorato',d.n);farmBuilt(d.k);")
# ---------- tracce di zampe ridisegnate + quadro della capanna spostato ----------
rep('else for(let i=0;i<5;i++){g.beginPath();g.ellipse(-16+i*8,(i%2?3:-3),3,1.7,.3,0,7);g.fill();g.beginPath();g.ellipse(-14+i*8,(i%2?3:-3),1.3,1,.3,0,7);g.fill()}',"else{const dr=e.k===1?-1:1;for(let i=0;i<5;i++){\n      g.save();g.translate((-30+i*15)*dr,i%2?5:-4);g.rotate(dr*Math.PI/2+(i%2?.2:-.2)*dr);g.scale(1.05,1.05);g.globalAlpha=1-i*.12;\n      const pr=(ox,oy,col)=>{g.fillStyle=col;g.beginPath();g.moveTo(ox,oy+4.2);g.bezierCurveTo(ox-6.2,oy+4,ox-6.4,oy-.2,ox-3,oy-1.4);g.quadraticCurveTo(ox,oy-2.4,ox+3,oy-1.4);g.bezierCurveTo(ox+6.4,oy-.2,ox+6.2,oy+4,ox,oy+4.2);g.fill();\n        for(const[tx,ty,ta]of[[-5.3,-3.6,-.5],[-1.9,-6,-.12],[1.9,-6,.12],[5.3,-3.6,.5]]){g.beginPath();g.ellipse(ox+tx,oy+ty,1.6,2.1,ta,0,7);g.fill()}};\n      pr(.5,.7,'rgba(255,238,200,.32)');pr(0,0,'rgba(54,34,17,.7)');g.restore()}}")
rep("{const px=19.4*TS,py=4;huRR(g,px,py,34,28,2,'#e4d2a0','#6a4426');","{const px=24.2*TS,py=4;huRR(g,px,py,34,28,2,'#e4d2a0','#6a4426');")
# ---------- orto/essiccatore: se il campo è affollato cerca più lontano e con distanze ridotte ----------
rep("function campTile(dx,dy,fp){","function campTile(dx,dy,fp,rx){")
rep("for(let r=-6;r<=6;r++)for(let q=-6;q<=6;q++){\n    const tx=Math.floor(cx+dx+q)","for(let r=-(rx?13:6);r<=(rx?13:6);r++)for(let q=-(rx?13:6);q<=(rx?13:6);q++){\n    const tx=Math.floor(cx+dx+q)")
rep("<(e.type==='plot'?2.8:e.type==='cdeco'?3.4:1.7)+(fp?.7:0)))continue;","<(rx?(e.type==='plot'||e.type==='cdeco'?2.4:1.4):(e.type==='plot'?2.8:e.type==='cdeco'?3.4:1.7))+(fp?.7:0)))continue;")
rep("if(bt){campAdd(d.k,bt[0],bt[1]);S.camp.push({k:d.k,tx:bt[0],ty:bt[1]});return 1}","if(!bt)for(const a of d.alt){const t=campTile(a[0],a[1],[1,2],1);if(t){bt=t;break}}\n    if(bt){campAdd(d.k,bt[0],bt[1]);S.camp.push({k:d.k,tx:bt[0],ty:bt[1]});return 1}")
# ---------- banco da lavoro: messaggi chiari (materiali mancanti / niente spazio) ----------
rep("""else h+=costHtml(d.cost)+'<button class="btn gold" data-dc="'+d.k+'"'+(hasRes(d.cost)?'':' disabled')+'>Costruisci</button>';""",
    """else h+=costHtml(d.cost)+(hasRes(d.cost)?'':'<div class="req">Ti mancano dei materiali.</div>')+'<button class="btn gold" data-dc="'+d.k+'"'+(hasRes(d.cost)?'':' disabled')+'>Costruisci</button>';""")
rep("""if(!campBuild(d)){UI.toast("Non c'è spazio libero intorno al campo per questa decorazione.");sfx('no');return}""",
    """if(!campBuild(d)){const o=b.parentNode.querySelector('.req.sp');if(!o)b.insertAdjacentHTML('beforebegin','<div class="req sp">Non c\\'è spazio libero intorno al campo per questa decorazione.</div>');sfx('no');return}""")
rep("const DECOR_QUIPS={lanterne:","const DECOR_QUIPS={orto:\"Cra! Un orto! Io controllo i semi. A morsi.\",essic:\"Cra! Pesce appeso! Solo guardare, giuro.\",lanterne:")
# tempo di gioco, sonno
rep("function updateTime(dt){\n  S.tod+=dt/DAYLEN;","function updateTime(dt){\n  try{farmTick(dt)}catch(e){if(!updateTime.er){updateTime.er=1;console.error('farm',e)}}\n  S.tod+=dt/DAYLEN;")
rep("    S.tod+=2;if(S.tod>=24){S.tod-=24;S.day++;S.stat.days=S.day}","    farmAdvance(2*DAYLEN,true);S.tod+=2;if(S.tod>=24){S.tod-=24;S.day++;S.stat.days=S.day}")
rep("    const night=S.tod>=19;S.tod=7;if(night){S.day++;S.stat.days=S.day}S.buff=0;","    const night=S.tod>=19;farmAdvance((night?(7-S.tod+24)%24:(S.tod<7?7-S.tod:0))*DAYLEN,true);S.tod=7;if(night){S.day++;S.stat.days=S.day}S.buff=0;")
# capitoli: il guardaroba passa da un'isola all'altra
rep("for(const k of['phats','phat','rec','xpt','cOpen','pname','hints','sound','music'])if(s0[k]!=null)d[k]=s0[k];",
    "for(const k of['phats','phat','rec','xpt','cOpen','pname','hints','sound','music','wown','wear'])if(s0[k]!=null)d[k]=s0[k];")
rep("n.pname=s.pname;n.phat=s.phat;n.phats=s.phats;n.rec=s.rec;n.xpt=s.xpt;n.cOpen=s.cOpen;n.hints=s.hints;",
    "n.pname=s.pname;n.phat=s.phat;n.phats=s.phats;n.rec=s.rec;n.xpt=s.xpt;n.cOpen=s.cOpen;n.hints=s.hints;n.wown=s.wown;n.wear=s.wear;")

# ---------- guardaroba: personaggio ----------
# nuovi cappelli sul protagonista
rep("g.beginPath();g.arc(6,hy-19,6,Math.PI*1.4,Math.PI*2.8);g.stroke();\n  }\n  g.restore();\n  g.restore();",
"""g.beginPath();g.arc(6,hy-19,6,Math.PI*1.4,Math.PI*2.8);g.stroke();
  }else if(hat==='straw'){
    const c1=hc||'#e0c070';
    g.fillStyle=dk(c1,.88);g.beginPath();g.ellipse(0,hy-5,hr+10,3.6,0,0,7);g.fill();g.strokeStyle='rgba(60,36,10,.7)';g.lineWidth=1.2;g.stroke();
    const q=g.createLinearGradient(0,hy-18,0,hy-5);q.addColorStop(0,'#f2e0a0');q.addColorStop(1,c1);
    g.fillStyle=q;g.beginPath();g.moveTo(-hr+.6,hy-5);g.quadraticCurveTo(-hr,hy-18,0,hy-18);g.quadraticCurveTo(hr,hy-18,hr-.6,hy-5);g.closePath();g.fill();g.stroke();
    g.fillStyle='#c9372c';g.fillRect(-hr+.9,hy-9.2,2*hr-1.8,2.6);
    g.strokeStyle='rgba(120,80,20,.45)';g.lineWidth=.8;for(let i=-2;i<=2;i++){g.beginPath();g.moveTo(i*3.4,hy-17.5);g.lineTo(i*3.7,hy-9.8);g.stroke()}
  }else if(hat==='chef'){
    g.fillStyle='#fff';g.strokeStyle='#8a8a9a';g.lineWidth=1.2;
    for(const[cx,cy,r]of[[-6,-17,6],[0,-21,7],[6,-17,6]]){g.beginPath();g.arc(cx,hy+cy,r,0,7);g.fill();g.stroke()}
    g.beginPath();g.rect(-hr+.8,hy-12,2*hr-1.6,7);g.fill();g.stroke();
    g.fillRect(-hr+1.4,hy-13,2*hr-2.8,3);
    g.strokeStyle='rgba(120,120,140,.5)';g.beginPath();g.moveTo(-3,hy-10);g.lineTo(-3,hy-6);g.moveTo(3,hy-10);g.lineTo(3,hy-6);g.stroke();
  }else if(hat==='turban'){
    const c1=hc||'#b8362c';
    const q=g.createLinearGradient(-hr,hy-18,hr,hy-4);q.addColorStop(0,dk(c1,1.3));q.addColorStop(1,dk(c1,.78));
    g.fillStyle=q;g.beginPath();g.ellipse(0,hy-8,hr+3,9,0,Math.PI,Math.PI*2);g.lineTo(hr+3,hy-5);g.quadraticCurveTo(0,hy-1.5,-hr-3,hy-5);g.closePath();g.fill();g.strokeStyle='rgba(30,10,6,.7)';g.lineWidth=1.2;g.stroke();
    g.strokeStyle='rgba(255,255,255,.3)';g.lineWidth=1.3;for(let i=0;i<3;i++){g.beginPath();g.moveTo(-hr-1+i*1.2,hy-6-i*2.6);g.quadraticCurveTo(0,hy-11-i*2.6,hr+1-i*1.2,hy-6-i*2.6);g.stroke()}
    g.fillStyle='#ffd23a';g.beginPath();g.arc(0,hy-12.5,2.2,0,7);g.fill();g.strokeStyle='#7a5a08';g.lineWidth=.9;g.stroke();
    g.fillStyle='#46c0c8';g.beginPath();g.arc(0,hy-12.5,.9,0,7);g.fill();
  }else if(hat==='crown'){
    const q=g.createLinearGradient(0,hy-21,0,hy-6);q.addColorStop(0,'#fff0a0');q.addColorStop(1,'#d9a21f');
    g.fillStyle=q;g.beginPath();g.moveTo(-hr+.6,hy-5);g.lineTo(-hr+.2,hy-17);g.lineTo(-hr*.5,hy-11);g.lineTo(0,hy-20.5);g.lineTo(hr*.5,hy-11);g.lineTo(hr-.2,hy-17);g.lineTo(hr-.6,hy-5);g.closePath();g.fill();g.strokeStyle='#6a4a08';g.lineWidth=1.3;g.stroke();
    g.fillStyle='#d8412f';g.beginPath();g.arc(0,hy-9.4,1.9,0,7);g.fill();g.fillStyle='#2f7fd0';g.beginPath();g.arc(-5.4,hy-8.6,1.3,0,7);g.arc(5.4,hy-8.6,1.3,0,7);g.fill();
    g.fillStyle='#fff6c0';for(const[px,py]of[[-hr+.2,hy-17.4],[0,hy-20.8],[hr-.2,hy-17.4]]){g.beginPath();g.arc(px,py,1.3,0,7);g.fill()}
  }else if(hat==='morion'){
    const q=g.createLinearGradient(-hr,0,hr,0);q.addColorStop(0,'#e4e8ee');q.addColorStop(.5,'#aab2bc');q.addColorStop(1,'#5f6772');
    g.fillStyle=q;g.beginPath();g.moveTo(-hr-1,hy-4);g.quadraticCurveTo(-hr-1,hy-17,0,hy-17.5);g.quadraticCurveTo(hr+1,hy-17,hr+1,hy-4);g.closePath();g.fill();g.strokeStyle='#2c323b';g.lineWidth=1.3;g.stroke();
    g.fillStyle='#8a929c';g.beginPath();g.moveTo(-hr-9,hy-8);g.quadraticCurveTo(-hr-3,hy-1,0,hy-3);g.quadraticCurveTo(hr+3,hy-1,hr+9,hy-8);g.quadraticCurveTo(hr+2,hy-5.5,0,hy-6.4);g.quadraticCurveTo(-hr-2,hy-5.5,-hr-9,hy-8);g.closePath();g.fill();g.stroke();
    g.strokeStyle='#707984';g.lineWidth=2.4;g.lineCap='round';g.beginPath();g.moveTo(-1.2,hy-17.2);g.quadraticCurveTo(0,hy-22.5,1.2,hy-17.2);g.stroke();
    g.fillStyle='#e0b13a';for(const px of[-5.4,5.4]){g.beginPath();g.arc(px,hy-8.2,.9,0,7);g.fill()}
  }
  g.restore();
  g.restore();""")
# nuovi cappellini sul pappagallo
rep("g.fillStyle='rgba(200,235,255,.28)';g.beginPath();g.arc(8.6,-9.8,3.7,0,7);g.fill()}\n  // zampe",
"""g.fillStyle='rgba(200,235,255,.28)';g.beginPath();g.arc(8.6,-9.8,3.7,0,7);g.fill()}
  else if(o.hat==='tricorno'){g.fillStyle='#1d2230';g.strokeStyle='#050810';g.lineWidth=.9;g.beginPath();g.moveTo(-1,-12);g.quadraticCurveTo(0,-19,5,-18);g.quadraticCurveTo(7,-21,9,-18);g.quadraticCurveTo(14,-19,14,-12);g.quadraticCurveTo(6.5,-9.5,-1,-12);g.closePath();g.fill();g.stroke();g.strokeStyle='#e0b13a';g.lineWidth=1;g.beginPath();g.moveTo(-.6,-11.8);g.quadraticCurveTo(6.5,-9.4,13.6,-11.8);g.stroke();g.fillStyle='#f4efe0';g.beginPath();g.arc(6.5,-15,1.2,0,7);g.fill()}
  else if(o.hat==='paglia'){g.fillStyle='#d2b062';g.strokeStyle='#5a3a10';g.lineWidth=.9;g.beginPath();g.ellipse(6,-13.6,10.4,2.5,0,0,7);g.fill();g.stroke();g.fillStyle='#ecd488';g.beginPath();g.moveTo(1.4,-13.4);g.quadraticCurveTo(1.4,-21,6,-21);g.quadraticCurveTo(10.6,-21,10.6,-13.4);g.closePath();g.fill();g.stroke();g.fillStyle='#c9372c';g.fillRect(1.6,-16.4,8.8,1.8)}
  else if(o.hat==='fiore'){g.fillStyle='#4f9a3a';g.strokeStyle='#1f4a14';g.lineWidth=.8;g.beginPath();g.ellipse(-.4,-13.6,3.4,1.5,.6,0,7);g.fill();g.stroke();g.fillStyle='#ff5a78';g.strokeStyle='#8a1034';for(let i=0;i<5;i++){const a=i/5*6.283-1.57;g.beginPath();g.ellipse(2.6+Math.cos(a)*2.4,-15.6+Math.sin(a)*2.4,2,1.5,a,0,7);g.fill();g.stroke()}g.fillStyle='#ffd23a';g.beginPath();g.arc(2.6,-15.6,1.2,0,7);g.fill()}
  else if(o.hat==='corona'){g.fillStyle='#f2c230';g.strokeStyle='#6a4a08';g.lineWidth=.9;g.beginPath();g.moveTo(1.4,-13);g.lineTo(1,-20);g.lineTo(3.8,-16.4);g.lineTo(6.2,-22);g.lineTo(8.8,-16.4);g.lineTo(11.4,-20);g.lineTo(11,-13);g.closePath();g.fill();g.stroke();g.fillStyle='#d8412f';g.beginPath();g.arc(6.2,-15,1.1,0,7);g.fill()}
  // zampe""")
# raccolta: sezione guardaroba
rep("uEsc(r.h)+'</div></div>').join('');\n  return h;\n};","uEsc(r.h)+'</div></div>').join('');\n  h+=wardCollectionHtml();\n  return h;\n};")

# ---------- menu: scheda Guardaroba ----------
rep("const tabs=[['au','🔊','Audio e schermo'],['pa','💾','Partita'],hasP?","const tabs=[['au','🔊','Audio e schermo'],['pa','💾','Partita'],['gd','👒','Guardaroba'],hasP?")
rep("  const curH=PHATS.find(x=>x.id===S.phat);\n","  const curH=PHATS.find(x=>x.id===S.phat);\n  const wI=k=>{const sel=(S.wear||{})[k],it=WEAR.find(x=>x.id===sel);return it?'<img alt=\"\" src=\"'+wearImg(it)+'\">':(k==='hat'?'🎩':'🧥')};\n")
rep("   +(hasP?pnl('pp','<div class=\"mhd2\">Pappagallo</div>'",
    "   +pnl('gd','<div class=\"mhd2\">Guardaroba</div>'+T('mWh',wI('hat'),'Cappello',wearName('hat'))+T('mWo',wI('out'),'Abito',wearName('out'))+'<p class=\"sm\">Cappelli e abiti si trovano giocando: casse, raccolti, ricette, capitoli. Quelli che mancano sono elencati con un indizio.</p>')\n   +(hasP?pnl('pp','<div class=\"mhd2\">Pappagallo</div>'")
rep("  const mp=c.querySelector('#mPn');if(mp)mp.onclick=",
    "  {const a=c.querySelector('#mWh');if(a)a.onclick=()=>{uShow('menu',false);wardSheet('hat')}}\n  {const a=c.querySelector('#mWo');if(a)a.onclick=()=>{uShow('menu',false);wardSheet('out')}}\n  const mp=c.querySelector('#mPn');if(mp)mp.onclick=")

# ---------- stile ----------
rep(".phs img,.phs .no{width:56px;height:56px;border-radius:10px;display:grid;place-items:center;font-size:26px;background:#d9a85a}",
    ".phs img,.phs .no{width:56px;height:56px;border-radius:10px;display:grid;place-items:center;font-size:26px;background:#d9a85a}\n"
    ".pgb{height:10px;border-radius:6px;background:rgba(0,0,0,.28);overflow:hidden;margin:6px 0}.pgb i{display:block;height:100%;width:0;background:linear-gradient(#9be06a,#3f9a2e);transition:width .9s linear}\n"
    ".wl{list-style:none;margin:0 0 8px;padding:0}.wl li{font:700 12.5px var(--f-b);padding:6px 9px;border-radius:10px;background:rgba(0,0,0,.09);margin-bottom:5px}.wl b{display:block;font-weight:800}\n"
    ".mr i img{width:34px;height:34px;border-radius:8px;display:block}")

# ---------- icone ----------
ICONS = '''
  <symbol id="i-semi" viewBox="0 0 24 24"><path d="M12 13c-.2-3 1.4-5.6 4.4-6.4 0 3-1.4 5.6-4.4 6.4z" fill="#5aa83a" stroke="#1f4a14" stroke-width="1.2"/><path d="M12 13c.2-2.4-1-4.4-3.4-5-.1 2.4 1 4.4 3.4 5z" fill="#7bc650" stroke="#1f4a14" stroke-width="1.2"/><path d="M12 13v4" stroke="#1f4a14" stroke-width="1.4"/><ellipse cx="7.4" cy="19.4" rx="2.4" ry="1.6" transform="rotate(-25 7.4 19.4)" fill="#c89a52" stroke="#5a3a10" stroke-width="1.1"/><ellipse cx="12.6" cy="20.2" rx="2.4" ry="1.6" transform="rotate(10 12.6 20.2)" fill="#d9ab62" stroke="#5a3a10" stroke-width="1.1"/><ellipse cx="17.4" cy="19.2" rx="2.4" ry="1.6" transform="rotate(25 17.4 19.2)" fill="#c89a52" stroke="#5a3a10" stroke-width="1.1"/></symbol>
  <symbol id="i-patata" viewBox="0 0 24 24"><path d="M3.5 14c0-4 4-7 9-6.4 5 .6 8.4 4 8 7.4-.4 3-4 4.6-8.6 4.2C7 18.8 3.5 17.4 3.5 14z" fill="#c9719a" stroke="#5a1e3c" stroke-width="1.5"/><path d="M7 12.4c2-1.2 4.4-1.4 6.4-.6M9 16.4c2 .6 4.6.2 6.4-1" stroke="#8a3a66" stroke-width="1.1" fill="none" stroke-linecap="round"/><circle cx="8" cy="11.4" r="1.1" fill="#fff" opacity=".45"/><path d="M19.6 8.2c1-2 2.6-2.8 3.4-2.6" stroke="#4a9a3a" stroke-width="1.6" fill="none" stroke-linecap="round"/></symbol>
  <symbol id="i-zucca" viewBox="0 0 24 24"><ellipse cx="12" cy="14" rx="9.4" ry="7.4" fill="#e8892a" stroke="#7a3a08" stroke-width="1.5"/><path d="M12 6.8v14.4M7.4 8.2c-2 3.6-2 8.6 0 11.8M16.6 8.2c2 3.6 2 8.6 0 11.8" stroke="#a85a14" stroke-width="1.2" fill="none"/><path d="M12 7c0-2 .8-3.4 2.4-4" stroke="#4a6a1c" stroke-width="2.2" fill="none" stroke-linecap="round"/><ellipse cx="8" cy="11" rx="1.6" ry="2.4" fill="#fff" opacity=".28"/></symbol>
  <symbol id="i-ananas" viewBox="0 0 24 24"><path d="M12 8.2c-3.8 0-6 3-6 7s2.4 6.4 6 6.4 6-2.4 6-6.4-2.2-7-6-7z" fill="#e8b830" stroke="#7a5008" stroke-width="1.5"/><path d="M8 11l8 9M16 11l-8 9M6.6 15.4h10.8M12 8.6v12.6" stroke="#b07a10" stroke-width="1" fill="none"/><path d="M12 8.2C10 6 8.6 4.4 8 2.4c2 .4 3.4 1.6 4 3 .6-1.4 2-2.6 4-3-.6 2-2 3.6-4 5.8z" fill="#4f9a3a" stroke="#1f4a14" stroke-width="1.2" stroke-linejoin="round"/></symbol>
  <symbol id="i-pescesec" viewBox="0 0 24 24"><path d="M2.5 13c3-5 9-6 13-3l5-3.4v12.8l-5-3.4c-4 3-10 2-13-3z" fill="#b9824a" stroke="#4a2a0c" stroke-width="1.5" stroke-linejoin="round"/><circle cx="7.4" cy="12" r="1.2" fill="#2a1608"/><path d="M10 10.4l5 5M13 9.4l4 5.4" stroke="#7a4a1c" stroke-width="1.1" stroke-linecap="round"/><path d="M6 2.4c1.4 1 2.6 1 4 0M8 2.6V7" stroke="#c9a85e" stroke-width="1.4" fill="none" stroke-linecap="round"/></symbol>
  <symbol id="i-fruttasec" viewBox="0 0 24 24"><circle cx="8" cy="14.6" r="4.4" fill="#7a2a4a" stroke="#2e0e1e" stroke-width="1.4"/><circle cx="16" cy="13.6" r="4.4" fill="#8a3456" stroke="#2e0e1e" stroke-width="1.4"/><circle cx="12" cy="18.6" r="3.6" fill="#6a2040" stroke="#2e0e1e" stroke-width="1.3"/><path d="M6.2 13.4c1-1 2.4-1.2 3.4-.6M14.4 12.4c1-1 2.4-1.2 3.4-.6" stroke="#c88aa6" stroke-width="1" fill="none"/><path d="M12 4c1 3 3 4 6 4-1 3-4 3-6 1z" fill="#7aa83a" stroke="#2a4a14" stroke-width="1.1"/></symbol>'''
m=re.search(r'  <symbol id="i-arrosto"[^\n]*</symbol>',src)
if not m: print('PATCH FAIL icone'); sys.exit(1)
src=src[:m.end()]+ICONS+src[m.end():]

# ---------- previsto / registro modifiche / copia stabile ----------
rep("""const COMING=[
  {t:"L'orto",d:"Semi da piantare e raccolti da curare: cibo che cresce mentre esplori.",st:"In programma"},
  {t:"L'essicatore",d:"Pesce e frutta da far seccare per le lunghe traversate, senza paura che vadano a male.",st:"In programma"},
  {t:"App per Android",d:"Il gioco sul telefono come una vera app, da installare senza passare dal browser.",st:"In studio"}
];""","const COMING=[];")
rep("    h+='<h3>Previsto nella Stagione 1</h3>","    if(COMING.length)h+='<h3>Previsto nella Stagione 1</h3>")
rep("const CHANGELOG=[\n","""const CHANGELOG=[
  {v:"0.9",d:"7 nov 2026",t:"Orto, essiccatore e guardaroba",n:[
    "L'orto: dal Banco da lavoro (Il tuo campo) si costruisce un orto recintato con lo spaventapasseri. Quattro zolle, tre colture (patata dolce, zucca, ananas) che si sbloccano a mano a mano che raccogli. Cresce anche mentre sei lontano, la pioggia raddoppia la velocità, e dormire fa passare il tempo. Ogni raccolto restituisce almeno un seme, quindi non resti mai senza.",
    "L'essiccatore: un telaio al sole con tre ripiani per fare pesce secco, bacche secche e ananas essiccato. Di notte ci mette il doppio, con la pioggia si ferma. Il cibo secco ha una scorta tutta sua e non va a male.",
    "Sei nuove risorse (semi, patate dolci, zucche, ananas, pesce secco, frutta secca) con le loro icone, e quattro nuove ricette al falò: patate alla brace, zuppa di zucca, ananas caramellato e lo Spezzatino del naufrago.",
    "Guardaroba nel Menu: nove cappelli e sette abiti da trovare (orto, ricette, pesca, casse, capitoli, bottino del galeone) e da scegliere come per il pappagallo. Quello che indossi si vede anche nelle conversazioni e nel galeone. Gli oggetti che mancano sono elencati con un indizio, anche nella Raccolta.",
    "Quattro nuovi cappellini per il pappagallo: tricorno, cappello di paglia, fiore di ibisco e coroncina d'oro.",
    "Copia stabile: dal Menu › Partita (o dal Diario → Novità) il pulsante «Versione stabile (prima delle novità)» riapre la versione di prima con lo stesso salvataggio; da lì si torna alla versione nuova con «Torna alla versione nuova».",
    "Lingue: orto, essiccatore, guardaroba e relativi avvisi sono tradotti in inglese, tedesco, spagnolo e francese; anche i fumetti dei personaggi ora si traducono come il resto del testo.",
    "Tolta la voce «App per Android» dal Diario.",
    "Banco da lavoro: se mancano materiali per orto e decorazioni compare «Ti mancano dei materiali» (l'orto vuole 4 corde); se non c'è spazio nel campo, il messaggio compare dentro la finestra.",
    "Nella capanna il quadretto della mappa è stato spostato sul muro libero, non più dietro i barili.",
    "Le tracce di zampe sono state ridisegnate: ora sono vere impronte con cuscinetto e quattro dita.",
    "Orto ed essiccatore: se il campo è molto pieno (seconda isola) ora cercano un posto più lontano invece di dire «non c'è spazio».",
    "Orto ed essiccatore: con la finestra aperta il tempo ora scorre in diretta (barra e conto alla rovescia), senza dover chiudere e riaprire.",
    "Zattera rifatta: tronchi con corteccia e teste tagliate, schiuma, base dell'albero, corda e barilotto. La vela ora gira attorno all'albero con la direzione e rimane un po' indietro quando vira (rossa con teschio dopo il potenziamento).",
    "Banco da lavoro, orto ed essiccatore non si attraversano più; sotto l'essiccatore, in mezzo ai due montanti, si può passare.",
    "Alberi, cespugli e rocce non coprono più banco, orto ed essiccatore: vengono spostati poco più in là.",
    "Vecchio campo abbandonato: tenda rifatta (tela rattoppata, palo spezzato, corde e picchetti), con pentolino e tazza accanto.",
    "Zattera: l'albero ora resta fermo sulla sua base mentre giri. Vecchio campo: falò e croce più a destra della tenda, forziere un po' più in basso."
  ]},
""")
rep("function journalBody(){","""const IS_STABLE=/stabile/i.test(location.pathname);
const verLbl=()=>IS_STABLE?'Torna alla versione nuova':'Versione stabile (prima delle novità)';
function verSwitch(){
  try{localStorage.setItem('sm_ver',IS_STABLE?'nuova':'stabile')}catch(e){}
  try{saveGame(true)}catch(e){}
  location.href=IS_STABLE?'index.html':'stabile.html';
}
function journalBody(){""")
rep('id="nwC4">Prova: assalto al galeone</button></div>\'+CHANGELOG','id="nwC4">Prova: assalto al galeone</button><button class="btn" id="nwVer">\'+verLbl()+\'</button></div>\'+CHANGELOG')
rep("const nc=c.querySelector('#nwC4');if(nc)nc.onclick=","{const nv=c.querySelector('#nwVer');if(nv)nv.onclick=verSwitch}\n  const nc=c.querySelector('#nwC4');if(nc)nc.onclick=")
# il cambio di versione sta anche nel Menu › Partita (il Diario › Novità è protetto da password)
rep("T('mJ','📖','Diario e novità',null)","T('mJ','📖','Diario e novità',null)+T('mVer','🔁',verLbl(),null)")
rep("  c.querySelector('#mJ').onclick=()=>{uShow('menu',false);UI.openJournal('n')};","  c.querySelector('#mJ').onclick=()=>{uShow('menu',false);UI.openJournal('n')};\n  c.querySelector('#mVer').onclick=verSwitch;")
# se è stata scelta la versione stabile, l'APK (che apre sempre index.html) rimanda lì
rep("<style>:root{color-scheme:light;","<script>try{if(localStorage.getItem('sm_ver')==='stabile'&&!/[?&]nuova\\b/.test(location.search)&&!/stabile/i.test(location.pathname)){window.__REDIR=1;location.replace('stabile.html')}}catch(e){}</script><style>:root{color-scheme:light;")

# ---------- esportazione per i test automatici ----------
rep("  tileInfo(x,y){return{walk:walkT[tIdx(x,y)],block:blockT[tIdx(x,y)],sea:seaT[tIdx(x,y)],e:elevT[tIdx(x,y)],free:freeT(x,y)}}\n};",
    "  tileInfo(x,y){return{walk:walkT[tIdx(x,y)],block:blockT[tIdx(x,y)],sea:seaT[tIdx(x,y)],e:elevT[tIdx(x,y)],free:freeT(x,y)}},\n  farm:{GC,DRYR,WEAR,DECOR,PHATS,RECIPES,gardPlant,gardHarvest,dryPut,dryTake,farmAdvance,farmInit,farmTick,wardCheck,heroSpec,lookSave,wardSheet,wearImg,campBuild,campTile,hasFarm,wearName,gardCrops,gardNext,drawOrto,drawEssic,drawChar,CH,rcap,hasRes,payRes,gain,eatBest,eatFood}\n};")
# ---------- fumetti: si traduce la frase intera prima di andare a capo ----------
rep("FXL.bubbles.push({e,txt:pn(txt),t:0","FXL.bubbles.push({e,txt:(typeof I18N!=='undefined'?I18N.tr(pn(txt)):pn(txt)),t:0")

# ---------- traduzioni v0.9 (i18n/d.tsv) aggiunte al PACK esistente ----------
import json
_i=src.index('var PACK=')+len('var PACK=');_j=src.index(',NO=new WeakMap()',_i)
pk=json.loads(src[_i:_j]);ix={r[0]:n for n,r in enumerate(pk)}
nw=0
for ln in open('/home/claude/i18n/d.tsv',encoding='utf8').read().split('\n'):
    if not ln.strip(): continue
    r=ln.split('\t')
    if len(r)!=5: print('TSV FAIL',ln[:60]); sys.exit(1)
    if r[0] in ix: pk[ix[r[0]]]=r
    else: ix[r[0]]=len(pk); pk.append(r); nw+=1
src=src[:_i]+json.dumps(pk,ensure_ascii=False,separators=(',',':'))+src[_j:]
print('PACK:',len(pk),'voci (+%d)'%nw)

open('/home/claude/work/base_index.html','w',encoding='utf8').write(src)
print('ok',len(src))
