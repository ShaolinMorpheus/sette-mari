const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>Pirati.startNew('T','m'));
for(let i=0;i<14;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(150)}
const r=await p.evaluate(async()=>{const P=Pirati,S=P.S;S.flags.lenza=1;S.res.coco=50;S.res.bacche=40;
 const m=P.E.find(e=>e.type==='rockpool');
 // accanto alla pozza, sul lato del mare
 let out=[];
 for(const[dx,dy]of[[0,1],[0,-1],[1,0],[-1,0],[0,.5]]){P.tp(m.tx+.5+dx,m.ty+.8+dy);await new Promise(r=>setTimeout(r,150));const t=P.tinfo();out.push([dx,dy,t&&t.l])}
 P.UI.sync();return {out,coco:S.res.coco,bacche:S.res.bacche}});
console.log(JSON.stringify(r));await b.close()})();
