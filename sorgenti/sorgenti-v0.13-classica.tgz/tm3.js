const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [n,w,h] of [['land',844,390],['port',390,844]]){
const p=await b.newPage({viewport:{width:w,height:h},hasTouch:true,isMobile:true});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});await p.waitForTimeout(1500);
const r=await p.evaluate(async()=>{
 const cv=document.getElementById('cv')||document.querySelector('canvas'),j=document.getElementById('joy').getBoundingClientRect();
 const cx=j.left+j.width/2,cy=j.top+j.height/2,rot=document.body.classList.contains('rot');
 const ev=(t,x,y,id)=>cv.dispatchEvent(new PointerEvent(t,{pointerId:id,clientX:x,clientY:y,bubbles:true,pointerType:'touch'}));
 const res={};const x0=Pirati.P.x,y0=Pirati.P.y;
 // tocco lontano (nessun movimento)
 ev('pointerdown',cx-300*(rot?0:1),cy-(rot?0:0)-(rot?-300:0),1);await new Promise(r=>setTimeout(r,200));res.farOn=document.getElementById('joy').classList.contains('on');ev('pointerup',cx,cy,1);
 // tocco sul joystick e trascino a destra schermo (+x)
 ev('pointerdown',cx,cy,2);ev('pointermove',cx+40,cy,2);await new Promise(r=>setTimeout(r,700));
 res.on=document.getElementById('joy').classList.contains('on');res.knob=document.getElementById('joyKnob').style.transform;res.moved=Math.hypot(Pirati.P.x-x0,Pirati.P.y-y0);
 const q=document.getElementById('joy').getBoundingClientRect();res.joyStill=[Math.round(q.left-j.left),Math.round(q.top-j.top)];
 ev('pointermove',cx+300,cy+200,2);await new Promise(r=>setTimeout(r,200));const q2=document.getElementById('joy').getBoundingClientRect();res.joyAfterFar=[Math.round(q2.left-j.left),Math.round(q2.top-j.top)];
 ev('pointerup',cx,cy,2);res.off=!document.getElementById('joy').classList.contains('on');
 return res});
console.log(n,JSON.stringify(r));await p.close()}
await b.close()})();
