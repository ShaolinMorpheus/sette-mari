// Controllo traduzioni v0.9: percorre orto, essiccatore, guardaroba e menu in italiano,
// raccoglie ogni testo mostrato (nodi, attributi, avvisi, banner) e verifica che esista in en/de/es/fr.
const L=require('./aud/lib.js');
const LANGS=['en','de','es','fr'];
(async()=>{const {b,p,errs}=await L.boot({dsf:1.5});
 const ev=async(f,a)=>{try{return await p.evaluate(f,a)}catch(e){return {ERRORE:e.message.split('\n')[0].slice(0,240)}}};
 const sleep=ms=>p.waitForTimeout(ms);
 await sleep(1200);
 await p.evaluate(()=>{try{I18N.set('it')}catch(e){}});
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);await sleep(500);
 await p.evaluate(()=>{
   Pirati.S.tutDone=1;Pirati.S.tut=null;
   window.__sl=ms=>new Promise(r=>setTimeout(r,ms));
   window.__cd=async()=>{for(let i=0;i<60&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await window.__sl(80)}};
   const LOG=window.__LOG={toast:new Set(),banner:new Set(),nodes:new Set()};
   const UI=Pirati.UI,ot=UI.toast,ob=UI.banner;
   UI.toast=function(t){LOG.toast.add(String(t));return ot.apply(this,arguments)};
   UI.banner=function(t,s){LOG.banner.add(String(t));String(s||'').split('\n').forEach(x=>{if(x)LOG.banner.add(x)});return ob.apply(this,arguments)};
   const has=t=>/[A-Za-zÀ-ÿ]{3}/.test(t);
   window.__snap=(sel)=>{for(const r of document.querySelectorAll(sel)){
       const w=document.createTreeWalker(r,NodeFilter.SHOW_TEXT);let n;
       while(n=w.nextNode()){const t=n.nodeValue.trim();if(t.length>=3&&has(t))LOG.nodes.add(t)}
       for(const e of r.querySelectorAll('[title],[aria-label],[placeholder]'))for(const a of['title','placeholder']){const v=e.getAttribute(a);if(v&&has(v))LOG.nodes.add(v.trim())}}};
 });
 const snap=sel=>ev(s=>window.__snap(s),sel);
 const closeSheet=()=>ev(()=>{(document.getElementById('shNo')||{click(){}}).click()});
 // ---- preparazione ----
 await ev(()=>{const S=Pirati.S;S.flags.axe=1;S.flags.flint=1;S.built={falo:1,capanna:1,banco:1};
   for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}
   for(const k of['legna','pietra','corda','rottami','pesce','bacche'])S.res[k]=30;
   S.res.ananas=3;Pirati.UI.sync();
   const f=Pirati.EID.plot_falo;Pirati.tp(f.fp[0]+1,f.fp[1]+4)});
 // ---- banco da lavoro: voci orto ed essiccatore ----
 await ev(async()=>{Pirati.UI.openUpgrades();await window.__sl(250);window.__snap('#sheetCard')});
 await ev(async()=>{const c=document.getElementById('sheetCard');c.querySelector('[data-dc="orto"]').click();await window.__sl(250);
   document.getElementById('sheetCard').querySelector('[data-dc="essic"]').click();await window.__sl(1100);window.__snap('#toasts');window.__snap('#qbanner')});
 await closeSheet();
 await snap('#res');
 // ---- orto ----
 const lab=await ev(async()=>{const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k==='orto');Pirati.tp(e.x/44,(e.y+30)/44);await window.__sl(300);const t=Pirati.tinfo();if(t&&t.l)window.__LOG.nodes.add(t.l);window.__snap('#act, #btnAct, .act');return t&&t.l});
 await ev(async()=>{await window.__cd();Pirati.act();await window.__sl(300);window.__snap('#sheetCard')});
 await ev(async()=>{const q=()=>document.getElementById('sheetCard');
   for(let i=0;i<3;i++){const bt=q().querySelector('[data-pl="'+i+':patata"]');if(bt){bt.click();await window.__sl(120)}}
   window.__snap('#sheetCard');
   Pirati.S.res.semi=0;     // senza semi: compare il messaggio «Ti serve un seme»
   const s0=Pirati.S.res.semi;Pirati.farm.gardPlant;       // (nessuna azione)
 });
 await ev(async()=>{Pirati.UI.sync();document.getElementById('shNo').click();Pirati.act();await window.__sl(300);window.__snap('#sheetCard');Pirati.S.res.semi=6});
 await closeSheet();
 await ev(async()=>{Pirati.farm.farmAdvance(100)});
 await ev(async()=>{await window.__cd();Pirati.act();await window.__sl(250);window.__snap('#sheetCard')});   // crescita a metà
 await closeSheet();
 // pioggia sull'orto (nessun ripiano in corso): avviso «La pioggia fa bene»
 await ev(async()=>{Pirati.WX.i=1;Pirati.farm.farmTick(1.1);await window.__sl(300);window.__snap('#toasts');
   await window.__cd();Pirati.act();await window.__sl(250);window.__snap('#sheetCard')});
 await closeSheet();
 await ev(()=>{Pirati.WX.i=0;Pirati.farm.farmTick(1.1)});
 await ev(async()=>{Pirati.farm.farmAdvance(900)});
 await sleep(1600);      // tick: «Nell'orto è pronto»
 await ev(()=>window.__snap('#toasts'));
 await ev(async()=>{await window.__cd();Pirati.act();await window.__sl(300);window.__snap('#sheetCard');
   const a=document.getElementById('gdAll');if(a){a.click();await window.__sl(900)}
   window.__snap('#sheetCard');window.__snap('#toasts');window.__snap('#qbanner')});
 await closeSheet();
 // piantare con più colture disponibili
 await ev(async()=>{await window.__cd();Pirati.act();await window.__sl(250);window.__snap('#sheetCard');
   const q=()=>document.getElementById('sheetCard');const bt=q().querySelector('[data-pl="0:zucca"]');if(bt)bt.click();await window.__sl(200);
   const b2=q().querySelector('[data-pl="1:patata"]');if(b2)b2.click();await window.__sl(200);window.__snap('#sheetCard')});
 await closeSheet();
 // pieno: raccolto con scorta piena
 await ev(async()=>{const S=Pirati.S;S.gard.pl[2]={c:'patata',p:999};S.res.patata=Pirati.farm.rcap('patata');await window.__cd();Pirati.act();await window.__sl(250);
   const h=document.querySelector('#sheetCard [data-hv="2"]');if(h){h.click();await window.__sl(200)}window.__snap('#toasts');S.res.patata=0});
 await closeSheet();
 // ---- essiccatore ----
 await ev(async()=>{const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k==='essic');Pirati.tp(e.x/44,(e.y+30)/44);await window.__sl(300);const t=Pirati.tinfo();if(t&&t.l)window.__LOG.nodes.add(t.l);
   await window.__cd();Pirati.act();await window.__sl(300);window.__snap('#sheetCard');
   const q=()=>document.getElementById('sheetCard');
   q().querySelector('[data-dp="0:pesce"]').click();await window.__sl(120);
   q().querySelector('[data-dp="1:bacche"]').click();await window.__sl(120);
   q().querySelector('[data-dp="2:ananas"]').click();await window.__sl(120);
   window.__snap('#sheetCard')});
 await closeSheet();
 // pioggia con il pesce appeso: avviso «Piove: l'essiccatore si ferma»
 await ev(async()=>{Pirati.WX.i=1;Pirati.farm.farmTick(1.1);await window.__sl(300);window.__snap('#toasts');
   await window.__cd();Pirati.act();await window.__sl(250);window.__snap('#sheetCard')});
 await closeSheet();
 await ev(()=>{Pirati.WX.i=0;Pirati.farm.farmTick(1.1);Pirati.S.tod=12;Pirati.farm.farmAdvance(1000)});
 await sleep(1700);
 await ev(()=>window.__snap('#toasts'));
 await ev(async()=>{await window.__cd();Pirati.act();await window.__sl(300);window.__snap('#sheetCard');
   for(const i of[0,1,2]){const t=document.querySelector('#sheetCard [data-dt="'+i+'"]');if(t){t.click();await window.__sl(150)}}
   window.__snap('#toasts')});
 await closeSheet();
 // ---- guardaroba: avvisi ----
 await ev(async()=>{const S=Pirati.S,F=Pirati.farm;S.flags.parrot=1;S.flags.hat=1;
   F.wardCheck();await window.__sl(300);                                   // iniziale (silenzioso)
   S.gard.harv=1;F.wardCheck();await window.__sl(450);window.__snap('#qbanner');   // cappello di paglia (singolo)
   S.gard.harv=5;F.wardCheck();await window.__sl(450);window.__snap('#qbanner');   // cappellino pappagallo (singolo)
   S.gard.harv=10;F.wardCheck();await window.__sl(450);window.__snap('#qbanner');  // abito (singolo)
   S.day=5;S.cOpen=9;S.flags.ch1=1;S.flags.ch2end=1;try{localStorage.setItem('sm_gal','1')}catch(e){}
   S.stat=S.stat||{};S.stat.fish=20;S.stat.forage=20;
   F.wardCheck();await window.__sl(450);window.__snap('#qbanner')});          // più novità insieme
 // ---- guardaroba: schede e menu ----
 await ev(async()=>{Pirati.S.wown=Pirati.S.wown||{};
   // lascia alcuni capi "da trovare"
   delete Pirati.S.wown.h_corona;delete Pirati.S.wown.o_gent;delete Pirati.S.wown.h_elmo;Pirati.S.flags.ch2end=0;Pirati.S.flags.ch1=1;
   delete Pirati.S.wown.o_cors;delete Pirati.S.wown.h_turb;Pirati.S.cOpen=5;
   Pirati.UI._mt='gd';Pirati.UI.openMenu();await window.__sl(300);window.__snap('#menu')});
 await ev(async()=>{document.getElementById('mWh').click();await window.__sl(350);window.__snap('#sheetCard')});
 await closeSheet();
 await ev(async()=>{Pirati.UI._mt='gd';Pirati.UI.openMenu();await window.__sl(250);document.getElementById('mWo').click();await window.__sl(350);window.__snap('#sheetCard')});
 await closeSheet();
 await ev(async()=>{Pirati.UI._mt='pa';Pirati.UI.openMenu();await window.__sl(300);window.__snap('#menu')});
 await ev(async()=>{Pirati.UI._mt='pp';Pirati.UI.openMenu();await window.__sl(300);window.__snap('#menu')});
 await ev(()=>{const x=document.getElementById('mX');if(x)x.click()});
 // ---- ricette al falò e foglio delle risorse (testi dei nuovi cibi) ----
 await ev(async()=>{const S=Pirati.S;S.res.patata=3;S.res.zucca=2;S.res.ananas=2;S.res.coco=4;S.res.pescesec=3;S.res.fruttasec=2;S.res.semi=4;Pirati.UI.sync();
   const f=Pirati.EID.plot_falo;Pirati.tp(f.fp[0]+1,f.fp[1]+4);await window.__sl(200);
   Pirati.UI.openCook(f);await window.__sl(300);window.__snap('#sheetCard')});
 await closeSheet();
 await snap('#res');
 // ---- raccolta di tutte le stringhe e verifica nelle 4 lingue ----
 const data=await ev(()=>({toast:[...window.__LOG.toast],banner:[...window.__LOG.banner],nodes:[...window.__LOG.nodes]}));
 const res={};
 for(const lg of LANGS){
   res[lg]=await ev((lg)=>{I18N.set(lg);const bad=[];
     const all=[].concat(window.__LOG.toast.size?[...window.__LOG.toast]:[],[...window.__LOG.banner],[...window.__LOG.nodes]);
     for(const s of new Set(all)){const r=I18N.tr(s);if(r===s)bad.push(s)}
     return bad},lg);
 }
 await ev(()=>I18N.set('it'));
 console.log('Testi raccolti: nodi',data.nodes.length,'avvisi',data.toast.length,'banner',data.banner.length,'· etichetta orto:',JSON.stringify(lab));
 for(const lg of LANGS){console.log('\n== '+lg+' non tradotti ('+(res[lg].length||JSON.stringify(res[lg]))+') ==');if(Array.isArray(res[lg]))for(const s of res[lg])console.log('  · '+s.slice(0,130))}
 require('fs').writeFileSync('/tmp/i18n_strings.json',JSON.stringify(data,null,1));
 console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
