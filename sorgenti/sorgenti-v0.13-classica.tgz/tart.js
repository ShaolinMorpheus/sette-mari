const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({dsf:2});
 const ev=async(f,a)=>{try{return await p.evaluate(f,a)}catch(e){return {ERRORE:e.message.split('\n')[0].slice(0,220)}}};
 await p.waitForTimeout(1200);
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);
 await p.waitForTimeout(500);
 await p.evaluate(()=>{Pirati.S.tutDone=1;Pirati.S.tut=null});
 await ev(()=>{const S=Pirati.S;S.flags.axe=1;S.flags.flint=1;S.built={falo:1,capanna:1,banco:1};
   for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}
   for(const k of['legna','pietra','corda','rottami','pesce','bacche'])S.res[k]=30;
   const f=Pirati.EID.plot_falo;Pirati.tp(f.fp[0]+1,f.fp[1]+4)});
 await ev(async()=>{const UI=Pirati.UI;UI.openUpgrades();const c=document.getElementById('sheetCard');
   c.querySelector('[data-dc="orto"]').click();await new Promise(r=>setTimeout(r,200));
   document.getElementById('sheetCard').querySelector('[data-dc="essic"]').click();await new Promise(r=>setTimeout(r,200))});
 await p.evaluate(()=>{(document.getElementById('shNo')||{click(){}}).click();for(const id of['hud','qbanner','dlg','rot']){const e=document.getElementById(id);if(e)e.style.display='none'}});
 await p.waitForTimeout(300);
 const pos=await ev(()=>{const o=Pirati.E.find(e=>e.type==='cdeco'&&e.k==='orto'),d=Pirati.E.find(e=>e.type==='cdeco'&&e.k==='essic');return {o:[o.x,o.y],d:[d.x,d.y]}});
 console.log(JSON.stringify(pos));
 const shotAt=async(name,ent,W,H,dx,dy)=>{
   await ev((a)=>{const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k===a);Pirati.tp(e.x/44,(e.y+40)/44);Pirati.cam.x=e.x;Pirati.cam.y=e.y-30},ent);
   await p.waitForTimeout(500);
   const sc=await ev((a)=>{const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k===a);return Pirati.toScreen(e.x,e.y)},ent);
   const x=Math.max(0,Math.round(sc.x||sc[0])-W/2+(dx||0)),y=Math.max(0,Math.round(sc.y||sc[1])-H+(dy||40));
   await p.screenshot({path:'aud/art_'+name+'.png',clip:{x,y,width:W,height:H}});
 };
 // orto: vuoto
 await shotAt('orto0','orto',340,230);
 // semi appena piantati: patata / zucca / ananas
 await ev(()=>{const S=Pirati.S;S.gard.harv=10;S.gard.pl=[{c:'patata',p:5},{c:'zucca',p:5},{c:'ananas',p:5},{c:'patata',p:5}]});
 await p.waitForTimeout(250);await shotAt('orto1','orto',340,230);
 await ev(()=>{const S=Pirati.S;S.gard.pl=[{c:'patata',p:60},{c:'zucca',p:110},{c:'ananas',p:150},{c:'patata',p:100}]});
 await p.waitForTimeout(250);await shotAt('orto2','orto',340,230);
 await ev(()=>{const S=Pirati.S;S.gard.pl=[{c:'patata',p:130},{c:'zucca',p:220},{c:'ananas',p:300},{c:'patata',p:160}]});
 await p.waitForTimeout(250);await shotAt('orto3','orto',340,230);
 await ev(()=>{const S=Pirati.S;S.gard.pl=[{c:'patata',p:200,n:1},{c:'zucca',p:320,n:1},{c:'ananas',p:480,n:1},{c:'patata',p:200,n:1}]});
 await p.waitForTimeout(250);await shotAt('orto4','orto',340,230);
 // essiccatore
 await shotAt('essic0','essic',260,190);
 await ev(()=>{const S=Pirati.S;S.dry.sl=[{r:'pesce',nm:'Pesce secco',p:10,t:300},{r:'bacche',nm:'Bacche secche',p:10,t:200},{r:'ananas',nm:'Ananas essiccato',p:10,t:240}]});
 await p.waitForTimeout(250);await shotAt('essic1','essic',260,190);
 await ev(()=>{const S=Pirati.S;S.dry.sl=[{r:'pesce',nm:'Pesce secco',p:150,t:300},{r:'bacche',nm:'Bacche secche',p:100,t:200},{r:'ananas',nm:'Ananas essiccato',p:120,t:240}]});
 await p.waitForTimeout(250);await shotAt('essic2','essic',260,190);
 await ev(()=>{const S=Pirati.S;S.dry.sl=[{r:'pesce',nm:'Pesce secco',p:300,t:300,n:1},{r:'bacche',nm:'Bacche secche',p:200,t:200,n:1},{r:'ananas',nm:'Ananas essiccato',p:240,t:240,n:1}]});
 await p.waitForTimeout(250);await shotAt('essic3','essic',260,190);
 console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
