const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1500);
const r=await p.evaluate(()=>{const C=Ch4,K=C.K,P=C.P;const g=K.gd[2];C.tp(36,11);
 for(const f of K.fol){f.x=P.x+(Math.random()*20-10);f.y=P.y+(Math.random()*20-10)}
 g.x=P.x+90;g.y=P.y;g.st='chase';
 let log=[];for(let i=0;i<450;i++){C.step(1/30);if(i%90==0)log.push(K.fol.map(f=>f.hp).join('')+'|'+g.hp+'/'+Math.round(g.ko))}
 let md=1e9;const A=[P,...K.fol,...K.gd];for(let i=0;i<A.length;i++)for(let j=i+1;j<A.length;j++)if(A[i].ko<=0&&A[j].ko<=0)md=Math.min(md,Math.hypot(A[i].x-A[j].x,A[i].y-A[j].y));
 return {log,md}});
console.log(JSON.stringify(r),errs);
await p.evaluate(()=>{const K=Ch4.K;Ch4.tp(25,10);Ch4.K.atk=0;Ch4.atk();Ch4.step(.1)});await p.waitForTimeout(100);await p.screenshot({path:'s2.png'});await b.close()})()
