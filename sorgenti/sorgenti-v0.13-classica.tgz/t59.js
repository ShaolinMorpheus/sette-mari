const {chromium}=require('playwright');(async()=>{const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await (await b.newContext({viewport:{width:1000,height:460},locale:'it-IT'})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/sette-mari/www/_t.html');await p.waitForTimeout(3500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(500,200);await p.waitForTimeout(250)}
const info=await p.evaluate(()=>{const T=__t;T.S.tod=12.5;const act=(T.SHORE||[]).filter(s=>s.act);const s=act[(act.length/2)|0];T.P.x=s.x-s.nx*120;T.P.y=s.y-s.ny*120;return [T.SHORE.length,act.length]});
await p.evaluate(()=>{document.querySelectorAll('body *').forEach(e=>{if(e.tagName!=='CANVAS'&&!e.querySelector('canvas')&&e.tagName!=='SCRIPT'&&e.tagName!=='STYLE'&&getComputedStyle(e).position!=='static')e.style.display='none'})});await p.waitForTimeout(2500);await p.screenshot({path:'beach1.png'});await p.waitForTimeout(1700);await p.screenshot({path:'beach2.png'});
const snd=await p.evaluate(async()=>{const T=__t;T.auInit();T.AU.on=true;T.sfx('cra');await new Promise(r=>setTimeout(r,800));return [!!T.AU._pb,T.AU._pb&&T.AU._pb.duration]});
console.log(info,snd,er);await b.close()})()
