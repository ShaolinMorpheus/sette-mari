#!/usr/bin/env python3
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH29b FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
OLD1="""PHO.share=async function(url,name,msg){
  if(!url)return;
  try{const r=await fetch(url),bl=await r.blob(),f=new File([bl],name,{type:'image/jpeg'});"""
NEW1="""PHO.share=async function(url,name,msg){
  if(!url)return;
  try{const C=window.Capacitor,PL=C&&C.Plugins;
    if(C&&C.isNativePlatform&&C.isNativePlatform()&&PL&&PL.Filesystem&&PL.Share){
      const w=await PL.Filesystem.writeFile({path:name,data:url.split(',')[1],directory:'CACHE'});
      await PL.Share.share({title:'Sette Mari',text:'Una foto ricordo da Sette Mari',files:[w.uri],dialogTitle:'Condividi la foto'});return}
  }catch(e){if(e&&/cancel/i.test(String(e.message||e)))return}
  try{const r=await fetch(url),bl=await r.blob(),f=new File([bl],name,{type:'image/jpeg'});"""
rep(OLD1,NEW1)
OLD2="""  try{const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();
    msg&&msg('Se il telefono non salva il file, fai uno screenshot: la foto resta nell\\'album.')}
  catch(e){msg&&msg('Non posso condividere da qui: fai uno screenshot, la foto resta nell\\'album.')}};"""
NEW2="""  PHO.big(url,name);};
PHO.big=function(url,name){
  const d=document.createElement('div');d.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(10,8,4,.92);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:10px;box-sizing:border-box';
  d.innerHTML='<img alt="" src="'+url+'" style="max-width:96%;max-height:64%;border-radius:10px;border:3px solid #f3e3b8;-webkit-touch-callout:default;user-select:auto"><div style="color:#f3e3b8;font:700 14px sans-serif;text-align:center;max-width:90%">Da qui la condivisione diretta non è disponibile: <b>tieni premuta la foto</b> per salvarla o inviarla (WhatsApp, ecc.), oppure scarica il file.</div><div style="display:flex;gap:8px"><a class="btn gold" download="'+name+'" href="'+url+'" style="text-decoration:none">⬇ Scarica</a><button class="btn" id="phBigX">Chiudi</button></div>';
  document.body.appendChild(d);d.querySelector('#phBigX').onclick=()=>d.remove()};"""
rep(OLD2,NEW2)
A='''    "Casse, forzieri, barili e matasse di corda ora sono solidi'''
rep(A,'''    "Erba più ricca: prato fitto a più strati di verde e, vicino all'acqua, ciuffi alti con le spighe.",
    "Foto: il tasto Condividi ora apre il menu di Android nell'app; dove non è possibile mostra la foto grande da tenere premuta per salvarla o inviarla.",
'''+A)
open(P,'w',encoding='utf8').write(src)
print('patch29b ok')
