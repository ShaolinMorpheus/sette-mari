s=open('ch3_inject.js').read()
def rep(o,n,c=1):
    global s
    if s.count(o)!=c: print('FAIL',s.count(o),o[:80]); raise SystemExit(1)
    s=s.replace(o,n)
# obj text and css
rep("'/5): poi arriva il convoglio')","'/5)')")
rep("#c3obj{left:50%;transform:translateX(-50%);top:56px;max-width:46%;","#c3obj{left:50%;transform:translateX(-50%);top:46px;max-width:34%;")
rep("  tutStep();\n  $('c3obj').style.display=C.tut?'none':'block';\n  hud();\n}","  tutStep();\n  hud();\n  objVis(dt);parTick(dt);\n}")
# sail fix
rep("g.save();g.translate(s.x+c*m*sp0.L,s.y+sn*m*sp0.L*.55+6+bob);","g.save();g.translate(s.x+c*m*sp0.L,s.y+sn*m*sp0.L+8+bob);")
# perched parrot (after sails loop): find end of loop: before '// etichetta e barra'
rep("  // etichetta e barra\n","""  if(s===C.p&&sk<.3){const m0=sp0.masts[0],px=s.x+c*m0*sp0.L,py=s.y+sn*m0*sp0.L+8+bob-sp0.mh*k+8;drawParrot(g,px,py,{t,s:.78,perch:true,flip:c<0,hat:S&&S.phat})}
  // etichetta e barra
""")
# hud element + css
rep("<div class=\"pl\" id=\"c3obj\"></div>","<div class=\"pl\" id=\"c3obj\"></div><div id=\"c3par\"></div>")
rep("#c3tut{position:absolute;","#c3par{position:absolute;left:76px;top:100px;max-width:min(260px,30%);display:none;background:#fff6dc;color:#3a200c;border:3px solid #3a200c;border-radius:16px 16px 16px 4px;padding:7px 10px;font:800 13px/1.3 var(--f-b,Nunito,sans-serif);box-shadow:0 3px 0 rgba(0,0,0,.35)}#c3par b{color:#c8402e}\n#c3tut{position:absolute;")
# hooks
rep("function hurt(s,n){\n  if(s.dead)return;","function hurt(s,n){\n  if(s.dead)return;\n  if(s===C.p&&n>0)parEv('hit');")
rep("  toast(s.type==='galeone'?\"Galeone affondato","  parEv('kill');\n  toast(s.type==='galeone'?\"Galeone affondato")
rep("sfx('coin')}else{toast('Provviste","sfx('coin');parEv('crate')}else{toast('Provviste")
rep("  s.ally=true;s.conv=false;s.disabled=false;s.hull=s.max;C.pris=2;sfx('quest');","  s.ally=true;s.conv=false;s.disabled=false;s.hull=s.max;C.pris=2;sfx('quest');parEv('board',1);")
rep("toast(C.notes.ram?'Speronamento!","parEv('ram');toast(C.notes.ram?'Speronamento!")
rep("  sfx('quest');toast('Tito: «Capitano! Il galeone spagnolo","  parEv('convoy',1);sfx('quest');toast('Tito: «Capitano! Il galeone spagnolo")
# parrot module + objVis before spawnConvoy
rep("function spawnConvoy(){","""function objVis(dt){
  const o=$('c3obj'),t=o.textContent;
  if(t!==C.lastObj){C.lastObj=t;C.objT=7}
  if(C.tut)C.objT=7;else C.objT=Math.max(0,(C.objT||0)-dt);
  o.style.display=(!C.tut&&!C.over&&(C.objT>0||C.p.v<12))?'block':'none';
}
/* ---------------- Biscotto parla ---------------- */
const QUIPS=[
 'Crack! Biscotto vuole un biscotto. Anche mezzo va bene.',
 'Se affondiamo io volo via. Dettagli.',
 'Ho contato le onde: sono troppe, ho smesso.',
 'Sono un pappagallo, non un timone. Però ho opinioni.',
 'Il mare è grande e io sono piccolo. Ma ho ragione.',
 'Pezzi da otto! Pezzi da otto! ...non so cosa siano, li ripeto e basta.',
 'Capitano, il vento dice che sei bravo. Forse mentiva.',
 'Dodo cucina meglio di tutti. Se lo salviamo, mangiamo.',
 'Le vele si vedono prima dei cannoni: occhio all\\'orizzonte.',
 'Pip e Dodo contano su di noi. Non dimenticarlo.',
 'Le pattuglie si mettono di fianco per sparare: tienile di prua o di poppa.',
 'Sparare da vicino fa più danni.',
 'Lo scafo regge, ma non è eterno. In porto il carpentiere ripara tutto.'
];
const PEV={
  hit:['Ahi! Ci sparano! Rispondi al fuoco!','Giù la testa! Anzi, giù la nave!','Crack! Quello mi ha scompigliato le penne.'],
  kill:['Affondata! Una in meno!','Bel colpo, capitano! Io l\\'avevo detto.','Splash! Ho perso il conto, ma sono tante.'],
  ram:['Toc! Le navi non si sfiorano, si evitano.','Hai visto gli scogli? Erano lì prima di noi.','Piano! Lo scafo non è di gomma.'],
  crate:['Argento! Il mio lato preferito del mare.','Ottima pesca, capitano!','Crack! Pezzi da otto, finalmente!'],
  convoy:['Là! Il galeone spagnolo, con la scorta tutta attorno. Prudenza!','Eccoli! Dietro il galeone c\\'è la bandiera bianca: sono i nostri.'],
  board:['Pip! Dodo! Crack! Che bello rivedervi!','Abbordaggio riuscito! Il cuoco ha già chiesto della cambusa.']
};
const pick=a=>a[(Math.random()*a.length)|0];
function parSay(txt,ms){
  if(!C)return;const d=$('c3par');d.innerHTML='';const b=document.createElement('b');b.textContent='🦜 '+pn('Biscotto')+': ';d.appendChild(b);d.appendChild(document.createTextNode('«'+pn(txt)+'»'));
  d.style.display='block';C.parUntil=C.t+(ms||5200);C.parCd=7;if(AU.ctx&&AU.on)sfx('bird');
}
function parEv(k,force){if(!C||C.tut||C.over)return;if(!force&&(C.parCd>0||Math.random()>.65))return;parSay(pick(PEV[k]),4600)}
function dirName(dx,dy){const a=Math.atan2(dy,dx)*180/Math.PI,n=['a est','a sud-est','a sud','a sud-ovest','a ovest','a nord-ovest','a nord','a nord-est'];return n[((Math.round(a/45)%8)+8)%8]}
function parHint(){
  const p=C.p;
  if(p.hull<=p.max*.4){const pt=TPp(21,30);return 'Lo scafo scricchiola! Il porto è '+dirName(pt[0]-p.x,pt[1]-p.y)+': là ti riparano.'}
  if(C.silver>=5)return 'L\\'argento ci rende pesanti: più casse, meno velocità.';
  const cr=C.crates.find(c=>Math.hypot(c.x-p.x,c.y-p.y)<900);if(cr)return 'Casse in acqua '+dirName(cr.x-p.x,cr.y-p.y)+'! Prendile prima che affondino.';
  if(windK(p.hd)<.8)return 'Il vento è contro: gira di lato e le vele ti ringrazieranno.';
  if(C.convoy){const g=C.ships.find(s=>s.type==='galeone'&&!s.dead);if(g)return 'Il galeone spagnolo è '+dirName(g.x-p.x,g.y-p.y)+'. Attento alla scorta attorno.'}
  let b=null,bd=1e9;for(const s of C.ships){if(s.dead||s.conv||s.ally)continue;const d=Math.hypot(s.x-p.x,s.y-p.y);if(d<bd){bd=d;b=s}}
  if(b&&bd>500)return 'Vedo una vela '+dirName(b.x-p.x,b.y-p.y)+', capitano.';
  return null
}
function parTick(dt){
  if(C.parCd>0)C.parCd-=dt;
  const d=$('c3par');if(d.style.display==='block'&&(C.t>C.parUntil||C.over||C.tut))d.style.display='none';
  if(C.tut||C.over)return;
  if(C.parN==null)C.parN=12;C.parN-=dt;
  if(C.parN<=0){C.parN=rr(26,40);const h=Math.random()<.55?parHint():null;parSay(h||pick(QUIPS),5600)}
}
function spawnConvoy(){""")
open('ch3_inject.js','w').write(s)
