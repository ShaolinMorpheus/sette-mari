const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1500);
await p.evaluate(()=>{const C=Ch4;C.K.hold=true;C.K.c1=true;C.tp(26,13);C.step(.05)});await p.waitForTimeout(300);await p.screenshot({path:'s9.png'});console.log(errs);await b.close()})()
