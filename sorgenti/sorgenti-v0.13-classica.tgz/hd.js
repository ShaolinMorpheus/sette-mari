const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:420}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>Pirati.startNew('T','m'));
for(let i=0;i<14;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(300)}
console.log('default',await p.evaluate(()=>document.body.dataset.hand));
// open menu, click Joystick tile
await p.click('#bM');await p.waitForTimeout(400);
await p.screenshot({path:'/tmp/h1.png'});
const has=await p.evaluate(()=>!!document.getElementById('mHand'));console.log('tile',has);
await p.evaluate(()=>document.getElementById('mHand').click());await p.waitForTimeout(300);
console.log('after',await p.evaluate(()=>document.body.dataset.hand+' '+localStorage.getItem('sette-mari-hand')+' '+Pirati.S.hand));
await p.evaluate(()=>{document.getElementById('menu').hidden=true});
await p.waitForTimeout(500);await p.screenshot({path:'/tmp/h2.png'});
console.log(errs);await b.close()})();
