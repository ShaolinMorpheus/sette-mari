import re
s=open('ch3_inject.js').read()
def rep(o,n,c=1):
    global s
    if s.count(o)!=c: print('FAIL',s.count(o),o[:80]); raise SystemExit(1)
    s=s.replace(o,n)
# route
a=s.index("const ROUTE=[");b=s.index("\n",a)
route=r'''const ROUTE=(function(){
  const W=MW,H=MH,cl0=new Int16Array(W*H).fill(999),q=[];
  for(let i=0;i<W*H;i++)if(!seaT[i]||blockT[i]){cl0[i]=0;q.push(i)}
  for(let h=0;h<q.length;h++){const i=q[h],x=i%W,y=(i/W)|0;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=W||ny>=H)continue;const j=ny*W+nx;if(cl0[j]>cl0[i]+1){cl0[j]=cl0[i]+1;q.push(j)}}}
  const near=(tx,ty,R)=>{let b=-1,bd=1e9;for(let y=0;y<H;y++)for(let x=0;x<W;x++){if(cl0[y*W+x]<R)continue;const d=(x-tx)*(x-tx)+(y-ty)*(y-ty);if(d<bd){bd=d;b=y*W+x}}return b};
  for(const R of[6,5,4,3,2]){
    const st=near(MW-8,Math.round(MH*.58),R),gl=near(7,Math.round(MH*.3),R);if(st<0||gl<0)continue;
    const par=new Int32Array(W*H).fill(-2);par[st]=-1;const qq=[st];let found=false;
    for(let h=0;h<qq.length&&!found;h++){const i=qq[h],x=i%W,y=(i/W)|0;for(const[dx,dy]of[[-1,0],[0,-1],[0,1],[1,0]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=W||ny>=H)continue;const j=ny*W+nx;if(par[j]!==-2||cl0[j]<R)continue;par[j]=i;if(j===gl){found=true;break}qq.push(j)}}
    if(!found)continue;
    const path=[];for(let i=gl;i!==-1;i=par[i])path.push(i);path.reverse();
    const pts=[];for(let k=0;k<path.length;k+=9)pts.push(path[k]);if(pts[pts.length-1]!==gl)pts.push(gl);
    return pts.map(i=>[((i%W)+.5)*T,(((i/W)|0)+.5)*T]);
  }
  return [[(MW-8)*T,MH*.5*T],[7*T,MH*.3*T]];
})();
function routePos(a){let i=0;while(i<ROUTE.length-1){const d=Math.hypot(ROUTE[i+1][0]-ROUTE[i][0],ROUTE[i+1][1]-ROUTE[i][1]);if(a<=d)break;a-=d;i++}
  const A=ROUTE[i],B=ROUTE[Math.min(i+1,ROUTE.length-1)],d=Math.hypot(B[0]-A[0],B[1]-A[1])||1,t=Math.min(1,a/d);return{x:A[0]+(B[0]-A[0])*t,y:A[1]+(B[1]-A[1])*t,i:i+1,hd:Math.atan2(B[1]-A[1],B[0]-A[0])}}'''
s=s[:a]+route+s[b:]
# newRun enemies/convoy
a=s.index("  const lead=TP(88,20)");b=s.index("  for(const s of C.ships)if(!s.conv&&!clearAt(s.x,s.y,70))")
s=s[:a]+'''  const TQ=(x,y)=>[x*T,y*T];
  for(const [x,y] of[[44,58],[46,30],[78,56],[80,30],[108,62],[104,28],[64,80],[128,80]]){const p=TQ(x,y);const s=mkShip('mercante',p[0],p[1],rr(0,TAU));C.ships.push(s)}
  for(const [x,y] of[[75,42],[100,58],[114,36],[84,70]]){const p=TQ(x,y);const s=mkShip('pattuglia',p[0],p[1],rr(0,TAU));C.ships.push(s)}
'''+s[b:]
rep("fireQ:0,over:false,ramCd:0}","fireQ:0,over:false,ramCd:0,convoy:false}")
s=s.replace("function findSea(x,y)","""function spawnConvoy(){
  C.convoy=true;
  for(const[t,arc,lat]of[['scorta',1900,-70],['galeone',1520,0],['prigionieri',1140,30],['galeone',760,-20],['galeone',380,35],['scorta',0,70]]){
    const q=routePos(arc),sp0=SPEC[t];const s=mkShip(t,q.x,q.y,q.hd,{conv:true,prog:q.i,lat});C.ships.push(s)}
  sfx('quest');toast('Tito: «Capitano! Una fila di vele da est: è il convoglio!»',6000);
}
function findSea(x,y)""",1)
# story/J lines
s=s.replace("<b>J.:</b>","<b>Tito:</b>")
rep("toast('<b>Tito:</b> «Capitano, il convoglio! Una fila di vele a est, sulla rotta dello stretto.»')","toast('<b>Tito:</b> «Capitano, ci sono navi nemiche in zona. Affondane qualcuna: il convoglio arriverà presto.»')")
rep("if(!C.tut&&!C.notes.found&&C.ships.some(","if(!C.tut&&C.convoy&&!C.notes.found&&C.ships.some(")
# conditions
rep("if(!C.over&&(C.pris===2||C.prisLost)&&gal.length===0","if(!C.over&&C.convoy&&(C.pris===2||C.prisLost)&&gal.length===0")
rep("  const alive=C.ships.filter(s=>s.conv&&!s.dead);","  if(!C.convoy&&!C.tut&&(C.kills>=3||C.t>260))spawnConvoy();\n  const alive=C.ships.filter(s=>s.conv&&!s.dead);")
rep("$('c3obj').textContent=C.prisLost?","$('c3obj').textContent=!C.convoy?('Affonda le navi nemiche ('+Math.min(C.kills,3)+'/3): poi arriva il convoglio'):C.prisLost?")
# movement: stop when released
rep("  const tv=SAILSPD[C.sail]*windK(p.hd)","  const go=ctl&&(jm>.12||kx!==0||ky<0);\n  const tv=(go?SAILSPD[C.sail]:0)*windK(p.hd)")
rep("  s.v+=(tv-s.v)*Math.min(1,dt*1.1);","  s.v+=(tv-s.v)*Math.min(1,dt*(tv<s.v*.6?2.4:1.1));")
# visibility targeting
rep("function aimArc(){","function onScr(e){const o=$('c3ov'),w=o.clientWidth,h=o.clientHeight;if(!w)return true;const[x,y]=toScreen(e.x,e.y);return x>16&&x<w-16&&y>34&&y<h-16}\nfunction aimArc(){")
rep("for(const e of C.ships){if(e.dead||e.ally||e===p||e.sinking)continue;\n    const dist","for(const e of C.ships){if(e.dead||e.ally||e===p||e.sinking||!onScr(e))continue;\n    const dist")
rep("const list=own?C.ships.filter(e=>!e.dead&&e!==s&&!e.ally):[C.p];","const list=own?C.ships.filter(e=>!e.dead&&e!==s&&!e.ally&&onScr(e)):[C.p];")
# less aggressive
rep("dp<760*(C.plan?C.plan.detect:1)){s.hostile=true;","dp<520*(C.plan?C.plan.detect:1)){s.hostile=true;")
rep("      if(s.hostile||s.alert){","      if(s.type==='pattuglia'&&s.hostile&&dp>1000)s.hostile=false;\n      if(s.type==='scorta'&&s.alert&&dp>1500)s.alert=false;\n      if(s.hostile||s.alert){")
rep("const des=dp>520?want:","const des=dp>560?want:")
rep("sp0.spd*(dp<240?.8:1)*windK(s.hd));","sp0.spd*.75*windK(s.hd));")
rep("if(dp<640&&Math.abs(angD(sa,toP))<.7&&s.cd<=0&&(sd<0?s.cdL:s.cdR)<=0){fire(s,sd);s.cd=rr(1.4,2.6)","if(dp<540&&Math.abs(angD(sa,toP))<.6&&s.cd<=0&&(sd<0?s.cdL:s.cdR)<=0){fire(s,sd);s.cd=rr(2.6,4.4)")
# separation among ships
rep("  collide(dt);\n","  sepAll(dt);collide(dt);\n")
rep("function collide(dt){","""function sepAll(dt){
  const L=C.ships.filter(s=>!s.dead&&!s.sinking);
  for(let i=0;i<L.length;i++){const a=L[i];let ca=null;
    for(let j=i+1;j<L.length;j++){const b=L[j];
      if(Math.abs(a.x-b.x)>560||Math.abs(a.y-b.y)>560)continue;
      ca=ca||circ(a);const cb=circ(b);let pen=0;
      for(const u of ca)for(const v of cb){const ov=u[2]+v[2]+70-Math.hypot(u[0]-v[0],u[1]-v[1]);if(ov>pen)pen=ov}
      if(pen<=0)continue;
      let dx=b.x-a.x,dy=b.y-a.y;const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;
      const wa=a.still?0:1,wb=b.still?0:1,ws=wa+wb;if(!ws)continue;
      const k=Math.min(1,dt*5)*pen;
      const ax=a.x-dx*k*wa/ws,ay=a.y-dy*k*wa/ws,bx=b.x+dx*k*wb/ws,by=b.y+dy*k*wb/ws;
      if(wa&&shipOK(a,ax,ay,a.hd)){a.x=ax;a.y=ay}
      if(wb&&shipOK(b,bx,by,b.hd)){b.x=bx;b.y=by}
    }}
}
function collide(dt){""")
# tutorial texts
rep("x:'Trascina il pollice sullo schermo: la prua gira verso dove punti. Prova a far girare la nave.',ok:()=>Math.abs(angD(C.tut.hd0,C.p.hd))>.8}","x:'Spingi il joypad: la nave va verso dove punti. Se lo molli, si ferma. Prova a muoverti e a girare.',ok:()=>Math.hypot(C.p.x-C.tut.x0,C.p.y-C.tut.y0)>350}")
rep("tutStart(){C.tut={i:0,hd0:C.p.hd,tg:null}","tutStart(){C.tut={i:0,hd0:C.p.hd,x0:C.p.x,y0:C.p.y,tg:null}")
rep("x:'I tasti a sinistra regolano la velocità. Il quadrante","x:'I tasti a sinistra regolano la velocità massima. Il quadrante")
rep("x:'Il convoglio arriva da est. Affonda i galeoni e raccogli le casse d\\'argento.","x:'Prima affonda qualche nave nemica (pattuglie e mercantili): sparano poco e si scansano. Quando ne hai affondate tre arriva il convoglio da est. Affonda i galeoni e raccogli le casse d\\'argento.")
# pier shift already; dump etc untouched
open('ch3_inject.js','w').write(s)
