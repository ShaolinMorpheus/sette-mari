const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
const r=await p.evaluate(()=>{const C=Ch3.C;C.tut=null;const pt=C.ships.filter(s=>s.type==='pattuglia');
 const s=pt.find(x=>Math.hypot(x.x-C.p.x,x.y-C.p.y)>1000&&Math.hypot(x.x-C.p.x,x.y-C.p.y)<2200)||pt[0];const o=[];
 const near=pt.filter(x=>x!==s&&Math.hypot(x.x-s.x,x.y-s.y)<1500);
 o.push(pt.length,near.length,s.hostile);
 C.balls.push({x:s.x,y:s.y,vx:0,vy:0,t:0,life:5,own:C.p});
 const x0=s.x,y0=s.y;for(let i=0;i<240;i++)Ch3.step(1/30);
 o.push(s.hostile,near.every(n=>n.hostile),Math.round(Math.hypot(s.x-x0,s.y-y0)),Math.round(Math.hypot(s.x-C.p.x,s.y-C.p.y)),C.ships.length);return o});
console.log(JSON.stringify(r),errs);await b.close()})()
