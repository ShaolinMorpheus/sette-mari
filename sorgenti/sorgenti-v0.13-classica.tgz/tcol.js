const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({file:'index_test.html'});
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 const r=await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;
  for(const k of['legna','pietra','corda','rottami'])S.res[k]=500;
  for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];e.st=2;e.prog=1;S.built[id]=1}
  Pirati.UI.openUpgrades();
  const out=[];
  for(const k of['orto','essic']){const bt=document.querySelector('[data-dc="'+k+'"]');bt.click();}
  const cd=Pirati.E.filter(e=>e.type==='cdeco'&&(e.k==='orto'||e.k==='essic'));
  for(const e of cd)out.push(e.k+' tile '+e.tx+','+e.ty+' blk='+JSON.stringify(e.blk));
  
  const ok=(tx,ty)=>__T.boxFree((tx+.5)*44,(ty+.5)*44,9,5);
  out.push('orto-centro '+ok(40,29)+' essic-montante '+ok(40,25)+' essic-mezzo '+ok(41,25)+' banco '+(()=>{const e=Pirati.EID.plot_banco;return ok(e.fp[0],e.fp[1])+'/'+ok(e.fp[0]-1,e.fp[1])+'/'+ok(e.fp[0]+2,e.fp[1])})());
  const boxes=[];for(const e of cd){boxes.push([e.x-74,e.y-114,e.x+74,e.y+10])}
  const bn=Pirati.EID.plot_banco;boxes.push([(bn.fp[0]+1)*44-76,(bn.fp[1]+1)*44-124,(bn.fp[0]+1)*44+76,(bn.fp[1]+1)*44+10]);
  let bad=[];for(const e of Pirati.E){if(!/^(tree|pine|palm|bush|berry|rock)$/.test(e.type))continue;const b=Pirati.entBox(e);if(!b)continue;if(boxes.some(x=>b[0]<x[2]&&b[2]>x[0]&&b[1]<x[3]&&b[3]>x[1]))bad.push(e.type+'@'+e.tx+','+e.ty)}
  out.push('alberi sopra: '+bad.join(' '));
  return out.join(' | ')});
 console.log(r);console.log('ERR',JSON.stringify(errs));await b.close()})();
