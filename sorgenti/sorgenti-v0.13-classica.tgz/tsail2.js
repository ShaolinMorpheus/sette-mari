const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420},deviceScaleFactor:1})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(2500);await p.click('#bNew').catch(()=>{});
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(200)}
await p.waitForTimeout(800);
let i=0;for(const a of [0,1.2,1.57,1.95,3.14]){
 await p.evaluate(a=>{const s=Ch3.C.p;s.hd=a;s.v=0},a);await p.waitForTimeout(500);await p.screenshot({path:'ss'+(i++)+'.png',clip:{x:300,y:100,width:300,height:220}})}
console.log(er);await b.close()})();
