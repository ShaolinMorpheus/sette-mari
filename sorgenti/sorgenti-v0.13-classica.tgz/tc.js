const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({file:'index_test.html'});
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 const url=await p.evaluate(()=>{const c=document.createElement('canvas');c.width=520;c.height=300;const g=c.getContext('2d');g.fillStyle='#6f9640';g.fillRect(0,0,520,300);
  __T.drawSp(g,__T.SP.oldcamp,200,200,1.5);return c.toDataURL()});
 require('fs').writeFileSync('aud/oldcamp.png',Buffer.from(url.split(',')[1],'base64'));console.log('ERR',JSON.stringify(errs));await b.close()})();
