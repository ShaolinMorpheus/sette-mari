const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const er=[];
for(const w2 of [0,1]){
const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();p.on('pageerror',e=>er.push(e.message));
if(w2)await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate((w2)=>{const P=Pirati;let s=P.newState('D','m');if(w2)s=P.Ch2.convert(s);s.tutDone=1;s.flags.axe=1;s.q=w2?{c1:{st:'done',gi:0,p:0},c5:{st:'done',gi:0,p:0}}:{};localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)},w2);
await p.waitForTimeout(2000);
console.log('world',w2+1,await p.evaluate(()=>{const P=Pirati;
 const box=e=>P.entBox?P.entBox(e):null;return Object.keys(P).filter(k=>/box/i.test(k)).join()+' loots '+P.E.filter(e=>e.type==='loot').length}));
if(w2){
 await p.evaluate(()=>{const m=Pirati.EID.mast;Pirati.tp(m.x/44,m.y/44+1.2)});await p.waitForTimeout(600);
 await p.screenshot({path:'mast.png'});
 await p.evaluate(()=>{const m=Pirati.EID.mast;Pirati.interact?Pirati.interact(m):0});
}
await p.close()}
console.log(er);await b.close()})();
