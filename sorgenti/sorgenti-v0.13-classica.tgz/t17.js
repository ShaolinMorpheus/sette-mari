const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:412,height:915},hasTouch:true,isMobile:true});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>Pirati.startNew('T','m'));
for(let i=0;i<14;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(150)}
await p.evaluate(()=>{Pirati.S.flags.parrot=1;Pirati.S.phats={cuoco:1,bandana:1,monocolo:1};Pirati.S.phat='cuoco';Pirati.UI.openMenu()});
await p.waitForTimeout(400);await p.screenshot({path:'t17a.png'});
await p.click('[data-mn=pp]');await p.waitForTimeout(200);await p.screenshot({path:'t17b.png'});
await p.click('#mPh');await p.waitForTimeout(300);await p.screenshot({path:'t17c.png'});
await p.click('[data-ph=bandana]');await p.waitForTimeout(200);console.log(await p.evaluate(()=>Pirati.S.phat));
await p.evaluate(()=>Pirati.UI.openMenu());await p.waitForTimeout(200);await p.click('#mMus');console.log(await p.evaluate(()=>document.getElementById('mMus').className));
await b.close()})();
