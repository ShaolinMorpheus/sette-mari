#!/usr/bin/env python3
# v0.12d: Baia molto più lontana (mappa del mondo 1 allargata) e a forma della costa ovest dell'isola del Capitolo 2
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH16 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
rep("const I2=9;","const I2=70;")
# la Baia ricalca la costa ovest dell'isola vera del Capitolo 2 (stessa forma, stessa spiaggia)
rep("[79+I2,31,8,9],[82+I2,22,5,4],[74+I2,40,5,4.5]\n];","...[[24.6,30.6,4.6,5],[30,31,8,7],[36,21,11,8],[38,42,10,6],[44,31,5,9]].map(b=>[b[0]+51+I2,b[1]+1.6,b[2],b[3]])\n];")
rep("[71.8+I2,33,3.2,3.6],","[22.6+51+I2,32.6,3.6,4.2],[29+51+I2,46.6,5,2.2],")
rep("[80+I2,30,5,6,.7],[82+I2,22,3,2.5,.6]","[34+51+I2,40.6,8,5,.8],[28+51+I2,19.6,7,4,.7],[44+51+I2,29.6,8,4,.6],[38+51+I2,16.6,7,4,.8],[40+51+I2,34.6,9,7,.9]")
# vecchi salvataggi: la nebbia esplorata aveva righe da 99 caselle
rep("function fogFromStr(s){FOG.fill(0);","function fogFromStr(s){FOG.fill(0);if(s&&MW!==99&&s.length===99*MH){for(let y=0;y<MH;y++)for(let x=0;x<99;x++)FOG[y*MW+x]=s.charCodeAt(y*99+x)===49?1:0;FOGDIRTY=true;return}if(s&&MW!==99&&s.length===99*60){for(let y=0;y<60;y++)for(let x=0;x<99;x++)FOG[y*MW+x]=s.charCodeAt(y*99+x)===49?1:0;FOGDIRTY=true;return}")
# accampamento: correggo lo sprite (c[0]+I2 era un errore) e lo sposto con l'isola; zona libera dagli alberi
rep(".forEach((c,i)=>deco('fg'+i,c[0]+I2,c[1],c[2],null,{nohit:1,flip:!!c[3]}));",".forEach((c,i)=>deco('fg'+i,c[0],c[1]+I2,c[2],null,{nohit:1,flip:!!c[3]}));")
rep("  if(x>67+I2&&x<75+I2&&y>28&&y<38)return true;","  if(x>67+I2&&x<75+I2&&y>28&&y<38)return true;\n  if(WORLD===1&&x>76+I2&&x<90+I2&&y>21&&y<30)return true;")
open(P,'w',encoding='utf8').write(src)
print('patch16 ok')
