const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();
await p.goto('file:///home/claude/out/index_final.html');await p.evaluate(()=>{localStorage.setItem('sm_goto','#w4');localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:3,t:0}))});
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(3500);
console.log(await p.evaluate(()=>[location.hash,document.body.className,localStorage.getItem('sm_goto')]));await b.close()})();
