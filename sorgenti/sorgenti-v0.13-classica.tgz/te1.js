const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
console.log(await p.evaluate(()=>JSON.stringify(Pirati.E.filter(e=>e.x/44>47&&e.x/44<68&&e.y/44>23&&e.y/44<36&&!/^(tree|pine|palm|bush|berry|rock)$/.test(e.type)).map(e=>[e.id,e.type,e.spr||e.k||'',+(e.x/44).toFixed(1),+(e.y/44).toFixed(1)]))));
console.log(er);await b.close()})();
