#!/usr/bin/env python3
# v0.12e: editor (scogli in mare, alberi liberi) + migliorie del documento: marea, scheda dell'alba, Quaderno,
# premi di strada, premi di livello, vela all'orizzonte, nuovi cappelli
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH17 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
# i cappellini nuovi (x:1) si ottengono solo con le loro condizioni, non dalle casse
rep("S.phats=S.phats||{};const miss=PHATS.find(h=>!S.phats[h.id]);if(miss)S.phats[miss.id]=1;","S.phats=S.phats||{};const miss=PHATS.find(h=>!h.x&&!S.phats[h.id]);if(miss)S.phats[miss.id]=1;")
rep("const h=PHATS[S.cOpen/2-1];if(h){S.phats=S.phats||{};","const h=PHATS[S.cOpen/2-1];if(h&&!h.x){S.phats=S.phats||{};")
# scogli mossi o aggiunti dall'editor: sempre disegnati
rep("    if(e.type==='reef'&&WORLD!==2&&(e.tx<56||e.tx>76+I2))continue;\n","")
# --- oggetti luccicanti (tipo 'glint') ---
rep("      e.got=true;\n      if(e.type==='debris'){gain('rottami',1,e.x,e.y-20)}","      e.got=true;\n      if(e.type==='glint'){NV.collect(e)}\n      else if(e.type==='debris'){gain('rottami',1,e.x,e.y-20)}")
rep("    case'debris':return[e.x-26,e.y-30,e.x+26,e.y+8];","    case'debris':return[e.x-26,e.y-30,e.x+26,e.y+8];\n    case'glint':return[e.x-22,e.y-36,e.x+22,e.y+8];")
rep("    case'debris':case'bottle':case'loot':case'wparrot':return !e.got;","    case'debris':case'bottle':case'loot':case'wparrot':case'glint':return !e.got;")
rep("    case'debris':return{l:'Raccogli',i:'hand'};","    case'debris':return{l:'Raccogli',i:'hand'};\n    case'glint':return{l:'Raccogli',i:'hand'};")
rep("    case'debris':mk('pick',.45,0,null);break;","    case'debris':mk('pick',.45,0,null);break;\n    case'glint':mk('pick',.5,0,null);break;")
rep("-(e.type==='loot'||e.type==='bottle'||e.type==='debris'?.5*TS:0)","-(e.type==='loot'||e.type==='bottle'||e.type==='debris'||e.type==='glint'?.5*TS:0)")
rep("      case'debris':if(!e.got){drawSp(g,SP.debris,e.x,e.y);twinkle(g,e.x+10,e.y-24,t,8,e.x,'#fff6c0')}break;","      case'debris':if(!e.got){drawSp(g,SP.debris,e.x,e.y);twinkle(g,e.x+10,e.y-24,t,8,e.x,'#fff6c0')}break;\n      case'glint':drawGlint(g,e,t);break;")
rep("if(!(e.type==='loot'||e.type==='bottle'||e.type==='debris'||e.type==='rockpool'||e.type==='berry'||e.type==='bush')||!isInter(e))continue;","if(!(e.type==='loot'||e.type==='bottle'||e.type==='debris'||e.type==='glint'||e.type==='rockpool'||e.type==='berry'||e.type==='bush')||!isInter(e))continue;")
rep("const w=(e.type==='loot'||e.type==='bottle'?3:e.type==='debris'?2:1);","const w=(e.type==='loot'||e.type==='bottle'||e.type==='glint'?3:e.type==='debris'?2:1);")
rep("c.e.type==='debris'?'Cra! Rottami che luccicano!':","c.e.type==='debris'?'Cra! Rottami che luccicano!':c.e.type==='glint'?'Cra! Qualcosa luccica laggiù!':")
# --- passo periodico e avvio ---
rep("  updateEnts(dt);updateFx(dt);updateParrot(dt,RT);updateAmb(dt);\n}","  updateEnts(dt);updateFx(dt);updateParrot(dt,RT);updateAmb(dt);\n  try{NV.tick(dt)}catch(err){frameErr(err)}\n}")
rep("  if(WORLD===2)Ch2.onBegin();\n}","  if(WORLD===2)Ch2.onBegin();\n  try{NV.onBegin()}catch(e){console.error(e)}\n}")
# --- il Quaderno passa da un capitolo all'altro ---
rep("for(const k of['phats','phat','rec','xpt','cOpen','pname','hints','sound','music','wown','wear'])","for(const k of['phats','phat','rec','xpt','cOpen','pname','hints','sound','music','wown','wear','nv'])")
rep("n.wown=s.wown;n.wear=s.wear;","n.wown=s.wown;n.wear=s.wear;n.nv=s.nv;")
# --- livelli con premi ---
rep("UI.banner('Livello '+l1,LV_TITLES[l1-1]+'\\nLe azioni sono un po\\' più rapide');sfx('quest');","UI.banner('Livello '+l1,LV_TITLES[l1-1]+'\\n'+NV.lvText(l0,l1));sfx('quest');")
rep("const quiet=got.every(x=>x.id==='h_tri'||x.id==='o_cap'||x.id==='h_band');","const quiet=got.every(x=>x.id==='h_tri'||x.id==='o_cap'||x.id==='h_band'||x.quiet);")
rep("    for(const r of RECIPES){\n      const ok=hasRes(r.cost);","    for(const r of RECIPES){\n      if(r.lv&&lvOf(S.xpt||0)<r.lv){h+='<div class=\"upg\"><h3>🔒 '+r.n+'</h3><p class=\"sm\">Si sblocca al livello '+r.lv+'.</p></div>';continue}\n      const ok=hasRes(r.cost);")
rep("Indizio: cuoci al falò con '+Object.keys(r.cost).map(k=>RNAME[k].toLowerCase()).join(', ')+'.","Indizio: '+(r.lv&&lvOf(S.xpt||0)<r.lv?'si sblocca al livello '+r.lv:'cuoci al falò con '+Object.keys(r.cost).map(k=>RNAME[k].toLowerCase()).join(', '))+'.")
rep("    for(const d of DECOR){\n      const have=S.camp.some(o=>o.k===d.k);","    for(const d of DECOR){\n      if(d.lv&&lvOf(S.xpt||0)<d.lv){h+='<div class=\"upg\"><h3>🔒 '+d.n+'</h3><p class=\"sm\">Si sblocca al livello '+d.lv+'.</p></div>';continue}\n      const have=S.camp.some(o=>o.k===d.k);")
# --- disegni: cappelli nuovi dell'eroe e del pappagallo, decorazioni del campo ---
rep("g.fillStyle='#e0b13a';for(const px of[-5.4,5.4]){g.beginPath();g.arc(px,hy-8.2,.9,0,7);g.fill()}\n  }\n  g.restore();\n  g.restore();\n  if(o.emote){","g.fillStyle='#e0b13a';for(const px of[-5.4,5.4]){g.beginPath();g.arc(px,hy-8.2,.9,0,7);g.fill()}\n  }else if(typeof NVH!=='undefined'&&NVH[hat])NVH[hat](g,hy,hr,hc,back,sp_,dk);\n  g.restore();\n  g.restore();\n  if(o.emote){")
rep("g.arc(6.2,-15,1.1,0,7);g.fill()}\n  // zampe","g.arc(6.2,-15,1.1,0,7);g.fill()}\n  else if(typeof NVP!=='undefined'&&NVP[o.hat])NVP[o.hat](g);\n  // zampe")
rep("  else if(e.k==='essic'){drawEssic(g,e,t)}\n  g.restore();\n}","  else if(e.k==='essic'){drawEssic(g,e,t)}\n  else if(typeof NVCD!=='undefined'&&NVCD[e.k])NVCD[e.k](g,e,t,wood);\n  g.restore();\n}")
# --- per i test ---
rep("  get quality(){return QL},","  get NV(){return typeof NV!=='undefined'?NV:null},get quality(){return QL},")
# --- il codice nuovo ---
NEW=open('/home/claude/work/new17.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")
# --- registro delle novità ---
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "La marea: ogni alba (dal secondo giorno) porta tre cose sulla riva, con un luccichio da trovare: bottiglie con un biglietto, conchiglie rare, cassette, legni di mare.",
    "Scheda dell'alba: svegliandoti compare il riepilogo del giorno prima (pesci, reliquie, costruzioni, ricette), il cielo, la luna, l'orto, l'essiccatore e ciò che ha portato la marea.",
    "Quaderno delle collezioni (Diario › Raccolta): conchiglie, piume, sassi colorati e avvistamenti di creature, con premi per il guardaroba. Piccole cose brillanti lungo i sentieri finiscono nelle collezioni.",
    "Livelli con premi: livello 2 benda da pirata per Biscotto, 3 berretto da boscaiolo, 5 ricetta (crostata), 8 stendardo per il campo, 10 tricorno del Navigatore, 12 giubba del Corsaro. Gli altri livelli regalano qualcosa per il Quaderno.",
    "Una vela all'orizzonte: la prima volta che sali sul Pino Alto al tramonto, scorgi il galeone spagnolo (un indizio sul Capitolo 3).",
    "Nuovi cappelli: di conchiglie, con le piume; per Biscotto, cilindro e cuffia da marinaio.",
    "Editor: ora si possono selezionare, spostare, eliminare e aggiungere anche gli scogli in mare; alberi, cespugli e scogli si spostano liberi, a pixel, come i bauli.",
''')
open(P,'w',encoding='utf8').write(src)
print('patch17 ok')
