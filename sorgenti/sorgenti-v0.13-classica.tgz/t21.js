const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
const t0=Date.now();await p.goto('file:///home/claude/out/capitolo3_isola.html');
await p.waitForFunction(()=>window.Ch3&&Ch3.C!==undefined&&document.querySelector('#load')==null||true,{timeout:1000}).catch(()=>{});
await p.waitForTimeout(9000);console.log('t',Date.now()-t0);
await p.screenshot({path:'c3b.png'});
console.log(await p.evaluate(()=>{const C=Ch3.C;return C&&C.ships?C.ships.length:'noC'}),errs);await b.close()})()
