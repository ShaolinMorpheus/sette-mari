p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:70],s.count(a))
    s=s.replace(a,b)
# interaction hooks
rep("    case'cdeco':return null;\n    case'deco':if(e.nohit)","    case'cdeco':return null;\n    case'npc':return[e.x-22,e.y-80,e.x+22,e.y+6];\n    case'thief':return[e.x-26,e.y-40,e.x+26,e.y+8];\n    case'deco':if(e.nohit)")
rep("    case'cdeco':return e.k==='amaca'||e.k==='tavolo'||e.k==='cartello';\n  }","    case'cdeco':return e.k==='amaca'||e.k==='tavolo'||e.k==='cartello';\n    case'npc':return true;\n    case'thief':return !e.flee;\n  }")
rep("const REACHK={plot:1.55,","const REACHK={npc:1.9,thief:2,plot:1.55,")
rep("    case'cdeco':return e.k==='amaca'?{l:'Riposa',i:'bed'}","    case'npc':return{l:'Parla',i:'talk'};\n    case'thief':return{l:'Scaccia',i:'hand'};\n    case'cdeco':return e.k==='amaca'?{l:'Riposa',i:'bed'}")
rep("    case'cdeco':\n      if(e.k==='amaca'){UI.nap();return}","    case'npc':Ch2.talk(e);return;\n    case'thief':Ch2.scare(e);return;\n    case'cdeco':\n      if(e.k==='amaca'){UI.nap();return}")
rep("      case'cdeco':drawCDeco(g,e,t);break;\n    }","      case'cdeco':drawCDeco(g,e,t);break;\n      case'npc':drawNpc(g,e,t);break;\n      case'thief':drawThief(g,e,t);break;\n    }")
# mast
rep("      mk('chop',0,S.up.axe?2:3,'axe');P.act.per=AXE_T/actSpeed();break;","      mk('chop',0,e.id==='mast'?(S.up.axe?7:10):(S.up.axe?2:3),'axe');P.act.per=AXE_T/actSpeed();break;")
rep("      gain('legna',n,e.x,e.y-30);\n      hint('wood');break}","      gain('legna',n,e.x,e.y-30);\n      hint('wood');if(e.id==='mast')Ch2.onMast(e);break}")
rep("if(e.t<=0&&!nearPl(e,2.2)&&Math.abs(Math.floor(P.x/TS)-e.tx)","if(e.t<=0&&!e.once&&!nearPl(e,2.2)&&Math.abs(Math.floor(P.x/TS)-e.tx)")
# SIDE list, drink flag, tick, begin
rep("const SIDE=['s1','s2','s3','s4','s5','s6','s7'];","const SIDE=WORLD===2?['n1','n2','n3','n4','n5','n6','n7','n8']:['s1','s2','s3','s4','s5','s6','s7'];")
rep("Story.onDrink=function(){S.flags.drank=1;checkAll()};","Story.onDrink=function(){S.flags.drank=1;S.flags.c2drank=1;checkAll()};")
rep("  Story.parrotChat(dt);Extra.tick(dt);Extra.tickCalm(dt);","  if(WORLD===2)Ch2.tick(dt);\n  Story.parrotChat(dt);Extra.tick(dt);Extra.tickCalm(dt);")
rep("  UI.sync();UI.syncObj();UI.hud();UI.tutShow();\n}","  UI.sync();UI.syncObj();UI.hud();UI.tutShow();\n  if(WORLD===2)Ch2.onBegin();\n}")
# loot hooks
rep("Story.onLoot=function(e){\n","Story.onLoot=function(e){\n  if(WORLD===2&&Ch2.onLoot(e))return;\n")
# look hooks
rep("Story.look=function(e){\n  if(e.id==='feedback'){UI.openFeedback();return}","Story.look=function(e){\n  if(e.id==='feedback'){UI.openFeedback();return}\n  if(WORLD===2&&Ch2.look(e))return;")
# loot drawing kinds 10, 11
rep("function drawLoot(g,e,t){\n","""function drawLoot(g,e,t){
  if(e.kind===10||e.kind===11){
    if(e.got)return;g.save();g.translate(e.x,e.y);shadow(g,0,2,14,5,.28);
    if(e.kind===10){g.rotate(-.5);g.fillStyle='#6a4a2a';rr(g,-12,-3,10,6,2);g.fill();g.strokeStyle='#2a1a0e';g.lineWidth=1.2;g.stroke();g.fillStyle='#c7ced6';g.beginPath();g.moveTo(-2,-3);g.lineTo(15,0);g.lineTo(-2,3);g.closePath();g.fill();g.stroke();g.fillStyle='#d9a437';g.fillRect(-3,-5,2.4,10)}
    else{g.rotate(.18);g.fillStyle='#efe3bd';rr(g,-11,-7,22,14,2);g.fill();g.strokeStyle='#8a6a3a';g.lineWidth=1.2;g.stroke();g.fillStyle='#8a6a3a';for(let i=0;i<3;i++)g.fillRect(-8,-3+i*4,12-i*2,1.4);g.fillStyle='#d8412f';g.beginPath();g.arc(7,4,2.6,0,7);g.fill()}
    g.restore();twinkle(g,e.x+10,e.y-24,t,8,e.x,'#fff6c0');return}
""")
# deco specials: clue, cave
rep("  const s=spriteOf(e.spr);if(!s)return;\n  g.save();g.translate(e.x,e.y);\n  if(e.flip)g.scale(-1,1);","""  if(e.spr==='cave'){
    g.save();g.translate(e.x,e.y);shadow(g,0,4,70,14,.3);
    g.fillStyle='#6f675e';g.beginPath();g.moveTo(-70,2);g.quadraticCurveTo(-72,-70,-26,-84);g.quadraticCurveTo(0,-98,30,-86);g.quadraticCurveTo(72,-70,70,2);g.closePath();g.fill();g.strokeStyle='#2c2823';g.lineWidth=2;g.stroke();
    g.fillStyle='#8a8176';for(const[a,b,r]of[[-48,-30,18],[44,-34,16],[-18,-76,16],[22,-74,14]]){g.beginPath();g.ellipse(a,b,r,r*.7,0,0,7);g.fill()}
    const q=g.createRadialGradient(0,-20,4,0,-24,34);q.addColorStop(0,'#050403');q.addColorStop(1,'#1c1814');g.fillStyle=q;g.beginPath();g.moveTo(-30,2);g.quadraticCurveTo(-34,-50,0,-56);g.quadraticCurveTo(34,-50,30,2);g.closePath();g.fill();
    g.fillStyle='rgba(100,150,70,.7)';for(let i=0;i<6;i++){g.beginPath();g.ellipse(-62+i*24,-4,9,4,0,0,7);g.fill()}
    g.restore();return}
  if(e.spr==='clue'){
    if(e.hidden)return;g.save();g.translate(e.x,e.y);
    g.fillStyle='rgba(60,40,20,.55)';
    if(e.k===2){g.fillStyle='#8a8f96';g.beginPath();g.ellipse(0,-3,9,4.2,0,0,7);g.fill();g.strokeStyle='#3a3f46';g.lineWidth=1.4;g.stroke();g.fillStyle='#4a6a8a';g.beginPath();g.ellipse(0,-4,6,2.4,0,0,7);g.fill()}
    else for(let i=0;i<5;i++){g.beginPath();g.ellipse(-16+i*8,(i%2?3:-3),3,1.7,.3,0,7);g.fill();g.beginPath();g.ellipse(-14+i*8,(i%2?3:-3),1.3,1,.3,0,7);g.fill()}
    g.restore();if(!e.seen)twinkle(g,e.x+8,e.y-18,t,6,e.x,'#fff');return}
  const s=spriteOf(e.spr);if(!s)return;
  g.save();g.translate(e.x,e.y);
  if(e.flip)g.scale(-1,1);""")
# face detail in drawChar (scar, freckles)
rep("    if(sp_.real){g.strokeStyle='rgba(90,45,25,.55)';g.lineWidth=1;g.beginPath();g.moveTo(.4,hy+1);","    if(sp_.scar){g.strokeStyle='rgba(120,50,40,.75)';g.lineWidth=1.3;g.beginPath();g.moveTo(-6.4,hy-3.2);g.lineTo(-4.6,hy+4.6);g.stroke()}\n    if(sp_.freckles){g.fillStyle='rgba(150,80,40,.55)';for(const[fx,fy]of[[-5.2,3],[-3.4,4.2],[3.4,4.2],[5.2,3],[-4,2],[4,2]]){g.beginPath();g.arc(fx,hy+fy,.7,0,7);g.fill()}}\n    if(sp_.real){g.strokeStyle='rgba(90,45,25,.55)';g.lineWidth=1;g.beginPath();g.moveTo(.4,hy+1);")
open(p,'w',encoding='utf8').write(s)
print('ok')
