#!/usr/bin/env python3
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH32 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
rep('''<button class="btn gold" id="bkCp">Copia</button><button class="btn" id="bkDl">Salva file</button></div>''',
    '''<button class="btn gold" id="bkCp">Copia</button><button class="btn" id="bkSv">⬇ Scarica sul telefono</button><button class="btn" id="bkDl">Condividi</button><button class="btn" id="bkMl">✉ Invia per email</button></div>''')
rep('''      c.querySelector('#bkDl').onclick=async()=>{''','''      c.querySelector('#bkSv').onclick=async()=>{
        const name='sette-mari-salvataggio.txt',C=window.Capacitor,PL=C&&C.Plugins;
        try{
          if(C&&C.isNativePlatform&&C.isNativePlatform()&&!(C.isPluginAvailable&&C.isPluginAvailable('Filesystem'))){
            st.textContent='Questa versione dell\\'app non può salvare file nel telefono. Usa «Condividi» (poi «Salva in File» o Drive), «Invia per email» o «Copia». Con l\\'APK nuovo questo tasto funziona.';return}
          if(C&&C.isNativePlatform&&C.isNativePlatform()&&PL&&PL.Filesystem){
            try{await PL.Filesystem.requestPermissions()}catch(_){}
            let r,dir='DOCUMENTS';
            try{r=await PL.Filesystem.writeFile({path:name,data:code,directory:'DOCUMENTS',encoding:'utf8',recursive:true})}
            catch(e1){dir='la cartella dell\\'app';r=await PL.Filesystem.writeFile({path:name,data:code,directory:'EXTERNAL',encoding:'utf8',recursive:true})}
            st.textContent='Salvato! File «'+name+'» nella cartella Documenti del telefono (app File › Documenti).';
            if(dir!=='DOCUMENTS')st.textContent='Salvato nella cartella dell\\'app (Android › data › it.settemari.game › files). Per portarlo fuori usa «Condividi».';
            return;
          }
          const a=document.createElement('a'),b=new Blob([code],{type:'text/plain'});
          a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();a.remove();
          st.textContent='File scaricato (se il browser lo consente). In alternativa copia il codice.';
        }catch(_){st.textContent='Non riesco a scaricare il file: usa «Condividi» o «Copia».'}
      };
      c.querySelector('#bkMl').onclick=()=>{
        try{location.href='mailto:?subject='+encodeURIComponent('Salvataggio Sette Mari')+'&body='+encodeURIComponent('Codice di salvataggio di Sette Mari (copialo per intero nel gioco, in Copia di sicurezza › Ripristina):\\n\\n'+code);
          st.textContent='Si apre la tua app di posta: invia la mail a te stesso. Il codice resta nella tua casella.'}
        catch(_){st.textContent='Non riesco ad aprire la posta: usa «Copia».'}
      };
      c.querySelector('#bkDl').onclick=async()=>{''')
A='''    "Erba più ricca: prato fitto'''
rep(A,'''    "Copia di sicurezza: nuovo tasto «Scarica sul telefono» che salva il file nella cartella Documenti e «Invia per email» (salva il codice nella tua posta, funziona anche con le vecchie app); il vecchio «Salva file» ora si chiama «Condividi».",
'''+A)
open(P,'w',encoding='utf8').write(src)
print('patch32 ok')
