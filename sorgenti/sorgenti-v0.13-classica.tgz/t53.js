const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1000,height:480},locale:'en-US'})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(5000);
await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.p.hull=1;});await p.waitForTimeout(1500);await p.evaluate(()=>{Ch3.C.tut=null});await p.waitForTimeout(500);
await p.screenshot({path:'sea_en.png'});console.log(await p.evaluate(()=>I18N.missing().slice(0,80)),er);await b.close()})()
