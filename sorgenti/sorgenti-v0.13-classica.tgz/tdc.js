const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 for(const loc of ['isola1']){
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.built=S.built||{};S.built.banco=1;S.built.falo=1;S.built.capanna=1;for(const k of['legna','pietra','corda','rottami'])S.res[k]=60;Pirati.UI.sync()});
 await p.evaluate(()=>Pirati.UI.openUpgrades());await p.waitForTimeout(500);
 for(const k of['orto','essic']){
  const r=await p.evaluate(k=>{const b=document.querySelector('[data-dc="'+k+'"]');if(!b)return 'nobtn';const dis=b.disabled;b.click();return {dis,camp:(Pirati.S.camp||[]).map(o=>o.k).join(','),toast:(document.getElementById('toast')||{}).innerText}},k);
  console.log(k,JSON.stringify(r));await p.waitForTimeout(400)}
 }
 console.log('ERR',JSON.stringify(errs));await b.close()})();
