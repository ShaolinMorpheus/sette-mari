const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>Pirati.startNew('T','m'));
for(let i=0;i<8;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(300)}
const r=await p.evaluate(()=>{
 const rows=[];for(let y=14;y<48;y++){let s='';for(let x=64;x<99;x++){const t=Pirati.tileInfo(x,y);s+=t.sea?'~':t.block?'#':t.walk?(t.free?'.':'o'):'?'}rows.push(y+' '+s)}
 return rows.join('\n')+'\n'+JSON.stringify(Pirati.FIX)});
console.log(r);
await b.close()})();
