const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(2500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(2500);
await p.evaluate(()=>Pirati.Ch2.endCard('all'));await p.waitForTimeout(500);
await p.click('#eC3');await p.waitForTimeout(5000);
console.log(await p.evaluate(()=>[location.hash,document.body.className]));await p.screenshot({path:'c3.png'});console.log(er);await b.close()})();
