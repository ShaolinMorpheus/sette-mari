const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(450,400);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{const c=Pirati.Ch2.st();c.met.gnocco=1;Pirati.S.q.n1={st:'active',gi:0};Pirati.S.q.n4={st:'active',gi:0};const e=Pirati.EID.npc_gnocco;Pirati.P.x=e.x;Pirati.P.y=e.y+30;Pirati.cam.x=e.x;Pirati.cam.y=e.y});await p.waitForTimeout(800);
const btn=()=>p.evaluate(()=>[...document.querySelectorAll('#dlgChoices .btn')].map(b=>b.textContent));
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(700);await p.mouse.click(450,400);await p.waitForTimeout(2500);
console.log(await btn());await p.screenshot({path:'menu_g2.png'});
await p.evaluate(()=>[...document.querySelectorAll('#dlgChoices .btn')].find(b=>/Altro|Missioni/.test(b.textContent)).click());await p.waitForTimeout(2500);
console.log(await btn());console.log(er);await b.close()})();
