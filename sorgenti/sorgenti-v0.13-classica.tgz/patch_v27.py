#!/usr/bin/env python3
# v0.12o (D5): la grotta buia della prima isola (serve la torcia), con la cassa dell'Elmetto da minatore
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH27 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
NEW=open('/home/claude/work/new26.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")

# 1) la mappa interna esiste anche nella prima isola: regione di tile libera, nel mare a nord-est
rep("const CV_W=33,CV_H=12,CV_X0=12,CV_Y0=1;","const CV_W=WORLD===1?24:33,CV_H=WORLD===1?11:12,CV_X0=WORLD===1?72:12,CV_Y0=1;")
rep("function inCave(){return WORLD===2&&P.mode!=='raft'&&","function inCave(){return (WORLD===1||WORLD===2)&&P.mode!=='raft'&&")
# 2) entrata e uscita: punti diversi nelle due isole
rep("cavePlace((CV_X0+16)*TS,(CV_Y0+9.9)*TS);CVX.fade=1;sfx('thud');","if(WORLD===1)cavePlace((CV_X0+4.3)*TS,(CV_Y0+9.2)*TS);else cavePlace((CV_X0+16)*TS,(CV_Y0+9.9)*TS);CVX.fade=1;sfx('thud');")
rep("const f=nearestFree(Math.floor(CV2.cave[0]),Math.floor(CV2.cave[1])+2,6);","const cp=WORLD===1?CV1P:CV2.cave,f=nearestFree(Math.floor(cp[0]),Math.floor(cp[1])+2,6);")
# 2b) i versi del pappagallo in grotta solo se il pappagallo c'è (nella prima isola può non averlo ancora incontrato)
rep('if(tor){say(PAR,"Cra! Bella fiamma. Si vede tutto.")}','if(tor){if(S.flags.parrot)say(PAR,"Cra! Bella fiamma. Si vede tutto.")}')
rep('else if(S.up.torch){say(PAR,"Cra! Che buio! Accendi la torcia!");UI.toast(','else if(S.up.torch){if(S.flags.parrot)say(PAR,"Cra! Che buio! Accendi la torcia!");UI.toast(')
rep('else{say(PAR,"Cra! Buio fitto. Serve una torcia: si fa al Banco!");UI.toast(','else{if(S.flags.parrot)say(PAR,"Cra! Buio fitto. Serve una torcia: si fa al Banco!");UI.toast(')
# 3) la cassa si disegna dentro la grotta
rep("for(const nm of['cavex','cvrudder']){","for(const nm of['cavex','cvrudder','cvchest']){")
rep("function drawCaveSp(g,e,t){\n  if(e.spr==='cavex'){","function drawCaveSp(g,e,t){\n  if(e.spr==='cvchest'){drawCvChest(g,e,t);return}\n  if(e.spr==='cavex'){")
# 4) pulsanti: «Entra» all'ingresso, «Apri» sulla cassa
rep("if(e.id==='cave')return{l:'Entra',i:'hand'};if(e.id==='cavex')return{l:'Esci',i:'hand'};","if(e.id==='cave'||e.id==='cave1')return{l:'Entra',i:'hand'};if(e.id==='cavex')return{l:'Esci',i:'hand'};if(e.id==='cvchest')return{l:'Apri',i:'hand'};")
# 5) esamina: ingresso, uscita, cassa
rep("  if(WORLD===2&&Ch2.look(e))return;\n  if(e.id==='wreck'){","  if(WORLD===2&&Ch2.look(e))return;\n  if(WORLD===1&&cave1Look(e))return;\n  if(e.id==='wreck'){")
# 6) generazione del mondo 1: l'ingresso accanto alla cava
rep("  hutBuild();\n  // il pappagallo selvatico","  hutBuild();if(WORLD===1)cave1Place(deco);\n  // il pappagallo selvatico")
# 7) passo di gioco
rep("torchTick();caveStep(dt);hutStep(dt);","torchTick();caveStep(dt);hutStep(dt);try{cave1Tick(dt)}catch(e){console.error('grotta1',e)}")
# registro delle novità
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "La grotta buia della prima isola: vicino alla cava, sul lato roccioso, c'è un'apertura con travi di legno. Dentro è buio pesto anche di giorno: serve la torcia (si costruisce al Banco da lavoro) e la puoi accendere a qualsiasi ora. Tre sale, una pozza, cristalli che brillano, pipistrelli, tre bracieri da accendere con la torcia, un vecchio contrabbandiere con la sua cassetta e, in fondo, la cassa col Tricorno del contrabbandiere (guardaroba, anche per lo spaventapasseri) e 30 XP: si apre solo quando i tre bracieri sono accesi. Nuovo traguardo: Speleologo. Il pappagallo ti ricorda della grotta appena hai la torcia.",
''')
open(P,'w',encoding='utf8').write(src)
print('patch27 ok')
