const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.pre_v66.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.Ch2.convert(P.newState('D','m'));s.flags.parrot=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
const clr=async()=>{for(let k=0;k<4;k++){await p.evaluate(async()=>{for(let i=0;i<100&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,30))}});await p.waitForTimeout(500)}};
await clr();
const ev=(f,a)=>p.evaluate(f,a);
await ev(()=>{const C=Pirati.Ch2.st();for(const w of['ferro','nives','tito','gnocco'])C.met[w]=1;Pirati.S.q.c5={st:'done',gi:1,p:0};Object.assign(Pirati.S.res,{arrosto:5,rottami:5,bacche:5,coco:5,legna:5,pietra:5})});
// talk menu with extras
await ev(()=>{Pirati.tp(59.6,29.5);Pirati.Ch2.talk(Pirati.EID.npc_nives)});await p.waitForTimeout(800);
await p.screenshot({path:'t15_talk.png'});
console.log('choices',await ev(()=>[...document.querySelectorAll('#dlgChoices button')].map(b=>b.textContent)));
// riddle path: pick extra (index of 'Regalo o gioco')
await ev(()=>{const bs=[...document.querySelectorAll('#dlgChoices button')];bs.find(b=>/Regalo/.test(b.textContent)).click()});await p.waitForTimeout(500);
console.log('extras',await ev(()=>[...document.querySelectorAll('#dlgChoices button')].map(b=>b.textContent)));
await clr();
// treasure
console.log('tre',await ev(()=>['lt_isleA','lt_isleB','lt_isleC','lt_isleD','lt_hill'].map(i=>{const e=Pirati.EID[i];return e?[i,e.tx,e.ty,Pirati.tileInfo(e.tx,e.ty).walk]:[i,null]})));
await ev(()=>{Pirati.Ch2.onLoot(Pirati.EID.lt_hill)});await clr();
// parrot mark & big map
await ev(()=>{Pirati.PQ.mark=Pirati.EID.lt_isleA;Pirati.PQ.markT=1e9;Pirati.UI.openBigMap()});await p.waitForTimeout(600);await p.screenshot({path:'t15_map.png'});
await ev(()=>document.getElementById('mapOk').click());
// minimap marks + evening/night
await ev(()=>{Pirati.S.tod=20;Pirati.fast(1)});await p.waitForTimeout(25000);
console.log(await ev(()=>Pirati.E.filter(e=>e.type==='npc').map(e=>e.who+':'+(e.x/44).toFixed(1)+','+(e.y/44).toFixed(1)).join(' ')));
await p.screenshot({path:'t15_eve.png'});
await ev(()=>{Pirati.S.tod=23});await p.waitForTimeout(30000);
console.log('night',await ev(()=>Pirati.E.filter(e=>e.type==='npc').map(e=>e.who+':'+(e.x/44).toFixed(1)+','+(e.y/44).toFixed(1)).join(' ')));
await b.close()})();
