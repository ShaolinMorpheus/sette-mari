/* ---------------- B2: tratti di calma, forzieri, nebbia, bottiglie con mappa, brigantino ---------------- */
const inV=(x,y,m)=>{const z=camZoom();return Math.abs(x-cam.x)<VW/2/z+(m||0)&&Math.abs(y-cam.y)<VH/2/z+(m||0)};
function routeD(x,y){let m=1e9;for(const q of ROUTE){const d=Math.hypot(q[0]-x,q[1]-y);if(d<m)m=d}return m}
function pT(key,html,ms){if(C.notes[key]||C.t-(C.lastPT||-99)<16)return;C.notes[key]=1;C.lastPT=C.t;toast(html,ms)}   // avvisi facoltativi: mai due di seguito
function poiSpot(minD,maxD,r,gap,coast,avoidRoute){      // un punto di mare libero, lontano dal porto e dagli altri punti d'interesse
  const pt=TPp(21,30),used=C.poi.all;
  for(let k=0;k<500;k++){
    const x=rr(400,WW-400),y=rr(400,WH-400),dp=Math.hypot(x-pt[0],y-pt[1]);
    if(dp<minD||dp>maxD||!clearAt(x,y,r))continue;
    if(coast===1&&clearAt(x,y,r+300))continue;        // sulla costa: poco più in là c'è terra
    if(coast===0&&!clearAt(x,y,r+170))continue;       // in mare aperto
    if(avoidRoute&&routeD(x,y)<avoidRoute)continue;
    if(used.some(u=>Math.hypot(u[0]-x,u[1]-y)<gap))continue;
    return[x,y]
  }
  return null
}
function beachSpot(cx,cy,minD,maxD,gap){      // una casella di sabbia sulla riva con mare libero davanti: [x forziere, y forziere, x mare, y mare]
  const used=C.poi.all,pt=TPp(21,30);
  for(let k=0;k<5000;k++){
    const a=rr(0,TAU),d=rr(minD,maxD),x=cx+Math.cos(a)*d,y=cy+Math.sin(a)*d;
    if(x<300||y<300||x>WW-300||y>WH-300)continue;
    const tx=Math.floor(x/T),ty=Math.floor(y/T);if(tx<5||ty<5||tx>=MW-5||ty>=MH-5)continue;
    const i=tIdx(tx,ty);
    if(seaT[i]||blockT[i]||!walkT[i]||elevT[i]<SAND_LO||elevT[i]>SAND_HI)continue;
    const bx=(tx+.5)*T,by=(ty+.5)*T;
    if(Math.hypot(bx-pt[0],by-pt[1])<1500||used.some(u=>Math.hypot(u[0]-bx,u[1]-by)<gap))continue;
    for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){
      for(let s=1;s<=3;s++){
        const jx=tx+dx*s,jy=ty+dy*s,j=tIdx(jx,jy);
        if(walkT[j]||blockT[j])break;                  // altra terra o scoglio: non è la riva
        if(seaT[j]===1){
          const sx=(jx+dx+.5)*T,sy=(jy+dy+.5)*T;
          if(clearAt(sx,sy,40))return[bx-dx*14,by-dy*14,sx,sy];
          break
        }
      }
    }
  }
  return null
}
function poiPlace(){
  const P0=C.poi={all:[],chests:[],bottles:[],brigs:0,brigT:rr(34,58),botT:rr(55,85),nb:0,cove:null,fog:null};
  const pt=TPp(21,30);
  let q=poiSpot(1700,5600,100,1500,1,0);
  if(q){P0.cove={x:q[0],y:q[1],r:250,t:0,sT:2};P0.all.push(q)}
  for(let k=0;k<2;k++){
    const b=beachSpot(pt[0],pt[1],1900,5600,1500);
    if(b){P0.chests.push({k:'chest',x:b[0],y:b[1],sx:b[2],sy:b[3],n:2,open:0,t:rr(0,9),seed:rr(0,9)});P0.all.push([b[0],b[1]])}
  }
  q=poiSpot(2200,5600,100,1500,0,900);
  if(q){
    const f=P0.fog={x:q[0],y:q[1],r:520,blobs:[]};P0.all.push(q);
    for(let i=0;i<16;i++){const a=rr(0,TAU),d=Math.sqrt(Math.random())*f.r*.8;f.blobs.push({x:Math.cos(a)*d,y:Math.sin(a)*d,r:rr(170,250),ph:rr(0,TAU),sp:rr(.12,.28)})}
    for(let i=0,n=0;i<40&&n<2;i++){const a=rr(0,TAU),d=rr(60,240),x=f.x+Math.cos(a)*d,y=f.y+Math.sin(a)*d;if(!clearAt(x,y,40))continue;C.crates.push({x,y,t:rr(0,9),v:'silver',opt:true,fog:true});n++}
  }
}
function openChest(c){
  c.open=1;c.ot=0;
  for(let i=0;i<(c.n||2);i++)C.crates.push({x:c.sx+rr(-30,30),y:c.sy+rr(-30,30),t:rr(0,9),v:'silver',opt:true});
  for(let i=0;i<10;i++)C.fx.push({k:'flash',x:c.x+rr(-26,26),y:c.y+rr(-28,8),r:9,t:0,life:.6});
  sfx('quest');C.lastPT=C.t;
  if(c.k==='map'){
    if(C.map===c)C.map=null;
    toast('<b>Tesoro trovato!</b> Il forziere è pieno: raccogli le casse d\'argento che galleggiano in acqua.',6500);
    try{YD.stat('maps');yAnn(3200)}catch(e){}
    setTimeout(()=>{if(C&&!C.over)parEv('crate',1)},2200)
  }else toast('<b>Tito:</b> «Il forziere era pieno d\'argento! Raccogli le casse in acqua.»',6000)
}
function spawnBottle(){
  const p=C.p;
  for(let k=0;k<80;k++){
    const a=p.hd+rr(-1.3,1.3),d=rr(650,1150),x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;
    if(x<300||y<300||x>WW-300||y>WH-300||!clearAt(x,y,70))continue;
    C.poi.bottles.push({x,y,t:rr(0,9),vx:rr(-6,6),vy:rr(-6,6)});C.poi.nb++;
    toast('<b>Biscotto:</b> «Cra! Una bottiglia in acqua '+dirName(x-p.x,y-p.y)+'! C\'è qualcosa dentro!»',6500);C.lastPT=C.t;
    return
  }
  C.poi.botT=10
}
function takeBottle(b){
  b.got=1;const p=C.p;
  sfx('pick');for(let i=0;i<6;i++)C.fx.push({k:'flash',x:b.x+rr(-20,20),y:b.y+rr(-16,10),r:8,t:0,life:.45});
  const m=beachSpot(p.x,p.y,1700,3600,1100);
  if(!m){C.crates.push({x:b.x+30,y:b.y,t:0,v:'silver',opt:true});toast('<b>Nella bottiglia</b> c\'è solo un biglietto: «Buon vento, capitano!» E una cassa d\'argento che galleggia lì accanto.',6000);return}
  C.map={k:'map',x:m[0],y:m[1],sx:m[2],sy:m[3],n:3,open:0,t:0,seed:rr(0,9)};C.poi.chests.push(C.map);C.poi.all.push([m[0],m[1]]);
  toast('<b>Tito:</b> «Una mappa del tesoro! La X è su una spiaggia '+dirName(m[0]-p.x,m[1]-p.y)+', a '+Math.round(Math.hypot(m[0]-p.x,m[1]-p.y)/T)+' caselle. Segui la freccia color pergamena.»',8000);C.lastPT=C.t
}
function spawnBrig(){
  const p=C.p;
  for(let k=0;k<80;k++){
    const a=rr(0,TAU),d=rr(1900,2600),x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;
    if(x<300||y<300||x>WW-300||y>WH-300||!clearAt(x,y,90))continue;
    const s=mkShip('brigantino',x,y,a,{});C.ships.push(s);C.brig=s;C.poi.brigs++;
    toast('<b>Tito:</b> «Una vela viola '+dirName(x-p.x,y-p.y)+'! È un brigantino veloce: scappa appena ti vede. Se lo affondi porta casse d\'argento.»',7500);C.lastPT=C.t;
    return
  }
  C.poi.brigT=15
}
function brigAI(s,dt,dp){      // il brigantino scappa dal giocatore; dopo un po' si stanca e rallenta
  const p=C.p,sp0=SPEC.brigantino;
  if(dp>4600){s.dead=true;s.sinking=false;if(C.brig===s)C.brig=null;return}
  s.wpT=(s.wpT||0)-dt;
  if(!s.wp||s.wpT<=0||Math.hypot(s.wp[0]-s.x,s.wp[1]-s.y)<260){
    let best=null,bs=-1;
    for(let k=0;k<14;k++){const a=rr(0,TAU),d=rr(900,2000),x=s.x+Math.cos(a)*d,y=s.y+Math.sin(a)*d;if(x<300||y<300||x>WW-300||y>WH-300||!clearAt(x,y,90))continue;const sc=Math.hypot(x-p.x,y-p.y)+rr(0,500);if(sc>bs){bs=sc;best=[x,y]}}
    s.wp=best||randSea();s.wpT=rr(9,16)
  }
  const chase=dp<1500;
  if(chase&&!(s.tire>0))s.fl=(s.fl||0)+dt;else if(!chase)s.fl=Math.max(0,(s.fl||0)-dt*.5);
  if(s.tire>0)s.tire-=dt;
  else if(s.fl>12){s.tire=6.5;s.fl=0;if(dp<1400)toast('<b>Biscotto:</b> «Cra! Il brigantino rallenta, è stanco! Sotto, capitano!»',4500)}
  steerTo(s,s.wp[0],s.wp[1],dt,1.25);s.hd=avoid(s,s.hd);
  const hk=.55+.45*cl(s.hull/s.max,0,1);
  moveShip(s,dt,sp0.spd*windK(s.hd)*(chase?1:.55)*(s.tire>0?.45:1)*hk)
}
function poiStep(dt){
  const P0=C.poi;if(!P0)return;const p=C.p;
  // --- cala tranquilla ---
  const cv=P0.cove;
  if(cv){
    cv.t+=dt;const d=Math.hypot(p.x-cv.x,p.y-cv.y);
    if(d<cv.r){
      pT('cove','<b>Tito:</b> «Una cala tranquilla! Qui il mare è calmo e i pesci saltano. Fermati un po\': lo scafo si ripara da solo.»',6500);
      if(p.hull<p.max){p.hull=Math.min(p.max,p.hull+dt*.35);cv.hT=(cv.hT||0)-dt;if(cv.hT<=0){cv.hT=1.2;tone(880,0,.22,'triangle',.05);C.fx.push({k:'heal',x:p.x+rr(-70,70),y:p.y+rr(-34,20),vx:0,vy:-34,t:0,life:1.1})}}
    }else if(d<1500)pT('coveNear','<b>Tito:</b> «C\'è una cala tranquilla '+dirName(cv.x-p.x,cv.y-p.y)+'. Se lo scafo è rovinato, fermati lì.»',5500);
    cv.sT-=dt;if(cv.sT<=0){cv.sT=rr(2.4,5);if(d<1000&&AU.ctx&&AU.on){noiseBurst(.1,1500,.045);tone(520,260,.09,'sine',.03)}}
  }
  // --- forzieri sulla spiaggia e tesoro della mappa ---
  for(const c of P0.chests){
    c.t+=dt;if(c.open){c.ot=(c.ot||0)+dt;continue}
    const d=Math.hypot(p.x-c.x,p.y-c.y);
    if(d<200)openChest(c);
    else if(c.k==='chest'&&d<1500)pT('chestNear','<b>Tito:</b> «Un forziere sulla spiaggia '+dirName(c.x-p.x,c.y-p.y)+'! Avvicinati con la nave per aprirlo.»',6000)
  }
  // --- bottiglie ---
  if(!C.map&&P0.bottles.length===0&&P0.nb<3){P0.botT-=dt;if(P0.botT<=0){P0.botT=rr(75,115);spawnBottle()}}
  for(const b of P0.bottles){
    b.t+=dt;const nx=b.x+b.vx*dt,ny=b.y+b.vy*dt;if(seaOK(nx,ny)){b.x=nx;b.y=ny}else{b.vx=-b.vx;b.vy=-b.vy}
    const d=Math.hypot(p.x-b.x,p.y-b.y);
    if(d<95)takeBottle(b);else if(d>3600)b.got=2
  }
  if(P0.bottles.some(b=>b.got))P0.bottles=P0.bottles.filter(b=>!b.got);
  // --- nebbia: le pattuglie ti vedono solo da vicino ---
  const f=P0.fog;let inF=false;
  if(f){
    const d=Math.hypot(p.x-f.x,p.y-f.y);inF=d<f.r*.9;
    if(inF)pT('fog','<b>Tito:</b> «Nebbia fitta! Le pattuglie ti vedono solo da vicino. E qui in giro potrebbe esserci qualcosa…»',6500);
    else if(d<1500)pT('fogNear','<b>Biscotto:</b> «Cra! Un banco di nebbia '+dirName(f.x-p.x,f.y-p.y)+'. Nascondersi lì è facile!»',5500)
  }
  C.inFog=inF;C.fogA=(C.fogA||0)+((inF?1:0)-(C.fogA||0))*Math.min(1,dt*2);
  // --- brigantino viola (solo prima dell'arrivo del convoglio) ---
  if(C.brig&&C.brig.dead)C.brig=null;
  if(P0.brigs<2&&!C.brig&&!C.convoy){P0.brigT-=dt;if(P0.brigT<=0){P0.brigT=rr(70,110);spawnBrig()}}
}
/* ---- disegno ---- */
function glint(g,x,y,r){g.beginPath();g.moveTo(x-r,y);g.lineTo(x,y-r*.35);g.lineTo(x+r,y);g.lineTo(x,y+r*.35);g.closePath();g.moveTo(x,y-r);g.lineTo(x+r*.35,y);g.lineTo(x,y+r);g.lineTo(x-r*.35,y);g.closePath();g.fill()}
function coveDraw(g,cv,t){
  g.save();g.translate(cv.x,cv.y);g.lineCap='round';
  for(let i=0;i<24;i++){      // luccichio calmo
    const a=i*2.399+.7,d=Math.sqrt((i+.5)/24)*cv.r*.94,x=Math.cos(a)*d,y=Math.sin(a)*d,ph=Math.sin(t*1.1+i*1.7),al=.2+.34*Math.max(0,ph),l=14+((i*7)%3)*6;
    g.strokeStyle='rgba(236,255,250,'+al+')';g.lineWidth=3;g.beginPath();g.moveTo(x-l,y);g.quadraticCurveTo(x,y-3-ph*2.4,x+l,y);g.stroke()}
  for(let k=0;k<3;k++){const u=(t*.2+k/3)%1;g.strokeStyle='rgba(190,255,245,'+(.26*(1-u))+')';g.lineWidth=3;g.beginPath();g.arc(0,0,cv.r*(.25+.75*u),0,7);g.stroke()}
  g.setLineDash([12,14]);g.lineDashOffset=-t*8;g.strokeStyle='rgba(205,255,248,.45)';g.lineWidth=3;g.beginPath();g.arc(0,0,cv.r,0,7);g.stroke();g.setLineDash([]);
  const ring=(x,y,k)=>{g.strokeStyle='rgba(255,255,255,'+(.7*(1-k))+')';g.lineWidth=2.2;g.beginPath();g.ellipse(x,y+6,6+k*22,2.4+k*8,0,0,7);g.stroke()};
  for(let i=0;i<5;i++){      // pesci che saltano
    const per=3.2+i*.55,tt=t+i*1.9,ph=tt%per,dur=1;if(ph>dur+.7)continue;
    const sd=Math.floor(tt/per)*7.31+i*3.7,f1=Math.abs(Math.sin(sd*12.9898)*43758.5453)%1,f2=Math.abs(Math.sin(sd*78.233)*12345.678)%1;
    const a0=f1*TAU,d0=Math.sqrt(f2)*cv.r*.72,dir=f1>.5?1:-1,cx0=Math.cos(a0)*d0,cy0=Math.sin(a0)*d0;
    if(ph<.5)ring(cx0-dir*42,cy0,ph/.5);
    if(ph>=dur){ring(cx0+dir*42,cy0,(ph-dur)/.7);continue}
    const u=ph/dur,hh=Math.sin(u*Math.PI)*40,x=cx0+dir*(u-.5)*84,y=cy0-hh,ang=Math.atan2(-Math.cos(u*Math.PI)*Math.PI*40,dir*84);
    g.fillStyle='rgba(0,40,70,.16)';g.beginPath();g.ellipse(x,cy0+8,10*(1-hh/70),3,0,0,7);g.fill();
    g.save();g.translate(x,y);g.rotate(ang);if(dir<0)g.scale(1,-1);
    g.fillStyle='#86b9e6';g.beginPath();g.ellipse(0,0,12,4.8,0,0,7);g.fill();
    g.fillStyle='#e8f4ff';g.beginPath();g.ellipse(1,1.5,9,2.5,0,0,Math.PI);g.fill();
    g.fillStyle='#4f8fd0';g.beginPath();g.moveTo(-10,0);g.lineTo(-18,-6);g.lineTo(-18,6);g.closePath();g.fill();
    g.fillStyle='#1a2a3a';g.beginPath();g.arc(7,-1,1.2,0,7);g.fill();
    g.restore()
  }
  if(Math.hypot(C.p.x-cv.x,C.p.y-cv.y)<1300){g.textAlign='center';g.font='800 15px Nunito,Arial';g.lineWidth=4;g.strokeStyle='rgba(10,22,34,.85)';g.fillStyle='#c8fff2';g.strokeText('Cala tranquilla',0,-cv.r*.6);g.fillText('Cala tranquilla',0,-cv.r*.6)}
  g.restore()
}
function chestDraw(g,c,t){
  const op=c.open?Math.min(1,(c.ot||0)*3):0;
  g.save();g.translate(c.x,c.y);
  g.fillStyle='rgba(50,34,10,.3)';g.beginPath();g.ellipse(2,13,24,8,0,0,7);g.fill();
  if(c.k==='map'&&!c.open){      // la X rossa sulla sabbia
    const pl=.5+.5*Math.sin(t*3);
    g.strokeStyle='#b8321f';g.lineWidth=8;g.lineCap='round';g.beginPath();g.moveTo(-17,-17);g.lineTo(17,17);g.moveTo(17,-17);g.lineTo(-17,17);g.stroke();
    g.strokeStyle='rgba(255,236,170,'+(.3+.45*pl)+')';g.lineWidth=3;g.beginPath();g.arc(0,0,32+pl*7,0,7);g.stroke();
    g.fillStyle='rgba(255,246,190,'+(.4+.5*pl)+')';glint(g,-26,-22,8);glint(g,24,-12,6)
  }else{
    for(const[rx,ry,a,b2]of[[-29,5,15,10],[28,7,12,8],[-8,19,10,6]]){      // i sassi attorno al forziere
      g.fillStyle='#7d7a78';g.beginPath();g.ellipse(rx,ry,a,b2,0,0,7);g.fill();g.fillStyle='#a8a5a2';g.beginPath();g.ellipse(rx-2,ry-2,a*.7,b2*.6,0,0,7);g.fill();
      g.strokeStyle='#4a4846';g.lineWidth=1.6;g.beginPath();g.ellipse(rx,ry,a,b2,0,0,7);g.stroke()}
    g.fillStyle='#8a5a2a';g.strokeStyle='#2a1a0e';g.lineWidth=2.4;g.fillRect(-17,-8,34,22);g.strokeRect(-17,-8,34,22);
    g.fillStyle='#e8b730';g.fillRect(-17,-1,34,4);g.fillRect(-12,-8,4,22);g.fillRect(8,-8,4,22);
    if(!op){
      g.fillStyle='#9a6a34';g.beginPath();g.moveTo(-17,-8);g.quadraticCurveTo(0,-30,17,-8);g.closePath();g.fill();g.stroke();
      g.fillStyle='#e8b730';g.fillRect(-12,-17,4,9);g.fillRect(8,-17,4,9);g.fillRect(-3,-11,6,7);
      const s=.5+.5*Math.sin(t*4+c.seed);g.fillStyle='rgba(255,246,190,'+(.35+.55*s)+')';glint(g,13,-19,5+s*3)
    }else{
      g.fillStyle='#2a1608';g.fillRect(-15,-8,30,5);
      if((c.ot||0)<5){g.fillStyle='#e6ebf5';for(let i=0;i<5;i++){g.beginPath();g.arc(-11+i*5.5,-8,2.6,0,7);g.fill()}}
      g.fillStyle='#7a4c22';g.beginPath();g.moveTo(-17,-8);g.lineTo(-14,-30);g.quadraticCurveTo(0,-38,14,-30);g.lineTo(17,-8);g.closePath();g.fill();g.stroke();
      g.fillStyle='#e8b730';g.fillRect(-11,-26,4,14);g.fillRect(7,-26,4,14)
    }
  }
  g.restore();
  if(!c.open&&c.k==='chest'&&Math.hypot(C.p.x-c.x,C.p.y-c.y)<800){g.save();g.textAlign='center';g.font='800 14px Nunito,Arial';g.lineWidth=4;g.strokeStyle='rgba(10,22,34,.85)';g.fillStyle='#ffe9a0';g.strokeText('Forziere',c.x,c.y-48);g.fillText('Forziere',c.x,c.y-48);g.restore()}
}
function bottleDraw(g,b,t){
  const bob=Math.sin(b.t*2)*3;
  g.save();g.translate(b.x,b.y+bob);g.scale(1.3,1.3);
  const gl=g.createRadialGradient(0,0,4,0,0,60);gl.addColorStop(0,'rgba(190,255,230,.34)');gl.addColorStop(1,'rgba(190,255,230,0)');g.fillStyle=gl;g.fillRect(-60,-60,120,120);
  const u=(b.t*.5)%1;g.strokeStyle='rgba(255,255,255,'+(.5*(1-u))+')';g.lineWidth=2;g.beginPath();g.ellipse(0,12,16+u*24,6+u*8,0,0,7);g.stroke();
  g.rotate(-.5+Math.sin(b.t*1.3)*.12);
  g.fillStyle='rgba(150,225,200,.88)';g.strokeStyle='#2a5a50';g.lineWidth=2;
  g.beginPath();g.moveTo(-18,-7);g.lineTo(8,-7);g.quadraticCurveTo(14,-7,17,-3);g.lineTo(26,-3);g.lineTo(26,3);g.lineTo(17,3);g.quadraticCurveTo(14,7,8,7);g.lineTo(-18,7);g.quadraticCurveTo(-23,7,-23,0);g.quadraticCurveTo(-23,-7,-18,-7);g.closePath();g.fill();g.stroke();
  g.fillStyle='#f0e0b0';g.fillRect(-14,-3.5,20,7);g.strokeStyle='#a87a3a';g.lineWidth=1;g.strokeRect(-14,-3.5,20,7);
  g.fillStyle='#b98a55';g.fillRect(26,-3.4,6,6.8);
  g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=2;g.beginPath();g.moveTo(-16,-4.6);g.lineTo(6,-4.6);g.stroke();
  g.restore();
  const s=.5+.5*Math.sin(t*5+b.t);g.fillStyle='rgba(255,255,255,'+(.4+.5*s)+')';glint(g,b.x+16,b.y-18+bob,6+s*3)
}
function poiDraw(g,t){
  const P0=C.poi;if(!P0)return;
  const cv=P0.cove;if(cv&&inV(cv.x,cv.y,cv.r+150))coveDraw(g,cv,t);
  for(const c of P0.chests)if(inV(c.x,c.y,200))chestDraw(g,c,t);
  for(const b of P0.bottles)if(inV(b.x,b.y,150))bottleDraw(g,b,t)
}
let fogSpr=null;
function fogSprite(){return fogSpr||(fogSpr=sp(420,420,g=>{const q=g.createRadialGradient(210,210,10,210,210,205);q.addColorStop(0,'rgba(238,244,250,.86)');q.addColorStop(.55,'rgba(232,240,248,.5)');q.addColorStop(1,'rgba(230,238,248,0)');g.fillStyle=q;g.fillRect(0,0,420,420)},210,210))}
function poiFog(g,t){      // il banco di nebbia copre le navi, ma si dirada attorno al giocatore
  const f=C.poi&&C.poi.fog;if(!f||!inV(f.x,f.y,f.r+320))return;
  const spr=fogSprite(),p=C.p;
  for(const b of f.blobs){
    const x=f.x+b.x+Math.cos(t*b.sp+b.ph)*34,y=f.y+b.y+Math.sin(t*b.sp*.8+b.ph*1.3)*22,dpx=Math.hypot(x-p.x,y-p.y),thin=cl((dpx-90)/(b.r+130),.18,1);
    drawSp(g,spr,x,y,b.r*2/420,.94*thin)
  }
}
function poiMini(c,p,sc){
  const P0=C.poi;if(!P0)return;
  const put=(x,y,fn)=>{const dx=(x-p.x)*sc,dy=(y-p.y)*sc;if(dx*dx+dy*dy>106*106)return;c.save();c.translate(dx,dy);fn();c.restore()};
  if(P0.fog)put(P0.fog.x,P0.fog.y,()=>{c.fillStyle='rgba(235,242,250,.42)';c.beginPath();c.arc(0,0,Math.max(6,P0.fog.r*sc),0,7);c.fill()});
  if(P0.cove)put(P0.cove.x,P0.cove.y,()=>{c.strokeStyle='rgba(130,240,228,.95)';c.lineWidth=2.4;c.beginPath();c.arc(0,0,Math.max(5,P0.cove.r*sc),0,7);c.stroke()});
  for(const h of P0.chests){
    if(h.open)continue;
    if(h.k==='map'){let dx=(h.x-p.x)*sc,dy=(h.y-p.y)*sc;const d=Math.hypot(dx,dy),far=d>98,pl=.5+.5*Math.sin(C.t*6);if(far){dx=dx/d*98;dy=dy/d*98}
      c.save();c.translate(dx,dy);c.fillStyle='#ead7a4';c.strokeStyle='#2a1a0e';c.lineWidth=2;c.beginPath();c.arc(0,0,7.5+pl,0,7);c.fill();c.stroke();c.strokeStyle='#b8321f';c.lineWidth=2.6;c.beginPath();c.moveTo(-3.6,-3.6);c.lineTo(3.6,3.6);c.moveTo(3.6,-3.6);c.lineTo(-3.6,3.6);c.stroke();c.restore()}
    else put(h.x,h.y,()=>{c.fillStyle='#ffd23a';c.strokeStyle='#3a2410';c.lineWidth=1.6;c.fillRect(-4,-3,8,6);c.strokeRect(-4,-3,8,6)})
  }
  for(const b of P0.bottles)put(b.x,b.y,()=>{c.fillStyle='#9fe8d0';c.strokeStyle='#1a4a40';c.lineWidth=1.6;c.beginPath();c.arc(0,0,3.6,0,7);c.fill();c.stroke()})
}
function poiOverlay(g,w,h){
  const P0=C.poi;if(!P0||C.over||C.tut||C.go5)return;
  const out=(x,y)=>!(x>26&&x<w-26&&y>40&&y<h-26),m=C.map;
  if(m&&!m.open){
    const[x,y]=toScreen(m.x,m.y);
    if(out(x,y))edgeArrow(g,w,h,x,y,'#ead7a4',Math.hypot(m.x-C.p.x,m.y-C.p.y));
    else{g.save();g.translate(x,y-56-Math.abs(Math.sin(C.t*4))*9);g.fillStyle='#ead7a4';g.strokeStyle='#2a1a0e';g.lineWidth=2.5;g.beginPath();g.moveTo(0,16);g.lineTo(-12,-7);g.lineTo(12,-7);g.closePath();g.fill();g.stroke();g.restore()}
  }
  for(const b of P0.bottles){const[x,y]=toScreen(b.x,b.y);if(out(x,y))edgeArrow(g,w,h,x,y,'#9fe8d0',Math.hypot(b.x-C.p.x,b.y-C.p.y))}
  if((C.fogA||0)>.02){g.fillStyle='rgba(226,236,244,'+(C.fogA*.2)+')';g.fillRect(0,0,w,h)}
}
