#!/usr/bin/env python3
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH33 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
NEW=open('/home/claude/work/new30.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")
rep("try{blkSync(dt)}catch(e){console.error('blk',e)}","try{blkSync(dt)}catch(e){console.error('blk',e)}try{X2.tick(dt)}catch(e){console.error('x2',e)}")
rep("  try{rsDraw(g,t)}catch(e){}","  try{rsDraw(g,t)}catch(e){}\n  try{X2.draw(g,t)}catch(e){}")
rep("g.save();g.translate(cxm,cym);g.rotate(P.hd);g.fillStyle='#fff'","try{X2.mini(g,mxw,myw)}catch(e){}\n  g.save();g.translate(cxm,cym);g.rotate(P.hd);g.fillStyle='#fff'")
rep("[['q','Missioni'],['s','Stagione 1'],['r','Raccolta'],['a','Archivio'],['n','Novità']]","[['q','Missioni'],['o','Da fare'],['x','Statistiche'],['s','Stagione 1'],['r','Raccolta'],['a','Archivio'],['n','Novità']]")
rep("  if(jTab==='r')return Extra.collectionHtml();","  if(jTab==='o'||jTab==='x'){if(!S||!S.live)return'<p class=\"sm\">Comincia una partita: qui troverai le cose da fare e le tue statistiche.</p>';return jTab==='o'?X2.todoHtml():X2.statsHtml()}\n  if(jTab==='r')return Extra.collectionHtml();")
rep("if(perf)float(P.x,P.y-90,'Colpo perfetto! +1','#ffe27a');","if(perf){S.stat.perf=(S.stat.perf||0)+1;float(P.x,P.y-90,'Colpo perfetto! +1','#ffe27a')}")
rep("catch(_){}startNew(nm,hero)}","catch(_){}X2.ngAsk(()=>startNew(nm,hero))}")
rep("window.Pirati={RS,","window.Pirati={X2,RS,")
A='''    "Copia di sicurezza: nuovo tasto'''
rep(A,'''    "Diario, nuova scheda «Statistiche»: tempo di gioco, passi, miglia in mare, pesci, colpi perfetti, tesori e tanto altro.",
    "Diario, nuova scheda «Da fare»: cosa puoi fare adesso, in un colpo d'occhio.",
    "Incarico del giorno: ogni giorno Biscotto ti chiede una cosa semplice, con un piccolo premio (e il conto dei giorni di fila).",
    "Bottiglia del giorno: ogni giorno una bottiglia speciale sulla riva, con un regalo, un pezzo per il Quaderno o una mappa del tesoro.",
    "Caccia al tesoro: con la mappa cammini e leggi «freddo, tiepido, caldo, fuoco!» finché trovi il tesoro (vibra anche il telefono).",
    "Il mercante di passaggio: ogni tre giorni attracca sulla spiaggia, ti avvisa e lo trovi sulla minimappa. Scambia cose comuni con cose rare.",
    "Missioni di Biscotto: cinque brevi missioni per isola, una alla volta. L'ultima è il segreto dell'isola: una X graffiata per terra, tutta da cercare.",
    "Nuova partita+: chi ha finito il Capitolo 1 può ricominciare tenendo cappelli, Quaderno e traguardi.",
    "Schermata iniziale: ora sta tutta in una schermata, senza scorrere.",
'''+A)
open(P,'w',encoding='utf8').write(src)
print('patch33 ok')
