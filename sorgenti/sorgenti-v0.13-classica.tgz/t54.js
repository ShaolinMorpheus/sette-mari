const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1000,height:480},locale:'de-DE'})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(6000);
await p.screenshot({path:'int_de.png'});console.log(await p.evaluate(()=>I18N.missing().filter(s=>!/^(Sette Mari|Isola|Preparo|Disegno|Popolo|Sopravvivi|Naufrago)/.test(s)).slice(0,40)),er);await b.close()})()
