const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const out=[];
 const mk=async(file,dump,flag)=>{const ctx=await b.newContext({viewport:{width:915,height:412},deviceScaleFactor:1,hasTouch:true});
   const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error'&&!/agent-proxy|Failed to load resource/.test(m.text()))errs.push('console:'+m.text().slice(0,160))});
   await p.addInitScript(([d,f])=>{try{if(!sessionStorage.getItem('_t_init')){localStorage.clear();sessionStorage.setItem('_t_init','1');if(d)for(const k in d)localStorage.setItem(k,d[k])}}catch(e){}},[dump,flag]);
   await p.goto('file:///home/claude/out/'+file);
   await p.waitForFunction(()=>window.Pirati&&window.Pirati.S,null,{timeout:90000}).catch(()=>{});await p.waitForTimeout(1200);return {ctx,p,errs}};
 const skip=async(p)=>{for(let i=0;i<14;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS','tutSkip']){const e=document.getElementById(id);if(e&&!e.hidden&&e.offsetParent!==null)e.click()}try{Pirati.UI.dlgAuto&&Pirati.UI.dlgAuto()}catch(e){}});await p.waitForTimeout(120)}};
 // --- 1. vecchia versione: crea una partita con un po' di progresso ---
 const A=await mk('index.html',null);
 await A.p.evaluate(()=>Pirati.startNew('Vecchio','m'));await skip(A.p);
 await A.p.evaluate(()=>{const S=Pirati.S;S.flags.axe=1;S.flags.flint=1;S.flags.hat=1;S.flags.parrot=1;S.built={falo:1,capanna:1,banco:1};S.tutDone=1;S.tut=null;S.day=3;
   for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}
   for(const k of['legna','pietra','corda','rottami','pesce','bacche'])S.res[k]=9;S.phats={};S.xpt=300;Pirati.saveGame()});
 const dump1=await A.p.evaluate(()=>{const o={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);o[k]=localStorage.getItem(k)}return o});
 out.push(['vecchia ch1: chiavi',Object.keys(dump1).join(',')+' | errori '+JSON.stringify(A.errs)]);
 // vecchia versione: passa al capitolo 2 e dump
 await A.p.evaluate(()=>{Pirati.Ch2.begin()});await A.p.waitForNavigation({timeout:20000}).catch(()=>{});
 await A.p.waitForFunction(()=>window.Pirati&&window.Pirati.S&&window.Pirati.S.live,null,{timeout:60000}).catch(()=>{});await A.p.waitForTimeout(1200);
 const dump2=await A.p.evaluate(()=>{const o={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);o[k]=localStorage.getItem(k)}return o});
 out.push(['vecchia ch2: ',JSON.stringify(await A.p.evaluate(()=>({ch:Pirati.S.ch,world:Pirati.WORLD})))+' | errori '+JSON.stringify(A.errs)]);
 await A.ctx.close();
 // --- 2. nuova versione con salvataggio capitolo 1 ---
 for(const [name,dump] of [['ch1',dump1],['ch2',dump2]]){
   const B=await mk('index_final.html',dump);
   const r=await B.p.evaluate(()=>{try{Pirati.startContinue();return {ok:true}}catch(e){return {err:String(e)}}});
   await B.p.waitForTimeout(2500);await skip(B.p);
   const st=await B.p.evaluate(()=>{const S=Pirati.S,F=Pirati.farm;if(!S||!S.live)return {live:false};
     F.wardCheck();return {live:true,ch:S.ch,world:Pirati.WORLD,name:S.name,day:S.day,wown:Object.keys(S.wown||{}),gard:S.gard||null,dry:S.dry||null,camp:(S.camp||[]).map(o=>o.k),spec:F.heroSpec().hat,hasPOP:typeof F.hasFarm}});
   out.push(['nuova con salvataggio vecchio '+name,JSON.stringify(r)+' '+JSON.stringify(st)]);
   // gioca un po' con il tempo e costruisci orto nel vecchio salvataggio
   const g=await B.p.evaluate(async()=>{const S=Pirati.S,F=Pirati.farm,o={};
     for(const k of['legna','pietra','corda','rottami'])S.res[k]=30;
     const d=F.DECOR.find(x=>x.k==='orto');o.cost=JSON.stringify(d.cost);
     try{o.placed=F.campBuild(d);}catch(e){o.err=String(e)}
     F.farmInit();o.gard=JSON.stringify(S.gard);F.farmAdvance(50);
     Pirati.saveGame();return o});
   out.push(['  orto su vecchio salvataggio '+name,JSON.stringify(g)]);
   await B.p.reload();await B.p.waitForFunction(()=>window.Pirati&&window.Pirati.S,null,{timeout:90000}).catch(()=>{});await B.p.waitForTimeout(1000);
   await B.p.evaluate(()=>{try{Pirati.startContinue()}catch(e){}});await B.p.waitForTimeout(2500);
   out.push(['  dopo ricarica '+name,JSON.stringify(await B.p.evaluate(()=>{const S=Pirati.S;return S&&S.live?{camp:(S.camp||[]).map(o=>o.k),gard:!!S.gard,ents:Pirati.E.filter(e=>e.type==='cdeco'&&e.k==='orto').length}:{live:false}}))+' errori '+JSON.stringify(B.errs)]);
   await B.ctx.close();
 }
 console.log(out.map(x=>x.join(': ')).join('\n'));
 await b.close()})();
