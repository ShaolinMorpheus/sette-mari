p='base_index.html';s=open(p,encoding='utf8').read()
a=s.index("  for(const h of hs.filter(h=>!h.x&&!h.offer))");b=s.index("  const g=Ch2.GREET[w][(Math.random()*3)|0];")
new='''  const qs=hs.filter(h=>!h.x&&!h.offer).map(h=>({t:h.label(),h}));
  const oth=hs.filter(h=>h.x||h.offer).map(h=>({t:h.label(),h}));
  if(w==='nives')oth.push({t:"Scambiare materiali",h:'trade'});
  if(w==='gnocco')oth.push({t:"Fatti cucinare qualcosa",h:'cook'});
  const grp=(L,name,q)=>{if(!L.length)return;choices.push({t:L.length===1?L[0].t:name,fn:()=>{act=L.length===1?L[0].h:{sub:L,q}}})};
  grp(qs,"Missioni…","Di cosa si tratta?");
  choices.push({t:"Chiacchierare un po'",fn:()=>{act='chat'}});
  grp(oth,"Altro…","Cosa facciamo?");
  choices.push({t:"Niente, a dopo",fn:()=>{}});
'''
s=s[:a]+new+s[b:]
a=s.index("    if(act==='trade')Ch2.openTrade();");b=s.index("  });\n};\nCh2.chat=")
new2='''    const go=x=>{if(x==='trade')Ch2.openTrade();else if(x==='cook')Ch2.openCook();else if(x==='chat')Ch2.chat(w);else if(x&&x.run)x.run()};
    if(act&&act.sub){const L=act.sub;act=null;UI.dlg([D(w,L.q||"Cosa facciamo?",{choices:L.map(o=>({t:o.t,fn:()=>{act=o.h}})).concat([{t:"Niente",fn:()=>{act=null}}])})],()=>go(act))}
    else go(act);
'''
s=s[:a]+new2+s[b:]
s=s.replace('["Altro…","More…"','["Missioni…","Missions…","Aufgaben…","Misiones…","Missions…"],["Di cosa si tratta?","What is it about?","Worum geht es?","¿De qué se trata?","De quoi s'+"'"+'agit-il ?"],["Altro…","More…"',1) if '["Missioni…"' not in s else s
open(p,'w',encoding='utf8').write(s)
