const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.built={falo:1,capanna:1,banco:1};for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}Pirati.saveGame();Pirati.Ch2.begin()});
 await p.waitForNavigation({timeout:20000}).catch(()=>{});
 await p.waitForFunction(()=>window.Pirati&&window.Pirati.S&&window.Pirati.S.live,null,{timeout:60000}).catch(()=>{});await p.waitForTimeout(1500);await L.skip(p);
 for(const k of[0,1]){await p.evaluate(k=>{const e=Pirati.E.find(x=>x.spr==='clue'&&x.k===k);e.hidden=0;const P=Pirati.P;P.x=e.x;P.y=e.y+50;Pirati.S.tod=11},k);await p.waitForTimeout(900);await L.skip(p);await p.screenshot({path:'aud/paw'+k+'.png',clip:{x:380,y:130,width:620,height:300}})}
 console.log('ERR',JSON.stringify(errs));await b.close()})();
