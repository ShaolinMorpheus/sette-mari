/* ====== NOVITÀ v0.11.2 (D2): equipaggio visibile sulla Sirena ======
   Chi è salito a bordo dipende dal finale del Capitolo 2 (tutti, Ferro, Ferro e Tito clandestino, tutti tranne Ferro, nessuno).
   Si vedono: nel finale del Capitolo 2, nell'anteprima della nave (Menu › Guardaroba › Nave) e, in miniatura, sul ponte della Sirena in mare. */
YD.crewAt=k=>({all:['ferro','nives','tito','gnocco'],ferro:['ferro'],ferro2:['ferro','tito'],fire:['nives','tito','gnocco'],solo:[]})[k]||[];
YD.crewKey=function(){
  try{const e=S&&S.flags&&S.flags.ch2end;
    if(typeof e==='string'&&e){if(YD._ck!==e){YD._ck=e;localStorage.setItem('sm_crew',e)}return e}   // sull'isola vale la partita in uso
    if(WORLD<=2)return null}catch(_){}
  if(YD._ck)return YD._ck;
  const now=Date.now();if(YD._ct&&now-YD._ct<3000)return null;YD._ct=now;     // in mare si legge il salvataggio dell'isola (non ad ogni fotogramma)
  let k=null;
  try{const q=JSON.parse(localStorage.getItem(slotKeyOf(SLOT))||'null'),f=q&&q.flags&&q.flags.ch2end;if(typeof f==='string'&&f)k=f}catch(_){}
  if(!k)try{k=localStorage.getItem('sm_crew')}catch(_){}
  if(k)YD._ck=k;return k};
YD.crew=()=>YD.crewAt(YD.crewKey());
/* firma per le immagini già preparate: cambia se cambia l'equipaggio o l'aspetto del capitano */
YD.crewSig=function(){
  const n=performance.now();if(YD._sg&&n-YD._st<500)return YD._sg;
  const c=YD.crew();let h='';try{const q=heroSpec();h=[q.hat,q.hatc,q.coat,q.skin,q.hair].join('.')}catch(e){}
  YD._st=n;return YD._sg=c.join(',')+'|'+h};
/* ------------------------------------------------------------------ di profilo --------
   P = {s: scala dei personaggi, helm:[x,y], mast:[x,y], pot:[x,y], bow:[x,y], lad:{x,y0,y1,w,f}}  (piedi = y) */
YD.crewSide=function(g,list,hero,P,t){
  t=t||0;const s=P.s,has=w=>list.includes(w),heroAtHelm=hero&&!has('ferro');
  const flame=(x,y)=>{const h=(8+Math.sin(t*9+x)*1.6)*s;g.fillStyle='#ff9a2a';g.beginPath();g.moveTo(x-3.6*s,y);g.quadraticCurveTo(x,y-h,x+3.6*s,y);g.fill();g.fillStyle='#ffe27a';g.beginPath();g.moveTo(x-1.8*s,y);g.quadraticCurveTo(x,y-h*.55,x+1.8*s,y);g.fill()};
  g.save();g.lineCap='round';g.lineJoin='round';
  // sartie (scaletta di corda) su cui si arrampica Tito
  if(has('tito')&&P.lad){const L=P.lad,top=1.6*s;
    g.strokeStyle='rgba(66,44,22,.92)';g.lineWidth=Math.max(1,s*1.8);
    g.beginPath();g.moveTo(L.x-L.w,L.y0);g.lineTo(L.x-top,L.y1);g.moveTo(L.x+L.w,L.y0);g.lineTo(L.x+top,L.y1);g.stroke();
    g.lineWidth=Math.max(1,s*1.3);
    for(let i=1;i<=7;i++){const f=i/8,y=L.y0+(L.y1-L.y0)*f,w=L.w+(top-L.w)*f;g.beginPath();g.moveTo(L.x-w,y);g.lineTo(L.x+w,y);g.stroke()}}
  // pentolone sul fuoco
  if(has('gnocco')&&P.pot){
    const px=P.pot[0]+s*27,py=P.pot[1];
    g.fillStyle='#3a3a44';g.strokeStyle='#14141c';g.lineWidth=Math.max(1,s*1.5);g.beginPath();g.moveTo(px-s*10,py-s*19);g.lineTo(px+s*10,py-s*19);g.lineTo(px+s*8,py-s*4);g.lineTo(px-s*8,py-s*4);g.closePath();g.fill();g.stroke();
    g.fillStyle='#7a7a88';g.fillRect(px-s*11,py-s*21,s*22,s*3.4);
    g.strokeStyle='rgba(255,255,255,.5)';g.lineWidth=Math.max(1,s*1.4);
    for(let i=0;i<2;i++){const u=(t*.5+i*.5)%1,sx=px+(i?4:-4)*s;g.globalAlpha=1-u;g.beginPath();g.moveTo(sx,py-s*23);g.quadraticCurveTo(sx+Math.sin(u*6)*3*s,py-s*(29+u*10),sx+(i?3:-3)*s,py-s*(34+u*10));g.stroke()}
    g.globalAlpha=1;flame(px-s*4,py-s*1);flame(px+s*3,py-s*1)}
  g.restore();
  const put=(spec,q,k)=>{if(!q||!spec)return;try{drawChar(g,q[0],q[1],{k:spec,dir:'f',t:t+k*1.7,s,noShadow:1})}catch(e){}};
  if(has('ferro'))put(CH.ferro,P.helm,0);
  if(has('nives'))put(CH.nives,P.mast,1);
  if(has('gnocco'))put(CH.gnocco,P.pot,3);
  if(has('tito')&&P.lad){const L=P.lad;put(CH.tito,[L.x,L.y0+(L.y1-L.y0)*(L.f||.4)],2)}
  if(hero){let hs=null;try{hs=heroSpec()}catch(e){hs=CH.hero_m}put(hs,heroAtHelm?P.helm:P.bow,4)}
  // ruota del timone: davanti al timoniere
  if((has('ferro')||heroAtHelm)&&P.helm){
    const r=s*10.5;g.save();g.translate(P.helm[0]+s*15,P.helm[1]-s*22);g.strokeStyle='#6a4220';g.lineWidth=Math.max(1,s*2.4);g.lineCap='round';
    g.beginPath();g.arc(0,0,r,0,7);g.stroke();g.lineWidth=Math.max(1,s*1.8);
    for(let i=0;i<4;i++){const a=i*Math.PI/4,c=Math.cos(a)*r*1.34,d=Math.sin(a)*r*1.34;g.beginPath();g.moveTo(c,d);g.lineTo(-c,-d);g.stroke()}
    g.fillStyle='#d8b24a';g.beginPath();g.arc(0,0,s*2.6,0,7);g.fill();g.restore()}};
/* finale del Capitolo 2: la nave che lascia la cala (coordinate dello sprite della nave, già scalate da sc) */
YD.crewCine=function(g,k,step,sc,t){
  let list=YD.crewAt(k);if(k==='ferro2'&&step<1)list=list.filter(w=>w!=='tito');   // Tito esce dal barile solo alla seconda scheda
  const K=1.25*sc,X=lx=>lx*K,Y=ly=>ly*K-6*sc,dy=Y(-49);
  YD.crewSide(g,list,true,{s:.5*K,helm:[X(-26),dy],mast:[X(8),dy],pot:[X(30),dy],bow:[X(104),dy],lad:{x:X(-72),y0:Y(-82),y1:Y(-128),w:X(19),f:.4}},t)};
/* anteprima della nave (Menu › Guardaroba › Nave): equipaggio sul ponte */
{const pv=YD.preview;YD.preview=function(cv,sel){pv(cv,sel);try{
  const g=cv.getContext('2d'),dk=Math.round(cv.height*.76),y=dk-8;
  YD.crewSide(g,YD.crew(),true,{s:.44,helm:[79,y],mast:[128,y],pot:[224,y],bow:[272,y],lad:{x:186,y0:dk-10,y1:dk-96,w:17,f:.4}},0)}catch(e){}}}
/* in mare, visti dall'alto (dentro l'immagine dello scafo): figurine piccole ai loro posti sul ponte.
   (cx,cy) = centro dello scafo, L = lunghezza, w = larghezza, masts = posizioni degli alberi (frazioni di L), sz = taglia */
YD.crewTop=function(g,list,hero,cx,cy,L,w,masts,sz){
  const has=k=>list.includes(k),mM=cx+L*(masts[0]),mA=cx+L*(masts.length>1?masts[1]:-.16),heroAtHelm=hero&&!has('ferro');
  const fig=(spec,x,y,tri)=>{
    if(!spec)return;g.save();g.translate(x,y);g.lineJoin='round';g.lineWidth=1;g.strokeStyle='#1c0f06';
    g.fillStyle='rgba(10,20,30,.28)';g.beginPath();g.ellipse(1.2,2.2,sz*.7,sz*1.15,0,0,7);g.fill();
    g.fillStyle=spec.coat||'#8a2a1c';g.beginPath();g.ellipse(0,0,sz*.62,sz*1.08,0,0,7);g.fill();g.stroke();            // spalle
    g.fillStyle=spec.skin||'#e6b78f';g.beginPath();g.arc(sz*.2,0,sz*.52,0,7);g.fill();g.stroke();                     // testa
    g.fillStyle=spec.hatc||spec.hair||'#333';
    if(tri||spec.hat==='tricorn'){g.beginPath();g.moveTo(sz*.18-sz*.62,0);g.lineTo(sz*.18,-sz*.62);g.lineTo(sz*.18+sz*.62,0);g.lineTo(sz*.18,sz*.62);g.closePath();g.fill();g.stroke()}
    else{g.beginPath();g.arc(sz*.14,0,sz*.48,0,7);g.fill();g.stroke()}
    g.restore()};
  const helmXY=[cx-L*.42,cy];
  if(has('ferro')||heroAtHelm){          // ruota del timone, davanti alla cabina di poppa
    g.save();g.translate(helmXY[0]+sz*1.7,cy);g.strokeStyle='#4a2c10';g.lineWidth=1.4;g.beginPath();g.arc(0,0,sz*.95,0,7);g.stroke();
    for(let i=0;i<4;i++){const a=i*Math.PI/4;g.beginPath();g.moveTo(Math.cos(a)*sz*1.3,Math.sin(a)*sz*1.3);g.lineTo(-Math.cos(a)*sz*1.3,-Math.sin(a)*sz*1.3);g.stroke()}g.restore()}
  const gx=cx-L*.34,gy=cy-w*.5;
  if(has('gnocco')){                      // pentolone: brace, bordo chiaro, minestra
    const px=gx+sz*1.9;g.fillStyle='rgba(255,140,40,.55)';g.beginPath();g.arc(px,gy,sz*1.3,0,7);g.fill();g.fillStyle='#34343c';g.beginPath();g.arc(px,gy,sz*.98,0,7);g.fill();
    g.strokeStyle='#8a8a98';g.lineWidth=1.2;g.stroke();g.fillStyle='#b8860b';g.beginPath();g.arc(px,gy,sz*.52,0,7);g.fill()}
  if(has('ferro'))fig(CH.ferro,helmXY[0],helmXY[1],1);
  if(has('gnocco'))fig(CH.gnocco,gx,gy);
  if(has('tito'))fig(CH.tito,mA+sz*1.5,cy+w*.46);
  if(has('nives'))fig(CH.nives,mM-sz*2.1,cy-w*.46);
  if(hero){let hs=null;try{hs=heroSpec()}catch(e){hs=CH.hero_m}fig(hs,heroAtHelm?helmXY[0]:cx+L*.62,cy)}};
