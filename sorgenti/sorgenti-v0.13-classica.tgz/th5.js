const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
for(const sel of ['#clkI','#bJ svg','#eat','#drink']){await p.waitForTimeout(500);await p.evaluate(s=>{const e=document.querySelector(s);e.dispatchEvent(new MouseEvent('click',{bubbles:true}))},sel);await p.waitForTimeout(200);console.log(sel,await p.evaluate(()=>[...document.querySelectorAll('.tipx')].map(x=>x.textContent)))}
// scambio Nives
await p.evaluate(()=>{const c=Pirati.Ch2.st();c.met.nives=1;Pirati.Ch2.openTrade()});await p.waitForTimeout(800);
await p.evaluate(()=>{const e=document.querySelector('#sheetCard svg.ic, .modal:not([hidden]) svg.ic');console.log(!!e)});
const html=await p.evaluate(()=>{const m=[...document.querySelectorAll('.modal')].find(x=>!x.hidden);return m?m.innerHTML.slice(0,500):'none'});console.log(html);
console.log(er);await b.close()})();
