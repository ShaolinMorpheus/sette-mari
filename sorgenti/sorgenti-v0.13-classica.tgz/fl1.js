const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:844,height:390}})).newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
const r=await p.evaluate(async()=>{const o={};const e=Pirati.EID.lt_flint;o.e=[e.x/44,e.y/44,e.got,e.blocked,e.fp];
 o.reach=Pirati.reachable(24,47);
 for(const [x,y] of [[24.5,46.3],[23.9,47.5],[25.2,47.8],[24.5,48.6]]){Pirati.tp(x,y);await new Promise(r=>setTimeout(r,300));Pirati.target();const t=Pirati.tinfo();o['t'+x+'_'+y]=JSON.stringify(t)}
 o.q=JSON.stringify(Object.keys(Pirati.S.q));return o});
console.log(JSON.stringify(r));
console.log(await p.evaluate(()=>{const o=[];for(let y=45;y<=50;y+=.5){let s=y.toFixed(1)+' ';for(let x=21;x<=28;x+=.25)s+=Pirati.boxFree(x*44,y*44,9,5)?'.':'#';o.push(s)}return o.join('\n')}));
await b.close()})();
