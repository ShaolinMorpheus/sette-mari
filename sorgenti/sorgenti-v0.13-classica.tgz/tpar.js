const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({dsf:2});
 const ev=async(f,a)=>{try{return await p.evaluate(f,a)}catch(e){return {ERRORE:e.message.split('\n')[0].slice(0,220)}}};
 await p.waitForTimeout(1200);
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);
 await p.waitForTimeout(500);
 await p.evaluate(()=>{Pirati.S.tutDone=1;Pirati.S.tut=null});
 const out=[];
 out.push(['sblocco',JSON.stringify(await ev(()=>{const S=Pirati.S,F=Pirati.farm;S.flags.hat=1;S.flags.parrot=1;F.farmInit();S.gard.harv=12;S.flags.ch1=1;S.stat=S.stat||{};S.stat.forage=20;F.wardCheck();return Object.keys(S.phats)}))]);
 await ev(()=>{Pirati.UI._mt='pp';Pirati.UI.openMenu()});await p.waitForTimeout(300);
 await p.screenshot({path:'aud/par_menu.png'});
 await ev(()=>{document.getElementById('mPh').click()});await p.waitForTimeout(300);
 await p.screenshot({path:'aud/par_sheet.png'});
 out.push(['sheet',JSON.stringify(await ev(()=>{const c=document.getElementById('sheetCard');return {n:c.querySelectorAll('[data-ph]').length,names:[...c.querySelectorAll('[data-ph]')].map(b=>b.dataset.ph+':'+b.innerText.replace(/\s+/g,' '))}}))]);
 // indossa ciascun cappellino e fotografa il pappagallo in gioco
 const ids=await ev(()=>Object.keys(Pirati.S.phats));
 await ev(()=>{(document.getElementById('shNo')||{click(){}}).click()});
 await p.evaluate(()=>{for(const id of['hud','qbanner','dlg','rot']){const e=document.getElementById(id);if(e)e.style.display='none'}});
 for(const id of ids){
   await ev((h)=>{Pirati.S.phat=h;Pirati.PAR.perch=false},id);await p.waitForTimeout(400);
   const sc=await ev(()=>{const s=Pirati.parrotScreen();return s});
   const x=Math.round(sc.x||sc[0]),y=Math.round(sc.y||sc[1]);
   await p.screenshot({path:'aud/par_'+id+'.png',clip:{x:Math.max(0,x-60),y:Math.max(0,y-70),width:120,height:110}});
 }
 console.log(out.map(x=>x.join(': ')).join('\n'));console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
