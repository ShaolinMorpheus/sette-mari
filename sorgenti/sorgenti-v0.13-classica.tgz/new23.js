/* ====== NOVITÀ v0.11.2 (D1): modalità foto ricordo ====== */
const PHO={W:640,H:480,K:'sm_photos',MAX:12,BG:['Giorno','Tramonto','Notte','Campo'],FR:['Legno','Oro','Corda','Pergamena'],st:{bg:0,fr:0,raf:0,shot:null,t0:0,cap:['','']},bgc:{},frc:{}};
{
  const css=document.createElement('style');
  css.textContent=`
#sheetCard.phc{max-width:900px;padding:10px 12px}
.phw{display:flex;gap:12px;align-items:flex-start}
.phv{position:relative;flex:none;width:min(60%,calc((100vh - 64px)*1.3333));line-height:0}
.phv canvas{display:block;width:100%;height:auto;border-radius:8px;box-shadow:0 4px 14px rgba(0,0,0,.45);background:#123}
#phFl{position:absolute;inset:0;background:#fff;opacity:0;border-radius:8px;pointer-events:none}
.phs{flex:1;min-width:0}
.phs h2{margin:0 0 2px;font-size:22px}
.phg1{margin:5px 0}.phg1>b{display:block;font-size:12px;letter-spacing:.5px;opacity:.8;margin-bottom:2px}
.phch{display:flex;flex-wrap:wrap;gap:4px}
.phch button{border:2px solid #7a5a30;border-radius:9px;background:#f0dfb4;color:#3a200c;font:800 12px var(--f-b,Nunito,sans-serif);padding:5px 8px;cursor:pointer}
.phch button.on{background:linear-gradient(#ffd98a,#e19a26);border-color:#3a200c}
.phs .row{margin-top:8px;flex-wrap:wrap}
#phMsg{font-size:13px;min-height:16px;margin:4px 0 0;font-weight:700}
.pha{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:8px 0}
.pha button{border:3px solid #7a5a30;border-radius:8px;background:#fff;padding:0;cursor:pointer;line-height:0;overflow:hidden}
.pha img{width:100%;height:auto;display:block}
.phone img{width:min(100%,calc((100vh - 120px)*1.3333));height:auto;border-radius:8px;display:block;margin:0 auto;box-shadow:0 4px 14px rgba(0,0,0,.4)}
@media (max-width:720px){.phw{flex-direction:column}.phv{width:100%}.pha{grid-template-columns:repeat(2,1fr)}}
`;
  document.head.appendChild(css);
}
PHO.list=()=>{try{const a=JSON.parse(localStorage.getItem(PHO.K)||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}};
PHO.put=a=>{for(;;){try{localStorage.setItem(PHO.K,JSON.stringify(a));return true}catch(e){if(a.length<=1)return false;a.shift()}}};
PHO.sub=()=>{const n=PHO.list().length;return n?n+' nell\'album':'scatta la prima'};
const phR=s=>()=>{s=(s*1664525+1013904223)%4294967296;return s/4294967296};
function phCloud(g,x,y,s,col){g.fillStyle=col;g.beginPath();for(const[dx,dy,r]of[[0,0,20],[24,-9,26],[52,0,22],[26,7,24],[-14,7,14],[66,8,14]]){g.moveTo(x+(dx+r)*s,y+dy*s);g.arc(x+dx*s,y+dy*s,r*s,0,6.3)}g.fill()}
function phPalm(g,x,y,h,lean,col,col2){
  g.save();g.lineCap='round';
  const tx=x+lean,ty=y-h;
  g.strokeStyle=col2||col;g.lineWidth=h*.075;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+lean*.1,y-h*.6,tx,ty);g.stroke();
  g.strokeStyle=col;g.lineWidth=h*.05;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+lean*.1,y-h*.6,tx,ty);g.stroke();
  g.fillStyle=col;
  for(let i=0;i<8;i++){const a=-Math.PI/2+(i-3.5)*.62,L=h*.5,ex=tx+Math.cos(a)*L,ey=ty+Math.sin(a)*L*.55+L*.42;
    g.beginPath();g.moveTo(tx,ty);g.quadraticCurveTo(tx+Math.cos(a)*L*.55,ty+Math.sin(a)*L*.9-10,ex,ey);g.quadraticCurveTo(tx+Math.cos(a)*L*.5,ty+Math.sin(a)*L*.4+8,tx,ty);g.fill()}
  g.restore()}
function phBgC(bg){
  if(PHO.bgc[bg])return PHO.bgc[bg];
  const W=PHO.W,H=PHO.H,cv=document.createElement('canvas');cv.width=W;cv.height=H;const g=cv.getContext('2d'),hz=236,sh=316,R=phR(91+bg*17);
  const lin=(y0,y1,st)=>{const q=g.createLinearGradient(0,y0,0,y1);st.forEach(s=>q.addColorStop(s[0],s[1]));return q};
  const glow=(x,y,r,c0,c1)=>{const q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,c0);q.addColorStop(1,c1);g.fillStyle=q;g.fillRect(x-r,y-r,r*2,r*2)};
  if(bg===0){            // giorno di sole
    g.fillStyle=lin(0,hz,[[0,'#5cb8f0'],[1,'#d6f2ff']]);g.fillRect(0,0,W,hz);
    glow(520,86,120,'rgba(255,248,200,.95)','rgba(255,248,200,0)');g.fillStyle='#fff6c8';g.beginPath();g.arc(520,86,32,0,6.3);g.fill();
    phCloud(g,92,84,1,'rgba(255,255,255,.95)');phCloud(g,300,52,.8,'rgba(255,255,255,.9)');phCloud(g,430,150,.7,'rgba(255,255,255,.8)');
    g.fillStyle='#6a9a8a';g.beginPath();g.ellipse(112,hz+2,70,17,0,Math.PI,0);g.fill();g.fillStyle='#4a8a5a';g.beginPath();g.ellipse(100,hz+2,42,12,0,Math.PI,0);g.fill();
    g.fillStyle=lin(hz,sh,[[0,'#4cbce2'],[1,'#1f80b4']]);g.fillRect(0,hz,W,sh-hz);
    g.fillStyle=lin(sh,H,[[0,'#f8e6ac'],[1,'#e2bd72']]);g.fillRect(0,sh,W,H-sh);
    phPalm(g,596,sh+70,230,-46,'#2f7a3a','#6a4a2a');phPalm(g,30,sh+60,170,34,'#3a8a40','#6a4a2a');
  }else if(bg===1){      // tramonto
    g.fillStyle=lin(0,hz,[[0,'#2a1a66'],[.45,'#b8468c'],[.8,'#ff8f5c'],[1,'#ffd08a']]);g.fillRect(0,0,W,hz);
    glow(330,hz,230,'rgba(255,214,120,.9)','rgba(255,150,80,0)');
    g.fillStyle='#fff0a8';g.beginPath();g.arc(330,hz+6,58,Math.PI,0);g.fill();
    g.fillStyle='rgba(255,170,150,.55)';for(const[x,y,w]of[[90,84,150],[420,60,170],[500,128,120],[40,150,110]]){g.beginPath();g.ellipse(x+w/2,y,w/2,6,0,0,6.3);g.fill()}
    g.fillStyle=lin(hz,sh,[[0,'#f08a6a'],[.4,'#b8508a'],[1,'#3a2a6a']]);g.fillRect(0,hz,W,sh-hz);
    g.fillStyle=lin(sh,H,[[0,'#c98a5c'],[1,'#6a4636']]);g.fillRect(0,sh,W,H-sh);
    phPalm(g,590,sh+70,235,-50,'#2a1630','#2a1630');phPalm(g,36,sh+60,175,36,'#2a1630','#2a1630');
    g.strokeStyle='#2a1630';g.lineWidth=2.2;g.lineCap='round';for(const[x,y]of[[150,70],[190,92],[224,66],[470,100]]){g.beginPath();g.moveTo(x-10,y-3);g.quadraticCurveTo(x-4,y-8,x,y);g.quadraticCurveTo(x+4,y-8,x+10,y-3);g.stroke()}
  }else{                 // notte (e campo)
    g.fillStyle=lin(0,hz,[[0,'#040818'],[1,'#1a3470']]);g.fillRect(0,0,W,hz);
    for(let i=0,N=bg===3?46:78;i<N;i++){const x=R()*W,y=R()*(hz-20),r=.6+R()*1.5;g.fillStyle='rgba(255,250,220,'+(.45+R()*.5)+')';g.beginPath();g.arc(x,y,r,0,6.3);g.fill()}
    if(bg===2){glow(130,96,110,'rgba(255,246,210,.55)','rgba(255,246,210,0)');g.fillStyle='#fff6dc';g.beginPath();g.arc(130,96,27,0,6.3);g.fill();g.fillStyle='rgba(190,180,150,.5)';for(const[x,y,r]of[[122,88,6],[140,104,5],[126,108,3.5]]){g.beginPath();g.arc(x,y,r,0,6.3);g.fill()}}
    g.fillStyle=lin(hz,sh,[[0,'#123a72'],[1,'#050f2a']]);g.fillRect(0,hz,W,sh-hz);
    g.fillStyle=lin(sh,H,[[0,bg===3?'#4a4a5a':'#42547a'],[1,bg===3?'#1c1c2a':'#1a2644']]);g.fillRect(0,sh,W,H-sh);
    phPalm(g,596,sh+70,225,-44,'#0a1226','#0a1226');phPalm(g,32,sh+60,170,34,'#0a1226','#0a1226');
    if(bg===3){ // tenda a destra e tronchi per il fuoco
      g.fillStyle='#3a2a22';g.beginPath();g.moveTo(470,hz+120);g.lineTo(560,hz+40);g.lineTo(640,hz+120);g.closePath();g.fill();
      g.fillStyle='#5a3e30';g.beginPath();g.moveTo(560,hz+40);g.lineTo(640,hz+120);g.lineTo(560,hz+120);g.closePath();g.fill();
      g.fillStyle='#150c08';g.beginPath();g.moveTo(560,hz+72);g.lineTo(588,hz+120);g.lineTo(532,hz+120);g.closePath();g.fill();
    }
  }
  // schiuma sulla battigia
  g.fillStyle=bg===0?'rgba(255,255,255,.75)':'rgba(255,255,255,.28)';g.beginPath();g.moveTo(0,sh);for(let x=0;x<=W;x+=16)g.lineTo(x,sh+2+Math.sin(x*.07)*3);g.lineTo(W,sh-5);g.lineTo(0,sh-5);g.closePath();g.fill();
  // conchiglie e sassolini sulla sabbia
  for(let i=0;i<16;i++){const x=40+R()*(W-80),y=sh+22+R()*(H-sh-60),r=2+R()*3.5;g.fillStyle=bg===0?'rgba(120,80,40,.22)':'rgba(0,0,0,.2)';g.beginPath();g.ellipse(x,y,r*1.5,r*.7,0,0,6.3);g.fill()}
  PHO.bgc[bg]=cv;return cv}
function phAnim(g,bg,t){
  const W=PHO.W,hz=236,sh=316;
  // onde: trattini che scorrono piano
  g.lineCap='round';
  for(let i=0;i<26;i++){const y=hz+8+(i*37)%((sh-hz)-14),x=((i*131+t*(8+(i%4)*3))%(W+60))-30,w=10+(i%5)*6,k=(y-hz)/(sh-hz);
    g.strokeStyle=bg===0?'rgba(255,255,255,'+(.25+k*.35)+')':bg===1?'rgba(255,220,170,'+(.18+k*.3)+')':'rgba(190,210,255,'+(.1+k*.18)+')';g.lineWidth=1.4+k*1.2;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+w/2,y-2,x+w,y);g.stroke()}
  if(bg===1){for(let i=0;i<9;i++){const y=hz+6+i*8,w=(70-i*3)*(.6+.4*Math.sin(t*1.7+i));g.fillStyle='rgba(255,226,150,'+(.55-i*.04)+')';g.fillRect(330-w/2+Math.sin(t*2+i)*4,y,w,3)}}
  if(bg===2){for(let i=0;i<8;i++){const y=hz+6+i*9,w=(34-i*2)*(.6+.4*Math.sin(t*2.1+i));g.fillStyle='rgba(255,246,210,'+(.5-i*.05)+')';g.fillRect(130-w/2+Math.sin(t*2+i)*3,y,w,2.4)}}
  if(bg===2||bg===3){const R=phR(5);for(let i=0;i<10;i++){const x=R()*W,y=R()*(hz-30),k=.5+.5*Math.sin(t*2.2+i*1.7);g.fillStyle='rgba(255,250,225,'+(.2+.5*k)+')';g.beginPath();g.arc(x,y,1.2+k*.8,0,6.3);g.fill()}}
}
function phFire(g,t,x,y,k){
  k=k||1;g.save();g.translate(x,y);g.scale(k,k);g.translate(-x,-y);
  // luce del fuoco sul terreno
  const q=g.createRadialGradient(x,y,6,x,y,230);q.addColorStop(0,'rgba(255,170,70,.42)');q.addColorStop(1,'rgba(255,120,40,0)');g.fillStyle=q;g.fillRect(0,0,PHO.W,PHO.H);
  // tronchi
  g.strokeStyle='#4a2c14';g.lineWidth=9;g.lineCap='round';g.beginPath();g.moveTo(x-30,y+9);g.lineTo(x+26,y-3);g.moveTo(x-26,y-3);g.lineTo(x+30,y+9);g.stroke();
  g.strokeStyle='#7a4a24';g.lineWidth=3;g.beginPath();g.moveTo(x-28,y+6);g.lineTo(x+24,y-5);g.stroke();
  // fiamme
  for(const[c,sc,dy]of[['#e0481c',1,0],['#ff9a2a',.78,-2],['#ffe27a',.5,-4]]){
    g.fillStyle=c;g.beginPath();g.moveTo(x-22*sc,y+3);
    for(let i=0;i<=6;i++){const u=i/6,fx=x-22*sc+u*44*sc,h=(30+Math.sin(t*9+i*1.9)*9+Math.sin(t*5.3+i)*5)*sc*(1-Math.abs(u-.5)*.9);g.lineTo(fx,y+dy-h)}
    g.lineTo(x+22*sc,y+3);g.closePath();g.fill()}
  g.restore();
  // scintille
  for(let i=0;i<9;i++){const u=((t*.6+i*.37)%1),sx=x+Math.sin(i*2.7+t*2)*(14+u*20)*k,sy=y-(30+u*110)*k;g.fillStyle='rgba(255,'+(170+(i*9)%60)+',80,'+(1-u)+')';g.beginPath();g.arc(sx,sy,1.9*(1-u)+.4,0,6.3);g.fill()}
}
function phFrC(){
  const st=PHO.st,key=st.fr+'|'+st.cap.join('|');
  if(PHO.frc.key===key&&PHO.frc.cv)return PHO.frc.cv;
  const W=PHO.W,H=PHO.H,cv=document.createElement('canvas');cv.width=W;cv.height=H;const g=cv.getContext('2d'),R=phR(33+st.fr);
  const ring=(b,fn)=>{g.save();g.beginPath();g.rect(0,0,W,H);g.rect(b,b,W-2*b,H-2*b);g.clip('evenodd');fn();g.restore()};
  if(st.fr===0){          // legno di nave con borchie
    const B=26;ring(B,()=>{const q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#9a6634');q.addColorStop(.5,'#6a4222');q.addColorStop(1,'#4a2c14');g.fillStyle=q;g.fillRect(0,0,W,H);
      g.strokeStyle='rgba(30,14,4,.55)';g.lineWidth=2;for(let x=70;x<W;x+=118){g.beginPath();g.moveTo(x,0);g.lineTo(x,B);g.moveTo(x+40,H-B);g.lineTo(x+40,H);g.stroke()}
      for(let y=60;y<H;y+=104){g.beginPath();g.moveTo(0,y);g.lineTo(B,y);g.moveTo(W-B,y+30);g.lineTo(W,y+30);g.stroke()}
      g.strokeStyle='rgba(255,220,160,.22)';g.lineWidth=1.4;for(let i=0;i<46;i++){const x=R()*W,y=R()<.5?R()*B:H-R()*B;g.beginPath();g.moveTo(x,y);g.lineTo(x+14+R()*30,y+(R()-.5)*3);g.stroke()}});
    g.strokeStyle='#2a1608';g.lineWidth=4;g.strokeRect(B-1,B-1,W-2*B+2,H-2*B+2);g.strokeStyle='#d6a85a';g.lineWidth=1.6;g.strokeRect(B+3,B+3,W-2*B-6,H-2*B-6);
    for(const[x,y]of[[13,13],[W-13,13],[13,H-13],[W-13,H-13],[W/2,13],[W/2,H-13]]){const q=g.createRadialGradient(x-1.5,y-1.5,1,x,y,7);q.addColorStop(0,'#fff0b0');q.addColorStop(1,'#a8781c');g.fillStyle=q;g.beginPath();g.arc(x,y,6.5,0,6.3);g.fill();g.strokeStyle='#4a2c08';g.lineWidth=1;g.stroke()}
  }else if(st.fr===1){    // oro con perline e gemme
    const B=28;ring(B,()=>{const q=g.createLinearGradient(0,0,W,H);q.addColorStop(0,'#f8e48e');q.addColorStop(.35,'#c0902a');q.addColorStop(.6,'#f4d870');q.addColorStop(1,'#a8761a');g.fillStyle=q;g.fillRect(0,0,W,H);
      g.fillStyle='rgba(80,48,6,.32)';for(let x=12;x<W;x+=15){g.beginPath();g.arc(x,B/2,3.1,0,6.3);g.arc(x,H-B/2,3.1,0,6.3);g.fill()}for(let y=12;y<H;y+=15){g.beginPath();g.arc(B/2,y,3.1,0,6.3);g.arc(W-B/2,y,3.1,0,6.3);g.fill()}});
    g.strokeStyle='#5a3a06';g.lineWidth=3;g.strokeRect(1.5,1.5,W-3,H-3);g.strokeRect(B,B,W-2*B,H-2*B);g.strokeStyle='#fff0b0';g.lineWidth=1.2;g.strokeRect(B-3,B-3,W-2*B+6,H-2*B+6);
    for(const[x,y]of[[16,16],[W-16,16],[16,H-16],[W-16,H-16]]){g.save();g.translate(x,y);g.rotate(Math.PI/4);const q=g.createLinearGradient(-10,-10,10,10);q.addColorStop(0,'#ff7a6a');q.addColorStop(1,'#a01810');g.fillStyle=q;g.fillRect(-9,-9,18,18);g.strokeStyle='#5a3a06';g.lineWidth=2;g.strokeRect(-9,-9,18,18);g.restore()}
  }else if(st.fr===2){    // corda intrecciata
    const B=22;ring(B,()=>{g.fillStyle='#5a4020';g.fillRect(0,0,W,H);
      const strand=(x0,y0,dx,dy,n)=>{for(let i=0;i<n;i++){const x=x0+dx*i,y=y0+dy*i;g.strokeStyle=i%2?'#e8d29a':'#c8a860';g.lineWidth=7;g.lineCap='round';g.beginPath();g.moveTo(x-(dy?B/2:5),y-(dx?B/2:5));g.lineTo(x+(dy?B/2:5),y+(dx?B/2:5));g.stroke();g.strokeStyle='rgba(90,60,20,.5)';g.lineWidth=1.2;g.beginPath();g.moveTo(x-(dy?B/2:5)+2,y-(dx?B/2:5)+2);g.lineTo(x+(dy?B/2:5)+2,y+(dx?B/2:5)+2);g.stroke()}};
      strand(6,B/2,9,0,72);strand(6,H-B/2,9,0,72);strand(B/2,6,0,9,54);strand(W-B/2,6,0,9,54)});
    g.strokeStyle='#3a2810';g.lineWidth=2.4;g.strokeRect(B,B,W-2*B,H-2*B);g.strokeRect(1,1,W-2,H-2);
    for(const[x,y]of[[B/2,B/2],[W-B/2,B/2],[B/2,H-B/2],[W-B/2,H-B/2]]){const q=g.createRadialGradient(x-3,y-3,2,x,y,15);q.addColorStop(0,'#fff0c0');q.addColorStop(1,'#a8842c');g.fillStyle=q;g.beginPath();g.arc(x,y,13,0,6.3);g.fill();g.strokeStyle='#3a2810';g.lineWidth=2;g.stroke();g.beginPath();g.arc(x,y,6,0,6.3);g.stroke()}
  }else{                  // pergamena con sigillo
    const B=22,jit=()=>(R()-.5)*7;
    g.fillStyle='#e8d29c';g.beginPath();g.rect(0,0,W,H);g.moveTo(B+jit(),B+jit());
    for(let x=B;x<=W-B;x+=22)g.lineTo(x,B+jit());for(let y=B;y<=H-B;y+=22)g.lineTo(W-B+jit(),y);for(let x=W-B;x>=B;x-=22)g.lineTo(x,H-B+jit());for(let y=H-B;y>=B;y-=22)g.lineTo(B+jit(),y);g.closePath();g.fill('evenodd');
    ring(B+4,()=>{g.fillStyle='rgba(140,90,30,.12)';for(let i=0;i<40;i++){g.beginPath();g.arc(R()*W,R()<.5?R()*B:H-R()*B,3+R()*14,0,6.3);g.fill()}for(let i=0;i<30;i++){g.beginPath();g.arc(R()<.5?R()*B:W-R()*B,R()*H,3+R()*12,0,6.3);g.fill()}});
    g.strokeStyle='#a8803c';g.lineWidth=2.2;g.beginPath();g.moveTo(B-2,B-2);for(let x=B;x<=W-B;x+=22)g.lineTo(x,B-2+(R()-.5)*3);for(let y=B;y<=H-B;y+=22)g.lineTo(W-B+2+(R()-.5)*3,y);for(let x=W-B;x>=B;x-=22)g.lineTo(x,H-B+2+(R()-.5)*3);for(let y=H-B;y>=B;y-=22)g.lineTo(B-2+(R()-.5)*3,y);g.closePath();g.stroke();
    const sx=W-52,sy=H-52,q=g.createRadialGradient(sx-5,sy-5,2,sx,sy,26);q.addColorStop(0,'#e0483a');q.addColorStop(1,'#8a1a12');g.fillStyle=q;g.beginPath();for(let i=0;i<18;i++){const a=i/18*6.283,r=i%2?22:26;g.lineTo(sx+Math.cos(a)*r,sy+Math.sin(a)*r)}g.closePath();g.fill();
    g.fillStyle='rgba(255,230,200,.8)';g.font='bold 26px serif';g.textAlign='center';g.textBaseline='middle';g.fillText('⚓',sx,sy+1);
  }
  // cartiglio con nome e giorno
  const [c1,c2]=st.cap;g.font='bold 21px Georgia,serif';const w1=g.measureText(c1).width;const bw=Math.min(W-120,Math.max(250,w1+86)),bh=48,bx=(W-bw)/2,by=H-bh-10;
  const q=g.createLinearGradient(0,by,0,by+bh);q.addColorStop(0,'#fbefc8');q.addColorStop(1,'#e2c27a');
  g.fillStyle=q;g.strokeStyle='#4a2c10';g.lineWidth=3;g.beginPath();if(g.roundRect)g.roundRect(bx,by,bw,bh,10);else g.rect(bx,by,bw,bh);g.fill();g.stroke();
  g.strokeStyle='rgba(120,80,30,.55)';g.lineWidth=1;g.beginPath();if(g.roundRect)g.roundRect(bx+4,by+4,bw-8,bh-8,7);else g.rect(bx+4,by+4,bw-8,bh-8);g.stroke();
  g.fillStyle='#3a200c';g.textAlign='center';g.textBaseline='middle';g.fillText(c1,W/2,by+19);g.font='italic 13px Georgia,serif';g.fillStyle='#6a4420';g.fillText(c2,W/2,by+37);
  g.fillStyle='#b8801c';g.font='bold 16px serif';g.fillText('★',bx+16,by+bh/2);g.fillText('★',bx+bw-16,by+bh/2);
  PHO.frc.key=key;PHO.frc.cv=cv;return cv}
function phFriends(){try{if(typeof Ch2==='undefined'||WORLD!==2||!S.c2)return[];return['nives','tito','gnocco','ferro'].filter(w=>CH[w]&&Ch2.tr(w)>=6)}catch(e){return[]}}
function phScene(g,t){
  const W=PHO.W,H=PHO.H,st=PHO.st,gy=392;
  g.drawImage(phBgC(st.bg),0,0);phAnim(g,st.bg,t);
  const fr=phFriends();
  // gli amici: due vicini al capitano (più grandi) e due dietro, ai lati
  const slot=[[212,-10,3.4],[428,-10,3.4],[108,-24,3.05],[532,-24,3.05]];
  fr.map((w,i)=>[w,i]).sort((a,b)=>slot[a[1]][1]-slot[b[1]][1]).forEach(([w,i])=>{const q=slot[i];try{drawChar(g,q[0],gy+q[1],{k:CH[w],dir:'f',t:t+i*1.3,s:q[2]})}catch(e){}});
  try{drawChar(g,W/2,gy,{k:heroSpec(),dir:'f',t,s:4.5})}catch(e){}
  try{if(S.flags.parrot)drawParrot(g,W/2-64,gy-4.5*33,{t:t*.5,s:2.7,perch:true,hat:S.phat,flip:false})}catch(e){}
  if(st.bg===3){phFire(g,t,92,gy+40,1.15);g.globalCompositeOperation='soft-light';const q=g.createRadialGradient(92,gy+10,10,92,gy+10,330);q.addColorStop(0,'rgba(255,170,70,.85)');q.addColorStop(1,'rgba(255,170,70,0)');g.fillStyle=q;g.fillRect(0,0,W,H);g.globalCompositeOperation='source-over'}
  g.drawImage(phFrC(),0,0);
}
/* ---- studio, scatto, album ---- */
PHO.nameLine=()=>{let n='';try{n=(S.name||'').trim()}catch(e){}return heroName()+(n?' '+n:'')};
PHO.shutter=()=>{noiseBurst(.04,3200,.16);tone(1500,700,.05,'square',.04);setTimeout(()=>{noiseBurst(.07,1700,.14);tone(900,400,.07,'square',.04)},90)};
PHO.open=function(keep){
  const st=PHO.st;
  if(!keep||!st.init){st.init=1;try{const h=((S&&S.tod)||12)%24;st.bg=h>=8&&h<17?0:(h>=17&&h<20)||(h>=5&&h<8)?1:2}catch(e){st.bg=0}}
  st.shot=null;
  let dt='';try{dt=new Date().toLocaleDateString('it-IT',{day:'numeric',month:'short',year:'numeric'})}catch(e){}
  st.cap=[PHO.nameLine(),'Giorno '+((S&&S.day)||1)+' · Sette Mari'+(dt?' · '+dt:'')];
  const alb=PHO.list().length;
  const h='<div class="phw"><div class="phv"><canvas id="phCv" width="'+PHO.W+'" height="'+PHO.H+'"></canvas><div id="phFl"></div></div><div class="phs"><h2>Foto ricordo</h2>'
   +'<div class="phg1"><b>Sfondo</b><div class="phch" id="phBg">'+PHO.BG.map((n,i)=>'<button data-b="'+i+'">'+n+'</button>').join('')+'</div></div>'
   +'<div class="phg1"><b>Cornice</b><div class="phch" id="phFr">'+PHO.FR.map((n,i)=>'<button data-f="'+i+'">'+n+'</button>').join('')+'</div></div>'
   +'<div id="phMsg"></div><div class="row" id="phMain"></div><div class="row" id="phNav"><button class="btn" id="shNo">Chiudi</button></div></div></div>';
  sheetFor(h,c=>{
    $('sheetCard').classList.add('phc');
    const cv=c.querySelector('#phCv'),g=cv.getContext('2d');
    const mark=()=>{c.querySelectorAll('#phBg button').forEach(b=>b.classList.toggle('on',+b.dataset.b===st.bg));c.querySelectorAll('#phFr button').forEach(b=>b.classList.toggle('on',+b.dataset.f===st.fr))};
    const msg=t=>{const e=c.querySelector('#phMsg');if(e)e.textContent=t||''};
    const main=(mode)=>{
      const m=c.querySelector('#phMain');
      if(mode==='shot'){m.innerHTML='<button class="btn gold" id="phSave">💾 Salva nell\'album</button><button class="btn" id="phShare">📤 Condividi</button><button class="btn" id="phAgain">↺ Rifai</button>';
        c.querySelector('#phSave').onclick=()=>PHO.save(c,msg,main);
        c.querySelector('#phShare').onclick=()=>PHO.share(st.shot,'sette-mari-foto.jpg',msg);
        c.querySelector('#phAgain').onclick=()=>{st.shot=null;msg('');main('studio');PHO.loop(cv,g)}}
      else{m.innerHTML='<button class="btn gold" id="phSnap">📷 Scatta</button><button class="btn" id="phAlb">Album ('+PHO.list().length+')</button>';
        c.querySelector('#phSnap').onclick=()=>PHO.snap(c,cv,g,msg,main);
        c.querySelector('#phAlb').onclick=()=>PHO.album()}};
    c.querySelectorAll('#phBg button').forEach(b=>b.onclick=()=>{st.bg=+b.dataset.b;mark();sfx('tap')});
    c.querySelectorAll('#phFr button').forEach(b=>b.onclick=()=>{st.fr=+b.dataset.f;mark();sfx('tap')});
    mark();main('studio');msg(alb?'':'Scegli sfondo e cornice.');PHO.loop(cv,g)});
};
PHO.loop=function(cv,g){
  const st=PHO.st;cancelAnimationFrame(st.raf);st.t0=performance.now();let last=0;
  const f=now=>{
    if(!document.body.contains(cv)||$('sheet').hidden||st.shot){return}
    if(now-last>70){last=now;phScene(g,(now-st.t0)/1000)}
    st.raf=requestAnimationFrame(f)};
  st.raf=requestAnimationFrame(f)};
PHO.snap=function(c,cv,g,msg,main){
  const st=PHO.st;cancelAnimationFrame(st.raf);
  phScene(g,(performance.now()-st.t0)/1000);
  try{st.shot=cv.toDataURL('image/jpeg',.88)}catch(e){st.shot=null}
  const fl=c.querySelector('#phFl');if(fl){fl.style.transition='none';fl.style.opacity='.95';requestAnimationFrame(()=>{fl.style.transition='opacity .45s ease-out';fl.style.opacity='0'})}
  PHO.shutter();
  if(!st.shot){msg('Non riesco a fare la foto su questo telefono.');main('studio');PHO.loop(cv,g);return}
  msg('Che bella foto!');main('shot')};
PHO.save=function(c,msg,main){
  const st=PHO.st;if(!st.shot)return;
  const a=PHO.list();a.push({d:st.shot,t:Date.now(),c:st.cap[0]+' · '+st.cap[1]});
  while(a.length>PHO.MAX)a.shift();
  if(!PHO.put(a)){msg('Non c\'è spazio per salvare: cancella qualche foto dall\'album.');return}
  try{S.flags.phN=(S.flags.phN||0)+1;saveGame()}catch(e){}
  sfx('ok');UI.toast('Foto salvata nell\'album ('+a.length+')');
  const b=c.querySelector('#phSave');if(b){b.disabled=true;b.textContent='✔ Salvata'}
  msg('Salvata! La trovi in «Album».');
  const al=c.querySelector('#phMain');if(al&&!c.querySelector('#phAlb2')){const x=document.createElement('button');x.className='btn';x.id='phAlb2';x.textContent='Apri l\'album';x.onclick=()=>PHO.album();al.appendChild(x)}};
PHO.share=async function(url,name,msg){
  if(!url)return;
  try{const r=await fetch(url),bl=await r.blob(),f=new File([bl],name,{type:'image/jpeg'});
    if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],title:'Sette Mari',text:'Una foto ricordo da Sette Mari'});return}}
  catch(e){if(e&&e.name==='AbortError')return}
  try{const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();
    msg&&msg('Se il telefono non salva il file, fai uno screenshot: la foto resta nell\'album.')}
  catch(e){msg&&msg('Non posso condividere da qui: fai uno screenshot, la foto resta nell\'album.')}};
PHO.album=function(){
  cancelAnimationFrame(PHO.st.raf);
  const a=PHO.list();
  let h='<h2>Album di viaggio</h2>';
  if(!a.length)h+='<p>L\'album è vuoto. Scatta la prima foto ricordo!</p>';
  else h+='<p class="sm">'+a.length+(a.length===1?' foto':' foto')+' · tocca una foto per vederla grande.</p><div class="pha">'+a.map((x,i)=>'<button data-i="'+i+'"><img alt="" src="'+x.d+'"></button>').reverse().join('')+'</div>';
  h+='<div class="row"><button class="btn gold" id="phStudio">📷 Studio</button><button class="btn" id="shNo">Chiudi</button></div>';
  sheetFor(h,c=>{
    $('sheetCard').classList.remove('phc');
    c.querySelector('#phStudio').onclick=()=>PHO.open(true);
    c.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>PHO.view(+b.dataset.i))})};
PHO.view=function(i){
  const a=PHO.list(),x=a[i];if(!x)return PHO.album();
  const h='<div class="phone"><img alt="" src="'+x.d+'"></div><p class="sm" id="phMsg" style="text-align:center;margin:6px 0">'+uEsc(x.c||'')+'</p><div class="row"><button class="btn gold" id="phSh">📤 Condividi</button><button class="btn" id="phDel">🗑 Elimina</button><button class="btn" id="phBk">← Album</button></div>';
  sheetFor(h,c=>{
    $('sheetCard').classList.add('phc');
    const msg=t=>{const e=c.querySelector('#phMsg');if(e)e.textContent=t};
    c.querySelector('#phBk').onclick=()=>PHO.album();
    c.querySelector('#phSh').onclick=()=>PHO.share(x.d,'sette-mari-foto-'+(i+1)+'.jpg',msg);
    let arm=0;const d=c.querySelector('#phDel');
    d.onclick=()=>{if(!arm){arm=1;d.textContent='Sicuro? Tocca ancora';setTimeout(()=>{if(d.isConnected){arm=0;d.textContent='🗑 Elimina'}},3000);return}
      const b=PHO.list();b.splice(i,1);PHO.put(b);sfx('tap');PHO.album()}})};
{
  const ls=()=>{try{return(S&&S.flags&&S.flags.phN)||0}catch(e){return 0}};
  NV3.AC.push({id:'foto1',n:'Fotografo',d:'Salva una foto ricordo nell\'album (Menu › Guardaroba).',ok:()=>ls()>=1});
  NV3.AC.push({id:'foto5',n:'Album di viaggio',d:'Salva cinque foto ricordo.',ok:()=>ls()>=5});
}
