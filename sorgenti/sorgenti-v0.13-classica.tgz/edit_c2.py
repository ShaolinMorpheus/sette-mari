import sys
p='ch4_inject.js'
s=open(p,encoding='utf8').read()
def rep(old,new,cnt=1):
    global s
    n=s.count(old)
    if n!=cnt:
        print('MISMATCH',n,'!=',cnt,'::',old[:90]);sys.exit(1)
    s=s.replace(old,new)

# E1 - personaggi: guardia addormentata (senza cappello) e comandante spagnolo
rep("CH.lupo={name:'Lupo',skin:'#d0a07c',hair:'#8a8a8a',coat:'#3a6a5a',coat2:'#27483e',pants:'#3a3028',shirt:'#eee6d2',hat:'tricorn',hatc:'#1a2a2a',trim:'#cfcfcf',sword:20,boots:1,w:1,tall:1};\n}\nfunction mkChar(",
"""CH.lupo={name:'Lupo',skin:'#d0a07c',hair:'#8a8a8a',coat:'#3a6a5a',coat2:'#27483e',pants:'#3a3028',shirt:'#eee6d2',hat:'tricorn',hatc:'#1a2a2a',trim:'#cfcfcf',sword:20,boots:1,w:1,tall:1};
  CH.guardiaz=Object.assign({},CH.guardia,{hat:'none',name:'Guardia'});
  CH.comandante={name:'Comandante',skin:'#d9a27c',hair:'#d4d4d8',coat:'#a8281e',coat2:'#6a1810',pants:'#201c24',shirt:'#f4efe0',hat:'comm',hatc:'#6a1418',trim:'#e8c860',sash:'#e8c860',sword:22,boots:1,mustache:1,w:1.12,tall:1.06};
}
function mkChar(""")

# E2 - guardie fuori servizio e comandante
rep("const DECKS=[{},{},{}];",
"""const DECKS=[{},{},{}];
/* guardie fuori servizio: dormono nelle cuccette o giocano a carte; il rumore le sveglia. [tipo, gx, gy, posto dopo il risveglio / ronda] */
const OFF_BY=[
 [['sleep',13,2,[[14,3],[16,3]]],['sleep',25,2,[[26,3],[28,3]]]],
 [['sleep',2,6,[[2,7],[4,7]]],['sleep',7,13,[[8,12],[6,12]]],['cards',20,3,[[20,4],[16,4]]],['cards',22,3,[[22,4],[26,4]]]],
 []];
const CMD_POST=[29,13];     // il comandante spagnolo studia le carte nella sala delle carte (ponte di comando)
const PORTS_BY=[[],[],[]];  // gli oblò lungo lo scafo (dove ogni tanto passa un gabbiano)""")

# E3 - creazione nelle liste delle guardie del ponte
rep("  D.gd=GP_BY[n].map(wp=>mkGuard(wp,n));",
"""  D.gd=GP_BY[n].map(wp=>mkGuard(wp,n));
  for(const[kind,gx,gy,wp]of OFF_BY[n]){
    const okc=c=>walkT[tIdx(OX+c[0],OY+c[1])]&&!propAt(OX+c[0],OY+c[1]);
    const w=wp.filter(okc);const g=mkGuard(w.length>1?w:[wp[0],wp[0]],n);g.off=kind;g.ph=Math.random()*6;
    if(kind==='sleep'){
      const bp=PROPS_BY[n].find(q=>q[0]==='bunk'&&q[1]===gx&&q[2]===gy);
      g.who='guardiaz';g.bunk=[gx,gy];g.bcol=(bp&&bp[5]&&bp[5].c)||'#a8503a';g.front=wp[0];
      g.x=wx(gx)+T;g.y=wy(gy)+T+4;g.face=Math.PI/2;g.dir='f'}
    else{g.face=-Math.PI/2;g.dir='b'}
    D.gd.push(g)}
  if(n===0){const c=mkGuard([CMD_POST,CMD_POST],n);c.cmd=1;c.who='comandante';c.hp=c.maxhp=6;c.hx=c.x;c.hy=c.y;c.face=-Math.PI/2;c.dir='b';D.gd.push(c)}""")

# E4 - stepGuard
rep("  if(g.ko>0){g.ko-=dt;g.mv=false;return}\n  const d=Math.hypot(P.x-g.x,P.y-g.y);",
    "  if(g.ko>0){g.ko-=dt;g.mv=false;return}\n  if(g.off){offStep(g,dt);return}\n  if(g.cmd&&cmdIdle(g,dt))return;\n  const d=Math.hypot(P.x-g.x,P.y-g.y);")
rep("      noiseAt(P.x,P.y,420,g);sfx('thud')}","      if(!g.cmd)noiseAt(P.x,P.y,420,g);sfx('thud')}")
rep("    const sp=112+al*10,n=d<70&&vis?[P.x,P.y]:nextStep(g);","    const sp=(g.cmd?122:112)+al*10,n=d<70&&vis?[P.x,P.y]:nextStep(g);")
rep("    if(d<34&&g.hitCd<=0){g.hitCd=1.2;g.swing=.32;hurtP(g)}","    if(d<34&&g.hitCd<=0){g.hitCd=g.cmd?.95:1.2;g.swing=.32;hurtP(g)}")

# E5 - rumore: sveglia le guardie fuori servizio; funzioni nuove
rep("function noiseAt(x,y,r,except){\n  for(const g of K.gd){if(g===except||g.ko>0||g.st==='chase'||g.fight)continue;\n    if(Math.hypot(g.x-x,g.y-y)<r){g.st='suspect';g.sx=x;g.sy=y;g.sw=0;g.alert=0;g.mv=false}}}",
"""function noiseAt(x,y,r,except){
  for(const g of K.gd){if(g===except||g.ko>0||g.st==='chase'||g.fight)continue;
    if(g.cmd&&!g.duel)continue;
    if(Math.hypot(g.x-x,g.y-y)<(g.off==='sleep'?r*.6:r)){
      if(g.off){wakeOff(g,x,y);continue}
      g.st='suspect';g.sx=x;g.sy=y;g.sw=0;g.alert=0;g.mv=false}}}
/* guardie fuori servizio: dormono o giocano a carte, ma un rumore forte le sveglia */
function wakeOff(g,x,y){
  if(!g.off)return;const was=g.off;g.off=0;g.look=null;g.nz=0;
  if(was==='sleep'){g.who='guardia';g.x=cx(g.front[0]);g.y=(OY+g.front[1]+.92)*T;g.flip=false;g.dir='f';g.face=Math.PI/2}
  g.st='suspect';g.sx=x==null?g.x:x;g.sy=y==null?g.y:y;g.sw=0;g.alert=0;g.mv=false;g.react=.45;
  if(g.dk===K.deck){K.fx.push({k:'star',x:g.x,y:g.y-64,t:0,life:.8});sfx('thud')}
  if(!K.notes.wake&&g.dk===K.deck){K.notes.wake=1;say('Biscotto','Si è svegliato! Nasconditi, o colpiscilo prima che ti veda.',5400)}}
function offStep(g,dt){
  g.mv=false;
  const dP=Math.hypot(P.x-g.x,P.y-g.y);
  if(g.off==='sleep'){
    // russano: si svegliano solo se ti fermi vicinissimo, o per un rumore forte
    g.nz=Math.max(0,(g.nz||0)+(dP<76?dt:-dt*.6));
    if(g.nz>2.2)wakeOff(g,P.x,P.y)}
  else{
    // assorti nel gioco: ti sentono solo se ti fermi dietro di loro, o se li guardi in faccia da vicino
    g.nz=Math.max(0,(g.nz||0)+(dP<56?dt:-dt*.6));
    const ang=Math.atan2(P.y-g.y,P.x-g.x),seen=dP<125&&Math.abs(AD(g.face,ang))<1&&los(g.x,g.y-6,P.x,P.y-6);
    if(g.nz>1.1||seen)wakeOff(g,P.x,P.y)}}
/* il comandante spagnolo: duello facoltativo (non chiama nessuno, nessun aiuto) */
function cmdIdle(g,dt){
  if(g.duel){
    if(g.st==='patrol'){ // ha perso di vista lo sfidante: torna al suo posto
      if(goTo(g,g.hx,g.hy,78,dt)){g.duel=0;g.hp=g.maxhp;g.face=-Math.PI/2;g.dir='b';g.flip=false}
      return true}
    return false}
  if(g.st==='chase'){g.duel=1;g.alert=3.2;return false}   // provocato: il duello comincia
  g.mv=false;g.hp=Math.min(g.maxhp,g.hp+dt*.4);g.face=-Math.PI/2;g.dir='b';return true}
function startDuel(){
  const c=K.gd.find(g=>g.cmd);if(!c||c.ko>0||c.duel)return;
  c.duel=1;c.st='chase';c.react=.6;c.alert=3.2;c.ls=[P.x,P.y];faceG(c,Math.atan2(P.y-c.y,P.x-c.x));progress();sfx('thud');
  say('Comandante','¡Alto! Un duello, ragazzo. Solo noi due: niente aiuti!',5200);
  if(!K.notes.duel2){K.notes.duel2=1;say('Biscotto','Ha 6 cuori e picchia forte: para al momento giusto e colpisci quando abbassa la sciabola!',6400)}}
function duelWon(c){
  if(K.duelWon)return;K.duelWon=true;
  let had=false;try{had=localStorage.getItem('sm_c4duel')==='1';localStorage.setItem('sm_c4duel','1')}catch(e){}
  K.duelFirst=!had;K.hp=K.maxhp;
  sfx('quest');K.fx.push({k:'star',x:c.x,y:c.y-84,t:0,life:1});
  toast('Duello vinto! Il comandante si arrende.',4800);
  say('Comandante','Basta, basta! Non ho mai visto una lama così svelta. La mia giubba è tua.',6200);
  if(!K.notes.duelw){K.notes.duelw=1;say('Biscotto',K.duelFirst?'Hai vinto la giubba del comandante: la trovi nel guardaroba!':'Il comandante è a terra: bel duello!',5600)}}
function stepGuard(g,dt){""")
rep("function stepGuard(g,dt){\n  g.hitCd=","function stepGuard(g,dt){\n  g.hitCd=") if False else None

# E6 - attacco: i dormienti non sono "all'erta"; il comandante non si colpisce alle spalle
rep("      const behind=g.st!=='chase'&&!(g.react>0)&&Math.abs(AD(g.face==null?0:g.face,Math.atan2(P.y-g.y,P.x-g.x)))>1.9;",
    "      const behind=!g.cmd&&(!!g.off||g.st!=='chase'&&!(g.react>0)&&Math.abs(AD(g.face==null?0:g.face,Math.atan2(P.y-g.y,P.x-g.x)))>1.9);")
rep("      if(!K.notes.ko){K.notes.ko=1;say('Biscotto','Resistono a più colpi! Colpiscili ancora, o fatti aiutare dalla ciurma.',5600)}}}\n}",
    "      if(!K.notes.ko){K.notes.ko=1;say('Biscotto','Resistono a più colpi! Colpiscili ancora, o fatti aiutare dalla ciurma.',5600)}}}\n  for(const g of K.gd)if(g.off&&g.ko<=0&&Math.hypot(g.x-P.x,g.y-P.y)<130)wakeOff(g,P.x,P.y);   // la sciabola che fende l'aria sveglia chi dorme\n}")
# E7 - colpi: il duello non fa rumore; sconfiggere il comandante
rep("moveEnt(g,nx*16,ny*16);noiseAt(g.x,g.y,300,g);","moveEnt(g,nx*16,ny*16);if(!g.cmd)noiseAt(g.x,g.y,300,g);")
rep("g.ko=1e9;g.st='ko';g.fight=null;K.kos++;","g.ko=1e9;g.st='ko';g.fight=null;K.kos++;if(g.cmd)duelWon(g);")
# E8 - la campana sveglia tutti
rep("  for(const g of K.gd){if(g.ko>0||g.st==='chase')continue;g.st='search';g.sx=P.x;g.sy=P.y;g.sw=0;g.alert=0;g.mv=false}\n}",
    "  for(const D of DECKS)for(const g of(D.gd||[]))if(g.off&&g.ko<=0)wakeOff(g,P.x,P.y);\n  for(const g of K.gd){if(g.ko>0||g.st==='chase'||(g.cmd&&!g.duel))continue;g.st='search';g.sx=P.x;g.sy=P.y;g.sw=0;g.alert=0;g.mv=false}\n}")
# E9 - i compagni non si intromettono nel duello e non attaccano chi dorme
rep("    for(const g of K.gd){if(g.ko>0)continue;const d=Math.hypot(g.x-f.x,g.y-f.y)","    for(const g of K.gd){if(g.ko>0||g.cmd||g.off)continue;const d=Math.hypot(g.x-f.x,g.y-f.y)")
# E10 - catturato: i dormienti restano nel letto, il comandante riparte da capo
rep("for(const g2 of K.gd){g2.st='patrol';g2.alert=0;g2.x=cx(g2.wp[0][0]);g2.y=(OY+g2.wp[0][1]+.92)*T}",
    "for(const g2 of K.gd){if(g2.off)continue;g2.st='patrol';g2.alert=0;if(g2.cmd){g2.duel=0;g2.hp=g2.maxhp;g2.x=g2.hx;g2.y=g2.hy;continue}g2.x=cx(g2.wp[0][0]);g2.y=(OY+g2.wp[0][1]+.92)*T}")
# E11 - il duello col comandante non conta come inseguimento
rep("K.gd.some(g=>g.ko<=0&&g.st==='chase'))K.chasedPre=true","K.gd.some(g=>g.ko<=0&&g.st==='chase'&&!g.cmd))K.chasedPre=true")
# E12 - disegno delle guardie speciali
rep("  if(e.guard){\n    const ko=e.ko>0;\n    if(ko){drawLying(g,e,t,'z z z');return}",
    "  if(e.guard){\n    if(e.who==='guardiaz'){drawSleeper(g,e,t);return}\n    const ko=e.ko>0;\n    if(ko){drawLying(g,e,t,e.cmd?'✦ ✦ ✦':'z z z');return}")
rep("    bladeAt(g,sb,24,null,e);\n    if(e.flash>0)g.restore();\n    allyHpPips(g,e);return}",
    "    bladeAt(g,sb,24,null,e);\n    if(e.flash>0)g.restore();\n    if(e.off==='cards')drawCards(g,e.x,e.y-70,t,e.ph);\n    allyHpPips(g,e);return}")
rep("function drawEnt(g,e,t){",
"""function drawSleeper(g,e,t){
  const x0=wx(e.bunk[0]),y0=wy(e.bunk[1]);
  g.save();g.translate(x0+2*T-18,y0+24);g.rotate(-1.38);
  drawChar(g,0,0,charO(e,t,{moving:false,noShadow:1,dir:'f'}));
  g.restore();
  // coperta sulle gambe, la testa resta sul cuscino
  g.fillStyle=e.bcol;g.fillRect(x0+38,y0+14,46,13);g.fillStyle='rgba(0,0,0,.2)';g.fillRect(x0+38,y0+22,46,5);g.fillStyle='rgba(255,255,255,.2)';g.fillRect(x0+38,y0+14,46,2);
  g.fillStyle='#e0b04a';g.fillRect(x0+38,y0+14,3,13);
  if(!(e.ko>0)){g.save();g.textAlign='center';g.lineWidth=3;g.strokeStyle='rgba(30,20,10,.75)';
    for(let i=0;i<3;i++){const p=(t*.55+i*.33)%1;g.globalAlpha=Math.sin(p*Math.PI);g.font='800 '+(10+i*3)+'px Nunito,Arial';g.fillStyle='#fff6dc';g.strokeText('z',x0+20+i*8+p*6,y0-2-p*22-i*4);g.fillText('z',x0+20+i*8+p*6,y0-2-p*22-i*4)}g.restore()}
}
function drawCards(g,x,y,t,seed){
  g.save();g.translate(x,y);
  for(let i=0;i<3;i++){g.save();g.rotate((i-1)*.34+Math.sin(t*1.3+seed)*.05);g.fillStyle='#fffdf4';g.strokeStyle='#4a3a28';g.lineWidth=1;rrect(g,-4,-11,8,12,1.6);g.fill();g.stroke();g.fillStyle=i===1?'#c8302a':'#222';g.font='800 6px Arial';g.textAlign='center';g.fillText(i===1?'♥':'♠',0,-3);g.restore()}
  g.restore()}
function drawEnt(g,e,t){""")
# E13 - rotte: niente cono per chi non e' di ronda; lanterne che ondeggiano
rep("    for(const gd of K.gd){if(gd.ko>0)continue;","    for(const gd of K.gd){if(gd.ko>0||gd.off||(gd.cmd&&!gd.duel))continue;")
rep("  for(const[lx,ly]of LAMPS){const X=cx(lx),Y=cy(ly),fl=1+.05*Math.sin(t*7+lx);\n    g.fillStyle='#2a1a0a';g.fillRect(X-2,Y-46,4,10);g.fillStyle='rgba(255,210,110,.95)';g.beginPath();g.ellipse(X,Y-30,6,8*fl,0,0,7);g.fill();g.fillStyle='rgba(255,255,230,.9)';g.beginPath();g.arc(X,Y-30,2.5,0,7);g.fill()}",
"""  for(const[lx,ly]of LAMPS){const X0=cx(lx),Y=cy(ly),fl=1+.05*Math.sin(t*7+lx),sw=Math.sin(t*1.25+lx*.9+ly*.5)*2.8,X=X0+sw;   // la nave dondola: le lanterne oscillano appena
    g.fillStyle='#2a1a0a';g.fillRect(X0-2,Y-46,4,6);g.strokeStyle='#2a1a0a';g.lineWidth=1.6;g.beginPath();g.moveTo(X0,Y-41);g.lineTo(X,Y-35);g.stroke();
    g.fillStyle='rgba(255,210,110,.95)';g.beginPath();g.ellipse(X,Y-30,6,8*fl,sw*.03,0,7);g.fill();g.fillStyle='rgba(255,255,230,.9)';g.beginPath();g.arc(X,Y-30,2.5,0,7);g.fill()}""")
# E14 - sfida al comandante
rep("    o('lure36',cx(36),(OY+15)*T-6,'Cannone',()=>fireLure(36));\n  }\n  if(n===1){",
    "    o('lure36',cx(36),(OY+15)*T-6,'Cannone',()=>fireLure(36));\n    o('duel',cx(CMD_POST[0]),cy(CMD_POST[1]+1),'Sfida il comandante',()=>startDuel(),()=>{const c=K.gd.find(g=>g.cmd);return !!c&&c.ko<=0&&!c.duel});\n  }\n  if(n===1){")
# E15 - suggerimenti d'ingresso
rep("hold:()=>{say('Biscotto','La sala delle carte: studiare la carta ti fa vedere dove fanno la ronda.',5600)},",
    "hold:()=>{say('Biscotto','La sala delle carte: studiare la carta ti fa vedere dove fanno la ronda.',5600);say('Tito','Quello è il comandante spagnolo! Se vuoi sfidarlo a duello premi «Usa» vicino a lui: è facoltativo.',6600)},")
rep("{cabin:()=>{say('Tito','Il dormitorio della ciurma: amache vuote, c\\'è sempre qualcuno di turno.')},",
    "{cabin:()=>{say('Tito','Il dormitorio della ciurma: due guardie dormono. Piano, o colpiscile nel sonno!',5400)},")
rep("quarters:()=>{say('Tito',K.rumTaken?'La mensa. Briciole e coltelli.':'La mensa. Briciole, coltelli... e una bottiglia di rum sul tavolo: può servire!',5000)},",
    "quarters:()=>{say('Tito',K.rumTaken?'La mensa. Briciole e coltelli.':'La mensa. Briciole, coltelli... e una bottiglia di rum sul tavolo: può servire!',5000);say('Nives','Due guardie giocano a carte: sono distratte, ma se ti fermi dietro di loro ti sentono.',5800)},")
# E16 - vita a bordo
rep("    stepAllies(dt);stepFollowers(dt);stepDuels(dt);sepAll(dt);","    stepAllies(dt);stepFollowers(dt);stepDuels(dt);sepAll(dt);stepRats(dt);")
rep("  // dialoghi e suggerimenti\n  sayNow();",
    "  // vita a bordo: scricchiolii del legno, gocce nella stiva\n  K.creakT=(K.creakT==null?5+Math.random()*5:K.creakT)-dt;if(K.creakT<=0){K.creakT=8+Math.random()*9;creak()}\n  if(K.deck===2){K.dripT=(K.dripT==null?4+Math.random()*5:K.dripT)-dt;if(K.dripT<=0){K.dripT=6+Math.random()*8;sfx('drip')}}\n  // dialoghi e suggerimenti\n  sayNow();")
rep("  // porte chiuse\n  for(const d of DOORS){if(d.open)continue;",
    "  if(K.deck>0){const D=DECKS[K.deck];if(D.rats)for(const r of D.rats)drawRat(g,r,t)}\n  drawGulls(g,t);\n  // porte chiuse\n  for(const d of DOORS){if(d.open)continue;")
rep("  g.fillStyle='#161616';for(const[x,y]of bord){if((x*3+y)%4!==0||x<12||x>38)continue;if(!isIn(x,y-1))g.fillRect(x*T+12,y*T+14,18,12);else if(!isIn(x,y+1))g.fillRect(x*T+12,y*T+14,18,12)}",
    "  g.fillStyle='#161616';PORTS_BY[DK]=[];for(const[x,y]of bord){if((x*3+y)%4!==0||x<12||x>38)continue;if(!isIn(x,y-1)||!isIn(x,y+1)){g.fillRect(x*T+12,y*T+14,18,12);PORTS_BY[DK].push([x*T+12,y*T+14])}}")
rep("function drawFloor(g,t){",
"""/* ---------------- vita a bordo: scricchiolii, ratti nella stiva, gabbiani agli oblò ---------------- */
function creak(){
  if(!(AU.ctx&&AU.on))return;
  const f=70+Math.random()*50;
  tone(f,f*.7,.5,'sawtooth',.03);tone(f*1.52,f*1.05,.34,'triangle',.016,.06);noiseBurst(.28,240,.018,.03)}
const RATN=[0,2,5];
function ratFree(x,y){const tx=Math.floor(x/T),ty=Math.floor(y/T);return inMap(tx,ty)&&walkT[tIdx(tx,ty)]&&!blockT[tIdx(tx,ty)]}
function makeRats(n){
  const out=[];let tries=0;
  while(out.length<RATN[n]&&tries++<800){
    const gx=1+((Math.random()*(SW-2))|0),gy=1+((Math.random()*(SH-2))|0);
    if(!roomAt(gx,gy))continue;
    const x=(OX+gx+.5)*T,y=(OY+gy+.5)*T;if(!ratFree(x,y)||Math.hypot(x-P.x,y-P.y)<260)continue;
    out.push({x,y,tx:null,ty:null,wait:Math.random()*2,sp:80,fl:0,dir:Math.random()<.5?-1:1,mv:0,ph:Math.random()*6,sq:0})}
  return out}
function stepRats(dt){
  if(!RATN[K.deck])return;
  const D=DECKS[K.deck];if(!D.rats)D.rats=makeRats(K.deck);
  for(const r of D.rats){
    r.sq=Math.max(0,r.sq-dt);
    const dP=Math.hypot(P.x-r.x,P.y-r.y);
    if(dP<140&&r.fl<=0){r.fl=1.2;const a=Math.atan2(r.y-P.y,r.x-P.x)+(Math.random()-.5)*1.2;r.tx=r.x+Math.cos(a)*200;r.ty=r.y+Math.sin(a)*160;r.sp=230;r.wait=0;
      if(r.sq<=0&&dP<120&&AU.ctx&&AU.on){r.sq=3;tone(2400,3200,.05,'square',.02);tone(3000,2200,.05,'square',.015,.06)}}
    if(r.fl>0)r.fl-=dt;
    if(r.wait>0){r.wait-=dt;r.mv=0;continue}
    if(r.tx==null){const a=Math.random()*6.283,d=60+Math.random()*130;r.tx=r.x+Math.cos(a)*d;r.ty=r.y+Math.sin(a)*d*.7;r.sp=85+Math.random()*30}
    const dx=r.tx-r.x,dy=r.ty-r.y,d=Math.hypot(dx,dy);
    if(d<6){r.tx=null;r.wait=.5+Math.random()*3.5;r.mv=0;continue}
    const m=Math.min(r.sp*dt,d),nx=r.x+dx/d*m,ny=r.y+dy/d*m;
    if(ratFree(nx,ny)&&ratFree(nx+dx/d*8,ny+dy/d*8)){r.x=nx;r.y=ny;r.mv=1;if(Math.abs(dx)>2)r.dir=dx<0?-1:1}else{r.tx=null;r.wait=.15;r.mv=0}}}
function drawRat(g,r,t){
  g.save();g.translate(r.x,r.y);g.scale(r.dir,1);
  g.fillStyle='rgba(10,8,20,.25)';g.beginPath();g.ellipse(0,1,8,2.6,0,0,7);g.fill();
  const bob=r.mv?Math.sin(t*26+r.ph)*.7:0;
  g.strokeStyle='#c9a0a0';g.lineWidth=1.3;g.lineCap='round';g.beginPath();g.moveTo(-6.5,-4+bob);g.quadraticCurveTo(-12,-1+Math.sin(t*9+r.ph)*2,-15,-3);g.stroke();
  g.fillStyle='#7d6c5c';g.beginPath();g.ellipse(0,-4+bob,7,3.5,0,0,7);g.fill();
  g.fillStyle='#8e7c6a';g.beginPath();g.ellipse(6.6,-4.4+bob,3.6,2.6,0,0,7);g.fill();
  g.fillStyle='#d8a0a8';g.beginPath();g.arc(9.9,-4.2+bob,1,0,7);g.fill();
  g.fillStyle='#c8aaa0';g.beginPath();g.arc(4.9,-6.9+bob,1.7,0,7);g.fill();
  g.fillStyle='#14100c';g.beginPath();g.arc(7.4,-5+bob,.7,0,7);g.fill();
  if(r.mv){g.strokeStyle='#5e4e40';g.lineWidth=1;const s=Math.sin(t*26+r.ph)*2;g.beginPath();g.moveTo(-3,-1.4);g.lineTo(-3+s,.6);g.moveTo(3,-1.4);g.lineTo(3-s,.6);g.stroke()}
  g.restore()}
function drawGulls(g,t){
  if(K.deck>1)return;
  const ps=PORTS_BY[K.deck]||[];
  for(let i=0;i<ps.length;i++){const X=wx(0)+ps[i][0],Y=wy(0)+ps[i][1];
    if(Math.abs(X-P.x)>720||Math.abs(Y-P.y)>420)continue;
    const per=34+(i%5)*6,off=(i*9.7)%per,u=(t+off)%per,ev=Math.floor((t+off)/per);
    if(u>2.4)continue;
    const p=u/2.4;
    g.save();g.beginPath();g.rect(X,Y,18,12);g.clip();
    g.fillStyle='rgba(150,205,240,'+(.9*Math.sin(p*Math.PI))+')';g.fillRect(X,Y,18,12);
    const gx=X-4+p*26,gy=Y+6+Math.sin(p*6)*1.5,fl=Math.sin(t*16);
    g.strokeStyle='#fff';g.lineWidth=1.6;g.lineCap='round';g.beginPath();g.moveTo(gx-5,gy-2.5*fl-1);g.quadraticCurveTo(gx-2.5,gy-4*fl-2.5,gx,gy);g.quadraticCurveTo(gx+2.5,gy-4*fl-2.5,gx+5,gy-2.5*fl-1);g.stroke();
    g.fillStyle='#fff';g.beginPath();g.ellipse(gx,gy+.5,1.6,1.1,0,0,7);g.fill();
    g.restore();
    if(ps[i].ev!==ev){ps[i].ev=ev;if(Math.hypot(X-P.x,Y-P.y)<360&&AU.ctx&&AU.on)sfx('gull')}}}
function drawFloor(g,t){""")
# E17 - scheda finale: duello
rep("+(first?'<div class=\"c4nw\">🎩 Nuovo nel guardaroba: Cappello da comandante</div>':'')}",
    "+(first?'<div class=\"c4nw\">🎩 Nuovo nel guardaroba: Cappello da comandante</div>':'')+(K.duelWon?'<div class=\"c4nw\">⚔ Duello vinto col comandante'+(K.duelFirst?': nuova giubba nel guardaroba':'')+'</div>':'')}")
# E18 - esportazioni per i test
rep("window.Ch4={KEYSP,","window.Ch4={OFF_BY,wakeOff,startDuel,stepRats,noiseAt,KEYSP,")
open(p,'w',encoding='utf8').write(s)
print('ok',len(s))
