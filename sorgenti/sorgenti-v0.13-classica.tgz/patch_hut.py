import re,json
p='base_index.html';s=open(p,encoding='utf8').read()
def rep(old,new,cnt=1):
    global s
    n=s.count(old)
    if n!=cnt: print('FAIL',n,old[:80]);raise SystemExit(1)
    s=s.replace(old,new)
mod=open('hut_mod.js',encoding='utf8').read()
rep("/* ====== METEO, LUNA, TORCIA E LIVELLO DELLA POZZA ====== */",mod+"/* ====== METEO, LUNA, TORCIA E LIVELLO DELLA POZZA ====== */")
# bandiera
rep("cnt:1,at:[[0,-5]]}","cnt:1,at:[[0,-3.3]]}")
rep("function campRestore(){\n  for(const o of(S.camp||[]))campAdd(o.k,o.tx,o.ty);",
"""function campRestore(){
  for(const o of(S.camp||[]))campAdd(o.k,o.tx,o.ty);
  // la bandiera, ormai, sta più vicina al campo (una sola volta, anche nei salvataggi vecchi)
  try{
    if(S.camp&&!S.flagMig&&S.camp.some(o=>o.k==='bandiera')){
      S.flagMig=1;
      for(const o of S.camp.filter(o=>o.k==='bandiera')){
        const e=E.find(x=>x.type==='cdeco'&&x.k==='bandiera'&&x.tx===o.tx&&x.ty===o.ty);
        if(e){delete EID[e.id];E.splice(E.indexOf(e),1)}
        S.camp.splice(S.camp.indexOf(o),1);
        const t=campTile(0,-3.3)||campTile(2,-3.3)||campTile(-2,-3.3);
        if(t){campAdd('bandiera',t[0],t[1]);S.camp.push({k:'bandiera',tx:t[0],ty:t[1]})}
        else{campAdd('bandiera',o.tx,o.ty);S.camp.push(o)}
      }
    }
  }catch(_){}""")
# genWorld hooks
rep("addBlock(e,f.tx,f.ty,f.w,f.h);delBlock(e);      // la piazzola vuota si attraversa; diventa solida solo quando è costruita\n  }\n  // il pappagallo selvatico",
    "addBlock(e,f.tx,f.ty,f.w,f.h);delBlock(e);      // la piazzola vuota si attraversa; diventa solida solo quando è costruita\n  }\n  hutBuild();\n  // il pappagallo selvatico")
rep("deco('cave','cave',(cv[0]+.5),cv[1]+.95,[cv[0]-1,cv[1],3,1],{hitw:150,hith:100,inter:'look',label:'La grotta'});caveBuild();","deco('cave','cave',(cv[0]+.5),cv[1]+.95,[cv[0]-1,cv[1],3,1],{hitw:150,hith:100,inter:'look',label:'La grotta'});caveBuild();hutBuild();")
# dockSpot
rep("(WORLD===2&&x>=CV_X0&&x<CV_X0+CV_W&&y>=CV_Y0&&y<CV_Y0+CV_H))continue;","(WORLD===2&&x>=CV_X0&&x<CV_X0+CV_W&&y>=CV_Y0&&y<CV_Y0+CV_H)||huReg(x,y))continue;")
# target
rep("const inC=inCave(),fishNear","const inC=inRoom(),fishNear")
rep("case'deco':if(e.id==='c2fire')return{l:'Scaldati',i:'fire'};","case'deco':if(hutLbl(e))return hutLbl(e);if(e.id==='c2fire')return{l:'Scaldati',i:'fire'};")
rep("case'deco':Story.look(e);return;","case'deco':if(e.id&&e.id.indexOf('h_')===0){hutLook(e);return}Story.look(e);return;")
rep("return{l:{capanna:'Riposa',banco:'Banco',falo:'Cucina',zattera:'Salpa'}[e.pid]||'Usa',i:e.pid==='falo'?'fire':e.pid==='capanna'?'bed':","return{l:{capanna:'Entra',banco:'Banco',falo:'Cucina',zattera:'Salpa'}[e.pid]||'Usa',i:e.pid==='falo'?'fire':e.pid==='capanna'?'hand':")
# plotUse
i=s.index("  if(id==='capanna'){\n    const can=S.tod>=19||S.tod<6;");j=s.index("  }else if(id==='banco'){UI.openUpgrades()}")
s=s[:i]+"  if(id==='capanna'){\n    hutEnter();\n"+s[j:]
# weather guards
rep("if(!inCave())UI.toast(weatherText(k));","if(!inRoom())UI.toast(weatherText(k));")
rep("if(k==='storm'){if(!inCave())hint('storm');WX.boltT=2.5}else if(k==='rain'){if(!inCave())hint('rain')}","if(k==='storm'){if(!inRoom())hint('storm');WX.boltT=2.5}else if(k==='rain'){if(!inRoom())hint('rain')}")
rep("if(inCave()){}else if(w.k==='storm'","if(inRoom()){}else if(w.k==='storm'")
rep("if(isNight()&&!inCave()){","if(isNight()&&!inRoom()){")
rep("  if(inCave())return 1;\n  const c=EID.plot_capanna;","  if(inHut())return 2;\n  if(inCave())return 1;\n  const c=EID.plot_capanna;")
rep("if(!EX.fw&&!inCave()&&","if(!EX.fw&&!inRoom()&&")
# render + step + css + export
rep("if(inCave()){renderCave(t);return}","if(inCave()){renderCave(t);return}\n  if(inHut()){renderHut(t);return}")
rep("torchTick();caveStep(dt);","torchTick();caveStep(dt);hutStep(dt);")
rep("body.incave #mini{display:none}","body.incave #mini,body.inhut #mini{display:none}")
rep("cave:{inside:()=>inCave(),","hut:{inside:()=>inHut(),enter:()=>hutEnter(),exit:()=>hutExit(),get G(){return HUT&&HUT.G},get X0(){return HUT&&HUT.x0},Y0:HU_Y0},\n  cave:{inside:()=>inCave(),")
# PACK
rows=[
["Entra","Enter","Betreten","Entrar","Entrer"],["Esci","Leave","Verlassen","Salir","Sortir"],["Uscita","Exit","Ausgang","Salida","Sortie"],
["Letto","Bed","Bett","Cama","Lit"],["Comodino","Nightstand","Nachttisch","Mesita de noche","Table de chevet"],["Armadio","Wardrobe","Kleiderschrank","Armario","Armoire"],
["Baule da marinaio","Sea chest","Seemannstruhe","Baúl de marinero","Coffre de marin"],["Libreria","Bookshelf","Bücherregal","Librería","Bibliothèque"],["Camino","Fireplace","Kamin","Chimenea","Cheminée"],
["Tavolo","Table","Tisch","Mesa","Table"],["Appendiabiti","Coat stand","Garderobenständer","Perchero","Portemanteau"],["Barili","Barrels","Fässer","Barriles","Tonneaux"],
["Tavolo delle mappe","Map table","Kartentisch","Mesa de mapas","Table des cartes"],["Telescopio","Telescope","Teleskop","Telescopio","Télescope"],["Baule","Chest","Truhe","Baúl","Coffre"],
["Apri","Open","Öffnen","Abrir","Ouvrir"],["Guarda","Look","Ansehen","Mirar","Regarder"],["Mappa","Map","Karte","Mapa","Carte"],["Riposa","Rest","Ausruhen","Descansar","Se reposer"],["Siediti","Sit down","Hinsetzen","Sentarse","S'asseoir"],
["Cra! Tre stanze! Quasi una reggia. Con le tavole storte.","Squawk! Three rooms! Almost a palace. With crooked boards.","Kra! Drei Zimmer! Fast ein Palast. Mit schiefen Brettern.","¡Cra! ¡Tres habitaciones! Casi un palacio. Con tablas torcidas.","Cra ! Trois pièces ! Presque un palais. Avec des planches de travers."],
["Il camino scoppietta. Qui dentro la pioggia sembra lontana.","The fireplace crackles. In here the rain feels far away.","Der Kamin knistert. Hier drinnen scheint der Regen weit weg.","La chimenea crepita. Aquí dentro la lluvia parece lejana.","La cheminée crépite. Ici, la pluie semble loin."],
["Il camino scoppietta piano. Che bel posto.","The fireplace crackles softly. What a nice place.","Der Kamin knistert leise. Was für ein schöner Ort.","La chimenea crepita despacio. Qué buen lugar.","La cheminée crépite doucement. Quel bel endroit."],
["Ti siedi a tavolo: mangiare per terra era peggio. Premi «Mangia» o cucina al falò.","You sit at the table: eating on the ground was worse. Press “Eat” or cook at the fire.","Du setzt dich an den Tisch: auf dem Boden zu essen war schlimmer. Drücke «Essen» oder koche am Feuer.","Te sientas a la mesa: comer en el suelo era peor. Pulsa «Comer» o cocina en la hoguera.","Tu t'assieds à table : manger par terre, c'était pire. Appuie sur «Manger» ou cuisine au feu."],
["Un tavolo vero, con due sgabelli. Il Cormorano non ne aveva uno migliore.","A real table, with two stools. The Cormorant didn't have a better one.","Ein echter Tisch mit zwei Hockern. Der Kormoran hatte keinen besseren.","Una mesa de verdad, con dos taburetes. El Cormorán no tenía una mejor.","Une vraie table, avec deux tabourets. Le Cormoran n'en avait pas de meilleure."],
["Il baule dei ricordi: un giorno dopo l'altro, qui dentro tengo il conto.","The chest of memories: day after day, I keep count in here.","Die Truhe der Erinnerungen: Tag für Tag führe ich hier Buch.","El baúl de los recuerdos: día tras día, aquí llevo la cuenta.","Le coffre des souvenirs : jour après jour, j'y tiens le compte."],
["Un comodino con una candela mezza consumata e un diario senza pagine scritte. Ancora.","A nightstand with a half-burnt candle and a journal with no pages written. Yet.","Ein Nachttisch mit einer halb heruntergebrannten Kerze und einem Tagebuch ohne beschriebene Seiten. Noch.","Una mesita con una vela medio gastada y un diario sin páginas escritas. Todavía.","Une table de chevet avec une bougie à moitié consumée et un journal sans page écrite. Pour l'instant."],
["L'armadio: una camicia a righe, un cappello di ricambio e un paio di calzoni che hanno visto giorni migliori.","The wardrobe: a striped shirt, a spare hat and a pair of trousers that have seen better days.","Der Schrank: ein gestreiftes Hemd, ein Ersatzhut und eine Hose, die bessere Tage gesehen hat.","El armario: una camisa a rayas, un sombrero de repuesto y unos pantalones que han visto días mejores.","L'armoire : une chemise rayée, un chapeau de rechange et un pantalon qui a connu des jours meilleurs."],
["Un baule da marinaio, vuoto. Per ora ci tengo i ricordi.","A sea chest, empty. For now I keep my memories in it.","Eine Seemannstruhe, leer. Vorerst bewahre ich darin meine Erinnerungen auf.","Un baúl de marinero, vacío. Por ahora guardo en él los recuerdos.","Un coffre de marin, vide. Pour l'instant j'y garde mes souvenirs."],
["Libri gonfi d'acqua, qualche mappa incompleta e una conchiglia che fa da fermalibri.","Water-swollen books, a few incomplete maps and a shell for a bookend.","Wassergequollene Bücher, ein paar unvollständige Karten und eine Muschel als Buchstütze.","Libros hinchados de agua, algunos mapas incompletos y una concha como sujetalibros.","Des livres gonflés d'eau, quelques cartes incomplètes et un coquillage en guise de serre-livres."],
["Il mio cappotto e il cappello a tre punte. Quando c'è bel tempo li lascio qui a prendere aria.","My coat and my tricorn hat. When the weather's nice I leave them here to air out.","Mein Mantel und mein Dreispitz. Bei schönem Wetter lasse ich sie hier lüften.","Mi abrigo y mi sombrero de tres picos. Cuando hace buen tiempo los dejo aquí para que se aireen.","Mon manteau et mon tricorne. Quand il fait beau, je les laisse ici pour qu'ils s'aèrent."],
["Barili vuoti. Ottimi da usare come sgabelli o come scuse.","Empty barrels. Great as stools or as excuses.","Leere Fässer. Bestens als Hocker oder als Ausreden.","Barriles vacíos. Perfectos como taburetes o como excusas.","Des tonneaux vides. Parfaits comme tabourets ou comme excuses."],
["Un telescopio ottone e fortuna. Dalla finestra vedo solo mare e nuvole, per ora.","A telescope made of brass and luck. From the window I only see sea and clouds, for now.","Ein Teleskop aus Messing und Glück. Aus dem Fenster sehe ich vorerst nur Meer und Wolken.","Un telescopio de latón y suerte. Desde la ventana solo veo mar y nubes, por ahora.","Un télescope de laiton et de chance. De la fenêtre, je ne vois que la mer et les nuages, pour l'instant."],
]
i=s.index('var PACK=');arr,end=json.JSONDecoder().raw_decode(s[i+9:])
have={r[0] for r in arr}
arr+=[r for r in rows if r[0] not in have]
s=s[:i]+'var PACK='+json.dumps(arr,ensure_ascii=False)+s[i+9+end:]
open(p,'w',encoding='utf8').write(s)
print('ok')
