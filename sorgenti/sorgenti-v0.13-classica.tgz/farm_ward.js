/* ====== ORTO, ESSICCATORE E GUARDAROBA (v0.9) ====== */
/* ---- l'orto: quattro zolle, tre colture che si sbloccano con i raccolti ---- */
const GC={
  patata:{n:'Patata dolce',t:200,y:2,need:0},
  zucca:{n:'Zucca',t:320,y:2,need:3},
  ananas:{n:'Ananas',t:480,y:1,need:8}
};
const GC_ORDER=['patata','zucca','ananas'];
/* ---- l'essiccatore: tre ripiani, il sole asciuga e la pioggia ferma tutto ---- */
const DRYR=[
  {id:'pesce',n:'Pesce secco',d:'Due pesci crudi salati e appesi al sole.',inp:{pesce:2},out:{pescesec:2},t:300},
  {id:'bacche',n:'Bacche secche',d:'Tre manciate di bacche stese ad asciugare.',inp:{bacche:3},out:{fruttasec:3},t:200},
  {id:'ananas',n:'Ananas essiccato',d:'Fette di ananas al sole: dolci e a lunga conservazione.',inp:{ananas:1},out:{fruttasec:3},t:240}
];
const isRain=()=>typeof WX!=='undefined'&&!!WX&&WX.i>.2;
const hasFarm=k=>!!(S&&S.camp&&S.camp.some(o=>o.k===k));
function farmInit(){if(!S)return;if(!S.gard)S.gard={pl:[null,null,null,null],harv:0};if(!S.dry)S.dry={sl:[null,null,null],done:0}}
const fmtT=s=>{s=Math.max(0,Math.ceil(s));return Math.floor(s/60)+':'+(s%60<10?'0':'')+(s%60)};
function farmAdvance(sec,sleepy){      // sec = tempo di gioco trascorso
  if(!S||!(sec>0))return;
  const rain=isRain(),g=S.gard,d=S.dry;
  if(g&&g.pl&&hasFarm('orto')){const r=rain?2.4:1;for(const p of g.pl)if(p&&GC[p.c]&&p.p<GC[p.c].t)p.p=Math.min(GC[p.c].t,p.p+sec*r)}
  if(d&&d.sl&&hasFarm('essic')&&!rain){const r=sleepy?.5:(skyLight(S.tod).dark>.3?.5:1);for(const s of d.sl)if(s&&s.p<s.t)s.p=Math.min(s.t,s.p+sec*r)}
}
let _fT=0,_rainWarn=false,_wT=0,_ivT=0;
function farmNotify(k,name){
  UI.toast(k==='orto'?'Nell\'orto è pronto: '+name+'.':'Essiccazione finita: '+name+'.');sfx('ok');
  const e=E.find(x=>x.type==='cdeco'&&x.k===k);if(e&&typeof sparkBurst==='function')sparkBurst(e.x,e.y-40,8);
  if(S.flags.parrot&&!UI.dlgOpen())setTimeout(()=>{if(!UI.dlgOpen()&&S&&S.live){say(PAR,k==='orto'?'Cra! Si mangia! Si mangia!':'Cra! Il pesce è pronto, sa di sole!',3.6);sfx('cra')}},900);
}
function farmTick(dt){
  if(!S||!S.live)return;
  farmAdvance(dt);
  _fT+=dt;if(_fT>=1){
    _fT=0;
    const g=S.gard,d=S.dry;
    if(g&&g.pl)for(const p of g.pl)if(p&&GC[p.c]&&p.p>=GC[p.c].t&&!p.n){p.n=1;farmNotify('orto',GC[p.c].n)}
    if(d&&d.sl)for(const s of d.sl)if(s&&s.p>=s.t&&!s.n){s.n=1;farmNotify('essic',s.nm)}
    if(isRain()){
      if(!_rainWarn){_rainWarn=true;if(!inRoom()){
        if(hasFarm('essic')&&d&&d.sl&&d.sl.some(s=>s&&s.p<s.t))UI.toast('Piove: l\'essiccatore si ferma finché non smette.');
        else if(hasFarm('orto')&&g&&g.pl&&g.pl.some(p=>p&&p.p<GC[p.c].t))UI.toast('La pioggia fa bene all\'orto: cresce più in fretta.')}}
    }else _rainWarn=false;
  }
  _wT+=dt;if(_wT>=2.5){_wT=0;try{wardCheck()}catch(e){}}
}
function farmBuilt(k){
  farmInit();
  if(k==='orto'){gain('semi',3,null,null,true);setTimeout(()=>UI.toast('Nel sacco hai trovato 3 semi di patata dolce. Piantali nell\'orto!'),700)}
  if(k==='essic')setTimeout(()=>UI.toast('Appendi pesce crudo o bacche all\'essiccatore: col sole si conservano a lungo.'),700);
}
function gardCrops(){return GC_ORDER.filter(k=>((S.gard&&S.gard.harv)||0)>=GC[k].need)}
function gardNext(){const h=(S.gard&&S.gard.harv)||0;for(const k of GC_ORDER)if(h<GC[k].need)return{k,left:GC[k].need-h};return null}
function gardPlant(i,c){
  const g=S.gard;if(g.pl[i]||!GC[c]||(g.harv||0)<GC[c].need||(S.res.semi||0)<1){sfx('no');return false}
  S.res.semi--;g.pl[i]={c,p:0};sfx('pick');addXp(2);UI.sync();saveGame(true);return true;
}
function gardHarvest(i){
  const g=S.gard,p=g.pl[i];if(!p||!GC[p.c]||p.p<GC[p.c].t){sfx('no');return 0}
  const C=GC[p.c],room=rcap(p.c)-(S.res[p.c]||0);
  if(room<C.y){UI.toast('Hai la scorta piena: mangia o cucina qualcosa prima di raccogliere.');sfx('no');return 0}
  const y=Math.min(room,C.y+(Math.random()<.25?1:0)),seeds=1+(Math.random()<.35?1:0);
  g.pl[i]=null;g.harv=(g.harv||0)+1;
  gain(p.c,y,null,null,true);gain('semi',seeds,null,null,true);addXp(8);sfx('ok');
  for(const k of GC_ORDER)if(GC[k].need>0&&g.harv===GC[k].need){gain('semi',2,null,null,true);setTimeout(()=>UI.banner('Nuovi semi',GC[k].n+'\nPuoi piantarla nell\'orto'),500)}
  U.sync&&U.sync();saveGame(true);return y;
}
function dryPut(si,rid){
  const r=DRYR.find(x=>x.id===rid),d=S.dry;if(!r||d.sl[si]||!hasRes(r.inp)){sfx('no');return false}
  payRes(r.inp);d.sl[si]={r:rid,p:0,t:r.t,nm:r.n};sfx('pick');addXp(2);UI.sync();saveGame(true);return true;
}
function dryTake(si){
  const d=S.dry,s=d.sl[si];if(!s||s.p<s.t){sfx('no');return false}
  const r=DRYR.find(x=>x.id===s.r);if(!r){d.sl[si]=null;return false}
  for(const k in r.out)if((S.res[k]||0)+r.out[k]>rcap(k)){UI.toast('Non hai posto per tutto: mangia o cucina qualcosa prima.');sfx('no');return false}
  for(const k in r.out)gain(k,r.out[k],null,null,true);
  d.sl[si]=null;d.done=(d.done||0)+1;addXp(6);sfx('ok');U.sync&&U.sync();saveGame(true);return true;
}
const ficn=k=>'<svg class="ic"><use href="#i-'+k+'"/></svg>';
function dryLine(r){      // ingressi (hai/serve) → uscite, con il tempo: pillole come nelle ricette
  const pill=(k,t,ok,x)=>'<span class="cost '+(ok?'ok':'no')+'"'+(x||'')+'><svg class="ic"><use href="#i-'+k+'"/></svg>'+t+'</span>';
  const inp=Object.keys(r.inp).map(k=>{const have=S.res[k]||0;return pill(k,have+'/'+r.inp[k],have>=r.inp[k],' data-k="'+k+'"')}).join('');
  const out=Object.keys(r.out).map(k=>pill(k,'+'+r.out[k],true,' style="background:rgba(236,190,84,.3);border-color:#b8862a"')).join('');
  return'<div class="costs" style="align-items:center;margin:6px 0 2px">'+inp+'<b style="color:#6a4424">→</b>'+out+'<span class="sm" style="margin:0 0 0 4px">⏱ '+fmtT(r.t)+'</span></div>';
}
UI.openGarden=function(){_ivT=performance.now();
  farmInit();let iv=0;
  const draw=()=>{
    const g=S.gard,crops=gardCrops(),nx=gardNext();
    let h='<h2>L\'orto</h2><p>Pianta un seme in una zolla e torna più tardi: cresce anche mentre sei lontano, e la pioggia lo aiuta.</p>';
    h+='<p class="sm">Semi: <b>'+(S.res.semi||0)+'</b> · Raccolti: <b>'+(g.harv||0)+'</b>'+(nx?' · Prossima coltura: '+GC[nx.k].n+' tra '+nx.left+(nx.left===1?' raccolto':' raccolti'):'')+'</p>';
    const rd=g.pl.filter(p=>p&&GC[p.c]&&p.p>=GC[p.c].t).length;
    if(rd>0)h+='<div class="row" style="margin-bottom:8px"><button class="btn gold" id="gdAll">Raccogli tutto ('+rd+')</button></div>';
    for(let i=0;i<4;i++){
      const p=g.pl[i];h+='<div class="upg" data-z="'+i+'">';
      if(!p){
        h+='<h3>Zolla '+(i+1)+'</h3><p class="sm">Vuota.</p>';
        if(!((S.res.semi||0)>0))h+='<div class="req">Ti serve un seme. Ogni raccolto ne restituisce almeno uno.</div>';
        else h+='<div class="row" style="flex-wrap:wrap;gap:6px">'+crops.map(k=>'<button class="btn" style="display:flex;align-items:center;justify-content:center;gap:7px" data-pl="'+i+':'+k+'">'+ficn(k)+'<span>'+GC[k].n+'</span><span>· '+fmtT(GC[k].t)+'</span></button>').join('')+'</div>';
      }else{
        const C=GC[p.c],done=p.p>=C.t;
        h+='<h3 style="display:flex;align-items:center;gap:7px;flex-wrap:wrap">Zolla '+(i+1)+' · '+ficn(p.c)+'<span>'+C.n+'</span></h3>';
        if(done)h+='<p class="sm">Matura! Raccoglierai '+C.y+(C.y>1?' frutti':' frutto')+' e almeno un seme.</p><button class="btn gold" data-hv="'+i+'">Raccogli</button>';
        else h+='<div class="pgb"><i data-pg="'+i+'" style="width:'+Math.round(p.p/C.t*100)+'%"></i></div><p class="sm">Pronta tra <span data-tm="'+i+'">'+fmtT((C.t-p.p)/(isRain()?2.4:1))+'</span>'+(isRain()?' (la pioggia aiuta)':'')+'</p>';
      }
      h+='</div>';
    }
    h+='<div class="row"><button class="btn" id="shNo">Chiudi</button></div>';
    sheetFor(h,c=>{
      c.querySelectorAll('[data-pl]').forEach(b=>b.onclick=()=>{const[i,k]=b.dataset.pl.split(':');if(gardPlant(+i,k))draw()});
      c.querySelectorAll('[data-hv]').forEach(b=>b.onclick=()=>{const y=gardHarvest(+b.dataset.hv);if(y){const e=E.find(x=>x.type==='cdeco'&&x.k==='orto');if(e&&typeof sparkBurst==='function')sparkBurst(e.x,e.y-30,8);draw()}});
      const a=c.querySelector('#gdAll');if(a)a.onclick=()=>{let n=0;for(let i=0;i<4;i++){const p=g.pl[i];if(p&&GC[p.c]&&p.p>=GC[p.c].t){if(gardHarvest(i))n++;else break}}if(n)UI.toast('Raccolto fatto: '+n+(n===1?' zolla':' zolle')+'.');draw()};
    });
  };
  draw();
  clearInterval(UI._gIv);UI._gIv=iv=setInterval(()=>{
    const sh=$('sheet');if(!sh||sh.hidden||!document.querySelector('#sheetCard [data-z]')){clearInterval(iv);return}
    {const n=performance.now(),dt=_ivT?Math.min(2,(n-_ivT)/1000):0;_ivT=n;if(typeof PAUSED!=='undefined'&&PAUSED&&dt>0)farmAdvance(dt)}
    let ch=false;
    for(let i=0;i<4;i++){const p=S.gard.pl[i],bar=document.querySelector('#sheetCard [data-pg="'+i+'"]');
      if(p&&GC[p.c]){const C=GC[p.c];if(p.p>=C.t&&bar)ch=true;else if(bar){bar.style.width=Math.round(p.p/C.t*100)+'%';const tm=document.querySelector('#sheetCard [data-tm="'+i+'"]');if(tm)tm.textContent=fmtT((C.t-p.p)/(isRain()?2.4:1))}}}
    if(ch)draw();
  },1000);
};
UI.openDryer=function(){
  farmInit();_ivT=performance.now();let iv=0;
  const draw=()=>{
    const d=S.dry;
    let h='<h2>L\'essiccatore</h2><p>Il sole asciuga pesce e frutta e li rende scorte che non vanno a male. Di notte ci mette il doppio, con la pioggia si ferma.</p>';
    for(let i=0;i<3;i++){
      const s=d.sl[i];h+='<div class="upg" data-z="'+i+'">';
      if(!s){
        h+='<h3>Ripiano '+(i+1)+'</h3><p class="sm">Libero.</p>';
        h+=DRYR.map(r=>{const ok=hasRes(r.inp);return'<div class="row" style="margin:4px 0;align-items:center;gap:8px"><div style="flex:1;min-width:0"><b>'+r.n+'</b><div class="sm">'+r.d+'</div>'+dryLine(r)+'</div><button class="btn gold" data-dp="'+i+':'+r.id+'"'+(ok?'':' disabled')+'>Appendi</button></div>'}).join('');
      }else{
        const done=s.p>=s.t;
        h+='<h3>Ripiano '+(i+1)+' · '+s.nm+'</h3>';
        if(done)h+='<p class="sm">Asciutto e pronto.</p><button class="btn gold" data-dt="'+i+'">Ritira</button>';
        else h+='<div class="pgb"><i data-pg="'+i+'" style="width:'+Math.round(s.p/s.t*100)+'%"></i></div><p class="sm">'+(isRain()?'Piove: fermo.':'Pronto tra')+' <span data-tm="'+i+'">'+fmtT((s.t-s.p)/(skyLight(S.tod).dark>.3?.5:1))+'</span></p>';
      }
      h+='</div>';
    }
    h+='<div class="row"><button class="btn" id="shNo">Chiudi</button></div>';
    sheetFor(h,c=>{
      c.querySelectorAll('[data-dp]').forEach(b=>b.onclick=()=>{const[i,r]=b.dataset.dp.split(':');if(dryPut(+i,r))draw()});
      c.querySelectorAll('[data-dt]').forEach(b=>b.onclick=()=>{if(dryTake(+b.dataset.dt)){const e=E.find(x=>x.type==='cdeco'&&x.k==='essic');if(e&&typeof sparkBurst==='function')sparkBurst(e.x,e.y-30,8);draw()}});
    });
  };
  draw();
  clearInterval(UI._dIv);UI._dIv=iv=setInterval(()=>{
    const sh=$('sheet');if(!sh||sh.hidden||!document.querySelector('#sheetCard [data-z]')){clearInterval(iv);return}
    {const n=performance.now(),dt=_ivT?Math.min(2,(n-_ivT)/1000):0;_ivT=n;if(typeof PAUSED!=='undefined'&&PAUSED&&dt>0)farmAdvance(dt)}
    let ch=false;
    for(let i=0;i<3;i++){const s=S.dry.sl[i],bar=document.querySelector('#sheetCard [data-pg="'+i+'"]');
      if(s){if(s.p>=s.t&&bar)ch=true;else if(bar){bar.style.width=Math.round(s.p/s.t*100)+'%';const tm=document.querySelector('#sheetCard [data-tm="'+i+'"]');if(tm)tm.textContent=fmtT((s.t-s.p)/(skyLight(S.tod).dark>.3?.5:1))}}}
    if(ch)draw();
  },1000);
};

/* ---- disegno: orto e essiccatore ---- */
function leaf(g,x,y,len,ang,col,w){g.save();g.translate(x,y);g.rotate(ang);g.fillStyle=col;g.beginPath();g.ellipse(0,-len/2,w||len*.28,len/2,0,0,7);g.fill();g.strokeStyle='rgba(20,50,14,.55)';g.lineWidth=.8;g.stroke();g.restore()}
function cropDraw(g,c,f,x,y,t){
  const st=f>=1?3:f<.25?0:f<.55?1:2,sw=Math.sin(t*1.6+x*.3)*.05;
  g.save();g.translate(x,y);
  if(c==='patata'){
    if(st===0){leaf(g,-1.5,0,5,-.5,'#9ad06a');leaf(g,1.5,0,5,.5,'#8cc45e')}
    else{const n=st===1?3:6,L=st===1?9:13;for(let i=0;i<n;i++){const a=(i/(n-1)-.5)*2.1+sw;leaf(g,(i/(n-1)-.5)*8,0,L-Math.abs(i-(n-1)/2)*1.6,a,i%2?'#5aa83a':'#6cc044',L*.3)}
      if(st===3){g.fillStyle='#c9719a';g.strokeStyle='#5a1e3c';g.lineWidth=.9;for(const[dx,dy,r]of[[-8,1,3.4],[6,2,3.8]]){g.beginPath();g.ellipse(dx,dy,r+1,r*.72,.3,0,7);g.fill();g.stroke()}g.fillStyle='rgba(255,255,255,.4)';g.beginPath();g.arc(-9,0,1,0,7);g.arc(5,1,1,0,7);g.fill()}}
  }else if(c==='zucca'){
    if(st===0){leaf(g,0,0,5,0,'#9ad06a',2.4)}
    else{leaf(g,-6,0,st===1?8:11,-.9+sw,'#4f9a34',st===1?4:5.6);leaf(g,6,0,st===1?8:11,.9-sw,'#58a63a',st===1?4:5.6);leaf(g,0,-1,st===1?9:13,sw,'#62b244',st===1?4:5.6);
      if(st>=2){const r=st===3?6.4:3.4,col=st===3?'#e8892a':'#7aae3c';g.fillStyle=col;g.strokeStyle=st===3?'#7a3a08':'#2f5a14';g.lineWidth=1;g.beginPath();g.ellipse(0,-r*.55,r*1.25,r,0,0,7);g.fill();g.stroke();
        g.strokeStyle=st===3?'rgba(120,56,10,.55)':'rgba(40,80,20,.5)';g.lineWidth=.9;g.beginPath();g.moveTo(0,-r*1.5);g.lineTo(0,r*.4);g.moveTo(-r*.6,-r*1.4);g.quadraticCurveTo(-r*.9,-r*.5,-r*.5,r*.3);g.moveTo(r*.6,-r*1.4);g.quadraticCurveTo(r*.9,-r*.5,r*.5,r*.3);g.stroke();
        g.strokeStyle='#4a3a14';g.lineWidth=1.6;g.beginPath();g.moveTo(0,-r*1.5);g.lineTo(1,-r*1.9);g.stroke()}}
  }else{   // ananas
    const n=st===0?3:st===1?5:7,L=st===0?6:st===1?11:15;
    for(let i=0;i<n;i++){const a=(i/(n-1)-.5)*2.2+sw*.6;leaf(g,(i/(n-1)-.5)*3,0,L*(1-Math.abs(i-(n-1)/2)*.07),a,i%2?'#6f9a52':'#7aaa5a',2.2)}
    if(st>=2){const r=st===3?5.6:3.2,col=st===3?'#e8b830':'#a8c050';g.fillStyle=col;g.strokeStyle=st===3?'#7a5008':'#4a6a1c';g.lineWidth=1;g.beginPath();g.ellipse(0,-r*1.1,r*.85,r*1.15,0,0,7);g.fill();g.stroke();
      g.strokeStyle='rgba(120,70,8,.5)';g.lineWidth=.8;for(let i=-1;i<=1;i++){g.beginPath();g.moveTo(i*r*.5-r*.5,-r*2);g.lineTo(i*r*.5+r*.5,0);g.moveTo(i*r*.5+r*.5,-r*2);g.lineTo(i*r*.5-r*.5,0);g.stroke()}
      if(st===3){for(let i=0;i<5;i++)leaf(g,0,-r*2.1,6.4,(i-2)*.38,'#4f9a3a',1.6)}}
  }
  g.restore();
}
function bubble(g,x,y,t){const b=Math.sin(t*4)*1.6;g.save();g.translate(x,y+b);g.fillStyle='#fff7d8';g.strokeStyle='#7a5a1a';g.lineWidth=1.3;rr(g,-9,-16,18,18,5);g.fill();g.stroke();g.beginPath();g.moveTo(-3,2);g.lineTo(0,6);g.lineTo(3,2);g.closePath();g.fill();g.fillStyle='#d8412f';g.font='800 14px Nunito,Arial,sans-serif';g.textAlign='center';g.fillText('!',0,-3);g.restore()}
function drawOrto(g,e,t){
  const gd=(S&&S.gard)||{pl:[]};
  shadow(g,0,4,74,10,.22);
  g.fillStyle='#775331';g.strokeStyle='#2a1508';g.lineWidth=1.3;rr(g,-68,-62,136,66,7);g.fill();g.stroke();
  g.fillStyle='rgba(30,16,6,.22)';for(let i=0;i<8;i++){g.fillRect(-62+i*16,-58,2,58)}
  const post=(x,y,h)=>{const q=g.createLinearGradient(x-2.4,0,x+2.4,0);q.addColorStop(0,'#b0804a');q.addColorStop(1,'#6a4424');g.fillStyle=q;g.fillRect(x-2.4,y-h,4.8,h);g.strokeStyle='#2a1508';g.lineWidth=1.1;g.strokeRect(x-2.4,y-h,4.8,h)};
  const rail=(x0,x1,y)=>{g.fillStyle='#9a6a3a';g.fillRect(x0,y-1.6,x1-x0,3.2);g.strokeStyle='#2a1508';g.lineWidth=1;g.strokeRect(x0,y-1.6,x1-x0,3.2)};
  // recinto dietro
  rail(-66,66,-58);rail(-66,66,-50);for(const x of[-66,-44,-22,0,22,44,66])post(x,-46,20);
  // aiuole sopraelevate
  for(let i=0;i<4;i++){
    const bx=-60+(i%2)*65,by=-44+((i/2)|0)*27;
    g.fillStyle='#4a2f18';g.strokeStyle='#1e0e04';g.lineWidth=1.2;rr(g,bx,by,58,17,4);g.fill();g.stroke();
    g.fillStyle='#8a6038';g.fillRect(bx+2,by+1.5,54,3);
    g.fillStyle='rgba(255,255,255,.07)';g.fillRect(bx+3,by+2,52,1.4);
    const p=gd.pl&&gd.pl[i];
    if(p&&GC[p.c]){const f=Math.min(1,p.p/GC[p.c].t);for(const dx of[14,43])cropDraw(g,p.c,f,bx+dx,by+13,t+i)}
    else{g.fillStyle='rgba(0,0,0,.12)';for(const dx of[14,43]){g.beginPath();g.ellipse(bx+dx,by+10,5,1.8,0,0,7);g.fill()}}
  }
  // spaventapasseri
  {const sx=-76,sb=-8,w=Math.sin(t*1.4)*1.2;
    post(sx,sb,46);g.fillStyle='#8a5e38';g.fillRect(sx-15,sb-33,30,3.4);g.strokeStyle='#2a1508';g.lineWidth=1;g.strokeRect(sx-15,sb-33,30,3.4);
    g.fillStyle='#b05a3a';g.beginPath();g.moveTo(sx-11,sb-32);g.lineTo(sx+11,sb-32);g.lineTo(sx+7,sb-14+w);g.lineTo(sx-7,sb-14-w);g.closePath();g.fill();g.stroke();
    g.fillStyle='#e8d098';g.beginPath();g.arc(sx,sb-41,6.2,0,7);g.fill();g.stroke();g.fillStyle='#2a1508';g.beginPath();g.arc(sx-2.2,sb-42,.9,0,7);g.arc(sx+2.2,sb-42,.9,0,7);g.fill();g.strokeStyle='#2a1508';g.beginPath();g.moveTo(sx-2.4,sb-38.4);g.lineTo(sx+2.4,sb-38.4);g.stroke();
    g.fillStyle='#222836';g.beginPath();g.moveTo(sx-11,sb-44);g.quadraticCurveTo(sx-9,sb-52,sx-4,sb-51);g.quadraticCurveTo(sx,sb-55,sx+4,sb-51);g.quadraticCurveTo(sx+9,sb-52,sx+11,sb-44);g.quadraticCurveTo(sx,sb-41,sx-11,sb-44);g.fill();g.stroke();
    g.strokeStyle='#d8c070';g.lineWidth=1.5;for(const d of[-1,1]){g.beginPath();g.moveTo(sx+d*15,sb-31);g.lineTo(sx+d*19,sb-26+w*d);g.stroke()}}
  // recinto davanti, basso
  rail(-66,66,-3);for(const x of[-66,-22,22,66])post(x,3,12);
  if(gd.pl&&gd.pl.some(p=>p&&GC[p.c]&&p.p>=GC[p.c].t))bubble(g,0,-72,t);
}
function drawEssic(g,e,t){
  const d=(S&&S.dry)||{sl:[]};
  shadow(g,0,4,52,8,.24);
  const post=(x,y,h,lean)=>{g.save();g.translate(x,y);g.rotate(lean);const q=g.createLinearGradient(-3,0,3,0);q.addColorStop(0,'#b0804a');q.addColorStop(1,'#6a4424');g.fillStyle=q;g.fillRect(-3,-h,6,h);g.strokeStyle='#2a1508';g.lineWidth=1.2;g.strokeRect(-3,-h,6,h);g.restore()};
  post(-44,2,78,.05);post(44,2,78,-.05);
  g.fillStyle='#9a6a3a';g.fillRect(-50,-78,100,5);g.strokeStyle='#2a1508';g.lineWidth=1.2;g.strokeRect(-50,-78,100,5);
  g.strokeStyle='#2a1508';g.lineWidth=1.6;g.beginPath();g.moveTo(-44,-30);g.lineTo(-30,-72);g.moveTo(44,-30);g.lineTo(30,-72);g.stroke();
  for(let i=0;i<3;i++){
    const x=-28+i*28,s=d.sl&&d.sl[i];
    g.strokeStyle='#c9a85e';g.lineWidth=1.3;g.beginPath();g.moveTo(x,-73);g.lineTo(x,s?-54:-60);g.stroke();
    if(!s){g.strokeStyle='#a88848';g.beginPath();g.arc(x,-58,2.4,0,7);g.stroke();continue}
    const f=Math.min(1,s.p/s.t),sway=Math.sin(t*1.8+i*2)*(.04+(isRain()?0:.03));
    g.save();g.translate(x,-73);g.rotate(sway);g.translate(-x,73);
    const mix=(a,b)=>{const p=n=>parseInt(n.slice(1),16),A=p(a),B=p(b),c=k=>Math.round(((A>>k)&255)*(1-f)+((B>>k)&255)*f);return'rgb('+c(16)+','+c(8)+','+c(0)+')'};
    if(s.r==='pesce'){
      for(let k=0;k<2;k++){const yy=-62+k*18,sz=1-.18*f;g.save();g.translate(x,yy);g.scale(sz,sz);
        g.fillStyle=mix('#a8c4d4','#a8692f');g.strokeStyle=mix('#2a4a60','#4a2a0c');g.lineWidth=1;
        g.beginPath();g.moveTo(0,-8);g.quadraticCurveTo(7,0,0,10);g.quadraticCurveTo(-7,0,0,-8);g.fill();g.stroke();
        g.beginPath();g.moveTo(0,10);g.lineTo(-5,16);g.lineTo(5,16);g.closePath();g.fill();g.stroke();
        g.fillStyle='#10202c';g.beginPath();g.arc(0,-4,1,0,7);g.fill();g.restore()}
    }else if(s.r==='bacche'){
      for(let k=0;k<2;k++)for(const dx of[-4,0,4]){g.fillStyle=mix('#d8382e','#4a1a2a');g.strokeStyle='rgba(40,0,0,.6)';g.lineWidth=.8;g.beginPath();g.arc(x+dx,-58+k*13+(dx?2:0),3.2-f*.8,0,7);g.fill();g.stroke()}
    }else{
      for(let k=0;k<3;k++){const yy=-60+k*11;g.fillStyle=mix('#f4d44a','#b8722a');g.strokeStyle='rgba(100,60,8,.7)';g.lineWidth=1;g.beginPath();g.ellipse(x,yy,6.5-f,3.6-f*.4,0,0,7);g.fill();g.stroke();g.fillStyle='rgba(120,70,10,.4)';g.beginPath();g.arc(x,yy,1.6,0,7);g.fill()}
    }
    g.restore();
  }
  if(d.sl&&d.sl.some(s=>s&&s.p>=s.t))bubble(g,0,-88,t);
  else if(isRain()&&d.sl&&d.sl.some(s=>s&&s.p<s.t)){g.fillStyle='rgba(120,170,220,.9)';for(let i=0;i<3;i++){g.beginPath();g.moveTo(-10+i*10,-94+Math.sin(t*5+i)*2);g.quadraticCurveTo(-7+i*10,-88,-10+i*10,-86);g.quadraticCurveTo(-13+i*10,-88,-10+i*10,-94+Math.sin(t*5+i)*2);g.fill()}}
}

/* ====== GUARDAROBA: cappelli e abiti da trovare, da scegliere dal Menu ====== */
const WEAR=[
  // cappelli del protagonista
  {id:'h_band',k:'hat',n:'Bandana rossa',hint:'',own:()=>true,spec:{hat:'bandana',hatc:'#c8372c'}},
  {id:'h_tri',k:'hat',n:'Tricorno del Capitano',hint:'Trovalo nella cassa dell\'isolotto.',own:()=>!!S.flags.hat,spec:{}},
  {id:'h_paglia',k:'hat',n:'Cappello di paglia',hint:'Fai il primo raccolto nell\'orto.',own:()=>((S.gard&&S.gard.harv)||0)>=1,spec:{hat:'straw',hatc:'#e0c070'}},
  {id:'h_pesc',k:'hat',n:'Berretto da pescatore',hint:'Pesca 12 volte.',own:()=>(S.stat.fish||0)>=12,spec:{hat:'cap',hatc:'#e0a82e'}},
  {id:'h_cuoco',k:'hat',n:'Toque da cuoco',hint:'Prepara 3 ricette diverse al falò.',own:()=>Object.keys(S.rec||{}).length>=3,spec:{hat:'chef'}},
  {id:'h_cremisi',k:'hat',n:'Tricorno cremisi',hint:'Apri 6 casse.',own:()=>(S.cOpen||0)>=6,spec:{hat:'tricorn',hatc:'#8a1c24',trim:'#f0d890'}},
  {id:'h_turb',k:'hat',n:'Turbante rosso e oro',hint:'Concludi il Capitolo 2.',own:()=>!!S.flags.ch2end,spec:{hat:'turban',hatc:'#b8362c'}},
  {id:'h_elmo',k:'hat',n:'Morione spagnolo',hint:'Riporta a casa il bottino del galeone.',own:()=>{try{return localStorage.getItem('sm_gal')==='1'}catch(e){return false}},spec:{hat:'morion'}},
  {id:'h_corona',k:'hat',n:'Corona del Re dei Mari',hint:'Completa registro dei pesci, reliquie e ricettario.',own:()=>fishCount()>=FISHES.length&&relicCount()>=RELICS.length&&Object.keys(S.rec||{}).length>=RECIPES.length,spec:{hat:'crown'}},
  // abiti del protagonista
  {id:'o_cap',k:'out',n:'Giacca rossa del Capitano',hint:'',own:()=>true,spec:{}},
  {id:'o_mar',k:'out',n:'Maglia da marinaio',hint:'Sopravvivi fino al giorno 4.',own:()=>(S.day||1)>=4,spec:{stripes:1,coat:'#f1ede0',coat2:'#3e6faa',pants:'#2f3a4d',shirt:'#f1ede0'}},
  {id:'o_cont',k:'out',n:'Salopette da contadino',hint:'Raccogli 10 volte dall\'orto.',own:()=>((S.gard&&S.gard.harv)||0)>=10,spec:{coat:'#8a6a3c',coat2:'#5e4624',pants:'#4a5f8a',shirt:'#efe3c0',boots:1}},
  {id:'o_cuoco',k:'out',n:'Giacca da cuoco',hint:'Prepara 5 ricette diverse al falò.',own:()=>Object.keys(S.rec||{}).length>=5,spec:{coat:'#f6f1e4',coat2:'#c8c0a8',pants:'#3a4252',shirt:'#f6f1e4',apron:1,trim:'#c8c0a8'}},
  {id:'o_esp',k:'out',n:'Giacca da esploratore',hint:'Concludi il Capitolo 1.',own:()=>!!S.flags.ch1,spec:{coat:'#7a8f4a',coat2:'#4f6230',pants:'#6b5a3a',shirt:'#efe6c8',boots:1,trim:'#d9c070'}},
  {id:'o_gent',k:'out',n:'Marsina di velluto',hint:'Apri 8 casse.',own:()=>(S.cOpen||0)>=8,spec:{coat:'#7a1f3a',coat2:'#4a1024',pants:'#2a2230',shirt:'#f8f2e4',tails:11,trim:'#e8c860',boots:1}},
  {id:'o_cors',k:'out',n:'Giacca da corsaro nero',hint:'Concludi il Capitolo 2.',own:()=>!!S.flags.ch2end,spec:{coat:'#26262e',coat2:'#14141a',pants:'#1c1c24',shirt:'#e8e0cc',sash:'#c9372c',trim:'#e0b13a',boots:1}},
  // cappellini del pappagallo
  {id:'tricorno',k:'par',n:'Tricorno pirata',hint:'Concludi il Capitolo 1.',own:()=>!!S.flags.ch1},
  {id:'paglia',k:'par',n:'Cappello di paglia',hint:'Raccogli 5 volte dall\'orto.',own:()=>((S.gard&&S.gard.harv)||0)>=5},
  {id:'fiore',k:'par',n:'Fiore di ibisco',hint:'Cogli 15 volte bacche o frutti.',own:()=>(S.stat.forage||0)>=15},
  {id:'corona',k:'par',n:'Coroncina d\'oro',hint:'Completa il registro dei pesci.',own:()=>fishCount()>=FISHES.length}
];
const WRH={},WRO={};for(const it of WEAR){if(it.k==='hat')WRH[it.id]=it.spec;else if(it.k==='out')WRO[it.id]=it.spec}
const WRSPEC={};
function wearSel(){
  try{
    if(typeof WORLD!=='undefined'&&WORLD>=3){const j=localStorage.getItem('sm_look');return j?JSON.parse(j):null}
    return S&&S.wear?S.wear:null;
  }catch(e){return null}
}
function heroSpec(){
  const f=window.__hero==='f',base=f?CH.hero_f:CH.hero_m;
  try{
    let noHat=false;try{noHat=!!(S&&S.live&&S.flags&&!S.flags.hat)}catch(_){}
    const sel=wearSel()||{};
    let hid=sel.hat||null,oid=sel.out||null;
    if(typeof WORLD!=='undefined'&&WORLD>=3){noHat=false;if(!hid)hid=sel.def||'h_tri'}
    else if(!hid&&noHat)hid='h_band';
    if(hid==='h_tri')hid=null;
    if(!hid&&!oid)return base;
    const key=(f?'f':'m')+'|'+hid+'|'+oid;
    return WRSPEC[key]||(WRSPEC[key]=Object.assign({},base,(oid&&WRO[oid])||{},(hid&&WRH[hid])||{}));
  }catch(e){return base}
}
function lookSave(){      // il look scelto vale anche sul mare e nel galeone, dove la partita è un'altra
  try{
    const sel=S&&S.wear||{};
    localStorage.setItem('sm_look',JSON.stringify({hat:sel.hat||null,out:sel.out||null,def:S&&S.flags&&S.flags.hat?'h_tri':'h_band'}));
  }catch(e){}
}
const wOwned=it=>it.k==='par'?!!(S.phats&&S.phats[it.id]):!!(S.wown&&S.wown[it.id]);
function wardCheck(){
  if(!S||!S.live||WORLD>2)return;
  S.wown=S.wown||{};S.phats=S.phats||{};
  const got=[];
  for(const it of WEAR){
    if(wOwned(it))continue;
    let ok=false;try{ok=!!it.own()}catch(e){}
    if(it.k==='par'&&!S.flags.parrot)ok=false;
    if(!ok)continue;
    if(it.k==='par')S.phats[it.id]=1;else S.wown[it.id]=1;
    got.push(it);
  }
  if(!wardCheck.first){wardCheck.first=1;lookSave()}
  if(!got.length)return;
  const it=got[0],lab=it.k==='hat'?'Nuovo cappello':it.k==='out'?'Nuovo abito':'Cappellino per il pappagallo';
  const quiet=got.every(x=>x.id==='h_tri'||x.id==='o_cap'||x.id==='h_band');
  if(!quiet){
    const tn=x=>{try{return window.I18N&&I18N.tr?I18N.tr(x):x}catch(e){return x}};
    if(got.length===1)UI.banner(lab,it.n+'\nMettilo dal Menu › '+(it.k==='par'?'Pappagallo':'Guardaroba'));
    else UI.banner(got.length+' novità nel guardaroba',got.slice(0,3).map(x=>tn(x.n)).join(', ')+(got.length>3?'…':'')+'\n'+(got.some(x=>x.k==='par')?'Scegli dal Menu › Guardaroba e Pappagallo':'Scegli dal Menu › Guardaroba'));
    sfx('relic');
  }
  saveGame(true);
}
function wearName(k){
  const sel=(S&&S.wear)||{},id=k==='hat'?sel.hat:sel.out;
  const it=WEAR.find(x=>x.id===id);
  if(it)return it.n;return k==='hat'?'Automatico':'Giacca rossa del Capitano';
}
const _wi={};
function wearImg(it){
  const f=window.__hero==='f',key=it.id+(f?'f':'m');if(_wi[key])return _wi[key];
  const W=112,cv=document.createElement('canvas');cv.width=cv.height=W;const g=cv.getContext('2d');
  const bg=g.createRadialGradient(W*.4,W*.3,4,W/2,W/2,W*.75);bg.addColorStop(0,'#fff3c8');bg.addColorStop(1,'#d9a85a');g.fillStyle=bg;g.fillRect(0,0,W,W);
  const base=f?CH.hero_f:CH.hero_m;
  const hatSpec=it.k==='hat'?it.spec:(WRH.h_tri||{});
  const k=Object.assign({},base,it.k==='out'?it.spec:{},hatSpec);
  g.save();
  if(it.k==='hat'){const sc=W/32,hy=-45*(k.tall||1);g.translate(W/2,W*.6-hy*sc);g.scale(sc,sc)}
  else{const sc=W/62;g.translate(W/2,W*.93);g.scale(sc,sc)}
  try{drawChar(g,0,0,{k,dir:'f',noShadow:1,t:0})}catch(e){}
  g.restore();
  try{_wi[key]=cv.toDataURL()}catch(e){_wi[key]=''}return _wi[key];
}
function wardSheet(kind){     // kind: 'hat' | 'out'
  const list=WEAR.filter(x=>x.k===kind),own=list.filter(wOwned),lock=list.filter(x=>!wOwned(x));
  const sel=(S.wear||{})[kind];
  let h='<h2>'+(kind==='hat'?'Cappello':'Abito')+'</h2><p>'+(kind==='hat'?'Scegli cosa portare in testa.':'Scegli cosa indossare.')+'</p><div class="phs">';
  if(kind==='hat')h+='<button data-w="" class="'+(!sel?'sel':'')+'"><span class="no">🎩</span>Automatico</button>';
  h+=own.map(it=>'<button data-w="'+it.id+'" class="'+(sel===it.id||(!sel&&kind==='out'&&it.id==='o_cap')?'sel':'')+'"><img alt="" src="'+wearImg(it)+'">'+it.n+'</button>').join('')+'</div>';
  if(lock.length)h+='<h3>Da trovare</h3><ul class="wl">'+lock.map(it=>'<li><b>🔒 '+it.n+'</b>'+it.hint+'</li>').join('')+'</ul>';
  h+='<div class="row"><button class="btn" id="shNo">Chiudi</button></div>';
  sheetFor(h,c=>{
    c.querySelectorAll('[data-w]').forEach(b=>b.onclick=()=>{
      S.wear=S.wear||{};const id=b.dataset.w||null;S.wear[kind]=(kind==='out'&&id==='o_cap')?null:id;
      lookSave();sfx('ok');saveGame();closeSheet();
    });
  });
}
function wardCollectionHtml(){
  const hero=WEAR.filter(x=>x.k!=='par'),par=WEAR.filter(x=>x.k==='par');
  const row=it=>wOwned(it)?'<div class="qc"><h4><span>'+uEsc(it.n)+'</span><svg class="ic"><use href="#i-check"/></svg></h4></div>':'<div class="qc"><h4><span>???</span></h4><div class="bl">Indizio: '+uEsc(it.hint)+'</div></div>';
  const n=WEAR.filter(wOwned).length;
  return'<h3>Guardaroba · '+n+'/'+WEAR.length+'</h3>'+hero.map(row).join('')+par.map(row).join('');
}
