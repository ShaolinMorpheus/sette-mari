const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>{Pirati.startNew('T','m')});
for(let i=0;i<12;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(500)}
await p.evaluate(async()=>{for(let i=0;i<80&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,50))}});
await p.waitForTimeout(500);
const bb=await p.evaluate(()=>{const r=document.getElementById('mini').getBoundingClientRect();return[r.x+r.width/2,r.y+r.height/2]});
await p.mouse.click(bb[0],bb[1]);await p.waitForTimeout(500);
console.log('open',await p.evaluate(()=>!document.getElementById('mapm').hidden));
const cb=await p.evaluate(()=>{const r=document.getElementById('mapCv').getBoundingClientRect();return[r.x+r.width*.4,r.y+r.height*.5]});
await p.mouse.click(cb[0],cb[1]);await p.waitForTimeout(300);
console.log('mark',await p.evaluate(()=>JSON.stringify(Pirati.S.mapMark)));
await p.screenshot({path:'bigmap.png'});await b.close()})();
