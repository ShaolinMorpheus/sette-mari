const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({});
 await p.waitForTimeout(1200);
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);
 await p.waitForTimeout(500);
 const r=await p.evaluate(()=>[...document.getElementById('app').children].map(e=>e.tagName+'#'+e.id+'.'+(e.className||'')+(e.hidden?' [h]':'')));
 console.log(r.join('\n'));
 await b.close()})();
