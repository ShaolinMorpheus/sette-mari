const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(2500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(3000);
const r=await p.evaluate(()=>{const e=Pirati.E.find(e=>e.id==='nave');Pirati.S.c2.parts.yard=1;Pirati.S.c2.parts.mast=1;Pirati.S.c2.parts.rudder=1;Pirati.S.c2.parts.sails=1;Pirati.Ch2.look(e);return Pirati.UI.dlgOpen()});
await p.waitForTimeout(800);await p.screenshot({path:'sail.png'});console.log(r,er);await b.close()})();
