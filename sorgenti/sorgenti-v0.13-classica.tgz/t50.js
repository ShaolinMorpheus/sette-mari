const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420},locale:'it-IT'})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(500)}
await p.waitForTimeout(3000);await p.screenshot({path:'main2.png'});
console.log(await p.evaluate(()=>[document.getElementById('objT').textContent,Object.keys(localStorage).join(',')]),er);
// bCap3 path
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1500);
await p.evaluate(()=>document.getElementById('bCap3').click());await p.waitForTimeout(6000);
console.log(p.url(),await p.evaluate(()=>typeof Ch3),er);await b.close()})()
