const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
const [x0,x1,y0,y1]=process.argv.slice(2).map(Number);
const r=await p.evaluate(([x0,x1,y0,y1])=>{const P=Pirati;let o=['    '+Array.from({length:x1-x0+1},(_,i)=>(x0+i)%10).join('')];for(let y=y0;y<=y1;y++){let s=String(y).padStart(3)+' ';for(let x=x0;x<=x1;x++){const t=P.tileInfo(x,y);s+=t.sea?'~':!t.walk?(t.e>0.15?',':'.'):P.reachable(x,y)?(t.block?'#':'o'):(t.block?'X':'x')}o.push(s)}return o},[x0,x1,y0,y1]);
console.log(r.join('\n'));await b.close()})();
