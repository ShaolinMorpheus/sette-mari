/* ====== NOVITÀ v0.11.2 (D3): festa al campo ======
   Ogni cinque giorni, di sera (19–22), al falò dei Fuggiaschi: fuoco grande, musica e un pentolone comune.
   Con tre raccolti dell'orto la zuppa vale doppio. Il premio è fiducia con tutti. Solo sull'isola dei Fuggiaschi, prima della partenza. */
const FE={CROPS:['patata','zucca','ananas','fungo']};
FE.f=()=>{const c=S&&S.c2;if(!c)return null;return c.fest=c.fest||{n:0,last:0,ann:0}};
FE.pos=()=>[FIX.smoke[0]*TS,FIX.smoke[1]*TS];
FE.near=r=>{const p=FE.pos();return hyp(P.x-p[0],P.y-p[1])<r*TS};
FE.dayOk=function(){
  try{const c=S&&S.c2;
    if(WORLD!==2||!S||!S.live||!c||S.flags.ch2end)return false;
    if(!(S.day>=5&&S.day%5===0))return false;
    if(Object.keys(c.met||{}).filter(k=>c.met[k]).length<2)return false;       // conosci almeno un altro fuggiasco oltre a Ferro
    if(typeof qAct==='function'&&qAct('c11',0))return false;                      // la sera della riunione non c'è festa
    return true}catch(e){return false}};
FE.on=()=>FE.dayOk()&&S.tod>=19&&S.tod<22;
FE.music=()=>FE.on()&&FE.near(16);
FE.nextTxt=function(){
  const d=(S&&S.day)|0,f=FE.f();let n=Math.max(5,Math.ceil(d/5)*5);
  if(n===d){if((f&&f.last===d)||S.tod>=22)n+=5;else return'stasera, dalle 19'}
  return'giorno '+n};
FE.crops=()=>FE.CROPS.reduce((a,k)=>a+((S.res[k]|0)),0);
FE.take=function(n){const ks=FE.CROPS.slice();while(n>0){ks.sort((a,b)=>(S.res[b]|0)-(S.res[a]|0));const k=ks[0];if(!(S.res[k]>0))break;S.res[k]--;n--}};
/* i fuggiaschi saltellano a tempo vicino al fuoco */
FE.hop=function(e,t){if(!FE.on()||e.mv)return 0;const p=FE.pos();if(hyp(e.x-p[0],e.y-p[1])>6.5*TS)return 0;return Math.abs(Math.sin(t*6+e.ph))*6};
/* note che salgono dal fuoco */
FE.draw=function(g,t){
  if(!FE.on())return;const p=FE.pos();if(hyp(P.x-p[0],P.y-p[1])>22*TS)return;
  g.save();g.textAlign='center';g.textBaseline='middle';g.lineJoin='round';
  for(let i=0;i<7;i++){const u=(t*.32+i*.143)%1,x=p[0]+Math.sin(i*2.7+t*.9)*70*(.4+u),y=p[1]-46-u*96,ch=i%2?'♪':'♫';
    g.globalAlpha=Math.sin(u*Math.PI);g.font='900 '+(16+(i%3)*4)+'px Arial,sans-serif';g.lineWidth=3;g.strokeStyle='rgba(60,30,10,.85)';g.strokeText(ch,x,y);
    g.fillStyle=['#ffd45a','#ff9a6a','#fff1b0'][i%3];g.fillText(ch,x,y)}
  g.restore()};
/* musica: una giga allegra in Re maggiore, con tamburello e cassa (stessi strumenti della musica del gioco) */
const FE_CH=[[62,66,69],[62,66,69],[67,71,74],[69,73,76]];
const FE_MEL=[[74,0,78,74,0,71,74,0],[76,0,74,71,0,69,71,0],[79,0,74,71,0,74,79,0],[76,0,73,69,0,73,76,0]];
function festaTick(t,b){
  const st=b%8,bar=((b/8)|0)%4,ch=FE_CH[bar],v=.06;
  if(st===0)mPad(t,ch,8*.26,v*.5);
  if(st===0||st===4)mNote(t,ch[0]-24+(st===4?7:0),.22,v*1.6,'triangle');
  if(st===0||st===4)mDrum(t,'k');
  if(st===2||st===6)mDrum(t,'s');
  mDrum(t,'h');
  if(st%2===1)for(const x of ch)mNote(t,x,.13,v*.42,'sawtooth');
  const m=FE_MEL[bar][st];if(m){mNote(t,m,.22,v*1.05,'triangle');mNote(t,m+12,.12,v*.25,'sine')}
}
/* l'invito di Gnocco */
FE.offer=function(){
  const full=FE.crops()>=3;let act=null;
  const ch=[];
  if(full)ch.push({t:"Metto tre raccolti dell'orto nel pentolone.",fn:()=>{act='full'}});
  ch.push({t:full?"Solo musica e fuoco, per stasera.":"Non ho abbastanza dall'orto: solo musica e fuoco.",fn:()=>{act='half'}});
  ch.push({t:"Più tardi.",fn:()=>{act=null}});
  UI.dlg([D('gnocco',"Stasera si fa festa! Fuoco grande, musica e il pentolone pieno. Una festa ogni cinque giorni, come si deve."),
    D('gnocco',full?"Hai le verdure dell'orto? Bastano tre raccolti per una zuppa che sazia tutto il campo.":"Se avessi qualcosa dall'orto la zuppa verrebbe meglio. Bastano tre raccolti: patate, zucca, ananas o funghi.",{choices:ch})],
    ()=>{if(act)FE.celebrate(act==='full');else FE._askT=75})};
FE.celebrate=function(full){
  const f=FE.f();if(!f)return;
  if(full)FE.take(3);
  f.last=S.day;f.n=(f.n|0)+1;
  const L=full?[
    D('gnocco',"Ecco la zuppa del campo! Patate dolci, zucca e... sale. Tanto sale."),
    D('nives',"Ha il sapore di casa. Non dirlo a Ferro."),
    D('tito',"Io non ci sono. Ma ne prendo una seconda porzione."),
    D('ferro',"...Una sera è una sera. Domani si lavora."),
    D('hero',"Il fuoco, la musica, facce stanche che sorridono. Per una sera la Baia sembra un posto dove restare.")
  ]:[
    D('gnocco',"Niente zuppa? Allora brodo e musica. Il brodo è una zuppa che ha perso fiducia in sé stessa."),
    D('nives',"Il fuoco e due note. Può bastare."),
    D('tito',"Io ballo. Cioè: no. Dondolo."),
    D('ferro',"Sedetevi. Una sera non cambia la rotta."),
    D('hero',"La prossima volta porterò qualcosa dall'orto: la zuppa vale doppio.")
  ];
  UI.dlg(L,()=>{
    for(const w of['ferro','nives','tito','gnocco'])Ch2.addTrust(w,full?2:1,true);
    S.vit.h=Math.min(100,S.vit.h+(full?60:14));
    if(full){S.vit.t=Math.min(100,S.vit.t+12);S.buff=Math.max(S.buff||0,300)}
    try{addXp(full?22:8)}catch(e){}
    sfx('quest');UI.sync();
    UI.toast(full?'Festa al campo: zuppa per tutti! Fiducia +2 con tutti, e tanta energia.':'Festa al campo: fiducia +1 con tutti. Con tre raccolti dell\'orto sarebbe doppia.',5200);
    saveGame()})};
FE.tick=function(dt){
  const f=FE.f();if(!f||!FE.dayOk())return;
  if(S.tod>=18.8&&S.tod<22&&f.ann!==S.day){f.ann=S.day;UI.banner('Festa al campo','Stasera dal falò: musica, fuoco grande\ne una zuppa per tutti. Dalle 19.')}
  if(!FE.on()||f.last===S.day){FE._ask=0;return}
  if(FE._askT>0){FE._askT-=dt;if(FE._askT<=0)FE._ask=0}
  if(FE.near(5.5)){if(!FE._ask&&!UI.dlgOpen()&&!PAUSED&&P.mode!=='raft'){FE._ask=1;FE.offer()}}
  else if(!FE.near(9))FE._ask=0};
{
  const ls=()=>{try{return(S&&S.c2&&S.c2.fest&&S.c2.fest.n)||0}catch(e){return 0}};
  NV3.AC.push({id:'festa1',n:'Ospite del campo',d:'Partecipa a una festa al campo dei Fuggiaschi.',ok:()=>ls()>=1});
  NV3.AC.push({id:'festa3',n:'Anima della festa',d:'Partecipa a tre feste al campo.',ok:()=>ls()>=3});
}
