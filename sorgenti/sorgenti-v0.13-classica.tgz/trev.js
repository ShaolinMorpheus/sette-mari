const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const out=[];
 const ctx=await b.newContext({viewport:{width:915,height:412},deviceScaleFactor:1,hasTouch:true,locale:'it-IT'});
 const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error'&&!/agent-proxy|Failed to load/.test(m.text()))errs.push('console:'+m.text().slice(0,200))});
 await p.addInitScript(()=>{try{if(!sessionStorage.getItem('_t_init')){localStorage.clear();sessionStorage.setItem('_t_init','1')}}catch(e){}});
 const wait=async()=>{await p.waitForFunction(()=>window.Pirati&&window.Pirati.S,null,{timeout:90000}).catch(()=>{});await p.waitForTimeout(1200)};
 const skip=async()=>{for(let i=0;i<14;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS','tutSkip']){const e=document.getElementById(id);if(e&&!e.hidden&&e.offsetParent!==null)e.click()}try{Pirati.UI.dlgAuto&&Pirati.UI.dlgAuto()}catch(e){}});await p.waitForTimeout(100)}};
 await p.goto('http://localhost:8765/index.html');await wait();
 await p.evaluate(()=>Pirati.startNew('Rev','m'));await skip();
 await p.evaluate(()=>{const S=Pirati.S,F=Pirati.farm;S.flags.axe=1;S.flags.flint=1;S.flags.hat=1;S.flags.parrot=1;S.tutDone=1;S.tut=null;S.built={falo:1,capanna:1,banco:1};
   for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}
   for(const k of['legna','pietra','corda','rottami'])S.res[k]=30;
   F.campBuild(F.DECOR.find(x=>x.k==='orto'));F.campBuild(F.DECOR.find(x=>x.k==='essic'));F.farmInit();S.gard.harv=4;S.gard.pl=[{c:'patata',p:100},{c:'zucca',p:50},null,null];S.dry.sl=[{r:'pesce',nm:'P',p:50,t:300},null,null];
   S.res.semi=5;S.res.patata=3;S.res.pescesec=2;S.wown={h_band:1,h_paglia:1,o_cap:1,o_cont:1};S.wear={hat:'h_paglia',out:'o_cont'};S.phats={paglia:1};S.phat='paglia';
   Pirati.saveGame()});
 out.push(['nuova: salvato',JSON.stringify(await p.evaluate(()=>{const j=JSON.parse(localStorage.getItem(Pirati.saveKey()));return {camp:j.camp.map(o=>o.k),res:Object.keys(j.res).join(','),wear:j.wear}}))]);
 // passa alla stabile (vecchio codice) con lo stesso salvataggio
 await p.goto('http://localhost:8765/stabile.html');await wait();
 await p.evaluate(()=>{try{Pirati.startContinue()}catch(e){console.error('cont',e)}});await p.waitForTimeout(3000);await skip();
 out.push(['stabile: stato',JSON.stringify(await p.evaluate(()=>{const S=Pirati.S;if(!S||!S.live)return {live:false};return {live:true,name:S.name,camp:(S.camp||[]).map(o=>o.k),ents:Pirati.E.filter(e=>e.type==='cdeco').map(e=>e.k),res:{semi:S.res.semi,patata:S.res.patata}}}))]);
 // muovi il giocatore vicino all'orto e guarda cosa succede
 await p.evaluate(()=>{const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k==='orto');if(e){Pirati.tp(e.x/44,e.y/44+2)}});await p.waitForTimeout(1500);
 out.push(['stabile: vicino all\'orto',JSON.stringify(await p.evaluate(()=>{try{const t=Pirati.tinfo();return {label:t&&t.l}}catch(e){return {err:String(e)}}}))]);
 await p.screenshot({path:'aud/rev_stabile.png'});
 // salva dalla stabile e torna alla nuova: il salvataggio dev'essere ancora completo
 await p.evaluate(()=>Pirati.saveGame());
 out.push(['stabile: salvataggio riscritto',JSON.stringify(await p.evaluate(()=>{const j=JSON.parse(localStorage.getItem(Pirati.saveKey()));return {camp:j.camp.map(o=>o.k),gard:!!j.gard,dry:!!j.dry,wown:Object.keys(j.wown||{}),wear:j.wear,semi:j.res.semi,phat:j.phat}}))]);
 await p.goto('http://localhost:8765/index.html?nuova');await wait();
 await p.evaluate(()=>{try{Pirati.startContinue()}catch(e){console.error('cont2',e)}});await p.waitForTimeout(3000);await skip();
 out.push(['nuova di nuovo',JSON.stringify(await p.evaluate(()=>{const S=Pirati.S;if(!S||!S.live)return {live:false};return {live:true,gard:S.gard&&S.gard.pl.map(x=>x&&x.c),dry:S.dry&&S.dry.sl.map(x=>x&&x.r),wear:S.wear,semi:S.res.semi,ents:Pirati.E.filter(e=>e.type==='cdeco').map(e=>e.k)}}))]);
 console.log(out.map(x=>x.join(': ')).join('\n'));console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
