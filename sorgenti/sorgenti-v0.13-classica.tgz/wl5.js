const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:844,height:390}})).newPage();
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
console.log(JSON.stringify(await p.evaluate(()=>Pirati.E.filter(e=>e.fp&&e.x/44>6&&e.x/44<32&&e.y/44>38&&e.y/44<54).map(e=>[e.type,e.id,typeof e.spr==='string'?e.spr:(e.spr&&e.spr.name)||'',+(e.x/44).toFixed(1),+(e.y/44).toFixed(1),e.fp.join('x'),e.blocked?1:0]))));
await b.close()})();
