const {chromium}=require('playwright');
const W=process.argv[2]==='2';
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
if(W)await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
if(W)await p.evaluate(()=>{const P=Pirati;localStorage.setItem(P.saveKey(),JSON.stringify(P.Ch2.convert(P.newState('D','m'))));P.startContinue('',null)});
else await p.evaluate(()=>Pirati.startNew('T','m'));
await p.waitForTimeout(2000);
const r=await p.evaluate(()=>{const P=Pirati,TS=44,st=4,o={bins:{},pts:[]};
 for(let y=0;y<60*TS;y+=st)for(let x=0;x<99*TS;x+=st){const e=P.elev(x/TS,y/TS);if(e<=P.WL)continue;const tx=Math.floor(x/TS),ty=Math.floor(y/TS),ti=P.tileInfo(tx,ty);
  if(ti.walk===1&&ti.block===0&&P.boxFree(x,y,9,5))continue;
  if(P.boxFree(x,y,9,5))continue;
  if(ti.block>0)continue; // entità: ok
  const d=e-P.WL;const k=d<.02?'<.02':d<.04?'<.04':d<.06?'<.06':d<.08?'<.08':'>=.08';o.bins[k]=(o.bins[k]||0)+1;
  if(d>=.05&&o.pts.length<60)o.pts.push([+(x/TS).toFixed(1),+(y/TS).toFixed(1),+d.toFixed(3),ti.walk]);}
 return o});
console.log(JSON.stringify(r));await b.close()})();
