import re,sys
src=open('w/index.html').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt: print('PATCH FAIL',n,old[:70]); sys.exit(1)
    src=src.replace(old,new)
rep("function auMusicTick(){\n  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running')return;","function auMusicTick(){\n  if(WORLD===3){Ch3.music();return}\n  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running')return;")
rep("if(window.__W2)return 2;","if(window.__W3)return 3;if(window.__W2)return 2;")
rep("const BLOBS=WORLD===2?BLOBS_2:BLOBS_1;","""const SC3=a=>[a[0]*1.515,a[1]*1.5].concat(a.slice(2));const BLOBS_3=[[10,30,8,7],[26,12,6,4.5],[24,47,7,5],[46,40,7,5],[63,30,6,5],[60,50,6,4],[78,16,6,4.5],[80,42,8,5],].map(SC3).concat([[165,25,8,6],[188,52,10,7],[170,78,7,5],[196,104,8,6],[150,108,9,6],[118,112,8,5],[84,110,10,6],[46,106,8,5],[20,102,7,5]]);
const BLOBS=WORLD===3?BLOBS_3:WORLD===2?BLOBS_2:BLOBS_1;""")
rep("const BEACH=WORLD===2?","const BEACH_3=[[22.45,45,2.6,5],[40.4,21,2,2.4],[62.1,36,2,1.8],[96.4,49,2.5,1.6]];const BEACH=WORLD===3?BEACH_3:WORLD===2?")
rep("const POND=WORLD===2?","const POND=WORLD===3?{x:1.5,y:1.5,rx:.2,ry:.2}:WORLD===2?")
rep("const C0=WORLD===2?","const C0=WORLD===3?{x:17.15,y:45}:WORLD===2?")
rep("const PATHS=WORLD===2?","const PATHS=WORLD===3?[]:WORLD===2?")
rep("const MESA=WORLD===2?","const MESA=WORLD===3?{x:-40,y:-40,rx:1,ry:1,h:1}:WORLD===2?")
rep("const MESA_PTS=WORLD===2?[]:","const MESA_PTS=WORLD!==1?[]:")
rep("const FORESTS=WORLD===2?FORESTS_2:FORESTS_1;","const FORESTS_3=[[10,30,6,5,.9],[26,12,4.5,3,.8],[24,47,5,3.5,.9],[46,40,5,3.5,.9],[63,30,4.5,3.5,.9],[60,50,4.5,2.8,.9],[78,16,4.5,3,.8],[80,42,6,3.5,.9],[90,28,2.8,2.8,.8],[34,31,2.5,2,.7],[72,32,2.2,1.7,.7]].map(SC3).concat([[165,25,5.5,4,.8],[188,52,7,5,.9],[170,78,5,3.5,.8],[196,104,5.5,4,.8],[150,108,6,4,.9],[118,112,5.5,3.5,.8],[84,110,7,4,.9],[46,106,5.5,3.5,.8],[20,102,5,3.5,.8]]);\nconst FORESTS=WORLD===3?FORESTS_3:WORLD===2?FORESTS_2:FORESTS_1;")
rep("const FIX=WORLD===2?FIX_2:FIX_1;","""const FIX_3=Object.assign({},FIX_2,{spawn:[17.15,45],sign:[21.55,43.6],wreck:[-60,-60],plots:{falo:{tx:1,ty:1,w:1,h:1},capanna:{tx:1,ty:1,w:1,h:1},banco:{tx:1,ty:1,w:1,h:1},zattera:{tx:1,ty:1,w:1,h:1}},lookout:[-50,-50],quarry:[-60,-60],boulders:[],raftLaunch:[22,30],smoke:[-60,-60],isl1:[-60,-60],isl2:[-60,-60],bottles:[]});
const FIX=WORLD===3?FIX_3:WORLD===2?FIX_2:FIX_1;""")
rep("  if(WORLD===2)return exclTile2(tx,ty);","  if(WORLD===3)return hyp(tx+.5-21.55,ty+.5-43.6)<2.2;\n  if(WORLD===2)return exclTile2(tx,ty);")
rep("  if(WORLD===2)return genWorld2();","  if(WORLD===3)return genWorld3();\n  if(WORLD===2)return genWorld2();")
gw3=r"""function genWorld3(){
  const r=mulberry(31);
  const taken=new Set(),key=(a,b)=>a+','+b;
  let n=0;
  const order=[];for(let ty=0;ty<MH;ty++)for(let tx=0;tx<MW;tx++)order.push([tx,ty]);
  for(let i=order.length-1;i>0;i--){const j=(r()*(i+1))|0;[order[i],order[j]]=[order[j],order[i]]}
  const okT=(tx,ty)=>walkT[tIdx(tx,ty)]&&!blockT[tIdx(tx,ty)]&&!exclTile(tx,ty);
  for(const[tx,ty]of order){
    if(!okT(tx,ty))continue;
    const e0=elevT[tIdx(tx,ty)];if(e0<WL+.27)continue;
    const fF=forestF(tx+.5,ty+.5),dens=1.4*fF+.06;
    if(r()>dens)continue;
    if(taken.has(key(tx-1,ty))||taken.has(key(tx+1,ty))||taken.has(key(tx,ty-1))||taken.has(key(tx,ty+1)))continue;
    if(taken.has(key(tx-1,ty-1))&&taken.has(key(tx+1,ty+1)))continue;
    taken.add(key(tx,ty));
    const pine=tx>52?r()<.7:r()<.2;
    const e=ent({id:'t'+(n++),type:pine?'pine':'tree',v:(r()*(pine?4:6))|0,x:(tx+.5+(r()-.5)*.3)*TS,y:(ty+.92)*TS,tx,ty,alive:true,grow:1,t:0,wood:pine?2:3,flip:r()<.5});
    addBlock(e,tx,ty,1,1);
  }
  const pal=[];
  for(const[tx,ty]of order){
    const e0=elevT[tIdx(tx,ty)];
    if(!okT(tx,ty)||e0<SAND_LO||e0>SAND_HI)continue;
    if(pal.some(p=>hyp(p[0]-tx,p[1]-ty)<2.6))continue;
    if(r()>.5)continue;
    pal.push([tx,ty]);if(pal.length>=120)break;
  }
  pal.forEach((p,i)=>{const e=ent({id:'p'+i,type:'palm',v:i%3,x:(p[0]+.5)*TS,y:(p[1]+.92)*TS,tx:p[0],ty:p[1],coco:true,cd:0,flip:r()<.5});addBlock(e,p[0],p[1],1,1)});
  {const rk=[];
   for(const[tx,ty]of order){
     if(rk.length>=30)break;
     if(!okT(tx,ty))continue;
     const e0=elevT[tIdx(tx,ty)];if(e0<WL+.3)continue;
     if(rk.some(p=>hyp(p[0]-tx,p[1]-ty)<4))continue;
     rk.push([tx,ty]);
   }
   rk.forEach((p,i)=>{const e=ent({id:'rx'+i,type:'rock',v:(i*3)%5,x:(p[0]+.5)*TS,y:(p[1]+.92)*TS,tx:p[0],ty:p[1],alive:true,hp:0,t:0});addBlock(e,p[0],p[1],1,1)});}
  const deco=(id,spr,x,y,fp,o)=>{const e=ent(Object.assign({id,type:'deco',spr,x:x*TS,y:y*TS},o||{}));if(fp)addBlock(e,fp[0],fp[1],fp[2],fp[3]);return e};
  deco('feedback','sign',FIX.sign[0],FIX.sign[1],[Math.floor(FIX.sign[0]),Math.floor(FIX.sign[1]),1,1],{k:.9,hitw:64,hith:84,label:'Porto di Calvara',inter:'none'});
  for(const id in FIX.plots){const f=FIX.plots[id];
    const e=ent({id:'plot_'+id,type:'plot',pid:id,x:(f.tx+f.w/2)*TS,y:(f.ty+f.h)*TS-2,tx:f.tx,ty:f.ty,tw:f.w,th:f.h,st:0,prog:0});
    addBlock(e,f.tx,f.ty,f.w,f.h);delBlock(e);
  }
  ent({id:'wparrot',type:'wparrot',x:-999,y:-999,alt:90,got:false});
  ent({id:'mraft',type:'mraft',x:-999,y:-999,hd:0});
  FIX.crabN=0;
  fixOccluded((tx,ty)=>{for(let j=-2;j<=2;j++)for(let i=-2;i<=2;i++){const a=tx+i,b=ty+j;if(inMap(a,b)&&elevT[tIdx(a,b)]<WL)return true}return false});
}
"""
rep("const TS=44, MW=99, MH=60,","const TS=44, MW=WORLD===3?210:99, MH=WORLD===3?126:60,")
rep("seaT[ty*MW+tx]=(e<WL-.035&&","seaT[ty*MW+tx]=(e<(WORLD===3?WL+.03:WL-.035)&&")
rep("function genWorld2(){",gw3+"function genWorld2(){")
old="if(!dl.open){if(!P.cl)updatePlayer(dt);updateTime(dt);updateVitals(dt);updateWeather(dt);updateChallenge(dt);Story.tick(dt)}"
rep(old,"if(!dl.open){if(WORLD===3){Ch3.step(dt)}else{if(!P.cl)updatePlayer(dt);updateTime(dt);updateVitals(dt);updateWeather(dt);updateChallenge(dt);Story.tick(dt)}}")
rep("  if(P.mode==='raft')drawRaftHull(g,t);","  if(P.mode==='raft'&&WORLD!==3)drawRaftHull(g,t);")
rep("  list.push(P);if(S.flags.parrot)list.push(PAR);if(P.mode==='raft')list.push(RAFTSAIL);","  if(WORLD===3){for(const q of Ch3.vis())list.push(q)}else{list.push(P);if(S.flags.parrot)list.push(PAR);if(P.mode==='raft')list.push(RAFTSAIL)}")
rep("const key=o=>o===P?P.y:","const key=o=>o.type==='c3'?o.s.y:o===P?P.y:")
rep("    if(e===P){drawPlayer(g,t);continue}","    if(e.type==='c3'){Ch3.drawShip(g,e,t);continue}\n    if(e===P){drawPlayer(g,t);continue}")
rep("  drawWParrot(g,EID.wparrot,t);\n","  drawWParrot(g,EID.wparrot,t);\n  if(WORLD===3)Ch3.drawFx(g,t);\n")
rep("  initInput();initStart();syncPause();\n","  initInput();initStart();syncPause();\n  if(WORLD===3)Ch3.boot();\n")
rep("function saveGame(quiet){\n  if(!S||!S.live)return;","function saveGame(quiet){\n  if(WORLD===3||!S||!S.live)return;")

rep("if(window.__W2)return 2;","if(window.__W4)return 4;if(window.__W2)return 2;")
rep("MW=WORLD===3?210:99, MH=WORLD===3?126:60,","MW=WORLD===4?72:WORLD===3?210:99, MH=WORLD===4?46:WORLD===3?126:60,")
rep("const BLOBS=WORLD===3?","const BLOBS=WORLD===4?[]:WORLD===3?")
rep("const BEACH=WORLD===3?","const BEACH=WORLD===4?[]:WORLD===3?")
rep("const POND=WORLD===3?","const POND=WORLD===4?{x:1.5,y:1.5,rx:.2,ry:.2}:WORLD===3?")
rep("const C0=WORLD===3?","const C0=WORLD===4?{x:30,y:23}:WORLD===3?")
rep("const PATHS=WORLD===3?","const PATHS=WORLD===4?[]:WORLD===3?")
rep("const MESA=WORLD===3?","const MESA=WORLD===4?{x:-40,y:-40,rx:1,ry:1,h:1}:WORLD===3?")
rep("const FIX=WORLD===3?FIX_3:WORLD===2?FIX_2:FIX_1;","""const FIX_4=Object.assign({},FIX_2,{spawn:[30,23],sign:[-60,-60],wreck:[-60,-60],plots:{falo:{tx:1,ty:1,w:1,h:1},capanna:{tx:1,ty:1,w:1,h:1},banco:{tx:1,ty:1,w:1,h:1},zattera:{tx:1,ty:1,w:1,h:1}},lookout:[-50,-50],quarry:[-60,-60],boulders:[],raftLaunch:[22,30],smoke:[-60,-60],isl1:[-60,-60],isl2:[-60,-60],bottles:[]});
const FIX=WORLD===4?FIX_4:WORLD===3?FIX_3:WORLD===2?FIX_2:FIX_1;""")
rep("  if(WORLD===2)return exclTile2(tx,ty);","  if(WORLD===4)return false;\n  if(WORLD===2)return exclTile2(tx,ty);")
rep("  if(WORLD===2)return genWorld2();","  if(WORLD===4)return genWorld4();\n  if(WORLD===2)return genWorld2();")
gw4=r"""function genWorld4(){
  for(const id in FIX.plots){const f=FIX.plots[id];
    const e=ent({id:'plot_'+id,type:'plot',pid:id,x:(f.tx+f.w/2)*TS,y:(f.ty+f.h)*TS-2,tx:f.tx,ty:f.ty,tw:f.w,th:f.h,st:0,prog:0});
    addBlock(e,f.tx,f.ty,f.w,f.h);delBlock(e);
  }
  ent({id:'wparrot',type:'wparrot',x:-999,y:-999,alt:90,got:false});
  ent({id:'mraft',type:'mraft',x:-999,y:-999,hd:0});
  FIX.crabN=0;
}
"""
rep("function genWorld2(){",gw4+"function genWorld2(){")
rep("if(WORLD===3){Ch3.step(dt)}else{","if(WORLD===4){Ch4.step(dt)}else if(WORLD===3){Ch3.step(dt)}else{")
rep("  computeTarget();\n  drawTargetRing(g,t);\n","  computeTarget();\n  drawTargetRing(g,t);\n  if(WORLD===4)Ch4.drawFloor(g,t);\n")
rep("      case'npc':drawNpc(g,e,t);break;","      case'npc':drawNpc(g,e,t);break;\n      case'c4':Ch4.drawEnt(g,e,t);break;")
rep("  drawWParrot(g,EID.wparrot,t);\n","  drawWParrot(g,EID.wparrot,t);\n  if(WORLD===4)Ch4.drawTop(g,t);\n")
rep("  initInput();initStart();syncPause();\n","  initInput();initStart();syncPause();\n  if(WORLD===4)Ch4.boot();\n")
rep("if(WORLD===3||!S||!S.live)return;","if(WORLD===4||WORLD===3||!S||!S.live)return;")
rep("  if(!S||!S.live)return'day';\n","  if(!S||!S.live)return'day';\n  if(WORLD===4)return'night';\n")

rep("  sea:{beat:.6,den:.7,","  assault:{assault:1,beat:.21,den:0,vol:.07,prog:[[57,60,64]],ext:[69],low:0},\n  sea:{beat:.6,den:.7,")
rep("  if(WORLD===4)return'night';\n","  if(WORLD===4)return'assault';\n")
rep("    const m=MUS[musicMood()],t=AU.nextT,b=AU.beat,ch=m.prog[((b/4)|0)%m.prog.length];","    const m=MUS[musicMood()],t=AU.nextT,b=AU.beat,ch=m.prog[((b/4)|0)%m.prog.length];\n    if(m.assault){assaultTick(t,b);AU.nextT+=m.beat;AU.beat++;continue}")
rep("function auMusicTick(){","""function mDrum(t,kind){
  const c=AU.ctx;
  if(kind==='k'){const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.setValueAtTime(130,t);o.frequency.exponentialRampToValueAtTime(42,t+.16);g.gain.setValueAtTime(.34,t);g.gain.exponentialRampToValueAtTime(.001,t+.22);o.connect(g);g.connect(AU.mbus);o.start(t);o.stop(t+.25);return}
  if(!AU._nb){const n=c.sampleRate*.3,b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;AU._nb=b}
  const s=c.createBufferSource();s.buffer=AU._nb;const f=c.createBiquadFilter(),g=c.createGain();
  if(kind==='s'){f.type='bandpass';f.frequency.value=1800;f.Q.value=.7;g.gain.setValueAtTime(.30,t);g.gain.exponentialRampToValueAtTime(.001,t+.16)}
  else{f.type='highpass';f.frequency.value=6500;g.gain.setValueAtTime(.07,t);g.gain.exponentialRampToValueAtTime(.001,t+.05)}
  s.connect(f);f.connect(g);g.connect(AU.mbus);s.start(t);s.stop(t+.2)}
const AS_CH={Am:[57,60,64],F:[53,57,60],G:[55,59,62],C:[48,52,55],E:[52,56,59]};
const AS_SEQ=['Am','Am','F','G','Am','Am','F','E','C','G','Am','Am','F','G','E','E'];
const AS_MEL=[[76,0,76,77,76,72,69,0],[72,0,74,72,69,0,0,0],[77,0,77,79,77,74,72,0],[74,0,76,74,71,0,67,0],[76,0,76,77,79,77,76,72],[81,0,79,76,72,0,76,0],[77,76,74,72,74,72,69,0],[71,0,74,76,80,0,0,0],
 [79,0,79,76,72,0,76,0],[74,0,74,71,67,0,71,0],[72,0,76,0,81,0,79,76],[76,0,72,0,69,0,0,0],[77,0,81,0,84,0,81,77],[79,0,83,0,86,0,83,79],[76,0,80,0,83,0,80,76],[81,0,0,0,0,0,0,0]];
function assaultTick(t,b){
  const st=b%8,bar=((b/8)|0)%16,ch=AS_CH[AS_SEQ[bar]],v=.075,sect=bar>=8;
  if(st===0)mPad(t,ch,8*.21*1.05,v*.5);
  const root=ch[0]-12;
  if(st===0||st===4)mNote(t,root,.34,v*1.5,'triangle');
  if(st===2||st===6)mNote(t,root+7,.2,v*.9,'triangle');
  if(st===0||st===4||(sect&&st===3))mDrum(t,'k');
  if(st===2||st===6)mDrum(t,'s');
  if(sect||st%2===0)mDrum(t,'h');
  if(st%2===1)mNote(t,ch[(st>>1)%3]+12,.16,v*.45,'sine');
  const m=AS_MEL[bar][st];
  if(m){let len=1;while(st+len<8&&!AS_MEL[bar][st+len])len++;const d=len*.21*.95;
    mNote(t,m,Math.min(d,.7),v*1.25,'triangle');mNote(t,m+12,Math.min(d,.5),v*.3,'square')}
}
function auMusicTick(){""")
rep("cv.addEventListener('wheel',e=>{e.preventDefault();cam.uz=","cv.addEventListener('wheel',e=>{e.preventDefault();if(WORLD===4)return;cam.uz=")
rep("  if(k==='+'||k==='='){cam.uz=","  if(WORLD!==4&&(k==='+'||k==='=')){cam.uz=")
rep("  if(k==='-'||k==='_'){cam.uz=","  if(WORLD!==4&&(k==='-'||k==='_')){cam.uz=")

inj3=open('ch3_inject.js').read();inj4=open('ch4_inject.js').read()
src=src.replace("<head>","<head><script>(function(){if(location.hash==='#w4')window.__W4=1;else window.__W3=1})();</script>",1)
tail="\n})();\n</script>"
k=src.rindex(tail)
src=src[:k]+"\n"+inj3+"\n"+inj4+tail+src[k+len(tail):]
open('/home/claude/out/capitolo3_isola.html','w').write(src)
print('ok',len(src))
