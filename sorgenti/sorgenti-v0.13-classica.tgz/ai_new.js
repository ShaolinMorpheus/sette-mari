const AD=(a,b)=>{let d=a-b;while(d>Math.PI)d-=Math.PI*2;while(d<-Math.PI)d+=Math.PI*2;return d};
function faceG(g,ang){g.face=ang;const c=Math.cos(ang);if(Math.abs(c)>.12)g.flip=c<0;g.dir=Math.sin(ang)<-.72?'b':'f'}
/* cammina verso un punto (con percorso se serve); true se arrivato */
function goTo(g,tx,ty,sp,dt){
  const dx=tx-g.x,dy=ty-g.y,d=Math.hypot(dx,dy);
  if(d<14){g.mv=false;return true}
  let hx=tx,hy=ty;
  if(d>60&&!los(g.x,g.y-6,tx,ty-6)){
    const key=((tx/T)|0)+','+((ty/T)|0);
    if(g.pfKey!==key||!(g.pfT>0)){g.pf=bfsFrom(tx,ty);g.pfKey=key;g.pfT=1.2}
    const n=nextStepF(g,g.pf);if(n){hx=n[0];hy=n[1]}}
  const ex=hx-g.x,ey=hy-g.y,ed=Math.hypot(ex,ey)||1,m=Math.min(sp*dt,ed);
  g.mv=moveEnt(g,ex/ed*m,ey/ed*m);g.wk+=dt*sp*.06;faceG(g,Math.atan2(ey,ex));return false}
/* un rumore attira le guardie vicine: vanno a vedere */
function noiseAt(x,y,r,except){
  for(const g of K.gd){if(g===except||g.ko>0||g.st==='chase'||g.fight)continue;
    if(Math.hypot(g.x-x,g.y-y)<r){g.st='suspect';g.sx=x;g.sy=y;g.sw=0;g.alert=0;g.mv=false}}}
function stepGuard(g,dt){
  g.hitCd=Math.max(0,g.hitCd-dt);g.pfT=(g.pfT||0)-dt;
  g.flash=Math.max(0,g.flash-dt);g.swing=Math.max(0,g.swing-dt);
  if(g.face==null)g.face=g.flip?Math.PI:0;
  if(g.ko>0){g.ko-=dt;g.mv=false;return}
  const d=Math.hypot(P.x-g.x,P.y-g.y);
  /* vista: cono davanti (circa 120°) oppure molto vicino */
  const ang=Math.atan2(P.y-g.y,P.x-g.x),cone=d<88||Math.abs(AD(g.face,ang))<1.05;
  const vis=!K.over&&d<290&&cone&&los(g.x,g.y-6,P.x,P.y-6);
  {let f=g.fight;
   if(f&&(f.hp<=0||f.dk!==undefined))f=g.fight=null;
   if(!f&&g.st!=='chase'){for(const a of allies()){if(a.hp<=0)continue;const da=Math.hypot(a.x-g.x,a.y-g.y);if(da<200&&los(g.x,g.y-6,a.x,a.y-6)){f=g.fight=a;g.fightT=Math.max(g.fightT,.5);break}}}
   if(f&&!(g.st==='chase'&&d<110)){
     const dx=f.x-g.x,dy=f.y-g.y,dd=Math.hypot(dx,dy)||1;faceG(g,Math.atan2(dy,dx));
     if(dd>240){g.fight=null}
     else if(dd>46){g.mv=moveEnt(g,dx/dd*100*dt,dy/dd*100*dt);g.wk+=dt*6;if(!g.mv&&dd>150)g.fight=null;return}
     else{g.mv=false;g.fightT-=dt;
       if(g.fightT<=0){g.fightT=1.5;g.swing=.32;f.hp--;f.flash=.3;sfx('thud');K.fx.push({k:'spark',x:(g.x+f.x)/2,y:g.y-34,t:0,life:.3});
         if(f.hp<=0){f.downT=0;g.fight=null;toast(CH[f.who].name+' è a terra! Vai ad aiutarlo.',4200);if(!K.notes.dwn){K.notes.dwn=1;say('Biscotto','Un pirata ferito! Avvicinati e premi «Aiuta».',5200)}}}
       return}}}
  /* ti ha visto */
  if(vis){
    if(g.st!=='chase'){
      g.st='chase';g.react=.42;g.mv=false;faceG(g,ang);
      if(!K.notes.sight){K.notes.sight=1;say('Biscotto','Guardia! Ti ha visto!',3600)}
      noiseAt(P.x,P.y,420,g);sfx('thud')}
    g.alert=3.2;g.ls=[P.x,P.y]}
  else if(g.st==='chase'){g.alert-=dt;if(g.alert<=0){g.st='search';g.sx=g.ls?g.ls[0]:g.x;g.sy=g.ls?g.ls[1]:g.y;g.sw=0}}
  if(g.react>0){g.react-=dt;g.mv=false;if(g.st==='chase')faceG(g,ang);return}
  if(g.st==='chase'){
    const sp=112,n=d<70&&vis?[P.x,P.y]:nextStep(g);
    if(n){const dx=n[0]-g.x,dy=n[1]-g.y,dd=Math.hypot(dx,dy)||1,m=Math.min(sp*dt,dd);g.mv=moveEnt(g,dx/dd*m,dy/dd*m);g.wk+=dt*sp*.06;faceG(g,Math.atan2(dy,dx))}else g.mv=false;
    if(d<34&&g.hitCd<=0){g.hitCd=1.2;g.swing=.32;hurtP(g)}
    return}
  if(g.st==='search'||g.st==='suspect'){
    const arrived=goTo(g,g.sx,g.sy,g.st==='search'?98:84,dt);
    if(arrived){g.sw+=dt;g.mv=false;
      const base=g.look==null?(g.look=g.face):g.look;faceG(g,base+Math.sin(g.sw*2.2)*1.25);
      if(g.sw>(g.st==='search'?3.4:2.4)){g.st='patrol';g.look=null;g.wait=.3}}
    return}
  /* ronda */
  const w=g.wp[g.wi],gx=cx(w[0]),gy=(OY+w[1]+.92)*T;
  if(g.wait>0){g.wait-=dt;g.mv=false;return}
  if(goTo(g,gx,gy,60,dt)){g.wi=(g.wi+1)%g.wp.length;g.wait=.7;const n=g.wp[g.wi];faceG(g,Math.atan2((OY+n[1]+.92)*T-g.y,cx(n[0])-g.x))}
}
/* compagni: combattono le guardie vicine, ma restano nei dintorni del capitano */
function stepAllies(dt){
  for(const g of K.gd)if(g.fldT>0)g.fldT-=dt;
  for(const f of allies()){
    f.hitCd=Math.max(0,f.hitCd-dt);f.swing=Math.max(0,f.swing-dt);f.flash=Math.max(0,f.flash-dt);f.busy=false;
    if(f.hp<=0){f.mv=false;f.busy=true;f.downT+=dt;if(f.downT>70){f.hp=1;f.downT=0}continue}
    const dPl=Math.hypot(f.x-P.x,f.y-P.y),post=f.dk!==undefined;
    let best=null,bd=1e9;
    for(const g of K.gd){if(g.ko>0)continue;const d=Math.hypot(g.x-f.x,g.y-f.y),dgp=Math.hypot(g.x-P.x,g.y-P.y);
      const near=post?d<300:((d<260&&dPl<520)||(g.st==='chase'&&d<480&&dPl<620)||(dgp<300&&d<520));
      if(near&&d<bd){bd=d;best=g}}
    f.tgt=best;
    if(!best)continue;
    f.busy=true;const g=best,dx=g.x-f.x,dy=g.y-f.y,d=bd;faceG(f,Math.atan2(dy,dx));
    if(d>44){
      let tx=g.x,ty=g.y;
      if(!(d<220&&los(f.x,f.y-6,g.x,g.y-6))){if(!g.fld||!(g.fldT>0)){g.fld=bfsFrom(g.x,g.y);g.fldT=.5}const n=nextStepF(f,g.fld);if(n){tx=n[0];ty=n[1]}}
      const ex=tx-f.x,ey=ty-f.y,ed=Math.hypot(ex,ey)||1;
      f.mv=moveEnt(f,ex/ed*150*dt,ey/ed*150*dt);f.wk+=dt*8;if(Math.abs(ex)>3)f.flip=ex<0;
    }else f.mv=false;
    if(d<=50&&f.hitCd<=0){f.hitCd=1.5;f.swing=.32;g.fight=f;g.fightT=Math.max(g.fightT,.6);
      hitGuard(g,1,dx/d,dy/d);if(g.ko>0)say(CH[f.who].name,pick(['Sistemato!','Uno in meno!','Dormi bene, casacca rossa.']),2600)}
  }}
