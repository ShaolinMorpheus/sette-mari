import json,re,sys
src=open('w/index.pre_v83.html',encoding='utf8').read()
pack=open('/home/claude/i18n/pack.json',encoding='utf8').read()
eng=open('/home/claude/i18n/engine.js',encoding='utf8').read().replace('__PACK__',pack)
def rep(a,b,cnt=1):
    global src
    assert src.count(a)>=1,('missing',a[:60])
    src=src.replace(a,b,cnt)
# 1 engine before main game script (second <script> in body = the one starting with (function(){ 'use strict')
k=src.index("<script>\n(function(){\n/* ---- 01_core.js")
ads=open('/home/claude/i18n/ads.js',encoding='utf8').read()
src=src[:k]+'<script src="ads-config.js"></script>\n'+eng+ads+src[k:]
# 2 toast + dialog
rep("UI.toast=function(txt,ms,img){\n  txt=pn(txt);","UI.toast=function(txt,ms,img){\n  txt=I18N.tr(pn(txt));")
rep("dl.txt=fmt(L.t);","dl.txt=fmt(I18N.tr(L.t));")
# 3 start screen language chips
rep('<span>·</span><button id="bNews" class="lnk">Novità</button>','<span>·</span><button id="bNews" class="lnk">Novità</button><span>·</span><button id="bLang" class="lnk">Lingua</button>')
rep("$('bHow').onclick=UI.showHow;","$('bLang').onclick=()=>sheetFor('<h2>Lingua</h2><div style=\"display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px\">'+I18N.langs.map(l=>'<button class=\"btn'+(l===I18N.lang?' gold':'')+'\" data-lg=\"'+l+'\">'+I18N.names[l]+'</button>').join('')+'<button class=\"btn\" id=\"shNo\">Chiudi</button></div>',cc=>{cc.querySelectorAll('[data-lg]').forEach(b=>b.onclick=()=>{I18N.set(b.dataset.lg);closeSheet()})});\n  $('bHow').onclick=UI.showHow;")
rep("const tabs=[['au','🔊','Audio e schermo'],['pa','💾','Partita'],hasP?['pp','🦜','Pappagallo']:null,['ai','❓','Aiuto']]","const tabs=[['au','🔊','Audio e schermo'],['pa','💾','Partita'],hasP?['pp','🦜','Pappagallo']:null,['lg','🌐','Lingua'],['ai','❓','Aiuto']]")
rep("+pnl('ai',","+pnl('lg',I18N.langs.map(l=>T('mLg_'+l,l.toUpperCase(),I18N.names[l],null,l===I18N.lang?'sel':'')).join(''))+pnl('ai',")
# 4 menu entry
rep("+T('mHand','🕹','Joystick',S.hand==='left'?'a sinistra':'a destra'))","+T('mHand','🕹','Joystick',S.hand==='left'?'a sinistra':'a destra'))")
rep("  c.querySelector('#mHow').onclick=()=>UI.showHow();","  c.querySelectorAll('[id^=mLg_]').forEach(b=>b.onclick=()=>{I18N.set(b.id.slice(4));UI.openMenu()});\n  c.querySelector('#mHow').onclick=()=>UI.showHow();")
exec(open('ads_patch.py',encoding='utf8').read())
rep(".mhd2{font:800 11px",".mpn{overflow:hidden}.mp:not([hidden]){display:grid;grid-template-columns:1fr 1fr;gap:6px 8px;align-content:start}.mp .mr{margin:0;min-height:40px;padding:5px 8px}.mp .mr .ml{font-size:13px;line-height:1.15}.mr.sel{background:#ffd964;box-shadow:inset 0 0 0 2px var(--wood-d)}.mp .sm,.mp .mhd2{grid-column:1/-1;margin:2px 0}.mpn{padding:8px 10px}\n.mhd2{font:800 11px")
# 5 changelog
rep('const CHANGELOG=[\n','const CHANGELOG=[\n  {v:"0.7",d:"3 nov 2026",t:"Più lingue e nuova icona",n:[\n    "Il gioco parla anche inglese, tedesco, spagnolo e francese: scegli la lingua nella schermata iniziale o dal menu (Audio e schermo → Lingua). Menu, comandi, tutorial, messaggi e istruzioni sono già tradotti; i dialoghi della storia arrivano nei prossimi aggiornamenti.",\n    "Nuova icona dell\'app: il pappagallo pirata."]},\n')
open('w2.html','w',encoding='utf8').write(src)
print(len(src))
# validate keys
miss=[]
for r in json.loads(pack):
    k=r[0]
    if '{}' in k: continue
    if k not in src and k.replace("'","\\'") not in src: miss.append(k)
print('keys not found in source:',len(miss))
for m in miss[:80]: print(' -',m[:90])
