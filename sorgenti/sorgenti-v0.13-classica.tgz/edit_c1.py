import sys
p='ch4_inject.js'
s=open(p,encoding='utf8').read()
def rep(old,new,cnt=1):
    global s
    n=s.count(old)
    if n!=cnt:
        print('MISMATCH',n,'!=',cnt,'::',old[:90]);sys.exit(1)
    s=s.replace(old,new)

# R1 - CSS: nuvolette piu' piccole e trasparenti + scheda stelle
rep("#c4say{position:absolute;left:10px;top:50px;max-width:min(300px,34%);display:none;background:#fff6dc;color:#3a200c;border:3px solid #3a200c;border-radius:16px 16px 16px 4px;padding:7px 10px;font:800 13px/1.3 var(--f-b,Nunito,sans-serif);box-shadow:0 3px 0 rgba(0,0,0,.35)}",
"#c4say{position:absolute;left:10px;top:50px;max-width:min(236px,27%);display:none;background:rgba(255,246,220,.76);color:#3a200c;border:2px solid rgba(58,32,12,.7);border-radius:12px 12px 12px 3px;padding:4px 8px;font:800 12px/1.25 var(--f-b,Nunito,sans-serif);box-shadow:0 2px 0 rgba(0,0,0,.2);pointer-events:none}")
rep("body.w4 #trow{left:auto!important;right:12px;top:8px}\n`;",
"""body.w4 #trow{left:auto!important;right:12px;top:8px}
.c4st{font-size:44px;line-height:1.05;letter-spacing:8px;margin:2px 0 2px}
.c4st i{font-style:normal;color:#cdbf9c;display:inline-block;transform:scale(.72);opacity:.55;transition:transform .42s cubic-bezier(.3,1.9,.5,1),opacity .3s,color .3s}
.c4st i.on{color:#f2b30f;transform:scale(1);opacity:1;text-shadow:0 3px 0 #8a5a08}
.c4ls{list-style:none;margin:4px 0 8px;padding:0;text-align:left;display:inline-block;font:800 14px/1.4 var(--f-b,Nunito,sans-serif)}
.c4ls li{padding:1px 0 1px 24px;position:relative;color:#7a6a4a}
.c4ls li:before{content:'☆';position:absolute;left:0;top:1px;color:#a8987a}
.c4ls li.ok{color:#3a200c}
.c4ls li.ok:before{content:'★';color:#e6a200}
.c4md{display:inline-block;margin:2px 0 4px;padding:2px 14px;border-radius:14px;border:2px solid #3a200c;font:900 14px var(--f-b,Nunito,sans-serif);color:#3a200c}
.c4md.g{background:linear-gradient(#ffe27a,#e6a914)}.c4md.s{background:linear-gradient(#f4f6fa,#b8c0cc)}.c4md.b{background:linear-gradient(#e8b27a,#b8743a)}.c4md.n{background:#e8dcc0}
.c4nw{margin:2px 0 6px;font:800 13px var(--f-b,Nunito,sans-serif);color:#2a6a3a}
`;""")

# R2 - NOBLOCK
rep("const NOBLOCK=['chair','coil','bench'];","const NOBLOCK=['chair','coil','bench','rum'];")
# R3/R4 - nuovi oggetti di scena (in coda: gli indici dell'editor restano stabili)
rep("['barrel',45,13,1,1],['coil',43,10,1,1]],","['barrel',45,13,1,1],['coil',43,10,1,1],['chest',14,13,1,1,{plain:1}]],")
rep("['bunk',45,10,2,1,{c:'#7a6a4e'}]],","['bunk',45,10,2,1,{c:'#7a6a4e'}],['rum',15,2,1,1]],")

# R5 - posti possibili per la chiave della cella
rep("const STAIRS=[{d:[37,10.5]},{u:[37,10.5],d:[37,3.5]},{u:[37,3.5]}];",
"""const STAIRS=[{d:[37,10.5]},{u:[37,10.5],d:[37,3.5]},{u:[37,3.5]}];
/* dove sta la chiave della cella: cambia a ogni partita (3 posti sul ponte di comando) */
const KEYSP=[
 {gx:3,gy:13,lab:'Cassapanca',goal:'La chiave della cella: cerca a poppa, nella cabina del comandante.',diary:'«La chiave della cella sta nella cassapanca, sotto il letto del comandante.»',start:'Prima la cella: la chiave sta nella cassapanca del comandante, nella cabina a poppa.',enter:'Una cassapanca in fondo, a sinistra! Quella con la serratura lucida.'},
 {gx:21,gy:2,lab:'Baule degli ufficiali',goal:'La chiave della cella: cerca negli alloggi degli ufficiali, a nord del corridoio.',diary:'«Stavolta la chiave della cella è nel baule fra le cuccette degli ufficiali. Nessuno la cercherà lì.»',start:'Prima la cella: stavolta la chiave è nel baule degli alloggi degli ufficiali, a nord del corridoio.',enter:'Il baule fra le cuccette luccica: la chiave deve essere lì dentro!'},
 {gx:14,gy:13,lab:'Baule dell\\'armeria',goal:'La chiave della cella: cerca nel baule dell\\'armeria, a sud del corridoio.',diary:'«La chiave della cella? In armeria, nel baule vicino alle armature.»',start:'Prima la cella: la chiave è nel baule dell\\'armeria, a sud del corridoio.',enter:'Il baule vicino alle armature luccica: ecco dov\\'è la chiave!'}];""")

# R6 - disegno: bagliore sul baule giusto + bottiglia di rum
rep("  if(k==='mast')return drawMast(g,e,t,x0,y0,gw,gd);\n  g.save();",
"  if(k==='mast')return drawMast(g,e,t,x0,y0,gw,gd);\n  if(k==='rum'&&(K.rum||K.rumTaken))return;\n  g.save();")
rep("  if(k==='chest'&&o==='k1'&&!K.key1){","  if(k==='chest'&&K.deck===0&&!K.key1&&K.keyAt!=null&&e.gx===KEYSP[K.keyAt].gx&&e.gy===KEYSP[K.keyAt].gy){")
rep("  if(k==='chest'&&o==='med'&&!K.medUsed){",
"  if(k==='rum'){const a=.5+.5*Math.sin(t*5);g.fillStyle='rgba(255,246,200,'+a+')';g.beginPath();g.arc(x0+gw/2+10,y0-9,3+a*2,0,7);g.fill()}\n  if(k==='chest'&&o==='med'&&!K.medUsed){")
# R7 - sprite della bottiglia
rep("PK.bed=(g,gw,gd)=>{",
"""PK.rum=(g,gw,gd)=>{
  const x=gw/2,y=16;
  ell(g,x,y+1,7,3,'rgba(0,0,0,.28)');
  const q=g.createLinearGradient(x-6,0,x+6,0);q.addColorStop(0,'#1f5a38');q.addColorStop(.45,'#3f9a62');q.addColorStop(1,'#16402a');
  g.fillStyle=q;rrect(g,x-6,y-15,12,16,4);g.fill();g.strokeStyle='#0c2a1a';g.lineWidth=1.2;g.stroke();
  g.fillStyle=q;g.fillRect(x-2.4,y-26,4.8,12);g.strokeRect(x-2.4,y-26,4.8,12);
  g.fillStyle='#c8a060';g.fillRect(x-2.8,y-29,5.6,4);g.strokeStyle='#5a3a14';g.lineWidth=1;g.strokeRect(x-2.8,y-29,5.6,4);
  g.fillStyle='#f4e6c0';g.fillRect(x-5,y-11,10,7);g.strokeStyle='#7a5a2a';g.lineWidth=.8;g.strokeRect(x-5,y-11,10,7);
  g.fillStyle='#b8402e';g.fillRect(x-3,y-9,6,1.6);g.fillRect(x-3,y-6.6,4,1.2);
  g.fillStyle='rgba(255,255,255,.55)';g.fillRect(x-4,y-13,1.6,9)};
PK.bed=(g,gw,gd)=>{""")
rep("    e.fp=[OX+gx,OY+gy,gw,gh];D.props.push(e)}","    if(kind==='rum')e.y+=3;\n    e.fp=[OX+gx,OY+gy,gw,gh];D.props.push(e)}")

# R8 - scrivania e baule della chiave
rep("""      if(!K.readDesk){K.readDesk=true;progress();say('Diario',"«La chiave della stiva la tiene il cuoco, nel barile col tappo rosso. Non la perdo mai di vista.»",7000);say('Biscotto','Barile col tappo rosso: la cambusa, sul ponte di mezzo! E la stiva è ancora più giù.',6200)}
      else say('Diario','«La chiave della cella sta nella cassapanca, sotto il letto del comandante.»',5200)});
    o('k1',cx(3),cy(14),'Cassapanca',()=>{if(K.key1)return toast('La cassapanca è vuota.');K.key1=true;progress();sfx('quest');toast('Hai la chiave della cella!');say('Tito','La cella è a prua, sul ponte di mezzo: scendiamo dalla scala nel ponte aperto.',6200)},()=>!K.key1);
""","""      if(!K.readDesk){K.readDesk=true;progress();say('Diario',"«La chiave della stiva la tiene il cuoco, nel barile col tappo rosso. Non la perdo mai di vista.»",7000);say('Biscotto','Barile col tappo rosso: la cambusa, sul ponte di mezzo! E la stiva è ancora più giù.',6200);if(K.keyAt!==0&&!K.key1)say('Diario',KEYSP[K.keyAt].diary,6400)}
      else say('Diario',KEYSP[K.keyAt].diary,5200)});
    KEYSP.forEach((ks,i)=>o('k1_'+i,cx(ks.gx),cy(ks.gy+1),ks.lab,()=>{
      if(K.key1)return toast('Il baule è vuoto.');
      if(K.keyAt!==i){sfx('tap');toast(pick(['Solo stracci e biscotti secchi: la chiave non c\\'è.','Qui dentro: calzini e una pipa. Nessuna chiave.','Vuoto! La chiave sarà in un altro posto.']),3400);return}
      K.key1=true;progress();sfx('quest');toast('Hai la chiave della cella!');say('Tito','La cella è a prua, sul ponte di mezzo: scendiamo dalla scala nel ponte aperto.',6200)}));
""")
# R9 - obiettivo suggerito dal pappagallo
rep("  if(!K.key1)return[cx(3),cy(13),'La chiave della cella: cerca a poppa, nella cabina del comandante.'];",
    "  if(!K.key1){const ks=KEYSP[K.keyAt];return[cx(ks.gx),cy(ks.gy+1),ks.goal]}")
# R10 - ingresso nelle stanze
rep("{cabin:()=>{say('Biscotto','Una cassapanca in fondo, a sinistra! Quella con la serratura lucida.')},",
    "{cabin:()=>{say('Biscotto',K.keyAt===0?KEYSP[0].enter:'La cabina del comandante: un letto, una scrivania... ma la chiave non è qui.')},")
rep("quarters:()=>{say('Tito','Gli alloggi degli ufficiali: russano come orsi. Piano!',4200)},",
    "quarters:()=>{if(K.keyAt===1&&!K.key1)say('Biscotto',KEYSP[1].enter,5200);else say('Tito','Gli alloggi degli ufficiali: russano come orsi. Piano!',4200)},")
rep("galley:()=>{say('Tito','L\\'armeria degli ufficiali! Quelle sciabole valgono più della tua: prendine una, Capitano.',5600)},",
    "galley:()=>{say('Tito','L\\'armeria degli ufficiali! Quelle sciabole valgono più della tua: prendine una, Capitano.',5600);if(K.keyAt===2&&!K.key1)say('Biscotto',KEYSP[2].enter,5200)},")
rep("quarters:()=>{say('Tito','La mensa. Briciole e coltelli.')},",
    "quarters:()=>{say('Tito',K.rumTaken?'La mensa. Briciole e coltelli.':'La mensa. Briciole, coltelli... e una bottiglia di rum sul tavolo: può servire!',5000)},")
# R11 - frase iniziale del pappagallo
rep("':'Crack! Prima la cella: i comandanti tengono le chiavi vicino al letto.',6600)","':'Crack! '+KEYSP[K.keyAt].start,6800)")
# R12 - stato iniziale
rep("mLv:0,mHold:0,back:0,readPlan:false};","mLv:0,mHold:0,back:0,readPlan:false,chasedPre:false,keyAt:(Math.random()*3)|0,rum:0,rumTaken:false};")
# R13 - inseguimenti prima della campana, tasto Usa/Lancia
rep("    for(const g of K.gd)stepGuard(g,dt);\n    stepAllies(dt);",
    "    for(const g of K.gd)stepGuard(g,dt);\n    if(!K.alarm&&!K.chasedPre&&K.gd.some(g=>g.ko<=0&&g.st==='chase'))K.chasedPre=true;\n    stepAllies(dt);")
rep("const o=nearObj();K.near=o;const b=$('c4use');b.disabled=!o;b.classList.toggle('lit',!!o);",
    "const o=nearObj();K.near=o;const b=$('c4use'),lanc=!o&&!!K.rum;b.disabled=!o&&!K.rum;b.classList.toggle('lit',!!o||lanc);{const bl=lanc?'Lancia':'Usa';if(b.textContent!==bl)b.textContent=bl}")
rep("function useBtn(){if(!K||K.over||PAUSED)return;const o=nearObj();if(!o){toast('Non c\\'è niente da usare qui.');return}o.use()}",
    "function useBtn(){if(!K||K.over||PAUSED)return;const o=nearObj();if(!o){if(K.rum)return throwRum();toast('Non c\\'è niente da usare qui.');return}o.use()}")
# R14 - HUD: gettone rum
rep("<div class=\"pl\">💰 <span id=\"c4db\">0</span>/9</div></div>","<div class=\"pl\">💰 <span id=\"c4db\">0</span>/9</div><div class=\"pl\" id=\"c4rm\" style=\"display:none\">🍾 Rum</div></div>")
rep("$('c4sv').textContent=K.silver;$('c4db').textContent=K.dob;","$('c4sv').textContent=K.silver;$('c4db').textContent=K.dob;{const rm=$('c4rm');if(rm)rm.style.display=K.rum?'':'none'}")
# R15 - rum: raccolta e lancio (dopo fireLure)
rep("/* oggetti usabili */\nfunction objectsFor(n){",
"""/* bottiglia di rum: secondo diversivo, silenzioso ma le guardie ci restano a lungo */
function takeRum(){
  K.rum=1;K.rumTaken=true;progress();sfx('pick');
  toast('Hai preso la bottiglia di rum! Premi «Lancia»: le guardie correranno a vedere.',5200);
  say('Biscotto','Rum! Lanciala lontano: le guardie vanno a controllare e si fermano a bere.',5600)}
function throwRum(){
  if(!K||!K.rum||K.over||PAUSED)return;
  const fx=K.fdx||1,fy=K.fdy||0,n0=Math.hypot(fx,fy)||1,dx=fx/n0,dy=fy/n0;
  let x=P.x,y=P.y;
  for(let d=20;d<=380;d+=10){const nx=P.x+dx*d,ny=P.y+dy*d,tx=Math.floor(nx/T),ty=Math.floor(ny/T);
    if(!inMap(tx,ty)||!walkT[tIdx(tx,ty)]||blockT[tIdx(tx,ty)]>0)break;x=nx;y=ny}
  for(let k=0;k<8&&!inFree(x,y);k++){x-=dx*12;y-=dy*12}
  if(Math.hypot(x-P.x,y-P.y)<70){toast('Lì davanti c\\'è un ostacolo: girati verso un po\\' di spazio libero.',3200);return}
  K.rum=0;progress();
  if(AU.ctx&&AU.on)noiseBurst(.18,900,.12);
  K.fx.push({k:'bot',x0:P.x,y0:P.y-34,x1:x,y1:y-4,t:0,life:.42});
  K.fx.push({k:'glass',x,y,t:-.42,life:1.5});
  setTimeout(()=>{if(AU.ctx&&AU.on){noiseBurst(.16,3400,.22);tone(2100,1500,.09,'triangle',.07);tone(2800,2000,.06,'triangle',.05,.06)}},420);
  noiseAt(x,y,560,null);
  let n=0;for(const g of K.gd)if(g.st==='suspect'&&g.sx===x&&g.sy===y){g.dwell=7;n++}
  if(!K.notes.rum){K.notes.rum=1;say('Tito',n?'Ha funzionato! Le guardie vanno a vedere... e a bere.':'Peccato: nessuna guardia qui vicino. Tienine una per la prossima volta!',4800)}}
/* oggetti usabili */
function objectsFor(n){""")
rep("    o('su',cx(37),(OY+11)*T-10,'Scala: sali',()=>takeStairs('u'));",
    "    o('rum',cx(15),cy(3),'Bottiglia di rum',()=>takeRum(),()=>!K.rum&&!K.rumTaken);\n    o('su',cx(37),(OY+11)*T-10,'Scala: sali',()=>takeStairs('u'));")
# R16 - la bussola di fine assalto: tre stelle
i=s.index("function leave(){")
j=s.index("function setParry(v){")
old_leave=s[i:j]
assert 'sm_c34r' in old_leave and 'Colpo perfetto' in old_leave and len(old_leave)<3000,len(old_leave)
# parte non-carry: ricostruita con le stelle
k0=old_leave.index("const full=K.cell&&K.silver>=1;")
nc=old_leave[k0:]
nc=nc.replace("<h2>'+title+'</h2><p>'+(bad||'Tutti sulla passerella: la Sirena può sciogliere le vele.')+'</p><div class=\"stats\">","<h2>'+title+'</h2><p>'+(bad||'Tutti sulla passerella: la Sirena può sciogliere le vele.')+'</p>'+starHtml(R,first)+'<div class=\"stats\">")
assert 'starHtml(R,first)' in nc
nc=nc.replace("uShow('endcard',true);sfx('quest');","uShow('endcard',true);starReveal(R.n);")
assert 'starReveal(R.n)' in nc
nc=nc.replace("K.over=true;\n  const bad=","const bad=",1) if "K.over=true;\n  const bad=" in nc else nc
new_leave="""function starRes(){const a=K.pris>=2,b=K.silver>=6,c=!!K.alarm&&!K.chasedPre;return{a,b,c,n:(a?1:0)+(b?1:0)+(c?1:0)}}
function starHtml(R,first){
  const md=R.n>=3?['g','Medaglia d\\'oro']:R.n===2?['s','Medaglia d\\'argento']:R.n===1?['b','Medaglia di bronzo']:['n','Nessuna medaglia'];
  const rows=[[R.a,'Pip e Dodo sono salvi','Libera Pip e Dodo dalla cella'],[R.b,'Sei casse d\\'argento prese','Casse d\\'argento: '+K.silver+' su 6'],[R.c,'Mai inseguiti prima della campana',K.alarm?'Ti hanno inseguito prima della campana':'Prendi l\\'argento senza farti inseguire']];
  return '<div class="c4st"><i id="c4s0">★</i><i id="c4s1">★</i><i id="c4s2">★</i></div><div class="c4md '+md[0]+'">'+md[1]+'</div><ul class="c4ls">'+rows.map(r=>'<li class="'+(r[0]?'ok':'')+'">'+(r[0]?r[1]:r[2])+'</li>').join('')+'</ul>'+(first?'<div class="c4nw">🎩 Nuovo nel guardaroba: Cappello da comandante</div>':'')}
function starReveal(n){
  for(let i=0;i<n;i++)setTimeout(()=>{const e=$('c4s'+i);if(e){e.classList.add('on');if(AU.ctx&&AU.on)tone(660+i*220,880+i*220,.16,'triangle',.12)}},500+i*430);
  setTimeout(()=>sfx(n>=3?'quest':'ok'),500+n*430)}
function leave(){
  if(K.over)return;
  try{if(K.silver>0)localStorage.setItem('sm_gal','1')}catch(e){}   // il bottino sbloccherà un cappello nel guardaroba
  const R=starRes();let best=0;try{best=+(localStorage.getItem('sm_c4star')||0)||0}catch(e){}
  const first=R.n>=3&&best<3;K.stars=R.n;
  try{if(R.n>best)localStorage.setItem('sm_c4star',String(R.n))}catch(e){}   // tre stelle: cappello da comandante
  K.over=true;
  if(K.carry){
    try{const c0=K.carry;localStorage.setItem('sm_c34r',JSON.stringify({silver:(c0.silver||0)+K.silver,pris:K.pris||c0.pris||0,hull:c0.hull,max:c0.max,kills:(c0.kills||0)+K.kos,t:c0.t,stars:R.n}));localStorage.removeItem('sm_c34')}catch(e){}
    const ttl=R.n>=3?'Assalto perfetto!':R.n===2?'Bel colpo!':R.n===1?'Tutti sulla passerella!':'Via, via, via!';
    $('endCard').innerHTML='<div class="seas"><b>Nave spagnola</b><span>Assalto · risultato</span></div><h2>'+ttl+'</h2>'+starHtml(R,first)+'<div class="row"><button class="btn gold" id="eGo">Torna sulla Sirena</button></div>';
    $('eGo').onclick=()=>{$('eGo').disabled=true;setTimeout(()=>{try{__go('#w3')}catch(e){}location.reload()},120)};
    uShow('endcard',true);starReveal(R.n);return}
  """+nc
s=s[:i]+new_leave+s[j:]
# R17 - '?' sulle guardie sospettose, brindisi per quelle attirate dal rum
rep("drawChar(g,e.x,e.y,charO(e,t,e.st==='chase'?{emote:'!',sab:sb}:{sab:sb}));",
    "drawChar(g,e.x,e.y,charO(e,t,e.st==='chase'?{emote:'!',sab:sb}:(e.st==='suspect'||e.st==='search')?{emote:(e.dwell>0&&e.st==='suspect'?'🍺':'?'),sab:sb}:{sab:sb}));")
# la guardia attirata dal rum si ferma più a lungo
rep("if(g.sw>(g.st==='search'?3.4:2.4)){g.st='patrol';g.look=null;g.wait=.3}",
    "if(g.sw>(g.dwell||(g.st==='search'?3.4:2.4))){g.st='patrol';g.look=null;g.wait=.3;g.dwell=0}")
# R18 - effetti: bottiglia in volo e vetri
rep("else if(q.k==='flash'){g.fillStyle='rgba(255,90,90,'+a*.7+')';g.beginPath();g.arc(q.x,q.y,26*(1+q.t*2),0,7);g.fill()}}",
"""else if(q.k==='flash'){g.fillStyle='rgba(255,90,90,'+a*.7+')';g.beginPath();g.arc(q.x,q.y,26*(1+q.t*2),0,7);g.fill()}
    else if(q.k==='bot'){const p=q.t/q.life,x=q.x0+(q.x1-q.x0)*p,y=q.y0+(q.y1-q.y0)*p-Math.sin(p*Math.PI)*54;g.save();g.translate(x,y);g.rotate(p*14);g.fillStyle='#2f8a52';g.strokeStyle='#0c2a1a';g.lineWidth=1.2;rrect(g,-4,-8,8,12,3);g.fill();g.stroke();g.fillRect(-1.6,-14,3.2,7);g.strokeRect(-1.6,-14,3.2,7);g.restore()}
    else if(q.k==='glass'&&q.t>=0){const p=q.t/q.life;g.fillStyle='rgba(214,150,40,'+(.5*(1-p*.6))+')';g.beginPath();g.ellipse(q.x,q.y+6,16+p*12,6+p*4,0,0,7);g.fill();
      for(let i=0;i<7;i++){const an=i*.9+.3,r=8+p*34*(.6+.1*(i%3));g.fillStyle='rgba(190,240,220,'+Math.max(0,1-p*1.2)+')';g.save();g.translate(q.x+Math.cos(an)*r,q.y-4+Math.sin(an)*r*.6-Math.sin(Math.min(1,p*2.4)*3.1)*14);g.rotate(an+p*6);g.fillRect(-2.5,-1,5,2);g.restore()}}}""")
# R19 - esportazioni per i test
rep("window.Ch4={sab:playerSab,","window.Ch4={KEYSP,throwRum,starRes,sab:playerSab,")
open(p,'w',encoding='utf8').write(s)
print('ok',len(s))
