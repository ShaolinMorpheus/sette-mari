import sys
for f in ['ch3_inject.js','ch3_inject.pre_voy.js']:
    s=open(f,encoding='utf8').read()
    if 'go5Start' in s: print(f,'already');continue
    def rep(a,b):
        global s
        assert s.count(a)==1,(f,a[:50],s.count(a))
        s=s.replace(a,b)
    rep("setTimeout(()=>endRun('completo'),500)}\n  else if(!tutSeen())","setTimeout(()=>go5Start(),500)}\n  else if(!tutSeen())")
    rep("if(!C.over&&C.convoy&&(C.pris===2||C.prisLost)","if(!C.over&&!C.go5&&C.convoy&&(C.pris===2||C.prisLost)")
    rep("if(!C.over&&C.escapes>0&&","if(!C.over&&!C.go5&&C.escapes>0&&")
    rep("  moveShip(p,dt,tv);\n","  moveShip(p,dt,tv);\n  if(C.go5&&!C.over&&Math.hypot(p.x-C.go5.x,p.y-C.go5.y)<3.4*T)go5Arrive();\n")
    rep("/* ---------------- fine ---------------- */","""/* ---------------- dopo il galeone: verso il grande viaggio ---------------- */
function go5Start(){
  C.ships=C.ships.filter(s=>s.ally);C.crates=[];C.balls=[];C.pend=[];C.convoy=true;
  const e=ROUTE[ROUTE.length-1],t=findSea(e[0],e[1]);C.go5={x:t[0],y:t[1]};
  UI.dlg([D('tito',"Capitano, la stiva è piena d'argento. Il convoglio spagnolo non ce la perdonerà."),D('hero',"Allora non aspettiamo. Le carte del galeone segnano un varco: lì finisce il mare che conosciamo."),D('biscotto',"Cra! Segui la freccia! Io faccio la vedetta!")],()=>{UI.banner('Nuovo obiettivo','Raggiungi il varco del grande viaggio')});
}
function go5Arrive(){
  C.over=true;const sv=C.silver;
  UI.dlg([D('hero',"Eccolo: il varco. Di là le carte non dicono più niente."),D('tito',"Argento a bordo ("+sv+" casse), Pip e Dodo al sicuro. Siamo pronti."),D('biscotto',"Cra! Pronti! Più o meno!")],()=>{
    const o=document.createElement('div');o.style.cssText='position:fixed;inset:0;z-index:99999;background:#06182a;color:#ffd23a;display:flex;flex-direction:column;align-items:center;justify-content:center;font:800 22px Nunito,Arial;text-align:center';
    o.innerHTML='<div style="font-size:15px;opacity:.8">Capitolo 4</div><div style="font-size:30px;margin:6px 0 14px">Il grande viaggio</div><div>Caricamento…</div>';document.body.appendChild(o);
    try{localStorage.setItem('sm_c5',JSON.stringify({fresh:1,silver:sv,hull:8}))}catch(e){}
    setTimeout(()=>{try{__go('#w5')}catch(e){}location.reload()},1600)});
}
/* ---------------- fine ---------------- */""")
    # obiettivo testo
    rep("$('c3obj').textContent=!C.convoy?(","$('c3obj').textContent=C.go5?('Raggiungi il varco del grande viaggio ('+Math.round(Math.hypot(C.go5.x-p.x,C.go5.y-p.y)/44)+' caselle, '+dirName(C.go5.x-p.x,C.go5.y-p.y)+')'):!C.convoy?(")
    # freccia a schermo
    rep("  for(const s of C.ships){\n    if(s.dead||!(s.type==='galeone'","""  if(C.go5&&!C.over){const[x,y]=toScreen(C.go5.x,C.go5.y);
    if(!(x>26&&x<w-26&&y>40&&y<h-26)){const a=Math.atan2(y-h/2,x-w/2),ex=cl(w/2+Math.cos(a)*(w/2-40),40,w-40),ey=cl(h/2+Math.sin(a)*(h/2-40),56,h-40),pl=.5+.5*Math.sin(C.t*6);
      g.save();g.translate(ex,ey);g.rotate(a);g.shadowColor='rgba(255,214,90,.9)';g.shadowBlur=14+pl*10;g.fillStyle='#ffd23a';g.strokeStyle='#2a1a0e';g.lineWidth=3;g.beginPath();g.moveTo(24,0);g.lineTo(-12,-15);g.lineTo(-6,0);g.lineTo(-12,15);g.closePath();g.fill();g.stroke();g.restore()}
    else{g.save();g.translate(x,y);const pl=.5+.5*Math.sin(C.t*5);g.strokeStyle='rgba(255,214,90,'+(.5+.4*pl)+')';g.lineWidth=5;g.beginPath();g.arc(0,0,3.4*44*camZoom(),0,7);g.stroke();g.fillStyle='#ffd23a';g.font='900 26px Nunito,Arial';g.textAlign='center';g.fillText('⚓',0,9);g.restore()}}
  for(const s of C.ships){
    if(s.dead||!(s.type==='galeone'""")
    # minimappa
    rep("  if(!VOY){const pt0=TPp(21,30)","""  if(C.go5){let dx=(C.go5.x-p.x)*sc,dy=(C.go5.y-p.y)*sc;const d=Math.hypot(dx,dy),far=d>96,pl=.5+.5*Math.sin(C.t*6);if(far){dx=dx/d*96;dy=dy/d*96}
    c.save();c.translate(dx,dy);if(far){const an=Math.atan2(dy,dx);c.save();c.rotate(an);c.fillStyle='#ffd23a';c.beginPath();c.moveTo(22,0);c.lineTo(10,-8);c.lineTo(10,8);c.closePath();c.fill();c.restore()}
    c.strokeStyle='rgba(255,214,90,'+(.3+.5*pl)+')';c.lineWidth=2.5;c.beginPath();c.arc(0,0,9+pl*6,0,7);c.stroke();
    c.fillStyle='#3a2410';c.strokeStyle='#ffd23a';c.lineWidth=2.5;c.beginPath();c.arc(0,0,8,0,7);c.fill();c.stroke();c.fillStyle='#ffd23a';c.font='900 11px Nunito,Arial';c.textAlign='center';c.fillText('★',0,4);c.restore()}
  if(!VOY&&!C.go5){const pt0=TPp(21,30)""")
    open(f,'w',encoding='utf8').write(s);print(f,'ok')
