const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.flags.sailed=1;S.up.sail=0;Pirati.boardRaft&&0});
 await p.evaluate(()=>{Pirati.S.live=true});
 // metti il giocatore sulla zattera in mare
 const r=await p.evaluate(()=>{const P=Pirati.P;P.mode='raft';P.x=2530+400;P.y=1406+300;P.hd=0;return 'ok'});
 for(const [i,hd] of [[0,0],[1,Math.PI/2],[2,Math.PI],[3,-Math.PI/2],[4,-.7]]){
   await p.evaluate(h=>{Pirati.P.hd=h},hd);await p.waitForTimeout(1600);
   await p.screenshot({path:'aud/raft'+i+'.png',clip:{x:420,y:150,width:500,height:300}});}
 console.log('ERR',JSON.stringify(errs));await b.close()})();
