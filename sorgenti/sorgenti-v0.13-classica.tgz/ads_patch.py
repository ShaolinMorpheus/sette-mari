rep("+T('mBk','🛟','Copia di sicurezza',null)","+T('mBk','🛟','Copia di sicurezza',null)+(SMAds.available()?T('mAd','🎁','Guarda un video','scorta in regalo')+T('mPriv','🔒','Privacy',null):'')")
rep("  c.querySelector('#mHow').onclick=()=>UI.showHow();",r"""  {const ad=c.querySelector('#mAd');if(ad)ad.onclick=async()=>{
    const now=Date.now(),last=+(localStorage.getItem('sette-mari-adt')||0);
    if(now-last<480000){UI.toast('Un video alla volta: riprova tra qualche minuto.');return}
    uShow('menu',false);
    const ok=await SMAds.reward();
    if(!ok){UI.toast('Nessun video disponibile ora. Riprova tra poco.');return}
    try{localStorage.setItem('sette-mari-adt',String(Date.now()))}catch(_){}
    gain('coco',3,null,null,true);gain('bacche',3,null,null,true);UI.toast('Scorta in regalo: +3 noci di cocco e +3 bacche.');sfx('ok');saveGame()};
   const pv=c.querySelector('#mPriv');if(pv)pv.onclick=()=>SMAds.privacy()}
  c.querySelector('#mHow').onclick=()=>UI.showHow();""")
rep("$('endCard').querySelector('#eGo').onclick=()=>{uShow('endcard',false);Story.afterEnd()};","$('endCard').querySelector('#eGo').onclick=()=>{uShow('endcard',false);Story.afterEnd();try{SMAds.interstitial()}catch(_){}};")
