const s=require('fs').readFileSync('w/index.html','utf8');
const m=[...s.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x=>x[1]).sort((a,b)=>b.length-a.length)[0];
try{new Function(m);console.log('syntax ok',m.length)}catch(e){console.log('SYNTAX',e.message)}
