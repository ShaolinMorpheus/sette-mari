const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
const r=await p.evaluate(()=>{const P=Pirati;const rows=[];for(let y=47;y<=52;y++){let s=String(y).padStart(2)+' ';for(let x=13;x<=25;x++){const t=P.tileInfo(x,y);s+=(t.e*100|0).toString().padStart(4)}rows.push(s)}
 return {keys:[],rows,ps:[P.P.x/44,P.P.y/44],t:JSON.stringify(P.tileInfo(18,51))+JSON.stringify(P.tileInfo(18,50))}});
console.log(r.keys.join(','),r.ps);console.log(r.rows.join('\n'),r.t);await b.close()})();
