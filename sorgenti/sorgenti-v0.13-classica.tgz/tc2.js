const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(300)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
for(let i=0;i<60&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(350)}
console.log(await p.evaluate(()=>[Pirati.WORLD,Pirati.S.ch,Pirati.UI.dlgOpen()]));
await p.evaluate(()=>{Pirati.S.tod=12;Pirati.S.up.torch=1;Pirati.cave.enter()});await p.waitForTimeout(2800);
console.log(await p.evaluate(()=>[Pirati.cave.inside(),Math.round(Pirati.P.x),Math.round(Pirati.P.y),document.body.className,Pirati.S.torchOn,document.getElementById('torchb').hidden]));
await p.screenshot({path:'cv_dark.png'});
await p.evaluate(()=>Pirati.toggleTorch());await p.waitForTimeout(800);await p.screenshot({path:'cv_torch.png'});
console.log(await p.evaluate(()=>[Pirati.S.torchOn,JSON.stringify(Pirati.tinfo())]));
console.log(er);await b.close()})();
