const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [n,w,h] of [['land',844,390],['port',390,844]]){
const p=await b.newPage({viewport:{width:w,height:h},hasTouch:true,isMobile:true});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;localStorage.setItem(P.saveKey(),JSON.stringify(P.newState('T','m')));P.startContinue('',null)});await p.waitForTimeout(1500);
await p.evaluate(()=>{Pirati.UI.showOverview(()=>{})});await p.waitForTimeout(700);
await p.screenshot({path:'tm_'+n+'.png'});await p.close()}
await b.close()})();
