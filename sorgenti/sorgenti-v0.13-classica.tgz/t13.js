const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1200);
const r=await p.evaluate(()=>{const C=Ch4,K=C.K,P=C.P;C.tp(33,8);const x=P.x,y=P.y;for(const f of K.fol){f.x=P.x+3;f.y=P.y+2}for(let i=0;i<30;i++)C.step(1/30);return [Math.round(P.x-x),Math.round(P.y-y),K.fol.map(f=>Math.round(Math.hypot(f.x-P.x,f.y-P.y)))]});
console.log(JSON.stringify(r),errs);await b.close()})()
