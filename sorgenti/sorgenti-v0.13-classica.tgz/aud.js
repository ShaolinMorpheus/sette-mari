const {chromium}=require('playwright');
const W=process.argv[2]==='2';
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
if(W)await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
if(W)await p.evaluate(()=>{const P=Pirati;localStorage.setItem(P.saveKey(),JSON.stringify(P.Ch2.convert(P.newState('D','m'))));P.startContinue('',null)});
else await p.evaluate(()=>Pirati.startNew('T','m'));
await p.waitForTimeout(2000);
const res=await p.evaluate(()=>{
 const P=Pirati,TS=44,MW=99,MH=60,st=11,GW=Math.floor(MW*TS/st),GH=Math.floor(MH*TS/st);
 const fr=new Uint8Array(GW*GH),land=new Uint8Array(GW*GH),cause=new Uint8Array(GW*GH);
 for(let j=0;j<GH;j++)for(let i=0;i<GW;i++){const x=i*st+st/2,y=j*st+st/2;
  const l=P.elev(x/TS,y/TS)>P.WL+.02;land[j*GW+i]=l?1:0;fr[j*GW+i]=P.boxFree(x,y,9,5)?1:0;
  if(l&&!fr[j*GW+i]){const ti=P.tileInfo(Math.floor(x/TS),Math.floor(y/TS));cause[j*GW+i]=ti.block>0?2:1}}
 // BFS dal punto di partenza
 const sx=Math.floor(P.P.x/st),sy=Math.floor(P.P.y/st),seen=new Uint8Array(GW*GH),q=[[sx,sy]];seen[sy*GW+sx]=1;
 for(let h=0;h<q.length;h++){const[x,y]=q[h];for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const a=x+dx,c=y+dy;if(a<0||c<0||a>=GW||c>=GH||seen[c*GW+a]||!fr[c*GW+a])continue;seen[c*GW+a]=1;q.push([a,c])}}
 const sc=2;const cv=document.createElement('canvas');cv.width=GW*sc;cv.height=GH*sc;const g=cv.getContext('2d');
 const im=new Image();return new Promise(r=>{im.onload=()=>{g.drawImage(im,0,0,cv.width,cv.height);
  g.globalAlpha=.8;
  for(let j=0;j<GH;j++)for(let i=0;i<GW;i++){const k=j*GW+i;
    if(land[k]&&fr[k]&&!seen[k]){g.fillStyle='#ff00ff';g.fillRect(i*sc,j*sc,sc,sc)}
    else if(cause[k]===1){g.fillStyle='#ff2020';g.fillRect(i*sc,j*sc,sc,sc)}
    else if(cause[k]===2){g.fillStyle='#2080ff';g.fillRect(i*sc,j*sc,sc,sc)}}
  g.globalAlpha=1;
  const ents=P.E.filter(e=>e.fp&&e.blocked).map(e=>[e.type+':'+(e.id||e.spr||''),e.fp.join(',')]);
  let n1=0,n2=0,n3=0;for(let k=0;k<GW*GH;k++){if(cause[k]===1)n1++;if(cause[k]===2)n2++;if(land[k]&&fr[k]&&!seen[k])n3++}
  r({img:cv.toDataURL(),n1,n2,n3,GW,GH})};im.src=P.prev()})});
require('fs').writeFileSync('aud'+(W?2:1)+'.png',Buffer.from(res.img.split(',')[1],'base64'));
console.log(res.n1,res.n2,res.n3,res.GW,res.GH);await b.close()})();
