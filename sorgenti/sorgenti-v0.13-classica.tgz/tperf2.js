const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:900,height:420},deviceScaleFactor:2.5});const p=await ctx.newPage();
await p.addInitScript(()=>{window.__d={};const o=CanvasRenderingContext2D.prototype.drawImage;CanvasRenderingContext2D.prototype.drawImage=function(im,...a){const w=a.length>=4?a[a.length-2]:im.width,h=a.length>=4?a[a.length-1]:im.height;const k=(im.id||im.width+'x'+im.height)+'->'+(w|0)+'x'+(h|0);window.__d[k]=(window.__d[k]||0)+1;return o.call(this,im,...a)}});
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(2500);
await p.click('#bNew').catch(()=>{});for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(200)}
await p.waitForTimeout(2000);await p.evaluate(()=>window.__d={});await p.waitForTimeout(2000);
const d=await p.evaluate(()=>window.__d);console.log(Object.entries(d).sort((a,b)=>b[1]-a[1]).slice(0,12));await b.close()})();
