const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:420}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>{Pirati.startNew('T','m')});
for(let i=0;i<12;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(500)}
const r=await p.evaluate(async()=>{const res=[];const m=Pirati.EID.mraft;m.x=2800;m.y=560;const cr=Pirati.EID.ci20;cr.x=cr.hx=2735;
 Pirati.S.built.zattera=1;
 for(const [dx,dy] of [[-150,0],[-100,0],[-70,0],[-45,0],[-30,0],[0,60],[60,0]]){Pirati.tp((m.x+dx)/44,(m.y+dy)/44);await new Promise(r=>setTimeout(r,80));const t=Pirati.tinfo();res.push(dx+','+dy+' -> '+(t&&t.l)+' crabx '+(cr.x|0))}
 return res});console.log(r.join('\n'));await b.close()})();
