const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(2500);await p.click('#bNew').catch(()=>{});
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(200)}
await p.waitForTimeout(800);
console.log(await p.evaluate(()=>{const C=Ch3.C;const g=Ch3.mkShip('galeone',C.p.x+120,C.p.y,0,{hull:3,max:14});C.ships.push(g);g.disabled=true;g.hull=3;g.x=C.p.x+120;g.y=C.p.y;Ch3.board();return [C.over,location.hash]}));
await p.waitForTimeout(3500);console.log(await p.evaluate(()=>[location.hash,document.body.className,document.title]));
await p.screenshot({path:'b4_0.png'});
for(let i=0;i<6;i++){await p.mouse.click(450,200);await p.waitForTimeout(400)}
await p.screenshot({path:'b4_1.png'});console.log(er);await b.close()})();
