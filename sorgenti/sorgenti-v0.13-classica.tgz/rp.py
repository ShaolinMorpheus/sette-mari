import sys
def edit(path, pairs, enc='utf8'):
    """pairs: list of (old,new[,cnt]); verifica i conteggi, poi scrive."""
    src=open(path,encoding=enc).read()
    for p in pairs:
        old,new=p[0],p[1]; cnt=p[2] if len(p)>2 else 1
        n=src.count(old)
        if n!=cnt:
            print('EDIT FAIL (%d trovati, attesi %d) in %s:'%(n,cnt,path),old[:100].replace('\n','\\n')); sys.exit(1)
        src=src.replace(old,new)
    open(path,'w',encoding=enc).write(src)
    print('edit ok',path,len(pairs))
