const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
 const ctx=await b.newContext({viewport:{width:915,height:412},deviceScaleFactor:1.5,hasTouch:true});
 const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.addInitScript(()=>{try{if(!sessionStorage.getItem('_t_init')){localStorage.clear();sessionStorage.setItem('_t_init','1')}}catch(e){}});
 await p.goto('file:///home/claude/out/index_final.html');
 await p.waitForFunction(()=>window.Pirati&&window.Pirati.S,null,{timeout:90000}).catch(()=>{});
 await p.waitForTimeout(1200);
 const ev=async(f,a)=>{try{return await p.evaluate(f,a)}catch(e){return {ERRORE:e.message.split('\n')[0].slice(0,220)}}};
 await p.evaluate(()=>Pirati.startNew('Test','f'));
 for(let i=0;i<14;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS','tutSkip']){const e=document.getElementById(id);if(e&&!e.hidden&&e.offsetParent!==null)e.click()}try{Pirati.UI.dlgAuto&&Pirati.UI.dlgAuto()}catch(e){}});await p.waitForTimeout(150)}
 const out=[];
 out.push(['ch1 prima',JSON.stringify(await ev(()=>{const S=Pirati.S,F=Pirati.farm;S.flags.hat=1;S.flags.parrot=1;F.farmInit();S.gard.harv=12;S.flags.ch1=1;S.cOpen=9;S.wown={};S.phats={};F.wardCheck();
   S.wear={hat:'h_paglia',out:'o_cont'};F.lookSave();S.phat='fiore';Pirati.saveGame();
   return {ch:S.ch,hero:S.hero,wown:Object.keys(S.wown).length,wear:S.wear,phat:S.phat,key:Pirati.saveKey()}}))]);
 // passaggio al capitolo 2
 await ev(()=>{Pirati.Ch2.begin()});
 await p.waitForNavigation({timeout:20000}).catch(()=>{});
 await p.waitForFunction(()=>window.Pirati&&window.Pirati.S&&window.Pirati.S.live,null,{timeout:60000}).catch(()=>{});
 await p.waitForTimeout(1500);
 out.push(['ch2',JSON.stringify(await ev(()=>{const S=Pirati.S,F=Pirati.farm;return {ch:S.ch,world:Pirati.WORLD,hero:S.hero,wown:Object.keys(S.wown||{}).length,wear:S.wear,phat:S.phat,phats:Object.keys(S.phats||{}),spec:F.heroSpec().hat+'/'+F.heroSpec().coat,gard:!!S.gard}}))]);
 // sblocco nuovo capo in ch2 e ritorno al ch1
 out.push(['ch2 nuovo capo',JSON.stringify(await ev(()=>{const S=Pirati.S,F=Pirati.farm;S.wown.h_turb=1;S.wear={hat:'h_turb',out:'o_cors'};F.lookSave();Pirati.saveGame();return {wear:S.wear}}))]);
 await ev(()=>{Pirati.Ch2.toCh1()});
 await p.waitForNavigation({timeout:20000}).catch(()=>{});
 await p.waitForFunction(()=>window.Pirati&&window.Pirati.S&&window.Pirati.S.live,null,{timeout:60000}).catch(()=>{});
 await p.waitForTimeout(1500);
 out.push(['ritorno ch1',JSON.stringify(await ev(()=>{const S=Pirati.S,F=Pirati.farm;return {ch:S.ch,world:Pirati.WORLD,wown:Object.keys(S.wown||{}).length,hasTurb:!!(S.wown||{}).h_turb,wear:S.wear,gardKept:!!S.gard&&S.gard.harv}}))]);
 console.log(out.map(x=>x.join(': ')).join('\n'));console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
