const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(3000);
for(const k of ['fire','solo','ferro']){
 await p.evaluate(k=>{Pirati.Ch2.ending(k)},k);await p.waitForTimeout(1500);
 await p.screenshot({path:'cine_'+k+'_0.png'});
 for(let i=0;i<3;i++){await p.waitForTimeout(500);await p.click('#intro').catch(()=>{});}
 await p.screenshot({path:'cine_'+k+'_1.png'});
 for(let i=0;i<12;i++){await p.waitForTimeout(500);await p.click('#intro',{timeout:500}).catch(()=>{});}
 await p.waitForTimeout(1200);
 console.log(k,await p.evaluate(()=>[Pirati.S.flags.ch2end,document.getElementById('intro').hidden,!document.getElementById('endcard').hidden]));
 await p.evaluate(()=>{Pirati.S.flags.ch2end=0;document.getElementById('endcard').hidden=true});
}
console.log(er);await b.close()})();
