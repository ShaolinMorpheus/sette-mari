const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:844,height:390}})).newPage();
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
const r=await p.evaluate(()=>{const P=Pirati,out=[];
 for(let ty=1;ty<59;ty++)for(let tx=1;tx<98;tx++){const t=P.tileInfo(tx,ty);if(t.e<.2||t.block)continue;
  // centro del tile
  if(P.boxFree((tx+.5)*44,(ty+.5)*44,9,5))continue;
  let nb=false;for(let j=-1;j<=1;j++)for(let i=-1;i<=1;i++)if(P.tileInfo(tx+i,ty+j).block)nb=true;
  out.push([tx,ty,+t.e.toFixed(2),nb?1:0,t.walk])}
 return out});
console.log(r.length,'isolated land tiles not free at centre');console.log(JSON.stringify(r.filter(a=>!a[3]).slice(0,80)));console.log('near blocks',r.filter(a=>a[3]).length);await b.close()})();
