const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 const r=await p.evaluate(()=>{const o={};for(const id of['falo','capanna','banco','zattera']){const e=Pirati.EID['plot_'+id];o[id]={fp:e.fp,st:e.st,blocked:e.blocked,x:e.x,y:e.y}}return JSON.stringify(o)});
 console.log(r);console.log(await p.evaluate(()=>Pirati.farm.DECOR.map(d=>d.k).join()));await b.close()})();
