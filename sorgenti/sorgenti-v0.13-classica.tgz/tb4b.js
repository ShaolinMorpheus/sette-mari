const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:900,height:420}});const p=await ctx.newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{if(!localStorage.getItem('sm_c34'))localStorage.setItem('sm_c34',JSON.stringify({pris:2,silver:0,hull:6,max:8,kills:3,t:300,shots:20,hits:10}))}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(3500);
await p.screenshot({path:'b4_0.png'});
for(let i=0;i<8;i++){await p.mouse.click(450,300);await p.waitForTimeout(500)}
await p.screenshot({path:'b4_1.png'});console.log(await p.evaluate(()=>[document.body.className,Object.keys(window.Ch4||{})]),er);await b.close()})();
