/* ====== NOVITÀ v0.11.2 (C): galeone — cappello da comandante, traguardo a 3 stelle ====== */
NVH.comm=(g,hy,hr,hc,back,sp_,dk)=>{
  const c1=hc||'#1c2a52',gold=(sp_&&sp_.trim)||'#e8c860';
  // feltro blu notte, due punte larghe ai lati
  const q=g.createLinearGradient(0,hy-22,0,hy-4);q.addColorStop(0,dk(c1,1.5));q.addColorStop(1,dk(c1,.78));
  g.fillStyle=q;g.beginPath();
  g.moveTo(-23,hy-6);g.quadraticCurveTo(-24,hy-20,-9,hy-16);g.quadraticCurveTo(0,hy-22,9,hy-16);g.quadraticCurveTo(24,hy-20,23,hy-6);g.quadraticCurveTo(0,hy-.5,-23,hy-6);g.closePath();g.fill();
  g.strokeStyle='#060a18';g.lineWidth=1.3;g.stroke();
  // gallone dorato lungo il bordo e sulle punte
  g.strokeStyle=gold;g.lineWidth=2.2;g.lineCap='round';
  g.beginPath();g.moveTo(-22.4,hy-6.4);g.quadraticCurveTo(0,hy-.6,22.4,hy-6.4);g.stroke();
  g.lineWidth=1.3;g.beginPath();g.moveTo(-22.8,hy-8);g.quadraticCurveTo(-23.4,hy-18.5,-9.4,hy-15.4);g.moveTo(22.8,hy-8);g.quadraticCurveTo(23.4,hy-18.5,9.4,hy-15.4);g.stroke();
  // tre piume bianche sulla cima
  const fe=(x,y,rot,len)=>{g.save();g.translate(x,y);g.rotate(rot);g.fillStyle='#f8f4ea';g.strokeStyle='#8a8478';g.lineWidth=.9;g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(len*.4,-len*.4,len*.18,-len);g.quadraticCurveTo(-len*.22,-len*.5,0,0);g.closePath();g.fill();g.stroke();g.restore()};
  fe(-5,hy-17,-.5,14);fe(0,hy-18.5,0,17);fe(5,hy-17,.5,14);
  if(!back){ // coccarda rossa con bottone dorato
    g.fillStyle='#d8312a';g.beginPath();g.arc(0,hy-9,3,0,7);g.fill();g.strokeStyle=gold;g.lineWidth=1.2;g.stroke();
    g.fillStyle=gold;g.beginPath();g.arc(0,hy-9,1,0,7);g.fill()}
};
{
  const ls=k=>{try{return localStorage.getItem(k)}catch(e){return null}};
  const add=it=>{if(WEAR.some(x=>x.id===it.id))return;WEAR.push(it);if(it.k==='hat')WRH[it.id]=it.spec;else if(it.k==='out')WRO[it.id]=it.spec};
  add({id:'h_comm',k:'hat',n:'Cappello da comandante',hint:'Galeone: salva i prigionieri, prendi le sei casse e non farti inseguire prima della campana (3 stelle).',own:()=>ls('sm_c4star')==='3',spec:{hat:'comm',hatc:'#1c2a52',trim:'#e8c860'}});
  add({id:'o_spag',k:'out',n:'Giubba del comandante',hint:'Galeone: vinci il duello facoltativo col comandante spagnolo.',own:()=>ls('sm_c4duel')==='1',spec:{coat:'#a8281e',coat2:'#6a1810',pants:'#242028',shirt:'#f4efe0',trim:'#e8c860',boots:1,sash:'#e8c860'}});
  NV3.AC.push({id:'duello',n:'Duellante',d:'Galeone: batti il comandante spagnolo in duello.',ok:()=>ls('sm_c4duel')==='1'});
  NV3.AC.push({id:'gal3',n:'Assalto perfetto',d:'Galeone: prigionieri salvi, sei casse d\'argento e nessun inseguimento prima della campana.',ok:()=>ls('sm_c4star')==='3'});
}
