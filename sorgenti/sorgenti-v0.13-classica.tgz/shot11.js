const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:915,height:412},deviceScaleFactor:1.5})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.removeItem('sm_c34')}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2800);
await p.evaluate(()=>{Ch4.K.gd.forEach(g=>g.ko=1e9);Ch4.tp(29.5,13.9)});await p.waitForTimeout(1000);
await p.screenshot({path:'sab/sh_a.png'});
await p.evaluate(()=>{Ch4.tp(28.2,15)});await p.waitForTimeout(1000);
await p.screenshot({path:'sab/sh_b.png'});
console.log(er);await b.close()})();
