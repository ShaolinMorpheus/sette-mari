p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:60],s.count(a))
    s=s.replace(a,b)

# 1. WORLD
rep("const I2=9;","""const WORLD=(function(){try{if(window.__W2)return 2;const K='sette-mari-e-mezzo-s1-v2',sl=+localStorage.getItem('sette-mari-slot')||1,k=sl===2||sl===3?K+'-s'+sl:K;const j=localStorage.getItem(k);if(!j)return 1;const o=JSON.parse(j);return o&&o.v===2&&o.ch===2?2:1}catch(e){return 1}})();
const I2=9;""")

# 2. constants
rep("const BLOBS=[","const BLOBS_1=[")
rep("""  [79+I2,31,8,9],[82+I2,22,5,4],[74+I2,40,5,4.5]
];""","""  [79+I2,31,8,9],[82+I2,22,5,4],[74+I2,40,5,4.5]
];
/* capitolo 2: la grande isola della Baia dei Fuggiaschi (molto più grande della prima) */
const BLOBS_2=[
  [53,30,27,16],[36,21,11,8],[70,18,12,7.5],[66,43,13,7],[38,42,10,6],[82,32,6,7],[27,32,5,6],
  [10,13,3.8,3.2],[12,49,4,3],[90,52,3.6,3],[91,9,4,3.2],[47,53,3,2.2]
];
const BLOBS=WORLD===2?BLOBS_2:BLOBS_1;""")
rep("const BEACH=[[13.8","const BEACH_1=[[13.8")
rep("[30,15.6,4.2,2.2]];\nconst POND={x:34,y:22.6,rx:2.7,ry:1.8};\nconst C0={x:33.5,y:27.6};","""[30,15.6,4.2,2.2]];
const BEACH=WORLD===2?[[22.6,31,3.6,4.2],[66,50.4,7,3],[48,11.4,6,2.2],[80,36.5,3,3.5],[29,45,5,2.2]]:BEACH_1;
const POND=WORLD===2?{x:31,y:25.2,rx:3.4,ry:2.2}:{x:34,y:22.6,rx:2.7,ry:1.8};
const C0=WORLD===2?{x:31.5,y:30}:{x:33.5,y:27.6};""")
rep("const PATHS=[[[15.4","const PATHS_1=[[[15.4")
rep("[[33.5,27.6],[40,25],[45,24]]];","""[[33.5,27.6],[40,25],[45,24]]];
const PATHS=WORLD===2?[[[23.5,31.2],[27.5,30.6],[31.5,30],[40,31],[50,31.5],[57,30.4]],[[31.5,30],[31.5,26.8]],[[57,30.4],[62,36],[66,42.5]],[[57,30.4],[63,24],[68,19]],[[57,30.4],[52,22],[48,14]],[[31.5,30],[34,37],[38,42]],[[57,30.4],[70,31],[79,33]]]:PATHS_1;""")
rep("const MESA={x:49.5,y:16.6,rx:3.8,ry:2.4,h:66};","const MESA=WORLD===2?{x:72.5,y:15.6,rx:4.6,ry:2.9,h:80}:{x:49.5,y:16.6,rx:3.8,ry:2.4,h:66};")
rep("const FORESTS=[[24,29","""const FORESTS_2=[[40,32,8,6,.85],[46,22,8,5,.9],[34,38,6,4,.7],[60,21,6,4,.8],[73,22,7,5,.9],[66,36,5,4,.6],[78,31,4,5,.7],[51,40,7,4,.6],[28,18,4,3,.6],[44,28,5,3,.5],[56,16,6,3,.8],[38,15,5,3,.7]];
const FORESTS_1=[[24,29""")
# end of FORESTS_1 line then define FORESTS
import re
m=re.search(r"const FORESTS_1=\[.*?\];\n",s,re.S)
s=s[:m.end()]+"const FORESTS=WORLD===2?FORESTS_2:FORESTS_1;\n"+s[m.end():]

# 3. FIX
rep("const FIX={\n  spawn:[14.4,47.3],","const FIX_1={\n  spawn:[14.4,47.3],")
rep("  bottles:[[12.5,38.4],[36.4,13.9],[56.7,35.2],[43.5,45.6]]\n};","""  bottles:[[12.5,38.4],[36.4,13.9],[56.7,35.2],[43.5,45.6]]
};
/* capitolo 2: luoghi fissi (coordinate in tile) */
const CV2={ship:[68.6,45.4],mast:[75.2,20.6],cave:[40.5,46.3],knife:[24.2,36.2],
  pages:[[34.5,14.8],[49.4,39.6],[79.3,28.6],[62.6,47.6]],
  islets:[[10,13],[12,49.4],[90,52],[91,9.4]]};
const FIX_2={
  spawn:[24.6,31.2],wreck:[68.6,45.4],sign:[25.8,29.4],loot:{},
  pond:[POND.x,POND.y],camp:[C0.x,C0.y],
  plots:{falo:{tx:30,ty:29,w:1,h:1},capanna:{tx:25,ty:26,w:3,h:2},banco:{tx:34,ty:28,w:2,h:1},zattera:{tx:21,ty:30,w:3,h:2}},
  lookout:[55.2,25.3],parrotTree:[2,2],oldcamp:[2,2],oldChest:[2,2],
  quarry:[75.4,25.4],
  boulders:[[73.5,24.4],[76.5,24.8],[79.5,24.4],[74.6,26.8],[77.6,27.1],[80.2,26.6],[72.4,27.4],[75.4,28.4],[78.8,28.6]],
  raftLaunch:[19.4,31.6],landing:[-60,-60],smoke:[58.4,30],
  isl1:[CV2.islets[1][0],CV2.islets[1][1]],isl2:[CV2.islets[0][0],CV2.islets[0][1]],bottles:[]
};
const FIX=WORLD===2?FIX_2:FIX_1;""")

# 4. exclTile / genWorld hooks
rep("function exclTile(tx,ty){\n  const x=tx+.5,y=ty+.5;","function exclTile(tx,ty){\n  if(WORLD===2)return exclTile2(tx,ty);\n  const x=tx+.5,y=ty+.5;")
rep("function genWorld(){\n  const r=mulberry(7);","function genWorld(){\n  if(WORLD===2)return genWorld2();\n  const r=mulberry(7);")
rep("const x=tx+i,y=ty+j;if(!freeT(x,y)||x>=64)continue;      // l'altra isola resta fuori portata, per ora","const x=tx+i,y=ty+j;if(!freeT(x,y)||(WORLD!==2&&x>=64))continue;      // l'altra isola resta fuori portata, per ora")
rep("if(e.type==='reef'&&(e.tx<56||e.tx>76+I2))continue;","if(e.type==='reef'&&WORLD!==2&&(e.tx<56||e.tx>76+I2))continue;")
rep("cam.x=(34+Math.sin(t*.06)*14)*TS;cam.y=(32+Math.cos(t*.045)*8)*TS;camClamp();","cam.x=((WORLD===2?40:34)+Math.sin(t*.06)*14)*TS;cam.y=((WORLD===2?30:32)+Math.cos(t*.045)*8)*TS;camClamp();")
open(p,'w',encoding='utf8').write(s)
print('ok')
