const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1600,height:900},deviceScaleFactor:1})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({silver:0,pris:0,hull:10,max:10,kills:0,t:0}))}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(3000);
const shots=JSON.parse(process.argv[2]);// [[deck,gx,gy,uz,name],...]
for(const [d,gx,gy,uz,name] of shots){
 await p.evaluate(([d,gx,gy,uz])=>{const K=Ch4.K;Ch4.setDeck(d,35,d===0?3.95:10.5);K.gd.forEach(g=>{g.ko=1e9});K.fol.concat(K.stay).forEach(f=>{f.x=-999;f.y=-999});Ch4.cam.uz=uz;K.say=[];K.sayT=0;document.getElementById('c4say').style.display='none';window.__fx=[Ch4.cam,gx,gy]},[d,gx,gy,uz]);
 await p.waitForTimeout(300);
 await p.evaluate(([gx,gy])=>{Ch4.tp(gx,gy)},[gx,gy]);await p.waitForTimeout(400);
 await p.evaluate(([gx,gy])=>{Ch4.tp(gx,gy)},[gx,gy]);await p.waitForTimeout(200);
 await p.screenshot({path:name+'.png'});}
console.log(er);await b.close()})();
