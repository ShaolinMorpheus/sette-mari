const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1000,height:500}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0}))}catch(e){}});
await p.goto('file:///home/claude/out/galeone_giocabile.html');await p.waitForTimeout(2500);
console.log(await p.evaluate(()=>[typeof Ch4,Ch4.K.deck,!!Ch4.K.carry,document.getElementById('c4use')?1:0]),er);await b.close()})();
