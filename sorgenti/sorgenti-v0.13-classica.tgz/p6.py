p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:70],s.count(a))
    s=s.replace(a,b)
# sign
rep("sign:[25.8,29.4],","sign:[27.5,32.6],")
# chapters
rep('Alleanze, diffidenza e una nave da trovare.",st:"In programma"}','Alleanze, diffidenza e una nave da trovare. Si inizia dal Capitolo 1, sbarcando sull\'isola dei fuggiaschi.",st:"Giocabile"}')
rep("const st=c.n===1&&S.flags.ch1?'Completato':c.st,","const st=(c.n===1&&S.flags.ch1)||(c.n===2&&S.flags.ch2end)?'Completato':c.st,")
rep("<p class=\"sm\">In programma: Capitolo 2 «La Baia dei Fuggiaschi». Intanto puoi tornare sull\\'isola e finire le missioni secondarie.</p>","<p class=\"sm\">Il Capitolo 2 «La Baia dei Fuggiaschi» è pronto: puoi iniziarlo qui sotto, oppure tornare sull\\'isola e finire le missioni secondarie.</p>")
# ship sprites
rep("SP.wreck=mkShipSprite(PAL_OUR,true);","SP.wreck=mkShipSprite(PAL_OUR,true);SP.wreck2=mkShipSprite(PAL_FUG,true);SP.shipFix=mkShipSprite(PAL_FUG,false);")
rep("const PAL_RIV=","const PAL_FUG={sail:['#d3e6ec','#5f93a8'],flag:'#22344c',emblem:'claw',hull:['#4d5b50','#27312c']};\nconst PAL_RIV=")
s=s.replace("deco('nave','wreck',","deco('nave','wreck2',")
s=s.replace("const sp=c.parts.yard?'shipOur':'wreck';","const sp=c.parts.yard?'shipFix':'wreck2';")
s=s.replace("EID.nave.spr=c.parts.yard?'shipOur':'wreck';","EID.nave.spr=c.parts.yard?'shipFix':'wreck2';")
s=s.replace("e.spr='shipOur';","e.spr='shipFix';")
# raft home on mainland (ch2)
rep("  const rx=P.x,ry=P.y,hd=P.hd,mr=EID.mraft;\n  P.mode='walk';","  const rx=P.x,ry=P.y,hd=P.hd,mr=EID.mraft;\n  if(WORLD===2&&!forceHome&&spot&&Ch2.mainLand(spot)){forceHome=true;UI.toast('La zattera torna alla spiaggia di casa.')}\n  P.mode='walk';")
# NPC walking: draw
rep("  const o={k:CH[e.who],dir:'f',flip:near?dx<0:e.flip,t:t+e.ph,walk:0,moving:false,look:near?clamp(dx/160,-1,1):0};","  const o={k:CH[e.who],dir:'f',flip:e.mv?e.flip:near?dx<0:e.flip,t:t+e.ph,walk:e.wk||0,moving:!!e.mv,look:near&&!e.mv?clamp(dx/160,-1,1):0};")
rep("Ch2.tick=function(dt){\n  const c=C();","Ch2.tick=function(dt){\n  const c=C();\n  Ch2.npcAI(dt);")
ai=r'''
/* ---------- i personaggi si muovono e commentano ---------- */
Ch2.mainLand=function(spot){
  if(!Ch2._bf){const f=FIX_2.spawn;Ch2._bf=bfsFrom(Math.floor(f[0]),Math.floor(f[1]))}
  return Ch2._bf.dist[tIdx(spot[0],spot[1])]>=0;
};
Ch2.SAY={
  tree:{ferro:["Buon legno. Troppo buono da sprecare.","Un albero in piedi vale più di cento parole."],nives:["Questo ramo farebbe un manico perfetto.","Che bel tronco… quasi quanto il mio martello."],tito:["Questo albero mi guarda male.","Sai che gli alberi sentono tutto? Io non ho detto niente."],gnocco:["Se facesse frutti… invece fa solo ombra.","Un albero senza frutti è come un piatto senza sale."]},
  fire:{ferro:["Il fuoco non va mai lasciato solo."],nives:["Il fuoco è l'unico collega che non mi contraddice."],tito:["Il fuoco è caldo. Notizia del giorno."],gnocco:["Pentola, fuoco, fame. La santa trinità."]},
  stall:{ferro:["Ordine. Tutto al suo posto."],nives:["Manca un attrezzo. Non guardate me."],tito:["Posso toccare? ...No. Va bene."],gnocco:["Sento odore di ferro. E di sale."]},
  sea:{ferro:["La nave parte quando il mare lo permette."],nives:["Il mare è bello. Finché non lo devi attraversare."],tito:["Un pesce! No, un'onda."],gnocco:["In quel mare c'è la cena. Spero."]},
  wander:{ferro:["Controllo il perimetro."],nives:["Mi sgranchisco le gambe e il carattere."],tito:["Io passavo di qui. Per caso."],gnocco:["Cerco ispirazione. E sale."]}
};
Ch2.PAIRS=[['nives','ferro',"Ferro, sorridi ogni tanto. Costa poco.","Il sorriso non è nel regolamento."],['gnocco','tito',"Tito, assaggia questo.","È... salato. Molto. Davvero tanto."],['tito','nives',"Nives, mi presti il martello?","No."],['gnocco','ferro',"Capo, stasera brodo di pesce!","Come ieri."],['nives','gnocco',"Il tuo brodo ha un nuovo colore.","Si chiama «carattere»."],['ferro','tito',"Tito. Le corde.","Sì, capo! Già fatte! ...quasi."]];
Ch2.spots=function(w){
  const d=Ch2.NPC[w],hx=d.at[0],hy=d.at[1],L=[];
  for(const e of E){
    if(e.type==='tree'||e.type==='pine'||e.type==='palm'){
      if(e.alive===false||e.id==='mast')continue;
      if(hyp(e.tx-hx,e.ty-hy)>8)continue;
      L.push({k:'tree',tx:e.tx,ty:e.ty});
    }
  }
  L.push({k:'fire',tx:57,ty:31},{k:'stall',tx:62,ty:31},{k:'stall',tx:60,ty:31});
  if(w==='tito'||w==='ferro')L.push({k:'sea',tx:66,ty:36});
  return L;
};
Ch2.npcAI=function(dt){
  const night=S.tod>=22||S.tod<6;
  Ch2._pc=(Ch2._pc||30)-dt;
  for(const w in Ch2.NPC){
    const e=EID['npc_'+w];if(!e)continue;
    if(e.wt==null){e.wt=2+Math.random()*8;e.mv=0;e.wk=0}
    const pd=hyp(P.x-e.x,P.y-e.y);
    if(e.mv){
      const g=e.tgt,dx=g.x-e.x,dy=g.y-e.y,dist=hyp(dx,dy);
      if(dist<5||pd<1.3*TS){e.mv=0;e.wt=3+Math.random()*4;if(dist<5&&g.k){const L=Ch2.SAY[g.k][w];if(L&&(g.k!=='wander'||Math.random()<.4)&&pd<16*TS){say(e,L[(Math.random()*L.length)|0],4.2);e.wt=7+Math.random()*6}}continue}
      const sp=54*dt,nx=e.x+dx/dist*sp,ny=e.y+dy/dist*sp,ntx=Math.floor(nx/TS),nty=Math.floor(ny/TS);
      if((ntx!==e.tx||nty!==e.ty)){
        if(!freeT(ntx,nty)){e.mv=0;e.wt=2;continue}
        delBlock(e);addBlock(e,ntx,nty,1,1);e.tx=ntx;e.ty=nty;
      }
      e.x=nx;e.y=ny;e.flip=dx<0;e.wk+=dt*3.3;
      continue;
    }
    e.wt-=dt;
    if(e.wt>0||night||pd<2.4*TS)continue;
    e.wt=4+Math.random()*6;
    const sps=Ch2.spots(w);
    for(let tr=0;tr<8;tr++){
      const s0=Math.random()<.25?{k:'wander',tx:Math.floor(Ch2.NPC[w].at[0]+(Math.random()-.5)*10),ty:Math.floor(Ch2.NPC[w].at[1]+(Math.random()-.5)*8)}:sps[(Math.random()*sps.length)|0];
      const f=s0.k==='tree'?nearestFree(s0.tx,s0.ty+1,1):freeT(s0.tx,s0.ty)?[s0.tx,s0.ty]:nearestFree(s0.tx,s0.ty,1);
      if(!f)continue;
      if(hyp(f[0]-Ch2.NPC[w].at[0],f[1]-Ch2.NPC[w].at[1])>9)continue;
      // percorso in linea retta senza ostacoli
      const x0=e.x/TS,y0=e.y/TS,x1=f[0]+.5,y1=f[1]+.92;let ok=true;
      const n=Math.ceil(hyp(x1-x0,y1-y0)*3);
      for(let i=1;i<=n;i++){const a=Math.floor(x0+(x1-x0)*i/n),b=Math.floor(y0+(y1-y0)*i/n);if((a!==e.tx||b!==e.ty)&&!freeT(a,b)&&!(a===f[0]&&b===f[1]&&false)){ok=false;break}}
      if(!ok)continue;
      e.tgt={x:(f[0]+.5)*TS,y:(f[1]+.92)*TS,k:s0.k};e.mv=1;break;
    }
  }
  // due personaggi vicini si parlano
  if(Ch2._pc<=0&&hyp(P.x-CP.x,P.y-CP.y)<15*TS&&!night){
    for(const pr of Ch2.PAIRS){
      const a=EID['npc_'+pr[0]],b=EID['npc_'+pr[1]];
      if(a&&b&&!a.mv&&!b.mv&&hyp(a.x-b.x,a.y-b.y)<3.4*TS){
        Ch2._pc=45+Math.random()*30;say(a,pr[2],3.6);a.flip=b.x<a.x;b.flip=a.x<b.x;
        setTimeout(()=>{if(S&&S.live)say(b,pr[3],3.6)},2800);break}
    }
  }
};
'''
rep("Ch2._th=0;\n","Ch2._th=0;\n"+ai)
open(p,'w',encoding='utf8').write(s)
