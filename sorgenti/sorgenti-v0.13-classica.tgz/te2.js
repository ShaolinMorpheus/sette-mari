const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{Pirati.S.tod=12;const e=Pirati.EID.clue2;Pirati.P.x=e.x+60;Pirati.P.y=e.y+30;Pirati.cam.x=e.x;Pirati.cam.y=e.y-60;Pirati.cam.uz=.8});await p.waitForTimeout(1500);await clr();
console.log(await p.evaluate(()=>[Pirati.EID.clue2.x/44,Pirati.EID.clue2.y/44,JSON.stringify(Pirati.tinfo())]));
await p.screenshot({path:'clue2.png'});
await p.evaluate(()=>{const e=Pirati.EID.c2cannon;Pirati.P.x=e.x+10;Pirati.P.y=e.y+36;Pirati.cam.x=e.x;Pirati.cam.y=e.y});await p.waitForTimeout(800);
console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
console.log(er);await b.close()})();
