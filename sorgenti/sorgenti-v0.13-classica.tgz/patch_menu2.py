import json
p='base_index.html';s=open(p,encoding='utf8').read()
i=s.index('var PACK=');arr,end=json.JSONDecoder().raw_decode(s[i+9:])
arr.append(["Altro…","More…","Mehr…","Más…","Autre…"])
s=s[:i]+'var PACK='+json.dumps(arr,ensure_ascii=False)+s[i+9+end:]
open(p,'w',encoding='utf8').write(s)
