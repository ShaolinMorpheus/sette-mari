const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(450,400);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{const c=Pirati.Ch2.st();c.met.nives=1;Pirati.Ch2.openTrade()});await p.waitForTimeout(800);
const box=await p.evaluate(()=>{const e=document.querySelector('#sheetCard .cost:not([data-k])');e.scrollIntoView();const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]});
await p.mouse.click(box[0],box[1]);await p.waitForTimeout(300);
console.log(await p.evaluate(()=>[...document.querySelectorAll('.tipx')].map(x=>x.textContent+' @'+x.style.left+','+x.style.top+' in '+x.parentNode.id)));
await p.screenshot({path:'tip2.png'});console.log(er);await b.close()})();
