const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(2000);await p.evaluate(()=>Pirati.startNew&&Pirati.startNew());await p.waitForTimeout(3000);
console.log(await p.evaluate(()=>{const G=Pirati.cave.G;if(!G)return 'noG';const W=G[0].length,H=G.length;const seen=new Set(),q=[[12,10]];seen.add('12,10');let n=0;while(q.length){const[x,y]=q.pop();n++;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const a=x+dx,b=y+dy;if(a<0||b<0||a>=W||b>=H||G[b][a]!==1||seen.has(a+','+b))continue;seen.add(a+','+b);q.push([a,b])}}let tot=0;G.forEach(r=>r.forEach(v=>{if(v===1)tot++}));return {reach:n,tot,rows:G.map(r=>r.map(v=>'#.~'[v]).join('')).join('\n')}}));
await b.close();console.log(er)})();
