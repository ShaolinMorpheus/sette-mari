const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:915,height:412},deviceScaleFactor:3})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.removeItem('sm_c34')}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2800);
await p.evaluate(()=>{Ch4.tp(37,9.4);const K=Ch4.K;K.gd.forEach(g=>{g.ko=1e9});K.fol.forEach(f=>{f.x+=900})});await p.waitForTimeout(600);
const dirs=[['E',1,0],['SE',.7,.7],['S',0,1],['SW',-.7,.7],['W',-1,0],['NW',-.7,-.7],['N',0,-1],['NE',.7,-.7]];
let n=0;
for(const mode of['idle','swing','parry']){
 for(const [nm,dx,dy] of dirs){
  await p.evaluate(([mode,dx,dy])=>{const K=Ch4.K,P=Ch4.P;K.fdx=dx;K.fdy=dy;if(Math.abs(dx)>.1)P.flip=dx<0;K.inv=9;K.parry=false;K.swingT=0;
    if(window.__fz)clearInterval(window.__fz);if(mode==='swing'){window.__fz=setInterval(()=>{K.swingT=.16},3)}if(mode==='parry'){K.parry=true;K.parT=1}},[mode,dx,dy]);
  await p.screenshot({path:`sab/${mode}_${nm}.png`,clip:{x:915/2-70,y:412/2-70,width:140,height:120}});
 }
}
await p.evaluate(()=>{Ch4.K.parry=false});
console.log(er);await b.close()})();
