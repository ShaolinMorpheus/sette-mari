const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));p.on('console',m=>{if(m.type()==='error'&&!/googleapis|ERR_|Failed to load/.test(m.text()))console.log('CON',m.text())});
await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;localStorage.setItem(P.saveKey(),JSON.stringify(P.Ch2.convert(P.newState('Davide','m'))));P.startContinue('',null)});
await p.waitForTimeout(1200);
const clr=async()=>{for(let k=0;k<5;k++){await p.evaluate(async()=>{for(let i=0;i<120&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,30))}});await p.waitForTimeout(600)}};
const st=async(l)=>console.log(l,await p.evaluate(()=>{const q=Pirati.S.q;return Object.keys(q).map(k=>k+':'+q[k].st[0]+q[k].gi).join(' ')}));
const ev=(f,a)=>p.evaluate(f,a);
await clr();
// c1
await ev(()=>Pirati.Story.onDrink());await clr();await st('c1');
// c2
await ev(()=>{Pirati.S.built.falo=1;Pirati.S.built.capanna=1;Pirati.Story.onGain()});await clr();await st('c2');
// c3
await ev(()=>Pirati.tp(57.4,30.2));await p.waitForTimeout(800);await clr();await st('c3');
// c4
await ev(()=>{Object.assign(Pirati.S.res,{legna:30,pietra:20,arrosto:9,coco:12,tela:9,corda:20,rottami:20,molluschi:4,bacche:4});Pirati.Ch2.talk(Pirati.EID.npc_ferro)});await clr();await st('c4');
// c5
for(const w of['nives','gnocco','tito']){await ev(w=>Pirati.Ch2.talk(Pirati.EID['npc_'+w]),w);await clr()}await st('c5');
// c6
await ev(()=>Pirati.Ch2.talk(Pirati.EID.npc_ferro));await clr();await st('c6a');
await ev(()=>Pirati.tp(68.6,48.6));await p.waitForTimeout(800);await clr();await st('c6b');
// c7 real chop
await ev(()=>{Pirati.S.flags.axe=1;Pirati.S.up.axe=1;Pirati.fast(1);const m=Pirati.EID.mast;Pirati.tp(m.tx+.5,m.ty+1.8)});
const r=await ev(async()=>{Pirati.go('mast');for(let i=0;i<400;i++){await new Promise(r=>setTimeout(r,100));if(Pirati.S.c2.parts.mast)return i}return -1});console.log('mast chop ticks',r);
await clr();await st('c7');
// c8
await ev(()=>{Pirati.Ch2.addTrust('tito',4);Pirati.Story.onGain()});await p.waitForTimeout(800);
await ev(()=>Pirati.Ch2.talk(Pirati.EID.npc_tito));await clr();await st('c8a');
await ev(()=>{Pirati.S.up.torch=1;Pirati.S.torchOn=true;Pirati.Ch2.look(Pirati.EID.cave)});await clr();await st('c8b');
// c9
await ev(()=>Pirati.Ch2.talk(Pirati.EID.npc_nives));await clr();await p.waitForTimeout(500);await st('c9');
// c10
await ev(()=>Pirati.Ch2.look(Pirati.EID.nave));await clr();await st('c10');
console.log('ship spr',await ev(()=>Pirati.EID.nave.spr));
// c11
await ev(()=>{Pirati.S.tod=20;Pirati.tp(57.4,30.2)});await p.waitForTimeout(1500);await clr();await st('c11');
// c12
await ev(()=>Pirati.Ch2.talk(Pirati.EID.npc_gnocco));await clr();await st('c12');
// trade
await ev(()=>Pirati.Ch2.openTrade());await p.waitForTimeout(300);await p.screenshot({path:'t2_trade.png'});
await ev(()=>{document.querySelector('[data-t="2"]').click()});console.log('after trade rottami',await ev(()=>Pirati.S.res.rottami));await ev(()=>document.getElementById('shNo').click());
// launch
await ev(()=>Pirati.Ch2.look(Pirati.EID.nave));await p.waitForTimeout(300);
for(let i=0;i<10;i++){await ev(()=>{const c=document.getElementById('dlgChoices');if(c&&c.children.length)return;Pirati.dlgAuto()});await p.waitForTimeout(150)}
await p.screenshot({path:'t2_launch.png'});
await ev(()=>Pirati.UI.dlgPick(1));await clr();await p.waitForTimeout(1500);
console.log('end',await ev(()=>({e:Pirati.S.flags.ch2end,tr:Pirati.S.c2.trust,card:!document.getElementById('endcard').hidden})));
await p.screenshot({path:'t2_end.png'});
await b.close()})();
