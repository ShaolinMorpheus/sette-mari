import re
p='ch4_inject.js';s=open(p,encoding='utf8').read()
L=s.split('\n')
def seg(a,b): # 1-based inclusive line range
    return a-1,b
# ---- locate by markers
def idx(m,start=0):
    for i in range(start,len(L)):
        if L[i].startswith(m):return i
    raise Exception(m)
i_pian=idx('/* ---------------- pianta della nave')
i_rn=idx('  return null};',i_pian)
i_props=idx('/* ---------------- oggetti di scena')
i_stato=idx('/* ---------------- stato')
i_gp=idx('const GP=')
i_logica=idx('/* ---------------- logica')
i_goal=idx('function goal(){')
i_prog=idx('function progress(){')
i_obj=idx('function objects(){')
i_near=idx('function nearObj(){')
i_enter=idx('const ENTER={')
i_quip=idx('function quip(){')
# ---------------- NEW layout block
layout=r"""/* ---------------- pianta della nave (3 ponti) ---------------- */
const G=[];
for(let y=0;y<SH;y++){G.push([]);for(let x=0;x<SW;x++)G[y].push(' ')}
const inHull=(x,y)=>{const xx=x+.5,yy=y+.5;let half=7.7;if(xx<5)half*=Math.sqrt(Math.max(0,1-Math.pow((5-xx)/5,2)));else if(xx>40)half*=Math.max(0,1-Math.pow((xx-40)/15,1.7));return Math.abs(yy-9)<=half};
const isIn=(x,y)=>x>=0&&y>=0&&x<SW&&y<SH&&G[y][x]!==' ';
let bord=[],DK=0;
const R=(x0,y0,x1,y1,f)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(G[y]&&G[y][x]==='.')G[y][x]=f};
const Wl=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(G[y]&&G[y][x]&&G[y][x]!==' ')G[y][x]='#'};
const Ds=(x,y,ch)=>{if(G[y]&&G[y][x]&&G[y][x]!==' ')G[y][x]=ch};
const DECKN=['Ponte di comando','Ponte di mezzo','La stiva'];
function layout(n){
  DK=n;
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++)G[y][x]=inHull(x,y)?'.':' ';
  bord=[];
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++)if(isIn(x,y)&&(!isIn(x-1,y)||!isIn(x+1,y)||!isIn(x,y-1)||!isIn(x,y+1)))bord.push([x,y]);
  for(const[x,y]of bord)G[y][x]='#';
  const fl=[['c','q','k','q','p'],['s','q','k','s','p'],['s','s','s','s','s']][n];
  R(1,2,10,15,fl[0]);R(12,2,30,4,fl[1]);R(12,13,21,15,fl[2]);R(23,13,30,15,fl[3]);R(41,2,46,15,fl[4]);
  Wl(11,2,11,15);Ds(11,8,'D');Ds(11,9,'D');
  Wl(11,5,31,5);Ds(15,5,'D');Ds(26,5,'D');
  Wl(11,12,31,12);Ds(15,12,'D');Ds(26,12,n===2?'H':'D');
  Wl(22,13,22,15);
  Wl(31,2,31,15);Ds(31,8,'D');Ds(31,9,'D');
  Wl(40,2,40,15);Ds(40,8,n===1?'L':'D');Ds(40,9,n===1?'L':'D');
  Wl(47,0,SW-1,SH-1);
}
layout(0);
const FLOOR='.cqkps';
const roomAt=(gx,gy)=>{
  if(gx<=10)return'cabin';
  if(gx>=40&&gx<=46)return'cell';
  if(gx>=32&&gx<=39)return'mid';
  if(gx>=12&&gx<=30){if(gy<=4)return'quarters';if(gy>=13)return gx<=21?'galley':'hold';return'corr'}
  return null};
const STAIRS=[{d:[37,10.5]},{u:[37,10.5],d:[37,3.5]},{u:[37,3.5]}];"""
# ---------------- props etc
props=r"""/* ---------------- oggetti di scena ---------------- */
const mid_=[['mast',35,8,1,1],['cannon',33,15,1,1,{d:1}],['cannon',36,15,1,1,{d:1}],['cannon',38,15,1,1,{d:1}]];
const PROPS_BY=[
 [['bed',2,3,2,2],['desk',6,6,3,1,{obj:'desk'}],['chest',3,13,1,1,{obj:'k1'}],['table',7,11,2,1],
  ['mast',21,8,1,1],['barrel',13,10,1,1],['barrel',29,6,1,1],['barrel',29,10,1,1],
  ['bunk',13,2,2,1,{c:'#7a8a5a'}],['bunk',16,2,2,1,{c:'#a8503a'}],['bunk',19,2,2,1,{c:'#5a7a9a'}],['bunk',22,2,2,1,{c:'#a8503a'}],['bunk',25,2,2,1,{c:'#7a8a5a'}],['bunk',28,2,2,1,{c:'#5a7a9a'}],['table',20,4,2,1],
  ['table',14,14,3,1],['barrel',13,13,1,1],['barrel',20,15,1,1],['barrel',24,13,1,1],['barrel',29,13,1,1],['barrel',24,15,1,1],['cannon',27,15,1,1,{d:1}],
  ['mast',35,8,1,1],['barrel',33,3,1,1],['barrel',33,14,1,1],['cannon',33,2,1,1,{d:-1}],['cannon',38,2,1,1,{d:-1}],['cannon',33,15,1,1,{d:1}],['cannon',36,15,1,1,{d:1}],['cannon',38,15,1,1,{d:1}],
  ['cannon',42,2,1,1,{d:-1}],['cannon',45,2,1,1,{d:-1}],['barrel',42,14,1,1],['barrel',45,14,1,1],['barrel',45,13,1,1]],
 [['bunk',2,4,2,1,{c:'#7a8a5a'}],['bunk',2,6,2,1,{c:'#a8503a'}],['bunk',2,11,2,1,{c:'#5a7a9a'}],['bunk',2,13,2,1,{c:'#a8503a'}],['bunk',7,4,2,1,{c:'#5a7a9a'}],['bunk',7,6,2,1,{c:'#7a8a5a'}],['bunk',7,11,2,1,{c:'#a8503a'}],['bunk',7,13,2,1,{c:'#7a8a5a'}],
  ['table',14,2,3,1],['table',20,2,3,1],['table',26,2,3,1],['barrel',13,4,1,1],['barrel',29,4,1,1],
  ['mast',21,8,1,1],['barrel',13,10,1,1],['barrel',29,6,1,1],
  ['stove',13,13,2,1],['table',17,13,2,1],['barrel',16,15,1,1],['barrel',17,15,1,1],['barrel',18,15,1,1],['barrel',19,15,1,1,{obj:'k2',red:1}],
  ['barrel',23,13,1,1],['barrel',30,13,1,1],['barrel',23,15,1,1],['barrel',30,15,1,1],['barrel',25,13,1,1],
  ['mast',35,8,1,1],['barrel',33,14,1,1],['cannon',33,2,1,1,{d:-1}],['cannon',38,2,1,1,{d:-1}],['cannon',33,15,1,1,{d:1}],['cannon',36,15,1,1,{d:1}],['cannon',38,15,1,1,{d:1}],
  ['barrel',42,14,1,1],['barrel',45,14,1,1]],
 [['barrel',2,5,1,1],['barrel',3,5,1,1],['barrel',2,6,1,1],['barrel',8,5,1,1],['barrel',9,5,1,1],['barrel',9,6,1,1],['barrel',2,12,1,1],['barrel',3,12,1,1],['barrel',8,12,1,1],['barrel',9,12,1,1],['barrel',9,11,1,1],
  ['barrel',13,2,1,1],['barrel',14,2,1,1],['barrel',13,3,1,1],['barrel',24,2,1,1],['barrel',25,2,1,1],['barrel',29,3,1,1],['barrel',29,4,1,1],
  ['mast',21,8,1,1],['barrel',13,10,1,1],['barrel',29,6,1,1],
  ['barrel',13,14,1,1],['barrel',14,14,1,1],['barrel',13,15,1,1],['barrel',19,14,1,1],['barrel',20,14,1,1],
  ['crate',24,14,1,1,{obj:'c0'}],['crate',26,14,1,1,{obj:'c1'}],['crate',28,14,1,1,{obj:'c2'}],['crate',24,15,1,1,{obj:'c3'}],['crate',26,15,1,1,{obj:'c4'}],['crate',28,15,1,1,{obj:'c5'}],['barrel',30,14,1,1],['barrel',30,15,1,1],
  ['mast',35,8,1,1],['cannon',33,15,1,1,{d:1}],['cannon',36,15,1,1,{d:1}],['cannon',38,15,1,1,{d:1}],['barrel',33,3,1,1],
  ['barrel',43,3,1,1],['barrel',44,3,1,1],['barrel',45,13,1,1],['barrel',45,14,1,1],['barrel',42,14,1,1]]
];
const LAMPS_BY=[
 [[9,3],[3,9],[8,13],[14,9],[20,9],[27,9],[14,3],[24,3],[14,14],[27,14],[44,4],[44,13],[35,5],[35,12]],
 [[3,8],[8,8],[14,9],[20,9],[27,9],[18,3],[24,3],[14,14],[27,14],[44,4],[44,13],[35,5],[35,12]],
 [[5,8],[20,9],[27,13],[16,14],[35,5],[35,12],[44,8],[20,3]]];
let PROPS=PROPS_BY[0],LAMPS=LAMPS_BY[0];
const propAt=(tx,ty)=>{const gx=tx-OX,gy=ty-OY;return PROPS.some(p=>gx>=p[1]&&gx<p[1]+p[3]&&gy>=p[2]&&gy<p[2]+p[4]&&p[0]!=='mast')};
"""
# remove old PROPS/LAMPS block (between i_props and i_stato) and the old propAt line later
# ---------------- build ents per deck
ents=r"""const GP_BY=[
 [[[14,9],[28,9]],[[28,7],[15,7]],[[33,13],[38,13],[38,10],[33,10]],[[42,4],[45,4],[45,12],[42,12]],[[45,8],[42,8]]],
 [[[14,8],[29,8]],[[29,10],[14,10]],[[33,6],[38,6],[38,12],[33,12]],[[13,14],[21,14]],[[14,4],[29,4]]],
 [[[14,8],[29,8]],[[16,10],[28,10]],[[37,13],[37,7]],[[3,8],[9,8]],[[24,13],[29,13]]]];
const DUELS_BY=[
 [['guardia',24,11,'barba',26,11],['lupo',36,5,'guardia',38,5]],
 [['barba',4,8,'lupo',6,8]],
 [['lupo',33,10,'guardia',35,10]]];
const DECKS=[{},{},{}];
function mkGuard(wp,n){return mkChar('guardia',wp[0][0],wp[0][1],{dk:n,guard:1,wp,wi:1,st:'patrol',ko:0,seen:0,hitCd:0,alert:0,wait:0,hp:3,maxhp:3,flash:0,swing:0,fight:null,fightT:0})}
function buildDeckEnts(n,D){
  D.props=[];
  for(const p of PROPS_BY[n]){const[kind,gx,gy,gw,gh,o]=p;
    const e=ent(Object.assign({id:'c4p'+E.length,type:'c4',k:'prop',dk:n,kind,gx,gy,gw,gh,x:(OX+gx+gw/2)*T,y:(OY+gy+gh)*T-3},o||{}));
    e.fp=[OX+gx,OY+gy,gw,gh];D.props.push(e)}
  D.gd=GP_BY[n].map(wp=>mkGuard(wp,n));
  D.duels=DUELS_BY[n].map(([w1,x1,y1,w2,x2,y2])=>[mkChar(w1,x1,y1,{dk:n,duel:1,fixed:1,flip:false,sd:0}),mkChar(w2,x2,y2,{dk:n,duel:1,fixed:1,flip:true,sd:1})]);
  for(const[a,b]of D.duels){a.mate=b;b.mate=a;a.cd=rr(.3,1);b.cd=rr(.6,1.4);a.sw=b.sw=0}
  D.cap=[];
  if(n===1){D.cap=[mkChar('pip',44,6,{dk:1,cap:1,flip:false}),mkChar('dodo',44,11,{dk:1,cap:1,flip:true})];for(const c of D.cap)initAlly(c)}
  D.objs=objectsFor(n);
}
function initAllyNone(){}
function setDeck(n,gx,gy,first){
  K.deck=n;layout(n);LAMPS=LAMPS_BY[n];PROPS=PROPS_BY[n];setupWorld();
  if(K.cell)openDoor('cell');if(K.hold)openDoor('hold');
  const D=DECKS[n];if(!D.built){D.built=true;buildDeckEnts(n,D)}
  for(const e of D.props)blockRect(e.fp[0],e.fp[1],e.fp[2],e.fp[3],1);
  K.gd=D.gd;K.duels=D.duels;K.cap=D.cap;K.objs=D.objs;
  if(!DECKS[n].img){bake();DECKS[n].img=SHIPC}SHIPC=DECKS[n].img;
  P.x=cx(gx);P.y=(OY+gy)*T;cam.x=P.x;cam.y=P.y;K.fx=[];K.field=null;
  const offs=[[-1.3,.9],[0,1.3],[1.3,.9],[-1.9,1.9],[1.9,1.9],[0,2.2],[-.8,2.6],[.8,2.6],[-1.4,-.8],[1.4,-.8]];
  let k=0;
  for(const f of K.fol){f.go=false;f.busy=false;f.fight=null;f.wt=rr(1,3);
    for(let t=0;t<offs.length;t++){const o=offs[(k+t)%offs.length],x=P.x+o[0]*T,y=P.y+o[1]*T;if(inFree(x,y)){f.x=x;f.y=y;break}f.x=P.x;f.y=P.y+4}k++}
  K.tr=[{x:P.x,y:P.y}];
  try{const fd=$('c4fade');if(fd&&!first){fd.style.opacity=1;setTimeout(()=>{fd.style.opacity=0},180)}}catch(e){}
  if(!first)toast(DECKN[n]);
}
function takeStairs(dir){
  const n=K.deck+(dir==='d'?1:-1);if(n<0||n>2)return;
  sfx('ok');const st=STAIRS[n],al=dir==='d'?st.u:st.d;
  setDeck(n,al[0],al[1]+(dir==='d'?-1.1:1.7));
}
"""
# ---------------- goal
goal=r"""function stairsGoal(want){const d=want>K.deck?'d':'u',st=STAIRS[K.deck][d];return[cx(st[0]),(OY+st[1])*T,want>K.deck?'Scendi: la scala è nel ponte aperto, vicino al grande albero a prua.':'Sali: la scala è nel ponte aperto, vicino al grande albero a prua.']}
function goalDeck(){if(!K.key1)return 0;if(!K.cell||!K.key2)return 1;if(!K.hold||K.silver<6)return 2;return 0}
function goal(){
  const want=goalDeck();if(K.deck!==want)return stairsGoal(want);
  if(!K.key1)return[cx(3),cy(13),'La chiave della cella: cerca a poppa, nella cabina del comandante.'];
  if(!K.cell)return[cx(39),cy(8.5),'La cella dei prigionieri è a prua, oltre il ponte aperto.'];
  if(!K.key2)return[cx(19),cy(15),'Ora serve la chiave della stiva: la cambusa è a sud del corridoio.'];
  if(!K.hold)return[cx(26),cy(12),'La porta della stiva è nel corridoio, lato sud.'];
  if(K.silver<6)return[cx(26),cy(14),'L\'argento è nella stiva: prendi quel che puoi.'];
  return[cx(35),cy(2),'Via! La passerella verso la Sirena è a nord, sul ponte aperto.']}
function objText(){
  if(!K.key1)return'Trova la chiave della cella';
  if(!K.cell)return'Libera Pip e Dodo';
  if(!K.key2)return'Trova la chiave della stiva';
  if(!K.hold)return'Apri la stiva';
  if(K.silver<6)return'Prendi l\'argento ('+K.silver+'/6)';
  return'Torna sulla Sirena'}
"""
objs=r"""function objectsFor(n){
  const L=[];
  const o=(id,x,y,label,use,on)=>L.push({id,x,y,label,use,on:on||(()=>true)});
  const sx=cx(37),sy=(OY+11)*T-10;
  if(n===0){
    o('desk',cx(7),cy(7),'Scrivania',()=>{
      if(!K.readDesk){K.readDesk=true;progress();say('Diario',"«La chiave della stiva la tiene il cuoco, nel barile col tappo rosso. Non la perdo mai di vista.»",7000);say('Biscotto','Barile col tappo rosso: la cambusa, sul ponte di mezzo! E la stiva è ancora più giù.',6200)}
      else say('Diario','«La chiave della cella sta nella cassapanca, sotto il letto del comandante.»',5200)});
    o('k1',cx(3),cy(14),'Cassapanca',()=>{if(K.key1)return toast('La cassapanca è vuota.');K.key1=true;progress();sfx('quest');toast('Hai la chiave della cella!');say('Tito','La cella è a prua, sul ponte di mezzo: scendiamo dalla scala nel ponte aperto.',6200)},()=>!K.key1);
    o('exit',cx(35),cy(2)-8,'Passerella',()=>leave(),()=>true);
    o('sd',sx,sy,'Scala: scendi',()=>takeStairs('d'));
  }
  if(n===1){
    o('su',cx(37),(OY+11)*T-10,'Scala: sali',()=>takeStairs('u'));
    o('sd',cx(37),(OY+4)*T-10,'Scala: scendi',()=>takeStairs('d'));
    o('cell',cx(39.4),cy(8.5),'Cella',()=>{
      if(K.cell)return;if(!K.key1){toast('È chiusa a chiave.');say('Biscotto','La chiave! Ci serve la chiave, non il pugno.');return}
      K.cell=true;openDoor('cell');progress();sfx('quest');K.pris=2;
      for(const c of K.cap){c.cap=0;c.dk=undefined;initAlly(c);K.fol.push(c)}
      toast('Pip e Dodo sono liberi!');
      say('Pip','Capitano! Sapevo che saresti venuto!');say('Dodo','Ho ancora il cucchiaio! E so dov\'è la cambusa: qui sul ponte, a sud del corridoio.',6200)},()=>!K.cell);
    o('k2',cx(19),cy(16),'Barile col tappo rosso',()=>{if(K.key2)return toast('Il barile è vuoto.');K.key2=true;progress();sfx('quest');toast('Hai la chiave della stiva!');say('Nives','La stiva è sul ponte più basso. Scendiamo dalla scala, in fondo al ponte aperto!',6200)},()=>!K.key2);
  }
  if(n===2){
    o('su',cx(37),(OY+4)*T-10,'Scala: sali',()=>takeStairs('u'));
    o('hold',cx(26),cy(11.4),'Stiva',()=>{
      if(K.hold)return;if(!K.key2){toast('La stiva è chiusa a chiave.');return}
      K.hold=true;openDoor('hold');progress();sfx('quest');say('Nives','Quanto argento... Prendiamone quanto reggono le braccia!')},()=>!K.hold);
    for(let i=0;i<6;i++){const gx=[24,26,28,24,26,28][i],gy=[14,14,14,15,15,15][i];
      o('c'+i,cx(gx),cy(gy)+8,'Cassa d\'argento',()=>{if(!K.hold||K['c'+i])return;K['c'+i]=true;K.silver++;progress();sfx('coin');toast('Cassa d\'argento! ('+K.silver+'/6)');
        if(K.silver===6)say('Biscotto','Basta così, la nave si abbassa! Risali fino al ponte aperto, poi via dalla passerella!',6200)},()=>K.hold&&!K['c'+i])}
  }
  return L}
"""
enter=r"""const ENTER_BY=[
{cabin:()=>{say('Biscotto','Una cassapanca in fondo, a sinistra! Quella con la serratura lucida.')},
 corr:()=>{say('Nives','Corridoio dei cannoni: cammina lungo i muri, le guardie fanno la ronda.')},
 quarters:()=>{say('Tito','Russano come orsi. Qui non c\'è niente di nostro: andiamo.',4200)},
 galley:()=>{say('Nives','La sala degli ufficiali. Niente di nostro, andiamo.')},
 hold:()=>{say('Tito','Barili di polvere nera. Meglio non scherzare col fuoco.')},
 cell:()=>{say('Tito','La prua: guardie di vedetta! Occhi aperti.')}},
{cabin:()=>{say('Tito','Il dormitorio della ciurma: amache vuote, c\'è sempre qualcuno di turno.')},
 corr:()=>{say('Nives','Ponte dei cannoni di mezzo. Attenti alle ronde.')},
 quarters:()=>{say('Tito','La mensa. Briciole e coltelli.')},
 galley:()=>{say('Biscotto','Odore di stufato vecchio... cerca il barile col tappo rosso!')},
 hold:()=>{say('Nives','La dispensa: sacchi e barili. Qui non c\'è argento.')},
 cell:()=>{say('Tito','Eccoli! Dietro le sbarre!')}},
{cabin:()=>{say('Nives','La santabarbara: barili di polvere dappertutto. Niente scintille!')},
 corr:()=>{say('Biscotto','La stiva: il pavimento puzza di catrame e di pezzi da otto.')},
 quarters:()=>{say('Tito','Magazzino: corde e vele di scorta.')},
 galley:()=>{say('Nives','Solo barili vuoti.')},
 hold:()=>{say('Nives','La stiva! Più argento di quanto abbia mai visto.')},
 cell:()=>{say('Tito','Zavorra e topi. Andiamo.')}}];
"""
new=[]
new+=L[:i_pian]
new+=layout.split('\n')
new+=L[i_rn+1:i_props]
new+=props.split('\n')
new+=L[i_stato:i_gp]
new+=ents.split('\n')
new+=L[i_logica:i_goal]
new+=goal.split('\n')
new+=L[i_prog:i_obj]
new+=objs.split('\n')
new+=L[i_near:i_enter]
new+=enter.split('\n')
new+=L[i_quip:]
s='\n'.join(new)
def rep(a,b,cnt=1):
    global s
    assert s.count(a)==cnt,('FAIL',s.count(a),a[:80]);s=s.replace(a,b)
# remove old propAt
a=s.index("const propAt=(tx,ty)=>{const gx=tx-OX,gy=ty-OY;return PROPS.some(p=>gx>=p[1]&&gx<p[1]+p[3]&&gy>=p[2]&&gy<p[2]+p[4]&&p[0]!=='mast')};\nfunction bfsField")
s=s[:a]+s[a:].replace("const propAt=(tx,ty)=>{const gx=tx-OX,gy=ty-OY;return PROPS.some(p=>gx>=p[1]&&gx<p[1]+p[3]&&gy>=p[2]&&gy<p[2]+p[4]&&p[0]!=='mast')};\n","",1)
# bake tweaks
rep("  // tappeto della cabina\n  {","  // tappeto della cabina\n  if(DK===0){")
rep("  g.strokeStyle='rgba(212,180,90,.7)';g.lineWidth=2;for(let i=0;i<26;i++)","  if(DK===1){g.strokeStyle='rgba(212,180,90,.7)';g.lineWidth=2;}for(let i=0;i<(DK===1?26:0);i++)")
rep("  // boccaporto sul ponte centrale\n  {","  // scale (sostituiscono il vecchio boccaporto)\n  {const st=STAIRS[DK];if(st.d)drawStairs(g,st.d[0]-1,st.d[1]-.5,false);if(st.u)drawStairs(g,st.u[0]-1,st.u[1]-.5,true)}\n  if(0){")
rep("  // luce del giorno sul ponte aperto\n  {","  // luce del giorno sul ponte aperto\n  if(DK===0){")
rep("  SHIPC=c;\n}","  {const tn=[0,.2,.38][DK];if(tn){g.fillStyle='rgba(8,12,40,'+tn+')';g.fillRect(0,0,W,H)}}\n  SHIPC=c;\n}")
rep("function bake(){","""function drawStairs(g,gx,gy,up){
  const x0=gx*T+4,y0=gy*T+6,w=3*T-8,h=2*T-12;
  g.fillStyle='#2a160a';g.fillRect(x0-4,y0-4,w+8,h+8);
  for(let i=0;i<6;i++){
    if(up){g.fillStyle=i%2?'#c09458':'#a67a42';g.fillRect(x0,y0+h-(i+1)*h/6,w,h/6);g.fillStyle='rgba(255,240,200,.22)';g.fillRect(x0,y0+h-(i+1)*h/6,w,3)}
    else{const k=i/5;g.fillStyle='rgb('+((130-k*105)|0)+','+((88-k*76)|0)+','+((44-k*40)|0)+')';g.fillRect(x0,y0+i*h/6,w,h/6);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(x0,y0+(i+1)*h/6-3,w,3)}}
  g.strokeStyle='#5a3a1c';g.lineWidth=5;g.beginPath();g.moveTo(x0,y0);g.lineTo(x0,y0+h);g.moveTo(x0+w,y0);g.lineTo(x0+w,y0+h);g.stroke();
  g.fillStyle='rgba(255,246,220,.9)';g.font='900 22px Nunito,Arial';g.textAlign='center';g.fillText(up?'▲':'▼',x0+w/2,y0+h/2+8)}
function bake(){""")
# DK for bake: setDeck calls layout(n) which sets DK
# boot
a=s.index("  setupWorld();\n  K={hp:6")
rep("  setupWorld();\n  K={hp:6","  K={hp:6")
rep("  buildEnts();K.objs=objects();\n","  K.deck=0;K.fol=[mkChar('tito',34,3),mkChar('nives',36,3),mkChar('moro',33,4),mkChar('gigi',35,4),mkChar('zeno',37,4)];\n  for(const f of K.fol)initAlly(f);\n  setDeck(0,35,3.95,true);\n")
# hud fade
rep("<div id=\"c4say\"></div>","<div id=\"c4say\"></div><div id=\"c4fade\" style=\"position:absolute;inset:0;background:#000;opacity:0;transition:opacity .22s;pointer-events:none\"></div>")
# ENTER usage
rep("if(r&&!K.rooms[r]){K.rooms[r]=1;if(K.t>2&&ENTER[r])ENTER[r]()}","const rk=K.deck+':'+r;if(r&&!K.rooms[rk]){K.rooms[rk]=1;if(K.t>2&&ENTER_BY[K.deck][r])ENTER_BY[K.deck][r]()}")
# draw filter
rep("function drawEnt(g,e,t){\n","function drawEnt(g,e,t){\n  if(e.dk!==undefined&&e.dk!==K.deck)return;\n")
# sirena only deck 0
rep("  // la Sirena attraccata sul lato nord e la passerella\n","  // la Sirena attraccata sul lato nord e la passerella\n  if(K.deck===0){\n")
open(p,'w',encoding='utf8').write(s)
