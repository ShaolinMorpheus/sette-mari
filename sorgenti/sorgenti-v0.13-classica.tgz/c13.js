const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
const U='file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html';
await p.goto(U);await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>Pirati.startNew('T','m'));
for(let i=0;i<8;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(300)}
await p.evaluate(()=>{const S=Pirati.S;S.flags.sailed=1;S.raftAt={x:34*44,y:22.6*44,hd:0};Pirati.saveGame()});
await p.reload();await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready);
await p.evaluate(()=>Pirati.startContinue&&Pirati.startContinue());await p.waitForTimeout(800);
console.log(await p.evaluate(()=>[JSON.stringify(Pirati.S.raftAt),Pirati.EID.mraft.x,Pirati.EID.plot_zattera.away]));
await b.close()})();
