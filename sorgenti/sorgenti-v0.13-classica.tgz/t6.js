const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1500);
const r=await p.evaluate(()=>{const C=Ch4,K=C.K,P=C.P;C.tp(14,8);for(const f of K.fol){f.x=P.x-20;f.y=P.y}const out=[];
 for(let i=0;i<300;i++){P.x+=1.2;C.step(1/30)}
 out.push(K.fol.map(f=>Math.round(Math.hypot(f.x-P.x,f.y-P.y))).join(','));
 for(let i=0;i<200;i++)C.step(1/30);out.push(K.fol.map(f=>Math.round(Math.hypot(f.x-P.x,f.y-P.y))).join(','));
 const g=K.gd[0];g.hp=1;g.x=P.x+500;K.atk=0;P.x=g.x-60;P.y=g.y;K.fdx=1;K.fdy=0;C.atk();for(let i=0;i<3000;i++)C.step(1/30);out.push(g.ko>0,g.st);return out});
console.log(JSON.stringify(r),errs);await b.close()})()
