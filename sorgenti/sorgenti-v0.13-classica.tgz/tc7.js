const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{Pirati.S.tod=12;Pirati.S.up.torch=1;Pirati.Ch2.addTrust('tito',3);Pirati.Ch2.st().said.rudder=1;Pirati.S.q.c8={st:'active',gi:2};Pirati.S.flags.parrot=1;Pirati.cave.enter()});await p.waitForTimeout(800);await clr();
await p.evaluate(()=>Pirati.toggleTorch());
console.log(await p.evaluate(()=>Pirati.S.torchOn));
const X0=12*44,Y0=44;
await p.evaluate(([x,y])=>{Pirati.P.x=x;Pirati.P.y=y;Pirati.cam.x=x;Pirati.cam.y=y},[X0+7.5*44,Y0+3.9*44]);await p.waitForTimeout(1500);await p.screenshot({path:'cv3_pool.png'});
// bats: go near first bat
const bt=await p.evaluate(()=>{return 0});
await p.evaluate(()=>{const B=Pirati.cavebats&&0});
await b.close();console.log(er)})();
