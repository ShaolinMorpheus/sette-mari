const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:412,height:915},hasTouch:true,isMobile:true});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>Pirati.startNew('T','m'));
for(let i=0;i<14;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(150)}
await p.evaluate(()=>{Pirati.S.flags.parrot=1;Pirati.S.phats={cuoco:1,bandana:1};(Pirati.UI||UI).openMenu()}).catch(e=>console.log(e.message));
await p.waitForTimeout(500);
console.log(await p.evaluate(()=>{const c=document.getElementById('menuCard'),m=document.getElementById('menu');const r=c.getBoundingClientRect(),a=document.getElementById('app').getBoundingClientRect();return {rot:document.body.classList.contains('rot'),card:[r.left,r.top,r.right,r.bottom].map(Math.round),app:[a.left,a.top,a.right,a.bottom].map(Math.round),sh:c.scrollHeight,ch:c.clientHeight}}));
await p.screenshot({path:'t16.png'});await b.close()})();
