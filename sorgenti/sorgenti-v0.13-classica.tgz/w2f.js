const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
const r=await p.evaluate(()=>{const P=Pirati;let f3=0,fw=0,ex=0,ok=0;for(let y=0;y<60;y++)for(let x=0;x<99;x++){const t=P.tileInfo(x,y);const f=P.forestF(x+.5,y+.5);if(f>.3){f3++;if(t.walk&&t.e>=P.WL+.27){fw++;if(P.exclTile(x,y))ex++;else ok++}}}
 return{f3,fw,ex,ok,W:P.WORLD}});
console.log(JSON.stringify(r));await b.close()})();
