const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error')errs.push(m.text())});
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1500);
console.log(await p.evaluate(()=>Object.keys(window.Ch4||{}).join()));
await p.screenshot({path:'s0.png'});
const r=await p.evaluate(async()=>{const C=window.Ch4,K=C.K,P=C.P;const o={};try{
 const g=K.gd[0];o.hp=g.hp;
 for(let i=0;i<3;i++){K.atk=0;K.fdx=(g.x>P.x)?1:-1;K.fdy=0;P.x=g.x-60*K.fdx;P.y=g.y;C.atk();o.hp+=','+g.hp+'/'+g.ko}
 for(let i=0;i<600;i++)C.step(1/30);o.ko=g.ko;o.fol=K.fol.length;
}catch(e){o.err=e.message}return o});
console.log(JSON.stringify(r),errs.slice(0,5));await p.screenshot({path:'s1.png'});await b.close()})()
