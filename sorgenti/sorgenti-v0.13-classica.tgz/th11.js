const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
// cannone
await p.evaluate(()=>{const e=Pirati.EID.c2cannon;Pirati.P.x=e.x+30;Pirati.P.y=e.y+30;Pirati.cam.x=e.x;Pirati.cam.y=e.y});await p.waitForTimeout(700);
console.log('cannone',await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(500);console.log(await p.evaluate(()=>Pirati.UI.dlgOpen()));await clr();
// clue2 visibile
await p.evaluate(()=>{const e=Pirati.EID.clue2;Pirati.P.x=e.x+40;Pirati.P.y=e.y+30;Pirati.cam.x=e.x;Pirati.cam.y=e.y});await p.waitForTimeout(900);await p.screenshot({path:'clue2.png'});
// capanna: mobili da ogni lato
await p.evaluate(()=>{Pirati.hut.enter()});await p.waitForTimeout(800);await clr();
const spots=[['h_sea',3.5,6.5],['h_sea',1.5,5.5],['h_sea',1.5,7.5],['h_chest',24.5,6.5],['h_chest',25.5,5.5],['h_ward',9.5,1.5],['h_ward',7.5,2.5],['h_bed',4.5,2.5],['h_bed',2.5,3.5],['h_hearth',12.5,1.5],['h_table',11.5,4.5],['h_table',13.5,5.5],['h_table',13.5,3.5],['h_map',20.5,3.5],['h_map',22.5,4.5]];
for(const [id,x,y] of spots){await p.evaluate(([x,y])=>{const X0=Pirati.hut.X0;Pirati.P.x=(X0+x)*44;Pirati.P.y=(1+y)*44},[x,y]);await p.waitForTimeout(150);const t=await p.evaluate(()=>{const t=Pirati.target();return t&&t.e.id});console.log(id,x,y,'->',t)}
await p.evaluate(()=>{const X0=Pirati.hut.X0;Pirati.cam.uz=.6;Pirati.P.x=(X0+7.5)*44;Pirati.P.y=(1+2.5)*44;Pirati.cam.x=Pirati.P.x;Pirati.cam.y=Pirati.P.y});await p.waitForTimeout(800);await p.screenshot({path:'hut_ward.png'});
console.log(er);await b.close()})();
