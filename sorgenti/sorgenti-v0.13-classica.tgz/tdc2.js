const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 const r=await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.built.banco=1;S.built.falo=1;S.built.capanna=1;S.built.zattera=1;
  const D=Pirati.farm.DECOR;const out=[];
  for(const k of['legna','pietra','corda','rottami','tela','pesce'])S.res[k]=500;
  Pirati.UI.openUpgrades();
  for(const d of D){const bt=document.querySelector('[data-dc="'+d.k+'"]');if(!bt){out.push(d.k+':nobtn');continue}bt.click();out.push(d.k+':'+((S.camp||[]).some(o=>o.k===d.k)?'ok':'FAIL'))}
  return out.join(' ')});
 console.log(r);console.log('ERR',JSON.stringify(errs));await b.close()})();
