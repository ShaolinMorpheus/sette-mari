const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
await p.evaluate(()=>Pirati.hut.enter());await p.waitForTimeout(800);
const res=await p.evaluate(()=>{const X0=Pirati.hut.X0,G=Pirati.hut.G,out={};
 for(const id of Object.keys(Pirati.EID).filter(k=>k.startsWith('h_'))){const e=Pirati.EID[id],f=e.fp;if(!f)continue;const ok=[],bad=[];
  for(let y=f[1]-1;y<=f[1]+f[3];y++)for(let x=f[0]-1;x<=f[0]+f[2];x++){const gx=x-X0,gy=y-1;if(!G[gy]||G[gy][gx]!==1)continue;
   Pirati.P.x=(x+.5)*44;Pirati.P.y=(y+.5)*44;const t=Pirati.target();(t&&t.e.id===id?ok:bad).push(gx+','+gy+(t?':'+t.e.id:''))}
  out[id]=[ok.length,bad.join(' ')]}
 return out});
console.log(JSON.stringify(res,null,0));console.log(er);await b.close()})();
