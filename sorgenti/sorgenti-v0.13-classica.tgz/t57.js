const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1000,height:460},locale:'it-IT'})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/sette-mari/www/_t.html');await p.waitForTimeout(3500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(500,200);await p.waitForTimeout(300)}
await p.evaluate(()=>{const T=__t;const ps=T.E.filter(e=>e.type==='pine'&&e.alive);const tr=T.E.filter(e=>e.type==='tree'&&e.alive);const e=ps[(ps.length/2)|0];T.P.x=e.x+30;T.P.y=e.y+80;T.S.tod=12.5;document.querySelectorAll('#tut,.tut').forEach(x=>x.hidden=true)});
await p.waitForTimeout(6000);await p.screenshot({path:'forest.png'});console.log(er);await b.close()})()
