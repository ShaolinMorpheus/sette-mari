const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:900,height:420},deviceScaleFactor:2.5});const p=await ctx.newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(2500);
await p.click('#bNew').catch(()=>{});for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(200)}
await p.waitForTimeout(2000);
const fps=await p.evaluate(()=>new Promise(r=>{let n=0,t0=performance.now();const f=()=>{n++;if(performance.now()-t0>3000)r(n/3);else requestAnimationFrame(f)};requestAnimationFrame(f)}));
console.log('fps',fps,await p.evaluate(()=>[innerWidth,devicePixelRatio,[...document.querySelectorAll('canvas')].map(c=>c.id+':'+c.width+'x'+c.height)]));
const cdp=await ctx.newCDPSession(p);await cdp.send('Profiler.enable');await cdp.send('Profiler.start');await p.waitForTimeout(3000);
const {profile}=await cdp.send('Profiler.stop');
const self={};const dt=profile.timeDeltas;const idx={};profile.nodes.forEach(n=>idx[n.id]=n);
profile.samples.forEach((id,i)=>{const n=idx[id];const k=n.callFrame.functionName+':'+n.callFrame.lineNumber;self[k]=(self[k]||0)+dt[i]});
console.log(Object.entries(self).sort((a,b)=>b[1]-a[1]).slice(0,14).map(([k,v])=>k+' '+(v/1000|0)+'ms').join('\n'));
console.log(er);await b.close()})();
