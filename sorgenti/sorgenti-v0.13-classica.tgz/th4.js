const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
// tooltip HUD
for(const sel of ['#vT svg','#clkI']){await p.click(sel,{force:true});await p.waitForTimeout(300);console.log(sel,await p.evaluate(()=>[...document.querySelectorAll('.tipx')].map(x=>x.textContent)));}
await p.screenshot({path:'tip1.png'});
await p.waitForTimeout(2500);
// costruzione capanna
await p.evaluate(()=>{const e=Pirati.EID.plot_capanna;e.st=2;e.prog=1;Pirati.S.built.capanna=1;const f=e.fp;console.log(JSON.stringify(f))});
const f=await p.evaluate(()=>Pirati.EID.plot_capanna.fp);console.log('fp',f);
await p.evaluate(()=>{const f=Pirati.EID.plot_capanna.fp;Pirati.P.x=(f[0]+f[2]/2)*44;Pirati.P.y=(f[1]+f[3]+.6)*44;Pirati.cam.x=Pirati.P.x;Pirati.cam.y=Pirati.P.y});await p.waitForTimeout(800);
console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(1200);
console.log('inside',await p.evaluate(()=>Pirati.hut.inside()));await clr();
await p.screenshot({path:'hut_in.png'});
await p.evaluate(()=>{const X0=Pirati.hut.X0;Pirati.P.x=(X0+14)*44;Pirati.P.y=(1+7.5)*44});await p.waitForTimeout(500);
console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(1000);
console.log('inside after exit',await p.evaluate(()=>[Pirati.hut.inside(),Pirati.P.x/44,Pirati.P.y/44]));
// letto
await p.evaluate(()=>Pirati.hut.enter());await p.waitForTimeout(500);
await p.evaluate(()=>{const X0=Pirati.hut.X0;Pirati.S.tod=21;Pirati.P.x=(X0+2.5)*44;Pirati.P.y=(1+3.5)*44});await p.waitForTimeout(500);
console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(500);
console.log(await p.evaluate(()=>document.getElementById('sheetCard').textContent.slice(0,80)));
await p.screenshot({path:'hut_bed.png'});
// salva/ricarica dentro
await p.evaluate(()=>Pirati.saveGame());
console.log(er);await b.close()})();
