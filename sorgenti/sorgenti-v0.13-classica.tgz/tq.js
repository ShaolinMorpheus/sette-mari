const L=require('./aud/lib.js');
(async()=>{const {b,p}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.built={falo:1,capanna:1,banco:1};for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}Pirati.saveGame();Pirati.Ch2.begin()});
 await p.waitForNavigation({timeout:20000}).catch(()=>{});
 await p.waitForFunction(()=>window.Pirati&&window.Pirati.S&&window.Pirati.S.live,null,{timeout:60000}).catch(()=>{});await p.waitForTimeout(1500);
 console.log(await p.evaluate(()=>JSON.stringify({w:Pirati.WORLD,n:Object.keys(Pirati.EID).filter(k=>/clue|deco/.test(k)).slice(0,6),keys:Object.keys(Pirati).join(',')})));await b.close()})();
