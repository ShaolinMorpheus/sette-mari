const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:900,height:420}});const p=await ctx.newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:3,t:0}))}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(3000);
// 1) alleati: avvicinati a Tito: non deve scappare
const r=await p.evaluate(async()=>{const K=Ch4.K,P=Ch4.P,f=K.fol[0];const out=[];
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 // portati a 600px da lui
 P.x=f.x+600;P.y=f.y;await sleep(2500);out.push(['dopo 2.5s distanza',Math.round(Math.hypot(P.x-f.x,P.y-f.y))]);
 // cammina verso di lui
 for(let i=0;i<30;i++){const dx=f.x-P.x,dy=f.y-P.y,d=Math.hypot(dx,dy);if(d<20)break;P.x+=dx/d*6;P.y+=dy/d*6;await sleep(40)}
 const d0=Math.hypot(P.x-f.x,P.y-f.y);await sleep(1500);out.push(['avvicinato',Math.round(d0),'dopo 1.5s',Math.round(Math.hypot(P.x-f.x,P.y-f.y))]);
 // allontanati velocemente e controlla che segua
 P.x+=1100;await sleep(4000);out.push(['dopo 4s lontano',Math.round(Math.hypot(P.x-f.x,P.y-f.y))]);
 return out});
console.log(r,er);await b.close()})();
