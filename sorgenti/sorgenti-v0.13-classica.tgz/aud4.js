const {chromium}=require('playwright');
const W=process.argv[2]==='2';
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
if(W)await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
if(W)await p.evaluate(()=>{const P=Pirati;localStorage.setItem(P.saveKey(),JSON.stringify(P.Ch2.convert(P.newState('D','m'))));P.startContinue('',null)});
else await p.evaluate(()=>Pirati.startNew('T','m'));
await p.waitForTimeout(2000);
const r=await p.evaluate(()=>{const P=Pirati,TS=44;const tiles={};let n=0;
 for(let y=0;y<60*TS;y+=3)for(let x=0;x<99*TS;x+=3){const e=P.elev(x/TS,y/TS);if(e<=P.WL+.03)continue;const tx=Math.floor(x/TS),ty=Math.floor(y/TS),ti=P.tileInfo(tx,ty);
  if(ti.walk===1||ti.block>0)continue;
  // tile non calpestabile per la griglia, punto chiaramente a terra
  if(P.boxFree(x,y,9,5))continue;n++;const k=tx+','+ty;tiles[k]=(tiles[k]||0)+1}
 // 4 punti d'angolo: quanti punti-centro con piedi su sabbia asciutta (tutti i 4 angoli sopra WL+.04) sono bloccati
 let m=0;const t2={};
 for(let y=0;y<60*TS;y+=3)for(let x=0;x<99*TS;x+=3){const cs=[[x-9,y-5],[x+9,y-5],[x-9,y+5],[x+9,y+5],[x,y]];if(cs.some(c=>P.elev(c[0]/TS,c[1]/TS)<=P.WL+.04))continue;if(P.boxFree(x,y,9,5))continue;
  const tx=Math.floor(x/TS),ty=Math.floor(y/TS);let why='';
  const around=[];for(let j=-1;j<=1;j++)for(let i=-1;i<=1;i++){const a=P.tileInfo(tx+i,ty+j);if(a.block>0||a.walk!==1)around.push([i,j,a.block,a.walk])}
  m++;const k=tx+','+ty;t2[k]=(t2[k]||0)+1}
 return {nTerrain:n,tiles:Object.keys(tiles).length,dry:m,dryTiles:Object.entries(t2).slice(0,80)}});
console.log(JSON.stringify(r));await b.close()})();
