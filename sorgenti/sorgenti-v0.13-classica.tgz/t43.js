const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/sette-mari/www/index.html');await p.waitForTimeout(2500);
console.log(await p.evaluate(()=>typeof UI+' '+typeof say),er);await b.close()})()
