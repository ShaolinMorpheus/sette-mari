const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1500);
const r=await p.evaluate(()=>{const C=Ch4,K=C.K,P=C.P,o=[];
 const near=id=>{const ob=K.objs.find(q=>q.id===id);P.x=ob.x;P.y=ob.y+10;C.step(.02);const n=K.near;ob.use();return n&&n.id};
 K.inv=999;
 o.push(near('k1'));o.push(near('sd'));o.push(K.deck);
 o.push(near('cell'));o.push(K.cell,K.fol.length);
 o.push(near('k2'));o.push(near('sd'));o.push(K.deck);
 o.push(near('hold'));for(let i=0;i<6;i++)o.push(near('c'+i));o.push(K.silver);
 o.push(near('su'),K.deck,near('su'),K.deck,K.objs.some(q=>q.id==='exit'));
 for(let i=0;i<600;i++)C.step(1/30);
 o.push(K.fol.map(f=>f.hp).join(''),K.gd.filter(g=>g.ko>0).length,K.kos);
 return o});
console.log(JSON.stringify(r),errs);await b.close()})()
