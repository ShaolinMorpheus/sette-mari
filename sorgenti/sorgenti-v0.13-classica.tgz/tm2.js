const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [n,w,h] of [['land',844,390],['port',390,844]]){
const p=await b.newPage({viewport:{width:w,height:h},hasTouch:true,isMobile:true});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=0;s.tut=0;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});await p.waitForTimeout(1800);
await p.screenshot({path:'tm2_'+n+'1.png'});
console.log(n,await p.evaluate(()=>{const j=document.getElementById('joy'),a=document.getElementById('act');const q=e=>{const r=e.getBoundingClientRect();return [Math.round(r.left),Math.round(r.top),Math.round(r.width),getComputedStyle(e).position,getComputedStyle(e,'::after').content]};return JSON.stringify({joy:q(j),act:q(a),b:document.querySelector('#banner,.banner')&&document.querySelector('#banner,.banner').textContent})}));
await p.evaluate(()=>{Pirati.UI.tutNext()});await p.waitForTimeout(500);await p.screenshot({path:'tm2_'+n+'2.png'});
await p.evaluate(()=>{Pirati.UI.tutSkip()});await p.waitForTimeout(1500);await p.screenshot({path:'tm2_'+n+'3.png'});
console.log(n,'after skip',await p.evaluate(()=>JSON.stringify({ch1b:Pirati.S.flags.ch1b,banner:[...document.querySelectorAll('[id*=anner]')].map(e=>e.id+':'+e.textContent.slice(0,30)+':'+e.hidden)})));
await p.close()}
await b.close()})();
