const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();
await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
console.log(await p.evaluate(()=>{const P=Pirati;let o='';
 for(let y=31;y<=40;y++){let r=y+' ';for(let x=60;x<=76;x++){const t=P.tileInfo(x,y);const tr=P.E.find(e=>(e.type==='tree'||e.type==='pine'||e.type==='palm')&&Math.floor(e.x/44)===x&&Math.floor(e.y/44)===y);r+=tr?'T':t.sea?'~':t.free?'.':'#'}o+=r+'\n'}return o}));
await b.close()})();
