import re
f='base_index.html';s=open(f,encoding='utf-8').read()
# (a) frase pappagallo
old="Cra! Quel granchio mi ha guardato storto. Ci penso io. Tu, intanto."
new="Cra! Quel granchio mi ha guardato storto! Ci penso io!!"
print(s.count(old));s=s.replace(old,new)
# (b) salpare dopo la ricostruzione
a="""    if(qAct('c13',0)||qAct('c12',0)){
      if(qAct('c12',0)){UI.dlg([D('hero',"La nave è quasi pronta. Mancano le provviste: parla con Gnocco.")]);return true}
      Ch2.launch();return true}
    if(c.parts.yard){UI.dlg([D('hero',"La nave è montata e ben legata.")])}"""
b="""    if(c.parts.yard){Ch2.launch();return true}"""
assert a in s;s=s.replace(a,b)
# (c) cutscene
a="Ch2.ENDS={"
cine=r'''
/* ---------- scena animata dei finali (separata dal mondo) ---------- */
const CINE={on:false,step:0,t:0,k:'',cards:[],done:null,maxH:0};
function cineCard(){
  const c=CINE.cards[CINE.step],nm=c.w==='hero'?nomeP():pn((CH[c.w]&&CH[c.w].name)||c.w);
  $('introTxt').innerHTML=(c.w==='narr'?'':'<em>'+uEsc(nm)+'</em>')+uEsc(c.t)+'<small>Tocca per continuare</small>';
}
UI.cine=function(L,k,done){
  INTRO.on=false;
  Object.assign(CINE,{on:true,step:0,t:0,k,cards:L.map(x=>({w:x.w,t:typeof x.t==='function'?x.t():x.t})),done,maxH:0});
  uShow('intro',true);
  for(let i=0;i<CINE.cards.length;i++){CINE.step=i;cineCard();CINE.maxH=Math.max(CINE.maxH,$('introTxt').offsetHeight)}
  CINE.step=0;cineCard();
  const c=$('introCv'),d=Math.min(window.devicePixelRatio||1,1.6);c.width=Math.round(c.clientWidth*d);c.height=Math.round(c.clientHeight*d);
  $('intro').onclick=UI.cineNext;
};
UI.cineNext=function(){
  if(!CINE.on||CINE.t<.4)return;
  sfx('tap');CINE.step++;CINE.t=0;
  if(CINE.step>=CINE.cards.length){CINE.on=false;uShow('intro',false);$('intro').onclick=UI.introNext;const d=CINE.done;CINE.done=null;if(d)d();return}
  cineCard();
};
function drawCine(t){
  const c=$('introCv'),g=c.getContext('2d'),W=c.width,H=c.height,k=CINE.k,n=CINE.cards.length;
  const night=k==='solo',prog=Math.min(1,(CINE.step+Math.min(1,CINE.t/6))/n),hy=H*.46;
  const dawn=night?0:1,fire=k==='fire';
  const sky=g.createLinearGradient(0,0,0,hy);
  sky.addColorStop(0,rgbs(mixc([6,10,22],[120,150,200],dawn)));sky.addColorStop(1,rgbs(mixc([30,44,70],[250,190,130],dawn)));
  g.fillStyle=sky;g.fillRect(0,0,W,hy+2);
  if(night){g.fillStyle='#fff';for(let i=0;i<50;i++){g.globalAlpha=.4+.5*Math.abs(Math.sin(t*.8+i));g.fillRect((i*137.5%W),(i*71.3%(hy*.9)),2,2)}g.globalAlpha=1;
    g.fillStyle='#f4efd6';g.beginPath();g.arc(W*.75,H*.14,H*.04,0,7);g.fill()}
  else{g.fillStyle='rgba(255,226,160,.9)';g.beginPath();g.arc(W*.7,hy-H*.05-prog*H*.06,H*.06,0,7);g.fill()}
  const sea=g.createLinearGradient(0,hy,0,H);sea.addColorStop(0,rgbs(mixc([14,30,50],[90,170,190],dawn)));sea.addColorStop(1,rgbs(mixc([3,9,18],[24,88,128],dawn)));
  g.fillStyle=sea;g.fillRect(0,hy,W,H-hy);
  // riva che si allontana (a sinistra)
  const off=-prog*W*.55;
  g.fillStyle=night?'#050a10':'#2a3b34';g.beginPath();g.moveTo(off-10,hy+4);
  for(let x=0;x<=W*.6;x+=20)g.lineTo(off+x,hy-H*.05*(1-x/(W*.6))-Math.sin(x*.03)*H*.012);
  g.lineTo(off+W*.6,hy+4);g.closePath();g.fill();
  if(fire&&off>-W*.5){
    const fx=off+W*.18,fy=hy-H*.02;
    const gl=g.createRadialGradient(fx,fy,2,fx,fy,H*.2);gl.addColorStop(0,'rgba(255,170,60,.7)');gl.addColorStop(1,'rgba(255,90,20,0)');g.fillStyle=gl;g.fillRect(fx-H*.2,fy-H*.2,H*.4,H*.4);
    for(let i=0;i<24;i++){const ph=((t*.35+i/24)%1);g.fillStyle='rgba('+(60+ph*40|0)+','+(55+ph*30|0)+','+(52+ph*30|0)+','+(.5*(1-ph))+')';g.beginPath();g.arc(fx+Math.sin(i*5+t)*10+ph*40,fy-ph*H*.3,6+ph*18,0,7);g.fill()}
    for(let i=0;i<7;i++){const h=H*.04*(1+.5*Math.sin(t*9+i*2));g.fillStyle=i%2?'#ffb02e':'#ff6a1a';g.beginPath();g.moveTo(fx+(i-3)*8-5,fy);g.lineTo(fx+(i-3)*8,fy-h);g.lineTo(fx+(i-3)*8+5,fy);g.fill()}
  }
  if(night&&off>-W*.5){const lx=off+W*.2,ly=hy-H*.035,on=CINE.step<2||(t%3)<2.4;if(on){const gl=g.createRadialGradient(lx,ly,1,lx,ly,H*.06);gl.addColorStop(0,'rgba(255,220,130,.9)');gl.addColorStop(1,'rgba(255,200,90,0)');g.fillStyle=gl;g.fillRect(lx-H*.06,ly-H*.06,H*.12,H*.12)}}
  const wave=(l)=>{const by=hy+H*(.03+l*.085),A=(8+l*5)*H/600;g.beginPath();g.moveTo(0,H);
    for(let x=0;x<=W;x+=14)g.lineTo(x,by+Math.sin(x*.012+t*(1.1+l*.25)+l)*A+Math.sin(x*.031+t*1.9+l*2)*A*.35);
    g.lineTo(W,H);g.closePath();g.fillStyle=rgbs(mixc([8+l*3,22+l*5,36+l*6],[40+l*10,120+l*8,160+l*6],dawn),.9);g.fill();
    g.strokeStyle='rgba(225,240,250,.25)';g.lineWidth=2;g.stroke()};
  for(let l=0;l<3;l++)wave(l);
  const spr=SP.shipFix||SP.shipOur;
  if(spr){
    const tx=$('introTxt'),dd=c.width/(c.clientWidth||c.width),cardTop=(tx&&tx.offsetHeight)?(tx.offsetTop+tx.offsetHeight-Math.max(CINE.maxH||0,tx.offsetHeight))*dd-10*dd:H;
    const sy0=hy+H*.07,sc=Math.min(W/430*.7,H/330*.62,Math.max(.2,cardTop-8*dd-sy0)/((spr.h-spr.ay)*1.1)),sx=W*(.42+prog*.14)+Math.sin(t*.7)*8;
    const sy=Math.max(sy0,Math.min(hy+H*.18,cardTop-(spr.h-spr.ay)*sc-10*dd))+Math.sin(t*1.2)*6;
    g.save();g.translate(sx,sy);g.rotate(Math.sin(t*1.05)*.05);drawSp(g,spr,0,0,sc);g.restore();
  }
  for(let l=3;l<6;l++)wave(l);
  const v=g.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,H*.9);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,.5)');g.fillStyle=v;g.fillRect(0,0,W,H);
}
'''
assert s.count(a)==1
s=s.replace(a,cine+a)
# usa cine nel finale
a="  UI.dlg(L,()=>{c.endings[k]=1;S.flags.ch2end=k;"
assert a in s
s=s.replace(a,"  UI.cine(L,k,()=>{c.endings[k]=1;S.flags.ch2end=k;")
# tick + tasto
a="  if(INTRO.on){INTRO.t+=dt;drawIntro(t)}"
s=s.replace(a,a+"\n  if(CINE.on){CINE.t+=dt;drawCine(t)}")
a="  if(!$('intro').hidden){if(k===' '||k==='Enter'||k==='ArrowRight'){e.preventDefault();UI.introNext()}return}"
assert a in s
s=s.replace(a,"  if(!$('intro').hidden){if(k===' '||k==='Enter'||k==='ArrowRight'){e.preventDefault();CINE.on?UI.cineNext():UI.introNext()}return}")
open(f,'w',encoding='utf-8').write(s)
