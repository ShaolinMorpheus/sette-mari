/* ===== EDITOR MAPPA (solo admin: Diario → Novità → «Editor mappa») ===== */
const ED={on:false,sel:null,drag:null,pan:null,pt:new Map(),pinch0:0,ed:{mv:{},del:[],add:[],vv:{},t:[]},undo:[],grid:true,bound:false,brush:null,size:2.5,paint:null,dirty:false};
let EDR=0;
const ED_BAKED=null;   // @@EDBAKED@@ mappa definitiva: { "1":{mv,del,add,vv}, "2":{...} }
const EDKEY='sm_edits_w'+WORLD;
const edNorm=o=>({mv:(o&&o.mv)||{},del:(o&&o.del)||[],add:(o&&o.add)||[],vv:(o&&o.vv)||{},t:(o&&o.t)||[]});
function edStore(){try{localStorage.setItem(EDKEY,JSON.stringify(ED.ed))}catch(e){}}
const edOk=e=>!['crab','mraft','thief','npc','cdeco','glint'].includes(e.type)&&e.spr!=='hut'&&e.spr!=='cave'&&!/^nv_/.test(e.spr||'')&&!/^(cav|cvr|h_)/.test(e.id||'')&&e.x>0&&e.y>0&&e.x<WW&&e.y<WH;
const ED_NAMES={reef:'Scoglio in mare',tree:'Albero',pine:'Pino',palm:'Palma',rock:'Roccia',bush:'Cespuglio',berry:'Cespuglio di bacche',rockpool:'Pozza di molluschi',debris:'Rottami',bottle:'Bottiglia',loot:'Cassa / oggetto',wparrot:'Pappagallo selvatico'};
const ED_SPR={lamp:'Lanterna',barrel0:'Barile',barrel1:'Barile (2)',crate:'Cassa di legno',coil:'Corda arrotolata',sign:'Cartello',mesa:'Altopiano',wreck:'Relitto',oldcamp:'Campo abbandonato',lookout:'Pino Alto',pit:'Buca',rowboat:'Barca a remi'};
const ED_PLOT={falo:'Falò',capanna:'Capanna',banco:'Banco da lavoro',zattera:'Zattera'};
function edName(e){if(e.type==='plot')return ED_PLOT[e.pid]||'Costruzione';if(e.type==='deco')return ED_SPR[e.spr]||('Oggetto «'+e.spr+'»');return ED_NAMES[e.type]||e.type}
const ED_DUP=e=>['tree','pine','palm','rock','bush','berry','rockpool','debris','reef'].includes(e.type)||(e.type==='deco'&&['lamp','barrel0','barrel1','crate','coil'].includes(e.spr));
const ED_PAL=[['Albero','tree'],['Pino','pine'],['Palma','palm'],['Cespuglio','bush'],['Cespuglio di bacche','berry'],['Roccia','rock'],['Scoglio in mare','reef'],['Pozza di molluschi','rockpool'],['Rottami','debris'],['Lanterna','deco','lamp'],['Barile','deco','barrel0'],['Barile (2)','deco','barrel1'],['Cassa di legno','deco','crate'],['Corda arrotolata','deco','coil']];
const ED_LAMP={type:'deco',spr:'lamp',nohit:1,x:.5*TS,y:.8*TS,fp:[0,0,1,1],lk:{x:0,y:0,k:'lanterne'},blocked:true,id:'lamptpl'};
const edTpl=(t,s)=>(t==='deco'&&s==='lamp'&&!E.some(e=>e.type==='deco'&&e.spr==='lamp'))?ED_LAMP:E.find(e=>e.type===t&&(s==null||e.spr===s)&&e.alive!==false&&e.id.indexOf('ed')!==0&&edOk(e))||E.find(e=>e.type===t&&(s==null||e.spr===s));
function edRemove(e){if(e.xb){blockRect(e.fp[0]-1,e.fp[1],1,1,-1);blockRect(e.fp[0]+e.fp[2],e.fp[1],1,1,-1);e.xb=0}delBlock(e);const i=E.indexOf(e);if(i>=0){E.splice(i,1);EDR++}delete EID[e.id]}
const edFree=e=>!!(e.fp&&e.fp[2]===1&&e.fp[3]===1&&e.type!=='plot');   // alberi, cespugli, scogli...: posizione libera, la casella che blocca è quella sotto la base
function edMove(e,x,y){
  let dx,dy;const was=e.blocked;
  if(edFree(e)){if(!e._fo)e._fo=[e.fp[0]-Math.floor(e.x/TS),e.fp[1]-Math.floor(e.y/TS)];dx=Math.floor(x/TS)+e._fo[0]-e.fp[0];dy=Math.floor(y/TS)+e._fo[1]-e.fp[1]}
  else{dx=Math.round((x-e.x)/TS);dy=Math.round((y-e.y)/TS)}
  if(was){if(e.xb){blockRect(e.fp[0]-1,e.fp[1],1,1,-1);blockRect(e.fp[0]+e.fp[2],e.fp[1],1,1,-1);e.xb=0}delBlock(e)}
  e.x=x;e.y=y;if(e.lk){e.lk.x=x;e.lk.y=y}if(e.tx!=null){e.tx+=dx;e.ty+=dy}if(e.fp){e.fp[0]+=dx;e.fp[1]+=dy}
  if(was)reBlock(e);
}
function edMake(d){
  if(EID[d.id])return null;
  const tpl=edTpl(d.t,d.s);if(!tpl)return null;
  const o={};for(const k in tpl){const v=tpl[k];if(v===null||(typeof v!=='object'&&typeof v!=='function'))o[k]=v}
  if(tpl.lk)o.lk={x:tpl.lk.x,y:tpl.lk.y,k:tpl.lk.k};
  o.id=d.id;o.blocked=false;o.parrotHost=false;o.keep=false;
  if('alive' in o){o.alive=true;o.grow=1;o.fall=0}if('got' in o)o.got=false;if('ready' in o)o.ready=true;if('coco' in o){o.coco=true;o.cd=0}
  if(d.v!=null&&'v' in o)o.v=d.v;if(d.f!=null&&'flip' in o)o.flip=!!d.f;
  let dx,dy;
  if(edFree(tpl)){const fo=[tpl.fp[0]-Math.floor(tpl.x/TS),tpl.fp[1]-Math.floor(tpl.y/TS)];dx=Math.floor(d.x/TS)+fo[0]-tpl.fp[0];dy=Math.floor(d.y/TS)+fo[1]-tpl.fp[1]}
  else{dx=Math.round((d.x-tpl.x)/TS);dy=Math.round((d.y-tpl.y)/TS)}
  o.x=d.x;o.y=d.y;if(tpl.tx!=null){o.tx=tpl.tx+dx;o.ty=tpl.ty+dy}
  const e=ent(o);if(e.lk){e.lk.x=d.x;e.lk.y=d.y}
  if(tpl.fp){addBlock(e,tpl.fp[0]+dx,tpl.fp[1]+dy,tpl.fp[2],tpl.fp[3])}
  return e;
}
function edApply(o){
  if(!o)return;o=edNorm(o);
  for(const id of o.del){const e=EID[id];if(e)edRemove(e)}
  for(const d of o.add)edMake(d);
  for(const id in o.mv){const e=EID[id];if(e&&edOk(e))edMove(e,o.mv[id][0],o.mv[id][1])}
  for(const id in o.vv){const e=EID[id];if(e&&'v' in e)e.v=o.vv[id]}
}
function edBoot(){
  try{if(ED_BAKED&&ED_BAKED[WORLD])edApply(ED_BAKED[WORLD])}catch(e){console.warn('ED baked',e)}
  try{const l=JSON.parse(localStorage.getItem(EDKEY)||'null');ED.ed=edNorm(l);edApply(ED.ed)}catch(e){console.warn('ED local',e)}
}
function edRec(e){
  if(e.id.indexOf('ed')===0){const d=ED.ed.add.find(a=>a.id===e.id);if(d){d.x=Math.round(e.x);d.y=Math.round(e.y);d.v=e.v;d.f=e.flip?1:0}}
  else ED.ed.mv[e.id]=[Math.round(e.x),Math.round(e.y)];
  edStore();
}
function edMaxV(e){return e.type==='tree'?SP.tree.length:e.type==='pine'?SP.pine.length:e.type==='palm'?SP.palm.length:e.type==='bush'?SP.bush.length:e.type==='berry'?(SP.berry||[]).length:(e.type==='rock'||e.type==='reef')?(SP.boulder||[]).length:0}
const edZmin=()=>ED.x?.08:.35;
function edHit(wx,wy){
  if(ED.x){let best=null,bs=1e9;const z=camZoom();for(const it of ED.x.items()){const d=Math.hypot(wx-it.x,wy-it.y),R=Math.max(it.r||24,26/z);if(d<R&&d<bs){bs=d;best=it}}return best}
  let best=null,bs=1e9;
  for(const e of E){
    if(!edOk(e))continue;
    let sc=1e9;
    if(e.type==='plot'&&e.fp){const x0=e.fp[0]*TS,y0=e.fp[1]*TS,x1=x0+e.fp[2]*TS,y1=y0+e.fp[3]*TS;if(wx>=x0-8&&wx<=x1+8&&wy>=y0-40&&wy<=y1+8)sc=Math.hypot(wx-(x0+x1)/2,wy-(y0+y1)/2)*.6}
    else{const dx=Math.abs(wx-e.x);if(dx<34&&wy>e.y-84&&wy<e.y+16)sc=Math.hypot(dx,wy-(e.y-26))}
    if(e===ED.sel)sc-=14;
    if(sc<bs){bs=sc;best=e}
  }
  return bs<1e8?best:null;
}
const edW=(sx,sy)=>{const z=camZoom();return[cam.x+(sx-VW/2)/z,cam.y+(sy-VH/2)/z]};
function edLabel(){const el=document.getElementById('edSel');if(!el)return;const e=ED.sel;
  if(ED.x){edxLabel(el);return}
  el.innerHTML=e?'<b>'+edName(e)+'</b><small>'+Math.floor(e.x/TS)+','+Math.floor(e.y/TS)+'</small>'
    +'<button class="btn" id="edDel">Elimina</button>'+(ED_DUP(e)?'<button class="btn" id="edDup">Duplica</button>':'')+(edMaxV(e)>1?'<button class="btn" id="edVar">Aspetto</button>':'')+'<button class="btn" id="edAdd">+ Aggiungi</button>'
    :'<span>Tocca un oggetto per selezionarlo.</span><button class="btn" id="edAdd">+ Aggiungi</button>';
  const q=id=>el.querySelector('#'+id);
  if(q('edDel'))q('edDel').onclick=()=>{const e=ED.sel;if(!e)return;const rec=e;ED.sel=null;
    const isNew=e.id.indexOf('ed')===0,addD=isNew?ED.ed.add.find(a=>a.id===e.id):null;
    edRemove(e);if(isNew){ED.ed.add=ED.ed.add.filter(a=>a.id!==e.id)}else{ED.ed.del.push(e.id);delete ED.ed.mv[e.id]}edStore();
    ED.undo.push(()=>{E.push(rec);EDR--;EID[rec.id]=rec;if(rec.fp)reBlock(rec);if(isNew){if(addD)ED.ed.add.push(addD)}else ED.ed.del=ED.ed.del.filter(i=>i!==rec.id);edStore()});edLabel()};
  if(q('edDup'))q('edDup').onclick=()=>{const e=ED.sel;if(!e)return;edNew({t:e.type,s:e.spr,v:e.v,f:e.flip?1:0,x:e.x+TS,y:e.y})};
  if(q('edVar'))q('edVar').onclick=()=>{const e=ED.sel;if(!e)return;const o=e.v,n=(o+1)%edMaxV(e);e.v=n;if(e.id.indexOf('ed')===0)edRec(e);else{ED.ed.vv[e.id]=n;edStore()}ED.undo.push(()=>{e.v=o;if(e.id.indexOf('ed')===0)edRec(e);else{ED.ed.vv[e.id]=o;edStore()}})};
  if(q('edAdd'))q('edAdd').onclick=edPalette;
}
function edNew(d){
  let n=1;while(EID['ed'+n])n++;d.id='ed'+n;
  const e=edMake(d);if(!e){UI.toast('In questa mappa manca un modello per questo oggetto.');return}
  ED.ed.add.push(d);edStore();ED.sel=e;ED.undo.push(()=>{if(ED.sel===e)ED.sel=null;edRemove(e);ED.ed.add=ED.ed.add.filter(a=>a.id!==d.id);edStore();edLabel()});edLabel();
}
function edPalette(){
  const items=ED_PAL.filter(p=>edTpl(p[1],p[2]));
  sheetFor('<h2>Aggiungi oggetto</h2><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:8px">'+items.map((p,i)=>'<button class="btn" data-i="'+i+'">'+p[0]+'</button>').join('')+'</div><div class="row"><button class="btn" id="shNo">Chiudi</button></div>',c=>{
    c.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{const p=items[+b.dataset.i],tpl=edTpl(p[1],p[2]);closeSheet();
      const cx=Math.round(cam.x/TS)*TS+(tpl.x-(tpl.fp?tpl.fp[0]*TS:Math.floor(tpl.x/TS)*TS)),cy=Math.round(cam.y/TS)*TS+(tpl.y-(tpl.fp?tpl.fp[1]*TS:Math.floor(tpl.y/TS)*TS));
      const d={t:p[1],s:p[2]||null,v:null,f:0,x:cx,y:cy};if(tpl.v!=null)d.v=(Math.random()*Math.max(1,edMaxV(tpl)))|0;edNew(d)})});
}
function edNamesLocal(){try{return JSON.parse(localStorage.getItem('sm_edit_names')||'{}')}catch(e){return{}}}
function edCodeStr(){if(ED.x)return ED.x.code();const o={w:WORLD,mv:ED.ed.mv,del:ED.ed.del,add:ED.ed.add,vv:ED.ed.vv,t:ED.ed.t};const n=edNamesLocal();if(Object.keys(n).length)o.names=n;return JSON.stringify(o)}
async function edSaveFile(code,st){
  const name='sette-mari-mappa-m'+WORLD+'.json',C=window.Capacitor,PL=C&&C.Plugins;
  try{
    if(C&&C.isNativePlatform&&C.isNativePlatform()&&PL&&PL.Filesystem&&PL.Share){
      const r=await PL.Filesystem.writeFile({path:name,data:code,directory:'CACHE',encoding:'utf8'});
      try{await PL.Share.share({title:'Mappa Sette Mari',text:'Mappa di Sette Mari',files:[r.uri],dialogTitle:'Salva o invia il file'})}
      catch(e){if(!/cancel/i.test(String(e&&e.message||e)))await PL.Share.share({title:'Mappa Sette Mari',text:code,dialogTitle:'Salva o invia il codice'})}
      st.textContent='Scegli dove salvarlo o a chi inviarlo.';return;
    }
    const f=new File([code],name,{type:'application/json'});
    if(navigator.canShare&&navigator.canShare({files:[f]})){try{await navigator.share({files:[f],title:'Mappa Sette Mari'});st.textContent='Scegli dove salvarlo.';return}catch(e){if(e&&e.name==='AbortError')return}}
    const a=document.createElement('a'),b=new Blob([code],{type:'application/json'});
    a.href=URL.createObjectURL(b);a.download=name;document.body.appendChild(a);a.click();a.remove();
    st.textContent='File scaricato (se il browser lo consente). In alternativa copia il codice.';
  }catch(_){st.textContent='Non riesco a salvare il file: copia il codice.'}
}
function edCode(){
  const code=edCodeStr();
  sheetFor('<h2>Codice della mappa</h2><p class="sm">Copia il codice o scarica il file e mandalo a Claude: lo inserirà nel gioco per tutti.</p><textarea id="edTx" class="bkta" readonly>'+code.replace(/</g,'&lt;')+'</textarea><div class="row"><button class="btn" id="shNo">Chiudi</button><button class="btn" id="edFl">Scarica file</button><button class="btn gold" id="edCp">Copia</button></div><p class="sm" id="edSt"></p>',c=>{
    c.querySelector('#edFl').onclick=()=>edSaveFile(code,c.querySelector('#edSt'));
    c.querySelector('#edCp').onclick=async()=>{const tx=c.querySelector('#edTx'),st=c.querySelector('#edSt');try{await navigator.clipboard.writeText(tx.value);st.textContent='Codice copiato.'}catch(_){tx.focus();tx.select();try{document.execCommand('copy');st.textContent='Codice copiato.'}catch(__){st.textContent='Seleziona il testo e copialo a mano.'}}}});
}
/* ---- terreno: pennello di spiaggia / erba / mare ---- */
function edPaint(wx,wy){
  const t=[ED.brush,Math.round(wx/TS*4)/4,Math.round(wy/TS*4)/4,ED.size,ED.size];
  ED.ed.t.push(t);ED.paint.n++;ED.dirty=true;edStore();
}
function edBar2(){const b=document.getElementById('edHand');if(b)b.hidden=!ED.brush}
function edTerrain(){
  const nm={b:'Sabbia',g:'Erba',s:'Mare'};
  sheetFor('<h2>Terreno</h2><p class="sm">Scegli un pennello, poi tocca o trascina sulla mappa: aggiungi sabbia (spiaggia), erba o mare. I cerchi sono solo una guida: premi «Anteprima costa» per vedere il risultato vero (con «Griglia» spenta spariscono anche i cerchi).</p>'
   +'<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:8px"><button class="btn" data-b="b">Sabbia</button><button class="btn" data-b="g">Erba</button><button class="btn" data-b="s">Mare</button></div>'
   +'<h3>Grandezza</h3><div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px"><button class="btn" data-z="1.2">S</button><button class="btn" data-z="2.5">M</button><button class="btn" data-z="4.5">L</button><button class="btn" data-z="7">XL</button></div>'
   +'<div class="row"><button class="btn" id="edTU">Togli l\x27ultimo tocco</button><button class="btn" id="edTA">Cancella tutto il terreno</button></div><div class="row"><button class="btn" id="shNo">Chiudi</button></div><p class="sm" id="edTs"></p>',c=>{
    const st=c.querySelector('#edTs');const sh=()=>{st.textContent=(ED.brush?'Pennello: '+nm[ED.brush]+', raggio '+ED.size+' tile. ':'')+'Pezzi di terreno tuoi: '+ED.ed.t.length+'.'};sh();
    c.querySelectorAll('[data-b]').forEach(b=>b.onclick=()=>{ED.brush=b.dataset.b;ED.sel=null;edLabel();edBar2();sh();closeSheet();UI.toast('Pennello '+nm[ED.brush]+': tocca o trascina. Poi «Muovi» per spostarti.',3200)});
    c.querySelectorAll('[data-z]').forEach(b=>b.onclick=()=>{ED.size=+b.dataset.z;sh()});
    c.querySelector('#edTU').onclick=()=>{if(ED.ed.t.length){ED.ed.t.pop();ED.dirty=true;edStore()}sh()};
    let ask=0;c.querySelector('#edTA').onclick=()=>{if(!ask){ask=1;c.querySelector('#edTA').textContent='Sicuro? Tocca ancora';return}ED.ed.t=[];ED.dirty=true;edStore();sh();ask=0;c.querySelector('#edTA').textContent='Cancella tutto il terreno'};
  });
}
/* ---- nomi dei personaggi ---- */
const ED_NAMELIST=['Tonno','Pina','Nonno Ferro','Ferro','Nives','Gnocco','Capitan Pinza','Gambero','Aragosta','Pip','Dodo','Tito','Giacomo'];
function edNames(){
  const cur=edNamesLocal();
  sheetFor('<h2>Nomi dei personaggi</h2><p class="sm">Scrivi il nuovo nome accanto a quello attuale (lascia vuoto per non cambiarlo). Vale in tutti i dialoghi e i messaggi. Il nome del pappagallo si sceglie nel gioco.</p>'
   +'<div style="display:grid;grid-template-columns:1fr 1.4fr;gap:6px;align-items:center;margin-top:6px">'+ED_NAMELIST.map((n,i)=>'<span>'+n+'</span><input class="bkta" style="min-height:0;height:34px;padding:4px 8px" data-n="'+i+'" value="'+(cur[n]||'').replace(/"/g,'&quot;')+'" maxlength="22">').join('')+'</div>'
   +'<div class="row"><button class="btn" id="shNo">Chiudi</button><button class="btn gold" id="edNs">Salva nomi</button></div><p class="sm" id="edNt"></p>',c=>{
    c.querySelector('#edNs').onclick=()=>{const o={};c.querySelectorAll('[data-n]').forEach(i=>{const v=i.value.replace(/[<>&"]/g,'').trim();if(v&&v!==ED_NAMELIST[+i.dataset.n])o[ED_NAMELIST[+i.dataset.n]]=v});
      try{localStorage.setItem('sm_edit_names',JSON.stringify(o))}catch(e){}
      NMAP=Object.assign({},NM_BK,o);nmBuild();c.querySelector('#edNt').textContent='Nomi salvati: li vedrai nei prossimi dialoghi.'}});
}
function edUI(){
  let bar=document.getElementById('edBar');if(bar)return;
  const st=document.createElement('style');st.textContent='body.edit #hud,body.edit #joyGhost,body.edit #joy,body.edit #tank,body.edit #ctr,body.edit #act,body.edit #bcol,body.edit #hintb,body.edit #tut,body.edit #obj,body.edit #qbanner,body.edit #mini,body.edit #bJ,body.edit #bM,body.edit #chal,body.edit #res,body.edit #tl,body.edit #clock,body.edit #dlg,body.edit #c3,body.edit #c3ov,body.edit #c4{display:none!important}#edBar,#edSel{position:fixed;z-index:60;display:flex;gap:6px;align-items:center;flex-wrap:wrap;font:800 13px var(--f-b,Arial)}#edBar{top:8px;left:8px;right:8px}#edBar [hidden]{display:none!important}#edSel{left:8px;right:8px;bottom:10px;justify-content:center;background:rgba(40,24,10,.88);border:2px solid #6a4426;border-radius:14px;padding:7px 10px;color:#ffe9b0}#edSel small{opacity:.7}#edBar .btn,#edSel .btn{padding:7px 11px;font-size:13px}';
  document.head.appendChild(st);
  bar=document.createElement('div');bar.id='edBar';
  bar.innerHTML='<button class="btn gold" id="edX">Esci</button><button class="btn" id="edSv">Salva</button><button class="btn" id="edCd">Codice</button><button class="btn" id="edUn">↶ Annulla</button><button class="btn" id="edTr">Terreno</button><button class="btn" id="edAp">Anteprima costa</button><button class="btn" id="edNm">Nomi</button><button class="btn gold" id="edHand" hidden>Muovi</button><button class="btn" id="edZm">−</button><button class="btn" id="edZp">+</button><button class="btn" id="edGr">Griglia</button><button class="btn" id="edRs">Azzera</button>';
  document.body.appendChild(bar);
  const sel=document.createElement('div');sel.id='edSel';document.body.appendChild(sel);
  const $$=id=>bar.querySelector('#'+id);
  $$('edX').onclick=edStop;
  $$('edSv').onclick=()=>{edStore();UI.toast('Modifiche salvate su questo dispositivo.',2200)};
  $$('edCd').onclick=edCode;
  $$('edTr').onclick=edTerrain;$$('edNm').onclick=edNames;$$('edHand').onclick=()=>{ED.brush=null;edBar2();UI.toast('Torni a spostare gli oggetti.',1800)};
  $$('edUn').onclick=()=>{const f=ED.undo.pop();if(f){f();edLabel()}};
  $$('edZm').onclick=()=>{cam.uz=clamp(cam.uz/1.25,edZmin(),2.2);camClamp()};
  $$('edZp').onclick=()=>{cam.uz=clamp(cam.uz*1.25,edZmin(),2.2);camClamp()};
  $$('edGr').onclick=()=>{ED.grid=!ED.grid};
  let rs=0;$$('edRs').onclick=()=>{if(!rs){rs=1;$$('edRs').textContent='Sicuro? Tocca ancora';setTimeout(()=>{rs=0;$$('edRs').textContent='Azzera'},3000);return}try{if(ED.x)ED.x.reset();else localStorage.removeItem(EDKEY)}catch(e){}location.reload()};
}
function edBind(){
  if(ED.bound)return;ED.bound=true;
  const dn=e=>{if(!ED.on)return;e.stopImmediatePropagation();e.preventDefault();try{cv.setPointerCapture(e.pointerId)}catch(_){}
    const[sx,sy]=cvPt(e);ED.pt.set(e.pointerId,[sx,sy]);
    if(ED.pt.size===2){const a=[...ED.pt.values()];ED.pinch0=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);ED.drag=null;ED.pan=null;return}
    const[wx,wy]=edW(sx,sy);
    if(ED.brush){ED.paint={lx:wx,ly:wy,n:0};edPaint(wx,wy);return}
    const h=edHit(wx,wy);
    if(h){ED.sel=h;ED.drag={e:h,wx,wy,x0:h.x,y0:h.y,moved:false};edLabel()}
    else{ED.pan={sx,sy,cx:cam.x,cy:cam.y,moved:false}}};
  const mv=e=>{if(!ED.on)return;e.stopImmediatePropagation();e.preventDefault();
    const[sx,sy]=cvPt(e);if(!ED.pt.has(e.pointerId))return;ED.pt.set(e.pointerId,[sx,sy]);
    if(ED.pt.size===2){const a=[...ED.pt.values()],d=Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1]);if(ED.pinch0>10){cam.uz=clamp(cam.uz*d/ED.pinch0,edZmin(),2.2);camClamp()}ED.pinch0=d;return}
    if(ED.paint){const[wx,wy]=edW(sx,sy);if(Math.hypot(wx-ED.paint.lx,wy-ED.paint.ly)>ED.size*TS*.55){ED.paint.lx=wx;ED.paint.ly=wy;edPaint(wx,wy)}return}
    if(ED.drag){const D=ED.drag,[wx,wy]=edW(sx,sy),e2=D.e;
      let nx=D.x0+(wx-D.wx),ny=D.y0+(wy-D.wy);
      if(ED.x){const sn=ED.x.snap||22;nx=Math.round((D.x0+(wx-D.wx))/sn)*sn;ny=Math.round((D.y0+(wy-D.wy))/sn)*sn}
      else if((e2.fp||e2.type==='plot')&&!edFree(e2)){nx=D.x0+Math.round((wx-D.wx)/TS)*TS;ny=D.y0+Math.round((wy-D.wy)/TS)*TS}else{nx=Math.round(nx/3)*3;ny=Math.round(ny/3)*3}
      if(!D.moved&&(Math.abs(nx-D.x0)>1||Math.abs(ny-D.y0)>1)){D.moved=true;D.prev=[e2.x,e2.y]}
      if(D.moved&&(nx!==e2.x||ny!==e2.y)){if(ED.x)ED.x.move(e2,nx,ny);else edMove(e2,nx,ny)}}
    else if(ED.pan){const P0=ED.pan,z=camZoom();cam.x=P0.cx-(sx-P0.sx)/z;cam.y=P0.cy-(sy-P0.sy)/z;camClamp();if(Math.hypot(sx-P0.sx,sy-P0.sy)>6)P0.moved=true}};
  const up=e=>{if(!ED.on)return;e.stopImmediatePropagation();ED.pt.delete(e.pointerId);
    if(ED.paint){const n=ED.paint.n;ED.paint=null;if(n)ED.undo.push(()=>{ED.ed.t.splice(ED.ed.t.length-n,n);edStore()});return}
    if(ED.drag){const D=ED.drag;if(D.moved){if(ED.x){const px=D.prev,en=D.e;ED.x.save();ED.undo.push(()=>{ED.x.move(en,px[0],px[1]);ED.x.save()})}else{edRec(D.e);const px=D.prev,en=D.e;ED.undo.push(()=>{edMove(en,px[0],px[1]);edRec(en)})}}ED.drag=null}
    if(ED.pan){if(!ED.pan.moved){ED.sel=null;edLabel()}ED.pan=null}};
  cv.addEventListener('pointerdown',dn,true);cv.addEventListener('pointermove',mv,true);cv.addEventListener('pointerup',up,true);cv.addEventListener('pointercancel',up,true);
  cv.addEventListener('wheel',e=>{if(!ED.on)return;e.stopImmediatePropagation()},true);
}
function edStart(){
  if(!S||!S.live)return;
  ED.x=window.__EDX||null;
  edBind();edUI();ED.on=true;edBtns();ED.sel=null;ED.undo=[];document.body.classList.add('edit');edLabel();
  const b=document.getElementById('edBar'),s=document.getElementById('edSel');if(b)b.hidden=false;if(s)s.hidden=false;
  UI.toast('Editor mappa: tocca e trascina gli oggetti.',3000);
}
function edStop(){
  if(ED.x){try{ED.x.save()}catch(e){}try{localStorage.removeItem('sm_edx_auto');__go('#w1')}catch(e){}location.reload();return}
  edStore();ED.on=false;ED.drag=ED.pan=null;ED.pt.clear();document.body.classList.remove('edit');
  const b=document.getElementById('edBar'),s=document.getElementById('edSel');if(b)b.hidden=true;if(s)s.hidden=true;
  camClamp();saveGame();ED.brush=null;
  if(ED.dirty){edtPreview()}
}
function edDraw(){
  if(!ED.on||(!ED.x&&(inCave()||inHut())))return;
  const g=ctx,z=camZoom();
  g.setTransform(DPR*z,0,0,DPR*z,DPR*(VW/2-cam.x*z),DPR*(VH/2-cam.y*z));
  const vx0=cam.x-VW/2/z,vy0=cam.y-VH/2/z,vx1=cam.x+VW/2/z,vy1=cam.y+VH/2/z;
  if(ED.x){edxDraw(g,z,vx0,vy0,vx1,vy1);return}
  if(ED.grid){g.strokeStyle='rgba(255,255,255,.14)';g.lineWidth=1/z;g.beginPath();for(let x=Math.floor(vx0/TS)*TS;x<vx1;x+=TS){g.moveTo(x,vy0);g.lineTo(x,vy1)}for(let y=Math.floor(vy0/TS)*TS;y<vy1;y+=TS){g.moveTo(vx0,y);g.lineTo(vx1,y)}g.stroke()}
  if(ED.grid){const all=EDT_BK.map(p=>[p,1]).concat(ED.ed.t.map(p=>[p,0]));const col={b:'255,220,120',g:'110,200,90',s:'60,140,255'};
   for(const[p,bk]of all){const c=col[p[0]]||'255,255,255';g.fillStyle='rgba('+c+','+(bk?.16:.3)+')';g.strokeStyle='rgba('+c+',.8)';g.lineWidth=1.5/z;g.beginPath();g.ellipse(p[1]*TS,p[2]*TS,p[3]*TS,p[4]*TS,0,0,7);g.fill();g.stroke()}}
  for(const e of E){
    if(!edOk(e)||e.x<vx0-80||e.x>vx1+80||e.y<vy0-40||e.y>vy1+120)continue;
    if(e.fp&&e.blocked){g.strokeStyle='rgba(80,220,255,.6)';g.lineWidth=2/z;g.strokeRect(e.fp[0]*TS+1,e.fp[1]*TS+1,e.fp[2]*TS-2,e.fp[3]*TS-2)}
    const sel=e===ED.sel;g.fillStyle=sel?'#ffd23a':'rgba(255,255,255,.8)';g.strokeStyle='rgba(20,12,4,.9)';g.lineWidth=1.5/z;g.beginPath();g.arc(e.x,e.y,(sel?7:3.5)/z,0,7);g.fill();g.stroke();
  }
  const s=ED.sel;if(s){const pl=.5+.5*Math.sin(RT*6);g.strokeStyle='rgba(255,214,58,'+(.6+.4*pl)+')';g.lineWidth=3/z;g.setLineDash([8/z,5/z]);
    if(s.fp)g.strokeRect(s.fp[0]*TS-3,s.fp[1]*TS-3,s.fp[2]*TS+6,s.fp[3]*TS+6);else g.strokeRect(s.x-30,s.y-70,60,84);g.setLineDash([])}
}
/* ---- editor dei mondi speciali (galeone, interno nave, viaggio finale) ---- */
function edxLabel(el){
  const X=ED.x,e=ED.sel,q=id=>el.querySelector('#'+id);
  const add=X.palette?'<button class="btn" id="edAdd">+ Aggiungi</button>':'';
  el.innerHTML=e?'<b>'+(X.name?X.name(e):(e.lab||'Punto'))+'</b><small>'+(X.info?X.info(e):'')+'</small>'+(X.del?'<button class="btn" id="edDel">Elimina</button>':'')+(X.dup?'<button class="btn" id="edDup">Duplica</button>':'')+add
    :'<span>Tocca un punto per selezionarlo, poi trascinalo.</span>'+add;
  if(q('edDel'))q('edDel').onclick=()=>{const it=ED.sel;if(!it)return;const u=X.del(it);ED.sel=null;ED.dirty=true;X.save();if(u)ED.undo.push(()=>{u();X.save();edLabel()});edLabel()};
  if(q('edDup'))q('edDup').onclick=()=>{const it=ED.sel;if(!it)return;const n=X.dup(it);if(n){ED.sel=n;ED.dirty=true;X.save();ED.undo.push(()=>{X.del(n);ED.sel=null;X.save();edLabel()});edLabel()}};
  if(q('edAdd'))q('edAdd').onclick=()=>{
    sheetFor('<h2>Aggiungi</h2><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:8px">'+X.palette.map((p,i)=>'<button class="btn" data-i="'+i+'">'+p[0]+'</button>').join('')+'</div><div class="row"><button class="btn" id="shNo">Chiudi</button></div>',c=>{
      c.querySelectorAll('[data-i]').forEach(b=>b.onclick=()=>{const p=X.palette[+b.dataset.i];closeSheet();const it=X.add(p[1],Math.round(cam.x/22)*22,Math.round(cam.y/22)*22);if(it){ED.sel=it;ED.dirty=true;X.save();ED.undo.push(()=>{X.del(it);ED.sel=null;X.save();edLabel()});edLabel()}})})};
}
function edxDraw(g,z,vx0,vy0,vx1,vy1){
  const X=ED.x;
  if(ED.grid){g.strokeStyle='rgba(255,255,255,.12)';g.lineWidth=1/z;const st=z<.2?TS*5:TS;g.beginPath();for(let x=Math.floor(vx0/st)*st;x<vx1;x+=st){g.moveTo(x,vy0);g.lineTo(x,vy1)}for(let y=Math.floor(vy0/st)*st;y<vy1;y+=st){g.moveTo(vx0,y);g.lineTo(vx1,y)}g.stroke()}
  if(X.draw)X.draw(g,z,vx0,vy0,vx1,vy1);
  const fs=Math.min(30,12/z);g.font='800 '+fs+'px sans-serif';g.textAlign='center';
  for(const it of X.items()){
    if(it.x<vx0-60||it.x>vx1+60||it.y<vy0-60||it.y>vy1+60)continue;
    const sel=it===ED.sel,r=(sel?8:5)/z;
    g.fillStyle=sel?'#ffd23a':(it.col||'rgba(255,255,255,.9)');g.strokeStyle='rgba(20,12,4,.95)';g.lineWidth=1.6/z;g.beginPath();g.arc(it.x,it.y,r,0,7);g.fill();g.stroke();
    if(it.lab&&(z>.5||sel||it.big)){g.lineWidth=3/z;g.strokeStyle='rgba(20,12,4,.9)';g.fillStyle='#fff6dc';g.strokeText(it.lab,it.x,it.y-r-4/z);g.fillText(it.lab,it.x,it.y-r-4/z)}
    if(sel){const pl=.5+.5*Math.sin(RT*6);g.strokeStyle='rgba(255,214,58,'+(.6+.4*pl)+')';g.lineWidth=3/z;g.beginPath();g.arc(it.x,it.y,(it.r||24),0,7);g.stroke()}
  }
}
function edxApply(){try{localStorage.setItem('sm_edx_auto','1');ED.x.save()}catch(e){}UI.toast('Applico le modifiche…',2000);setTimeout(()=>location.reload(),600)}
async function edtPreview(){
  UI.toast('Ridisegno la costa…',3000);
  EDT.length=0;for(const p of EDT_BK)EDT.push(p);for(const p of ED.ed.t)EDT.push(p);
  EDTON=true;edtGrids(true);
  try{await bakeGround(()=>{})}catch(e){console.warn(e)}
  ED.dirty=false;UI.toast('Costa aggiornata.',1800);
}
function edBtns(){
  const bar=document.getElementById('edBar');if(!bar)return;
  bar.querySelectorAll('.edXb').forEach(b=>b.remove());
  const X=ED.x;
  const tr=bar.querySelector('#edTr');if(tr)tr.hidden=!!X;
  const ap=bar.querySelector('#edAp');if(ap){ap.textContent=X?'Applica e rivedi':'Anteprima costa';ap.onclick=()=>{if(X)edxApply();else edtPreview()}}
  if(X&&X.buttons)for(const b of X.buttons){const e=document.createElement('button');e.className='btn edXb';e.textContent=b.t;e.onclick=b.fn;bar.appendChild(e)}
}
function edAuto(){
  if(!window.__EDX)return;
  try{if(localStorage.getItem('sm_edx_auto')!=='1')return}catch(e){return}
  let n=0;const iv=setInterval(()=>{
    n++;if(n>80){clearInterval(iv);return}
    if(!S||!S.live)return;
    if(dl.open){try{UI.dlgAuto()}catch(e){}return}
    clearInterval(iv);try{localStorage.removeItem('sm_edx_auto')}catch(e){}
    setTimeout(()=>{try{edStart()}catch(e){console.warn(e)}},600);
  },500);
}
setTimeout(edAuto,1500);
window.__ED={start:edStart,stop:edStop,ED,scr:toScreen,E,EID,code:()=>JSON.stringify(ED.ed)};
