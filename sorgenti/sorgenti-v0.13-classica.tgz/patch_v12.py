#!/usr/bin/env python3
# v0.12: editor mappa (admin)
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH12 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
INJ=open('/home/claude/work/ed_inject.js',encoding='utf8').read().replace("let EDR=0;\n","")
BAKED=open("/home/claude/work/ed_baked.json",encoding="utf8").read().strip()
INJ=INJ.replace("const ED_BAKED=null;","const ED_BAKED="+BAKED+";")
rep("function ent(o){o.id=o.id||('e'+E.length);","let EDR=0;\nfunction ent(o){o.id=o.id||('e'+(E.length+EDR));")
rep("function frame(ts){\n",INJ+"\nfunction frame(ts){\n")
rep("if(!PAUSED&&!UI.sleeping){const n=Math.max(1,Math.round(TIMESCALE))","if(!PAUSED&&!UI.sleeping&&!ED.on){const n=Math.max(1,Math.round(TIMESCALE))")
rep("  render(t);\n  frameN++;","  render(t);if(ED.on)edDraw();\n  frameN++;")
rep("function camFollow(dt){\n","function camFollow(dt){\n  if(ED.on)return;\n")
rep("genWorld();pruneUnreachable();unhideLoot();","genWorld();pruneUnreachable();unhideLoot();edBoot();")
rep('<button class="btn" id="nwC3">','<button class="btn" id="nwEd">Editor mappa</button><button class="btn" id="nwC3">')
rep("  const go=c.querySelector('#nwGo');\n","  {const be=c.querySelector('#nwEd');if(be)be.onclick=()=>{uShow('journal',false);setTimeout(edStart,150)}}\n  const go=c.querySelector('#nwGo');\n")
rep('"Armadio della capanna: ora si apre','"Editor mappa (Diario → Novità, con password): metti in pausa il gioco, tocca un oggetto per selezionarlo, trascinalo dove vuoi, eliminalo, duplicalo, cambia aspetto o aggiungine di nuovi (alberi, pini, palme, cespugli, rocce, lanterne, barili, casse…). Puoi spostare anche capanna, falò, banco e zattera. «Salva» tiene le modifiche su questo telefono; «Codice» le copia per mandarle a Claude.",\n    "Mappa dell\'isola dei Relitti (seconda isola): oggetti e palme spostati o aggiunti con l\'editor, come li hai disegnati tu.",\n    "Il grande viaggio: Biscotto commenta con battute la nave fantasma.",\n    "Armadio della capanna: ora si apre')
open(P,'w',encoding='utf8').write(src)
print('patch12 ok')
