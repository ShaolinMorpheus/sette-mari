UI.openAdmin=function(){
  const body=()=>{
    if(!newsOK)return'<h2>Solo per me</h2><p class="sm">Area riservata: serve la password.</p><div class="row" style="gap:8px;margin-top:8px"><input id="nwPw" type="password" autocomplete="off" placeholder="Password" style="flex:1;min-width:0;padding:10px 12px;border-radius:10px;border:2px solid #7a5a34;font:700 15px inherit"><button class="btn gold" id="nwGo">Entra</button></div><p class="sm" id="nwErr" style="color:#a02818;font-weight:700"></p><div class="row"><button class="btn" id="shNo">Chiudi</button></div>';
    return'<h2>Solo per me</h2><h3>Editor</h3><div class="row" style="flex-wrap:wrap"><button class="btn" id="nwEd">Editor mappa</button><button class="btn" id="nwE3">Editor galeone</button><button class="btn" id="nwE4">Editor interno nave</button><button class="btn" id="nwE5">Editor viaggio finale</button></div><h3>Prova le missioni</h3><div class="row" style="flex-wrap:wrap"><button class="btn" id="nwC3">Capitolo 3 (battaglia)</button><button class="btn" id="nwC4">Assalto al galeone</button><button class="btn" id="nwC5">Il grande viaggio</button></div><h3>Versione</h3><div class="row"><button class="btn" id="nwVer">'+verLbl()+'</button></div><div class="row"><button class="btn" id="shNo">Chiudi</button></div>'};
  const wire=c=>{
    const go=c.querySelector('#nwGo');
    if(go){const tryPw=()=>{const v=(c.querySelector('#nwPw').value||'').trim();if(pwHash(v)===260412130){newsOK=true;sfx('ok');sheetFor(body(),wire)}else{c.querySelector('#nwErr').textContent='Password errata.';sfx('tap')}};go.onclick=tryPw;c.querySelector('#nwPw').onkeydown=e=>{if(e.key==='Enter')tryPw()}}
    {const nv=c.querySelector('#nwVer');if(nv)nv.onclick=verSwitch}
    const nc=c.querySelector('#nwC4');if(nc)nc.onclick=()=>{try{localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:3,t:0,shots:0,hits:0}))}catch(e){}__go('#w4');location.reload()};
    {const b3=c.querySelector('#nwC3');if(b3)b3.onclick=()=>{__go('#w3');location.reload()};const b5=c.querySelector('#nwC5');if(b5)b5.onclick=()=>{__go('#w5');location.reload()}}
    {const be=c.querySelector('#nwEd');if(be)be.onclick=()=>{closeSheet();setTimeout(edStart,150)}}
    for(const[id,h]of[['nwE3','#w3'],['nwE4','#w4'],['nwE5','#w5']]){const b=c.querySelector('#'+id);if(b)b.onclick=()=>{try{localStorage.setItem('sm_edx_auto','1');if(h==='#w4')localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:3,t:0,shots:0,hits:0}))}catch(e){}__go(h);location.reload()}}
  };
  sheetFor(body(),wire);
};
/* tastiera della password dentro al gioco: la tastiera di Android compare in verticale perché il gioco è ruotato */
function pwKb(c,go){
  const inp=c.querySelector('#nwPw');if(!inp||c.querySelector('#pwkb'))return;
  inp.readOnly=true;inp.setAttribute('inputmode','none');
  let up=false;
  const rows=['1234567890','qwertyuiop','asdfghjkl','^zxcvbnm<','.,!?-_@#$%&*+=/'];
  const d=document.createElement('div');d.id='pwkb';d.style.cssText='display:flex;flex-direction:column;gap:3px;margin:6px 0 0;user-select:none;-webkit-user-select:none';
  rows.forEach(r=>{const row=document.createElement('div');row.style.cssText='display:flex;gap:3px;justify-content:center';
    [...r].forEach(ch=>{const b=document.createElement('button');b.type='button';b.className='btn';b.style.cssText='min-width:0;flex:1;max-width:46px;height:27px;padding:0;font-weight:800;font-size:14px';b.textContent=ch==='^'?'⇧':ch==='<'?'⌫':ch;b.dataset.k=ch;row.appendChild(b)});d.appendChild(row)});
  d.onclick=e=>{const b=e.target.closest('button');if(!b)return;const k=b.dataset.k;try{sfx('tap')}catch(x){}
    if(k==='<')inp.value=inp.value.slice(0,-1);
    else if(k==='^'){up=!up;d.querySelectorAll('button').forEach(x=>{const q=x.dataset.k;if(/^[a-z]$/.test(q))x.textContent=up?q.toUpperCase():q})}
    else{inp.value+=(up&&/^[a-z]$/.test(k))?k.toUpperCase():k;if(up){up=false;d.querySelectorAll('button').forEach(x=>{const q=x.dataset.k;if(/^[a-z]$/.test(q))x.textContent=q})}}};
  inp.parentNode.insertAdjacentElement('afterend',d);
}
