#!/usr/bin/env python3
# v0.12q: collisioni casse/barili/forzieri, password con tastiera nel gioco, scheletro realistico
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH29 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
NEW=open('/home/claude/work/new29.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")
rep("try{rsTick(dt)}catch(e){console.error('zattera',e)}","try{rsTick(dt)}catch(e){console.error('zattera',e)}try{blkSync(dt)}catch(e){console.error('blk',e)}")
rep("c.querySelector('#nwPw').onkeydown=e=>{if(e.key==='Enter')tryPw()}}","c.querySelector('#nwPw').onkeydown=e=>{if(e.key==='Enter')tryPw()};pwKb(c,tryPw)}",2)
rep('<input id="nwPw" type="password" autocomplete="off" placeholder="Password"','<input id="nwPw" type="password" autocomplete="off" readonly inputmode="none" placeholder="Password"',2)
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Casse, forzieri, barili e matasse di corda ora sono solidi: non si attraversano più (scompare l'ostacolo quando il forziere è stato aperto).",
    "Password di «Novità» e «Solo per me»: tastiera tutta dentro al gioco, così non compare più quella verticale di Android.",
    "Lo scheletro della grotta è stato ridisegnato: teschio con bandana, costole, bacino, braccia con il biglietto, gambe e stivali.",
''')

# ---- erba: prato fitto a strati (B) + erba alta con spighe vicino all'acqua (D)
rep("""  const blade=(x,y,h,col)=>{g.strokeStyle=col;g.lineWidth=1.4;g.lineCap='round';g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+(r()-.5)*5,y-h*.6,x+(r()-.5)*8,y-h);g.stroke()};
""","""  const blade=(x,y,h,col)=>{g.strokeStyle=col;g.lineWidth=1.4;g.lineCap='round';g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+(r()-.5)*5,y-h*.6,x+(r()-.5)*8,y-h);g.stroke()};
  const tb=(x,y,h,lean,w,col)=>{g.fillStyle=col;g.beginPath();g.moveTo(x-w,y);g.quadraticCurveTo(x-w*.5+lean*.3,y-h*.6,x+lean,y-h);g.quadraticCurveTo(x+w*.5+lean*.3,y-h*.55,x+w,y);g.closePath();g.fill()};
  const reed=(x,y,hh)=>{
    g.fillStyle='rgba(20,50,20,.2)';g.beginPath();g.ellipse(x,y+1.5,9,2.6,0,0,7);g.fill();
    for(let i=0;i<7;i++){const a=(i-3)*2.6;tb(x+a*.55,y,hh*(.65+r()*.35),a*.9+(r()-.5)*3,1.3,i%2?'#4d8f38':'#3a7a2e')}
    for(let i=0;i<3;i++){const sx=x+(i-1)*4.5,sh=hh*(.95+r()*.2),tip=(i-1)*4+(r()-.5)*3;
      g.strokeStyle='#8a7a3a';g.lineWidth=1;g.lineCap='round';g.beginPath();g.moveTo(sx,y);g.quadraticCurveTo(sx+2.5,y-sh*.5,sx+tip,y-sh);g.stroke();
      g.fillStyle='#dcc67c';g.strokeStyle='#8a6a2a';g.lineWidth=.6;g.beginPath();g.ellipse(sx+tip,y-sh-3,1.7,4.4,tip*.07,0,7);g.fill();g.stroke()}
  };
""")
rep("""    for(let i=0;i<nT;i++){
      const x=(tx+r())*TS,y=(ty+r())*TS,hh=5+r()*7,l=hsl(84+r()*34,38+r()*20,28+r()*20,.9);
      for(let k=0;k<3;k++)blade(x+k*2.2-2,y,hh*(.7+r()*.5),l);
    }
""","""    const nT2=Math.round(nT*1.8);
    for(let i=0;i<nT2;i++){
      const x=(tx+r())*TS,y=(ty+r())*TS,hh=6+r()*9,hue=84+r()*34;
      if(r()<.35){g.fillStyle='rgba(20,50,20,.16)';g.beginPath();g.ellipse(x,y+1,5,1.6,0,0,7);g.fill()}
      const nb=3+((r()*3)|0);
      for(let k=0;k<nb;k++){const a=(k-(nb-1)/2),lean=a*2.2+(r()-.5)*3,h2=hh*(.7+r()*.5);tb(x+a*1.5,y,h2,lean,1.1,hsl(hue,42,22+r()*6,.95))}     // strato scuro
      for(let k=0;k<nb-1;k++){const a=(k-(nb-2)/2),lean=a*2.4+(r()-.5)*3,h2=hh*(.6+r()*.5);tb(x+a*1.4,y,h2,lean,.9,hsl(hue+4,48,36+r()*8,.95))}   // strato medio
      if(r()<.7){const a=(r()-.5)*4;tb(x+a,y,hh*(.5+r()*.3),a*1.5,.7,hsl(hue+10,55,56+r()*10,.95))}                                              // punta chiara
    }
    if(gT>.55&&s<.38&&!onPath&&fF<.5&&r()<.055)reed((tx+r())*TS,(ty+.3+r()*.6)*TS,22+r()*14);
""")
open(P,'w',encoding='utf8').write(src)
print('patch29 ok')
