const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext()).newPage();
p.on('pageerror',e=>console.log('ERR',e.message,e.stack&&e.stack.split('\n')[1]));p.on('console',m=>{if(m.type()==='error')console.log('C',m.text())});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');await p.waitForTimeout(8000);await b.close()})();
