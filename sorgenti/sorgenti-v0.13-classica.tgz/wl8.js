const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:2.37,hasTouch:true,isMobile:true});const p=await ctx.newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;s.tod=7.25;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
await p.evaluate(()=>{Pirati.tp(16.7,47.8)});await p.waitForTimeout(800);
await p.screenshot({path:'wl8_a.png'});
await p.evaluate(()=>{
 const cv=document.querySelector('canvas');const o=document.createElement('canvas');o.width=cv.width;o.height=cv.height;
 o.style.cssText=cv.style.cssText+';pointer-events:none;opacity:.55';o.className=cv.className;cv.parentNode.insertBefore(o,cv.nextSibling);
 const g=o.getContext('2d');const k=cv.width/Pirati.VW;
 for(let wy=40*44;wy<56*44;wy+=6)for(let wx=8*44;wx<30*44;wx+=6){
   if(Pirati.boxFree(wx,wy,9,5))continue;const[sx,sy]=Pirati.toScreen(wx,wy);g.fillStyle='rgba(255,0,0,.9)';g.fillRect(sx*k-2,sy*k-2,5*k,5*k)}
});
await p.waitForTimeout(300);await p.screenshot({path:'wl8_b.png'});await b.close()})();
