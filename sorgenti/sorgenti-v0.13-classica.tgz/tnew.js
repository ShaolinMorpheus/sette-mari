const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:915,height:412}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.removeItem('sm_c34')}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2800);
const out=[];
out.push(['followers',await p.evaluate(()=>Ch4.K.fol.map(f=>f.who).join(',')+' stay:'+Ch4.K.stay.length)]);
out.push(['rects',await p.evaluate(()=>{const r=id=>{const b=document.getElementById(id).getBoundingClientRect();return [id,Math.round(b.left),Math.round(b.top),Math.round(b.width)]};return [r('c4hit'),r('c4use'),r('c4par')]})]);
// 1. alleati fermi con guardia di pattuglia vicina
const r1=await p.evaluate(async()=>{const K=Ch4.K,P=Ch4.P;Ch4.tp(37,9.4);K.inv=99;
  const g=K.gd.find(x=>x);K.gd.forEach(x=>{x.ko=1e9});g.ko=0;g.st='patrol';g.x=P.x+120;g.y=P.y;g.wp=[[38,9],[39,9]];g.wi=0;g.wait=99;
  const f=K.fol[0];f.x=P.x-70;f.y=P.y+30;const x0=f.x,y0=f.y;
  await new Promise(r=>setTimeout(r,2500));
  return {allyMoved:Math.round(Math.hypot(f.x-x0,f.y-y0)),gst:g.st,ghp:g.hp,tgt:!!f.tgt}});
out.push(['pattuglia vicina, alleato fermo',r1]);
// 2. con inseguimento vicino, l'alleato interviene
const r2=await p.evaluate(async()=>{const K=Ch4.K,P=Ch4.P;const g=K.gd.find(x=>x.ko<=0);K.inv=99;g.st='chase';g.alert=9;g.x=P.x+80;g.y=P.y;
  await new Promise(r=>setTimeout(r,1500));const f=K.fol[0];return {tgt:!!f.tgt,ghp:g.hp,gst:g.st}});
out.push(['inseguimento: alleato interviene',r2]);
// 3. parata
const r3=await p.evaluate(async()=>{const K=Ch4.K,P=Ch4.P;K.gd.forEach(x=>{x.ko=1e9});Ch4.tp(37,9.4);K.fol.forEach(f=>{f.x+=900});K.inv=0;K.hp=K.maxhp;
  const g=K.gd[0];g.ko=0;g.st='chase';g.alert=9;g.hp=5;g.maxhp=5;g.x=P.x+30;g.y=P.y;g.hitCd=0;g.wp=[[38,9],[39,9]];
  K.fdx=1;K.fdy=0;
  const pb=document.getElementById('c4par');pb.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true}));
  const par1=K.parry;
  const hp0=K.hp;await new Promise(r=>setTimeout(r,900));const hpFront=K.hp;
  pb.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true}));const par2=K.parry;
  return {par1,par2,hp0,hpFront,blocks:K.parN2,gdist:Math.round(Math.hypot(g.x-P.x,g.y-P.y))}});
out.push(['parata davanti',r3]);
const r4=await p.evaluate(async()=>{const K=Ch4.K,P=Ch4.P;K.gd.forEach(x=>{x.ko=1e9});Ch4.tp(37,9.4);K.inv=0;K.hp=K.maxhp;
  const g=K.gd[0];g.ko=0;g.st='chase';g.alert=9;g.x=P.x-30;g.y=P.y;g.hitCd=0;K.fdx=1;K.fdy=0;P.flip=false;
  K.parry=true;K.parT=2;
  const hp0=K.hp;await new Promise(r=>setTimeout(r,700));const res={hp0,hp1:K.hp};K.parry=false;return res});
out.push(['parata ma colpo alle spalle',r4]);
// niente attacco durante la parata
out.push(['attacco in parata',await p.evaluate(()=>{const K=Ch4.K;K.parry=true;K.atk=0;K.swingT=0;document.getElementById('c4hit').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true}));const r=K.swingT;K.parry=false;return r})]);
console.log(out.map(x=>JSON.stringify(x)).join('\n'));console.log(er);await b.close()})();
