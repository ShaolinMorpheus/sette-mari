const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
const r=await p.evaluate(()=>{const C=Ch3.C,T=44;const o=[];const pt=C.ships.filter(s=>s.type==='pattuglia');o.push(pt.length,Math.round(Math.min(...pt.map(s=>Math.hypot(s.x-C.p.x,s.y-C.p.y)))),C.ships.filter(s=>s.type==='mercante').length,Math.round(Math.min(...C.ships.filter(s=>s.type==='mercante').map(s=>Math.hypot(s.x-C.p.x,s.y-C.p.y)))));
 C.tut=null;C.p.x=3000;C.p.y=3000;C.t=400;for(let i=0;i<5;i++)Ch3.step(.1);
 const g=C.ships.filter(s=>s.conv);o.push(C.convoy,g.length,g.map(s=>s.type[0]+(s.guard?'G':'')).join(''),Math.round(Math.min(...g.map(s=>Math.hypot(s.x-3000,s.y-3000)))));
 const R=Ch3.ROUTE;o.push(R[0].map(v=>Math.round(v/T)).join(','),g.map(s=>Math.round(s.x/T)+','+Math.round(s.y/T)).join(' '));return o});
await p.screenshot({path:'c3h.png'});console.log(JSON.stringify(r),errs);await b.close()})()
