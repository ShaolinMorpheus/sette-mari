const L=require('./aud/lib.js');
const fs=require('fs');
(async()=>{const {b,p,errs}=await L.boot({dsf:2});
 const ev=async(f,a)=>{try{return await p.evaluate(f,a)}catch(e){return {ERRORE:e.message.split('\n')[0].slice(0,220)}}};
 await p.waitForTimeout(1200);
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);
 await p.waitForTimeout(500);
 await p.evaluate(()=>{Pirati.S.tutDone=1;Pirati.S.tut=null});
 const out=[];
 // ---- stato iniziale ----
 out.push(['iniziale',JSON.stringify(await ev(()=>{const S=Pirati.S,F=Pirati.farm;F.wardCheck();return {wown:Object.keys(S.wown||{}),phats:Object.keys(S.phats||{})}}))]);
 // ---- menu: scheda Guardaroba con pochi capi (da trovare) ----
 await ev(()=>{Pirati.UI._mt='gd';Pirati.UI.openMenu()});
 await p.waitForTimeout(300);
 await p.screenshot({path:'aud/wd_menu0.png'});
 await ev(()=>{document.getElementById('mWh').click()});
 await p.waitForTimeout(300);
 await p.screenshot({path:'aud/wd_cappelli0.png'});
 await ev(()=>{(document.getElementById('shNo')||{click(){}}).click()});
 // ---- sblocco di tutto ----
 out.push(['sblocco',JSON.stringify(await ev(()=>{const S=Pirati.S,F=Pirati.farm;S.flags.hat=1;S.flags.parrot=1;try{localStorage.setItem('sm_gal','1')}catch(e){}
   F.farmInit();S.gard.harv=12;S.cOpen=9;S.flags.ch1=1;S.flags.ch2end=1;S.day=5;S.stat=S.stat||{};S.stat.fish=20;S.stat.forage=20;S.rec={};for(const r of F.RECIPES)S.rec[r.id||r.k||r]=1;
   F.wardCheck();return {wown:Object.keys(S.wown||{}).length,phats:Object.keys(S.phats||{}),recs:Object.keys(S.rec).length,rc:F.RECIPES.length}}))]);
 await p.waitForTimeout(400);
 // ---- scelta cappello e abito dalle schede ----
 await ev(()=>{Pirati.UI._mt='gd';Pirati.UI.openMenu()});await p.waitForTimeout(200);
 await ev(()=>{document.getElementById('mWh').click()});await p.waitForTimeout(300);
 await p.screenshot({path:'aud/wd_cappelli.png'});
 out.push(['cappelli sheet',JSON.stringify(await ev(()=>{const c=document.getElementById('sheetCard');return {n:c.querySelectorAll('[data-w]').length,lock:c.querySelectorAll('.wl li').length,imgs:[...c.querySelectorAll('img')].map(i=>i.src.length>200).every(Boolean)}}))]);
 await ev(()=>{document.querySelector('#sheetCard [data-w="h_cuoco"]').click()});await p.waitForTimeout(300);
 out.push(['scelto cappello',JSON.stringify(await ev(()=>({wear:Pirati.S.wear,look:localStorage.getItem('sm_look'),spec:Pirati.farm.heroSpec().hat})))]);
 await ev(()=>{Pirati.UI._mt='gd';Pirati.UI.openMenu()});await p.waitForTimeout(200);
 await ev(()=>{document.getElementById('mWo').click()});await p.waitForTimeout(300);
 await p.screenshot({path:'aud/wd_abiti.png'});
 await ev(()=>{document.querySelector('#sheetCard [data-w="o_gent"]').click()});await p.waitForTimeout(300);
 out.push(['scelto abito',JSON.stringify(await ev(()=>({wear:Pirati.S.wear,look:localStorage.getItem('sm_look'),coat:Pirati.farm.heroSpec().coat,hat:Pirati.farm.heroSpec().hat})))]);
 await ev(()=>{Pirati.UI._mt='gd';Pirati.UI.openMenu()});await p.waitForTimeout(300);
 await p.screenshot({path:'aud/wd_menu1.png'});
 await ev(()=>{document.getElementById('mX').click()});
 // ---- raccolta nel diario ----
 await ev(()=>{Pirati.UI.openJournal('n')});await p.waitForTimeout(200);
 out.push(['diario novita',JSON.stringify(await ev(()=>{const j=document.getElementById('journal');return {len:j.innerText.length,hasStab:/stabile|Versione/i.test(j.innerText)}}))]);
 await ev(()=>{document.getElementById('journal').hidden=true;Pirati.UI.sync()});
 // ---- foglio contatto: tutti i cappelli e gli abiti, maschio e femmina ----
 for(const sex of['m','f']){
   const url=await ev((sx)=>{
     window.__hero=sx;const S=Pirati.S,F=Pirati.farm,W=F.WEAR.filter(x=>x.k!=='par');
     const cw=96,chh=150,cols=8,rows=Math.ceil((W.length+1)/cols),cv=document.createElement('canvas');cv.width=cols*cw;cv.height=rows*chh;
     const g=cv.getContext('2d');g.fillStyle='#d9c08a';g.fillRect(0,0,cv.width,cv.height);
     const sv=S.wear;const cells=[{lab:'base',w:{}}].concat(W.map(it=>({lab:it.n,w:it.k==='hat'?{hat:it.id}:{out:it.id}})));
     cells.forEach((c,i)=>{S.wear=c.w;const k=F.heroSpec();const x=(i%cols)*cw+cw/2,y=((i/cols)|0)*chh+chh-24;
       g.save();g.translate(x,y);g.scale(1.9,1.9);try{F.drawChar(g,0,0,{k,dir:'f',noShadow:1,t:0})}catch(e){}g.restore();
       g.fillStyle='#2a1508';g.font='bold 9px sans-serif';g.textAlign='center';g.fillText(c.lab.slice(0,16),(i%cols)*cw+cw/2,((i/cols)|0)*chh+chh-6)});
     S.wear=sv;window.__hero=undefined;return cv.toDataURL('image/png')},sex);
   if(typeof url==='string')fs.writeFileSync('aud/wd_foglio_'+sex+'.png',Buffer.from(url.split(',')[1],'base64'));else out.push(['foglio '+sex,JSON.stringify(url)]);
 }
 console.log(out.map(x=>x.join(': ')).join('\n'));
 console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
