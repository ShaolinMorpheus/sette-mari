# Il grande viaggio: mondo "mare aperto" a cinque zone. Eseguito da mk_final.py (usa src e rep).
# VOY=1 quando l'indirizzo e' #w5: il mondo resta il 3 (mare) ma con mappa, isole e fix propri.
# BLOBS_5: [cx, cy, rx, ry] in tile, mappa 260x110, rotta da est (x grande) a ovest (x piccolo).
BL5 = [[262,28,9,10],[262,86,9,10],[238,16,9,6],[236,96,10,6],[226,34,3.2,2.6],[246,78,4,3],[204,16,8,5],[196,94,9,6],[207,60,3,2.4],[184,18,5,3.5],[182,84,5,4],[166,12,8,5],[160,96,10,6],[170,66,3.4,3],[143,17,6,4],[140,92,7,5],[138,66,3,2.4],[124,20,5,3.4],[122,86,5,3.6],[123,36,2.6,2.2],[108,28,3,2.4],[95,36,2.4,2.0],[98,80,4,3],[94,28,3,2.4],[104,96,5,3.4],[112,78,3,2.4],[79,68,2.4,2],[78,14,7,4.5],[80,92,8,5],[80,78,3.6,3],[60,34,3.4,2.8],[54,48,3,2.6],[87,33,3,2.4],[65,48,2.4,2],[40,14,6,4],[42,92,8,5],[24,18,5,4],[22,88,6,4],[10,50,9.5,9],[6,22,5,4],[5,84,6,4],[58,80,2.6,2.2]]
FO5 = [[b[0], b[1], b[2]*.78, b[3]*.78, .85] for b in BL5 if b[2] >= 4.5]
def lst(a):
    return '[' + ','.join('[' + ','.join(str(v) for v in r) + ']' for r in a) + ']'

rep("const BLOBS=WORLD===4?[]:WORLD===3?BLOBS_3:",
    "const BLOBS_5=" + lst(BL5) + ";\nconst BLOBS=WORLD===4?[]:WORLD===3?(VOY?BLOBS_5:BLOBS_3):")
rep("const BEACH=WORLD===4?[]:WORLD===3?BEACH_3:", "const BEACH=WORLD===4?[]:WORLD===3?(VOY?[]:BEACH_3):")
rep("const FORESTS=WORLD===3?FORESTS_3:WORLD===2?FORESTS_2:FORESTS_1;",
    "const FORESTS_5=" + lst(FO5) + ";\nconst FORESTS=WORLD===3?(VOY?FORESTS_5:FORESTS_3):WORLD===2?FORESTS_2:FORESTS_1;")
rep("const FIX=WORLD===4?FIX_4:WORLD===3?FIX_3:",
    "const FIX_5=Object.assign({},FIX_3,{spawn:[248,60],sign:[-60,-60],raftLaunch:[248,60]});\nconst FIX=WORLD===4?FIX_4:WORLD===3?(VOY?FIX_5:FIX_3):")
rep("MW=WORLD===4?72:WORLD===3?210:99, MH=WORLD===4?46:WORLD===3?126:60,",
    "MW=WORLD===4?72:WORLD===3?(VOY?260:210):WORLD===1?174:99, MH=WORLD===4?46:WORLD===3?(VOY?110:126):WORLD===1?72:60,")
# nessun cartello del porto
rep("  deco('feedback','sign',FIX.sign[0],FIX.sign[1],[Math.floor(FIX.sign[0]),Math.floor(FIX.sign[1]),1,1],{k:.9,hitw:64,hith:84,label:'Porto di Calvara'", "  if(!VOY)deco('feedback','sign',FIX.sign[0],FIX.sign[1],[Math.floor(FIX.sign[0]),Math.floor(FIX.sign[1]),1,1],{k:.9,hitw:64,hith:84,label:'Porto di Calvara'")
# l'alberatura nel mare ignoto e' piu' rada
rep("const pine=tx>52?r()<.7:r()<.2;", "const pine=VOY?r()<.45:tx>52?r()<.7:r()<.2;")
# disegno del fondale (sargassi, gorghi, boe, relitti) prima delle navi
rep("  if(WORLD===4)Ch4.drawFloor(g,t);\n", "  if(WORLD===4)Ch4.drawFloor(g,t);\n  if(WORLD===3&&VOY)Ch3.drawFloor(g,t);\n")

rep("  if(WORLD===3)return hyp(tx+.5-21.55,ty+.5-43.6)<2.2;","  if(WORLD===3)return VOY?(hyp(tx+.5-15.5,ty+.5-48)<4.5||(ty>=48&&ty<=53&&tx>=14&&tx<=26)):hyp(tx+.5-21.55,ty+.5-43.6)<2.2;")
