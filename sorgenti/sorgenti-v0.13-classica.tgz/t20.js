const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error'&&!/Failed to load/.test(m.text()))errs.push(m.text())});
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(2000);
console.log(Object.keys(await p.evaluate(()=>Object.keys(Ch3))).length, await p.evaluate(()=>Object.keys(Ch3).join()));
const d=await p.evaluate(()=>Ch3.dump().split('\n').slice(0,1)[0]);console.log(d);
await p.screenshot({path:'c3a.png'});console.log(errs);await b.close()})()
