const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:1100,height:620}});const p=await ctx.newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
for(let i=0;i<60&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(300)}
const r=await p.evaluate(()=>{Pirati.boardRaft();Pirati.P.x=35*44;Pirati.P.y=13.6*44;const d=Pirati.dockSpot();Pirati.leaveRaft(d);const m=Pirati.EID.mraft;return [d,Math.round(m.x),Math.round(m.y),JSON.stringify(Pirati.S.raftAt)]});
console.log(r);await p.evaluate(()=>Pirati.saveGame());await p.reload();await p.waitForTimeout(2500);await p.click('#bCont');await p.waitForTimeout(2500);
for(let i=0;i<60&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(300)}
console.log(await p.evaluate(()=>{const m=Pirati.EID.mraft;return [Math.round(m.x),Math.round(m.y),JSON.stringify(Pirati.S.raftAt)]}));
console.log(er);await b.close()})();
