p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:70],s.count(a))
    s=s.replace(a,b)
# guard SAY lookup + home + evening + quest lines
rep("if(dist<5&&g.k){const L=Ch2.SAY[g.k][w];if(L&&(g.k!=='wander'||Math.random()<.4)&&pd<16*TS){say(e,L[(Math.random()*L.length)|0],4.2);e.wt=7+Math.random()*6}}continue}",
"""if(dist<5&&g.k){let L=Ch2.SAY[g.k]&&Ch2.SAY[g.k][w];
        if(g.k!=='home'&&g.k!=='sit'){const qs=Ch2.questLine(w);if(qs&&Math.random()<.4)L=[qs]}
        if(L&&(g.k!=='wander'||Math.random()<.4)&&pd<16*TS){say(e,L[(Math.random()*L.length)|0],4.2);e.wt=7+Math.random()*6}}continue}""")
rep("    e.wt-=dt;\n    if(e.wt>0||night||pd<2.4*TS)continue;","""    if(!e.home)e.home={x:e.x,y:e.y};
    if(night){   // di notte tornano alla propria tenda
      if(hyp(e.x-e.home.x,e.y-e.home.y)>.9*TS&&!(e.hf>2)){e.tgt={x:e.home.x,y:e.home.y,k:'home'};e.mv=1;e.hf=(e.hf||0)+1}
      continue}
    e.hf=0;
    e.wt-=dt;
    if(e.wt>0||pd<2.4*TS)continue;""")
rep("      const s0=Math.random()<.25?{k:'wander'","      const eve=S.tod>=19&&S.tod<22;\n      const s0=eve&&Math.random()<.85?{k:'sit',tx:56+((Math.random()*4)|0),ty:30+((Math.random()*3)|0)}:Math.random()<.25?{k:'wander'")
rep("Ch2.SAY={","""Ch2.SAY={
  sit:{ferro:["Il fuoco, la sera. Il momento in cui si pensa di più.","Non è il momento di parlare. È il momento di ascoltare."],nives:["Ahh. Una sedia vera. Sto per addormentarmi in piedi.","Il fuoco crepita, il ferro riposa. La giornata è buona."],tito:["Sono qui. Non ho fatto niente. Sono qui.","Questo fuoco è più caldo di ieri. Forse."],gnocco:["Se stasera avanzasse qualcosa... non avanza mai.","Il fuoco, il pentolone, gli amici. Mi manca solo il pane."]},""")
rep("Ch2.spots=function(w){","""Ch2.QSAY={
  c7:{ferro:"Il Pino Maestro: dritto, alto, pesante. Non sprecare i colpi.",nives:"Per segare quel pino serve braccio e carattere. Il carattere ce l'hai.",tito:"Quel pino l'ho visto da lontano. Da lontano è bellissimo.",gnocco:"Tutto quel legno... e nemmeno un tavolo per mangiare."},
  c8:{ferro:"Il timone non è un affare di tutti. Meno ne parliamo, meglio è.",nives:"Il timone nascosto? Ferro e i suoi segreti. Qualcuno dovrà dirgli che i segreti pesano.",tito:"Se ti dico dove è il timone, mi fai un favore? Ah, sì. Sei tu che lo cerchi.",gnocco:"Una grotta buia, un timone, un cuoco spaventato. Non è la mia trama preferita."},
  c9:{ferro:"Le vele devono essere pronte prima dell'alba. Nives lo sa.",nives:"Tela buona costa. E io non faccio sconti. Quasi mai.",tito:"Le vele si tendono con le mani. Le mie sono pronte.",gnocco:"Le vele bianche, il mare blu. Peccato manchi il rosso della salsa."},
  c10:{ferro:"Albero, timone, vele. Manca l'ultimo ordine: montarli.",nives:"Il cantiere è la parte che mi piace. Martello, chiodi e silenzio. Meno il silenzio.",tito:"Sento che la nave ha un nome. Non so quale. Ma lo sento.",gnocco:"Sulla nave voglio un fornello. Anche piccolo."},
  c11:{ferro:"Stasera si parla. Domani si agisce.",nives:"La riunione di stasera... niente di buono, ma almeno c'è il fuoco.",tito:"Io non parlo nelle riunioni. Io osservo.",gnocco:"Stasera cucino per tutti. Anche per chi dice di no."},
  c12:{ferro:"Il viaggio sarà lungo. Il cibo decide molto.",nives:"Il cibo a bordo... meglio se asciutto. Mi senti, Gnocco?",tito:"Un viaggio senza biscotti è un viaggio triste. Non Biscotto, i biscotti!",gnocco:"Rifornimenti. La parola più bella della lingua italiana."}
};
Ch2.questLine=function(w){
  for(const q in Ch2.QSAY)if(qAct(q)&&Ch2.QSAY[q][w])return Ch2.QSAY[q][w];
  return null;
};
Ch2.RAINSAY={ferro:["Pioggia. Ripariamo le scorte.","La pioggia riempie la cisterna. Almeno quello."],nives:["Piove sul ferro! Ora arrugginisce.","Che meraviglia, l'acqua. Dall'alto."],tito:["Mi sto bagnando. Ma anche gli alberi.","Piove! Io non c'entro."],gnocco:["Pioggia: il pentolone si riempie da solo!","Piove. Brodo gratis."]};
Ch2.spots=function(w){""")
rep("Ch2.npcAI=function(dt){\n  const night=S.tod>=22||S.tod<6;","""Ch2.npcAI=function(dt){
  const night=S.tod>=22||S.tod<6;
  Ch2._wc=(Ch2._wc||40)-dt;
  if(Ch2._wc<=0&&S.wx&&(S.wx.k==='rain'||S.wx.k==='storm')){
    Ch2._wc=70+Math.random()*50;
    const ws=Object.keys(Ch2.NPC).filter(w=>{const e=EID['npc_'+w];return e&&hyp(e.x-P.x,e.y-P.y)<12*TS});
    if(ws.length){const w=ws[(Math.random()*ws.length)|0],L=Ch2.RAINSAY[w];say(EID['npc_'+w],L[(Math.random()*L.length)|0],4)}
  }""")
# trust tutorial after first chat
rep("    if(c.talkDay[w]!==S.day){c.talkDay[w]=S.day;Ch2.addTrust(w,1)}","    if(c.talkDay[w]!==S.day){c.talkDay[w]=S.day;Ch2.addTrust(w,1);if(!c.said.trustTut){c.said.trustTut=1;setTimeout(()=>UI.dlg([D('hero',\"Parlando con loro sembra che si fidino un po' di più. I cuori accanto al nome, quando mi rivolgo a qualcuno, dicono quanto.\"),D('hero',\"Se mi occupo di ciò che serve a ciascuno, forse la fiducia pesa più di quanto penso.\")]),600)}}")
# gifts, riddles, daily requests
rep("Ch2.talk=function(e){","""Ch2.FAV={ferro:'arrosto',nives:'rottami',tito:'bacche',gnocco:'coco'};
Ch2.RID={
  gnocco:[["Gnocco: «Ingrediente segreto del mio brodo: A) alga, B) cannella, C) sabbia?»",["Alga","Cannella","Sabbia"],0,"Alga! Hai il palato fine. O la fortuna dei pazzi.","Sabbia, ahimè. Era l'ingrediente involontario di ieri."],["Gnocco: «Cosa ci va con il pesce arrosto? A) limone, B) cioccolato, C) chiodi?»",["Limone","Cioccolato","Chiodi"],0,"Limone! Un cuoco nato.","No... il cioccolato era per un altro piatto. Che non esiste."],["Gnocco: «Quanto sale nel brodo? A) un pizzico, B) un pugno, C) tutto quello che c'è?»",["Un pizzico","Un pugno","Tutto quello che c'è"],0,"Un pizzico! Beh, io ne metto un pugno. Ma hai ragione.","Il mio metodo? Quasi! Ma il resto del campo non è d'accordo."]],
  nives:[["Nives: «Per piegare il ferro caldo uso: A) tenaglie, B) cucchiaio, C) pettine?»",["Tenaglie","Cucchiaio","Pettine"],0,"Tenaglie! Una che capisce.","Un pettine. No. Non voglio sapere il perché."],["Nives: «Cosa fa il martello? A) batte, B) taglia, C) canta?»",["Batte","Taglia","Canta"],0,"Batte. Semplice. E ti piace semplice.","Canta, se lo colpisci sulla incudine giusta. Ma batte."],["Nives: «La vela si cuce con: A) ago e filo di canapa, B) chiodi, C) nastro adesivo?»",["Ago e filo","Chiodi","Nastro adesivo"],0,"Ago e filo. Chi l'avrebbe detto.","Nastro adesivo? Siamo su un'isola dei pirati, non in un negozio."]],
  tito:[["Tito: «Quale nodo tiene meglio la barca al molo? A) gassa, B) fiocco, C) cravatta?»",["Gassa","Fiocco","Cravatta"],0,"La gassa! Sei più bravo di me. Non dirlo a nessuno.","Il fiocco è per i regali. Ma ci arrivi."],["Tito: «A cosa serve il bompresso? A) alla prua, B) al cuoco, C) alle chiacchiere?»",["Alla prua","Al cuoco","Alle chiacchiere"],0,"Alla prua! Ecco, non si può dire che non ti insegni cose.","Al cuoco no. Alle chiacchiere... anche."],["Tito: «Cosa regge l'albero maestro? A) sartie, B) spaghetti, C) buona volontà?»",["Sartie","Spaghetti","Buona volontà"],0,"Le sartie! Le conosci davvero.","La buona volontà aiuta. Ma servono le sartie."]],
  ferro:[["Ferro: «Qual è la prima regola del mare?»",["Si parte con l'ordine","Si parte col sole","Si parte in fretta"],0,"Esatto. Ordine prima di tutto.","No. Prima l'ordine. Poi il resto."],["Ferro: «Cosa tiene unito un equipaggio?»",["La disciplina","Il pranzo","La fortuna"],0,"Disciplina. Bene.","Anche il pranzo aiuta. Ma la disciplina è prima."],["Ferro: «Chi decide la rotta?»",["Il capitano","Il vento","Il cuoco"],0,"Il capitano. Mai il cuoco.","Il capitano. Sempre il capitano."]]
};
Ch2.REQ={
  ferro:[[{legna:4},"quattro tronchi"],[{pietra:4},"quattro pietre"],[{arrosto:2},"due pesci arrosto"]],
  nives:[[{rottami:3},"tre rottami"],[{corda:3},"tre corde"],[{legna:3},"tre tronchi"]],
  tito:[[{bacche:3},"tre bacche"],[{pesce:2},"due pesci"],[{coco:2},"due noci di cocco"]],
  gnocco:[[{pesce:3},"tre pesci"],[{molluschi:3},"tre molluschi"],[{bacche:3},"tre bacche"]]
};
for(const w of['ferro','nives','tito','gnocco']){
  const rq=()=>Ch2.REQ[w][S.day%3];
  Ch2.QH.push({w,active:()=>qDone('c5')&&C().met[w]&&(C().reqD||{})[w]!==S.day,offer:()=>true,ready:()=>hasRes(rq()[0]),label:()=>"Richiesta del giorno: "+rq()[1],run(){
    const c=C();c.reqD=c.reqD||{};
    if(!hasRes(rq()[0])){UI.dlg([D(w,"Oggi mi servirebbero "+rq()[1]+". Se riesci, portameli.")]);return}
    payRes(rq()[0]);UI.sync();c.reqD[w]=S.day;sfx('ok');addXp(12);Ch2.addTrust(w,1);
    UI.dlg([D(w,w==='ferro'?"Consegnato. Puntuale.":w==='nives'?"Proprio quello che serviva. Ti devo un favore.":w==='tito'?"Wow, davvero! Ti sei ricordato!":"Splendido! Ci faccio una cosa. Anche due."),D(w,"Grazie.")],()=>checkAll())}});
  Ch2.QH.push({w,active:()=>C().met[w]&&(C().giftD||{})[w]!==S.day&&!!(S.res[Ch2.FAV[w]]),label:()=>"Fai un regalo: "+RNAME[Ch2.FAV[w]].toLowerCase(),run(){
    const c=C();c.giftD=c.giftD||{};const f=Ch2.FAV[w];
    if(!(S.res[f]>=1)){UI.dlg([D(w,"Non ho bisogno di niente.")]);return}
    S.res[f]--;UI.sync();c.giftD[w]=S.day;sfx('ok');Ch2.addTrust(w,2);
    UI.dlg([D(w,w==='ferro'?"Non mi serviva. Ma lo tengo.":w==='nives'?"Ah! Proprio quello che cercavo. Come hai fatto a saperlo?":w==='tito'?"Per me?! Nessuno mi ha mai regalato niente. Nemmeno per sbaglio.":"Il mio preferito! Hai capito tutto.")],()=>checkAll())}});
  Ch2.QH.push({w,active:()=>C().met[w]&&(C().ridD||{})[w]!==S.day&&qDone('c5'),label:()=>"Gioca a indovinare",run(){
    const c=C();c.ridD=c.ridD||{};const r=Ch2.RID[w][S.day%3];
    const mk=(t,i)=>({t,fn:()=>{c.ridD[w]=S.day;if(i===r[2]){Ch2.addTrust(w,1);const k=['bacche','coco','rottami'][(Math.random()*3)|0];gain(k,2,P.x,P.y-20,true);addXp(8)}},next:[D(w,i===r[2]?r[3]:r[4])]});
    UI.dlg([D(w,r[0],{choices:r[1].map((t,i)=>mk(t,i))})],()=>checkAll())}});
}
Ch2.talk=function(e){""")
open(p,'w',encoding='utf8').write(s)
