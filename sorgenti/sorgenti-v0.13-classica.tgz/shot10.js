const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:412,height:915},deviceScaleFactor:1.5,hasTouch:true,isMobile:true})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.removeItem('sm_c34')}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2800);
await p.evaluate(()=>{const K=Ch4.K;K.gd.forEach(g=>{g.ko=1e9});Ch4.tp(30,15)});await p.waitForTimeout(900);
await p.screenshot({path:'sab/ph1.png'});
await p.evaluate(()=>{Ch4.tp(29.5,13)});await p.waitForTimeout(900);
await p.screenshot({path:'sab/ph2.png'});
console.log(er);await b.close()})();
