const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.built={falo:1,capanna:1,banco:1,zattera:1};for(const id of['falo','capanna','banco','zattera']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}Pirati.saveGame();Pirati.Ch2.begin()});
 await p.waitForNavigation({timeout:20000}).catch(()=>{});
 await p.waitForFunction(()=>window.Pirati&&window.Pirati.S&&window.Pirati.S.live,null,{timeout:60000}).catch(()=>{});await p.waitForTimeout(1500);await L.skip(p);
 const r=await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.built.banco=1;
  for(const k of['legna','pietra','corda','rottami','tela','pesce'])S.res[k]=500;
  const out=['world='+Pirati.WORLD+' plots='+Object.keys(Pirati.EID).filter(k=>k.startsWith('plot_')).join('/')];
  try{Pirati.UI.openUpgrades()}catch(e){out.push('open err '+e)}
  const f=Pirati.EID.plot_falo;let n=0;for(let a=-12;a<=12;a+=4)for(let c=-12;c<=12;c+=4){Pirati.E.push({type:'cdeco',tx:Math.floor(f.fp[0]+a),ty:Math.floor(f.fp[1]+c),x:0,y:0,fake:1});n++}out.push('fake='+n);const D=Pirati.farm.DECOR.filter(d=>d.k==='orto'||d.k==='essic');
  for(const d of D){const bt=document.querySelector('[data-dc="'+d.k+'"]');if(!bt){out.push(d.k+':nobtn');continue}try{bt.click()}catch(e){out.push('EXC '+d.k+' '+e)}out.push(d.k+':'+((S.camp||[]).some(o=>o.k===d.k)?'ok':'FAIL'))}
  return out.join(' ')});
 console.log(r);console.log('ERR',JSON.stringify(errs));await b.close()})();
