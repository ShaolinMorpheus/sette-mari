const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/sette-mari/www/index.html');await p.waitForTimeout(2500);
const v=await p.evaluate(()=>!!document.getElementById('bCap3'));await p.evaluate(()=>document.getElementById('bCap3').click());await p.waitForTimeout(6000);
console.log(v,p.url(),await p.evaluate(()=>typeof Ch3),er);await b.close()})()
