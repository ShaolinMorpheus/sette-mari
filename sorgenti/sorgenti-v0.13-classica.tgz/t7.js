const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1500);
const r=await p.evaluate(()=>{const C=Ch4,K=C.K,P=C.P;const q=K.duels[0][1];C.tp(28,11);P.x=q.x+60;P.y=q.y;K.fdx=-1;K.fdy=0;const o=[];
 for(let i=0;i<3;i++){K.atk=0;C.atk();for(let j=0;j<20;j++)C.step(1/30);o.push(q.hp)}
 for(let j=0;j<200;j++)C.step(1/30);o.push(q.ko>0,K.duels[0][0].sw);return o});
await p.screenshot({path:'s3.png'});console.log(JSON.stringify(r),errs);await b.close()})()
