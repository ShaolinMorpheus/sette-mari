/* ---------------- oggetti di scena ---------------- */
const NOBLOCK=['chair','coil','bench','rug'];
const PROPS_BY=[
 /* PONTE DI COMANDO */
 [['bed',2,3,2,2],['wardrobe',5,2,2,1],['bookshelf',8,2,2,1],['globe',9,4,1,1],
  ['desk',6,6,3,1,{obj:'desk'}],['chair',7,7,1,1,{d:'u'}],['chest',3,13,1,1,{obj:'k1'}],['chest',9,14,1,1,{plain:1}],
  ['table',7,11,2,1,{t:'dine'}],['chair',6,11,1,1,{d:'r'}],['chair',9,11,1,1,{d:'l'}],['chair',7,10,1,1,{d:'d'}],['chair',8,12,1,1,{d:'u'}],
  ['mast',21,8,1,1],['barrel',13,10,1,1],['barrel',29,6,1,1],['barrel',29,10,1,1],
  ['longtable',24,7,4,2,{t:'council'}],['chair',24,6,1,1,{d:'d'}],['chair',25,6,1,1,{d:'d'}],['chair',26,6,1,1,{d:'d'}],['chair',27,6,1,1,{d:'d'}],['chair',23,7,1,1,{d:'r'}],['chair',28,7,1,1,{d:'l'}],
  ['bunk',13,2,2,1,{c:'#7a8a5a'}],['chest',15,2,1,1,{plain:1}],['bunk',16,2,2,1,{c:'#a8503a'}],['bunk',19,2,2,1,{c:'#5a7a9a'}],['chest',21,2,1,1,{plain:1}],['bunk',22,2,2,1,{c:'#a8503a'}],['bunk',25,2,2,1,{c:'#7a8a5a'}],['chest',27,2,1,1,{plain:1}],['bunk',28,2,2,1,{c:'#5a7a9a'}],
  ['table',20,4,2,1,{t:'dine'}],['chair',19,4,1,1,{d:'r'}],['chair',22,4,1,1,{d:'l'}],['barrel',13,4,1,1],
  ['armor',12,13,1,1],['armor',21,13,1,1],['rack',13,15,2,1],['rack',16,15,2,1,{obj:'sword'}],['rack',19,15,2,1],['table',18,13,2,1,{t:'dine'}],['barrel',12,15,1,1],
  ['maptable',24,14,3,1,{obj:'chart'}],['chair',23,14,1,1,{d:'r'}],['chair',27,14,1,1,{d:'l'}],['bookshelf',28,15,2,1],['bookshelf',23,15,1,1],['globe',29,14,1,1],
  ['mast',35,8,1,1],['barrel',33,3,1,1],['barrel',33,14,1,1],['coil',34,6,1,1],['coil',39,13,1,1],['cannon',33,2,1,1,{d:-1}],['cannon',38,2,1,1,{d:-1}],['cannon',33,15,1,1,{d:1}],['cannon',36,15,1,1,{d:1,obj:'lure'}],['cannon',38,15,1,1,{d:1}],
  ['cannon',42,2,1,1,{d:-1}],['cannon',45,2,1,1,{d:-1}],['barrel',42,14,1,1],['barrel',45,14,1,1],['barrel',45,13,1,1],['coil',43,10,1,1]],
 /* PONTE DI MEZZO */
 [['bunk',2,4,2,1,{c:'#7a8a5a'}],['bunk',2,6,2,1,{c:'#a8503a'}],['bunk',2,11,2,1,{c:'#5a7a9a'}],['bunk',2,13,2,1,{c:'#a8503a'}],['bunk',7,4,2,1,{c:'#5a7a9a'}],['bunk',7,6,2,1,{c:'#7a8a5a'}],['bunk',7,11,2,1,{c:'#a8503a'}],['bunk',7,13,2,1,{c:'#7a8a5a'}],
  ['table',4,5,2,1,{t:'dine'}],['chair',4,4,1,1,{d:'d'}],['chair',5,6,1,1,{d:'u'}],['chest',5,14,1,1,{obj:'med',med:1}],['barrel',9,2,1,1],
  ['longtable',14,2,3,1,{t:'mess'}],['longtable',20,2,3,1,{t:'mess'}],['longtable',26,2,3,1,{t:'mess'}],['bench',14,3,3,1],['bench',20,3,3,1],['bench',26,3,3,1],['barrel',13,4,1,1],['barrel',29,4,1,1],
  ['mast',21,8,1,1],['barrel',13,10,1,1],['barrel',29,6,1,1],['longtable',23,6,3,1,{t:'dice'}],['chair',23,7,1,1,{d:'u'}],['chair',24,7,1,1,{d:'u'}],['chair',25,7,1,1,{d:'u'}],['coil',15,7,1,1],
  ['stove',13,13,2,1],['table',17,13,2,1,{t:'prep',obj:'recipe'}],['barrel',16,15,1,1],['barrel',17,15,1,1],['barrel',18,15,1,1],['barrel',19,15,1,1,{obj:'k2',red:1}],['sack',21,15,1,1],['sack',21,13,1,1],
  ['barrel',23,13,1,1],['barrel',30,13,1,1],['barrel',23,15,1,1],['barrel',30,15,1,1],['barrel',25,13,1,1],['sack',28,13,1,1],['sack',28,15,1,1],['sack',29,15,1,1],
  ['mast',35,8,1,1],['barrel',33,14,1,1],['cannon',33,2,1,1,{d:-1}],['cannon',38,2,1,1,{d:-1}],['cannon',33,15,1,1,{d:1}],['cannon',36,15,1,1,{d:1,obj:'lure'}],['cannon',38,15,1,1,{d:1}],['coil',34,6,1,1],
  ['barrel',42,14,1,1],['barrel',45,14,1,1],['bucket',44,3,1,1]],
 /* LA STIVA */
 [['barrel',2,5,1,1],['barrel',3,5,1,1],['barrel',2,6,1,1],['barrel',8,5,1,1],['barrel',9,5,1,1],['barrel',9,6,1,1],['barrel',2,12,1,1],['barrel',3,12,1,1],['barrel',8,12,1,1],['barrel',9,12,1,1],['barrel',9,11,1,1],['sack',5,3,1,1],['sack',6,3,1,1],['sack',5,14,1,1],['coil',5,9,1,1],
  ['barrel',13,2,1,1],['barrel',14,2,1,1],['barrel',13,3,1,1],['barrel',24,2,1,1],['barrel',25,2,1,1],['barrel',29,3,1,1],['barrel',29,4,1,1],['sack',18,2,1,1],['sack',19,2,1,1],
  ['mast',21,8,1,1],['barrel',13,10,1,1],['barrel',29,6,1,1],
  ['barrel',13,14,1,1,{powder:1}],['barrel',14,14,1,1,{powder:1}],['barrel',13,15,1,1,{powder:1}],['barrel',19,14,1,1,{powder:1}],['barrel',20,14,1,1,{powder:1}],['barrel',20,15,1,1,{powder:1}],
  ['crate',24,14,1,1,{obj:'c0'}],['crate',26,14,1,1,{obj:'c1'}],['crate',28,14,1,1,{obj:'c2'}],['crate',24,15,1,1,{obj:'c3'}],['crate',26,15,1,1,{obj:'c4'}],['crate',28,15,1,1,{obj:'c5'}],['barrel',30,14,1,1],['barrel',30,15,1,1],
  ['mast',35,8,1,1],['cannon',33,15,1,1,{d:1}],['cannon',36,15,1,1,{d:1}],['cannon',38,15,1,1,{d:1}],['barrel',33,3,1,1],['coil',34,6,1,1],
  ['barrel',43,3,1,1],['barrel',44,3,1,1],['barrel',45,13,1,1],['barrel',45,14,1,1],['barrel',42,14,1,1]]
];
const LAMPS_BY=[
 [[9,3],[3,9],[8,13],[14,9],[20,9],[27,9],[14,3],[24,3],[14,14],[27,14],[44,4],[44,13],[35,5],[35,12],[26,6]],
 [[3,8],[8,8],[14,9],[20,9],[27,9],[18,3],[24,3],[14,14],[27,14],[44,4],[44,13],[35,5],[35,12]],
 [[5,8],[20,9],[27,13],[16,14],[35,5],[35,12],[44,8],[20,3]]];
/* decorazioni sui muri: [tipo, gx, gy] (cella del muro) */
const DECOR_BY=[
 [['paint',13,5],['map',19,5],['paint',22,5],['flag',29,5],['sconce',11,7],['sconce',11,10],['cross',20,12],['cross',29,12],['paint',17,12],['flag',24,12],['sconce',31,7],['sconce',31,10],['map',22,14],['shelf',22,15],['sconce',40,7],['sconce',40,10]],
 [['pans',18,12],['pans',20,12],['hams',24,12],['hams',28,12],['sconce',11,7],['sconce',11,10],['cross',17,5],['paint',24,5],['flag',29,5],['chains',40,5],['chains',40,13],['sconce',31,7],['sconce',31,10],['shelf',22,14]],
 [['chains',31,4],['chains',31,13],['sconce',11,7],['sconce',11,10],['net',17,5],['net',25,5],['sconce',31,7],['sconce',31,10],['sconce',40,7],['sconce',40,10]]];
let PROPS=PROPS_BY[0],LAMPS=LAMPS_BY[0];
const propAt=(tx,ty)=>{const gx=tx-OX,gy=ty-OY;return PROPS.some(p=>gx>=p[1]&&gx<p[1]+p[3]&&gy>=p[2]&&gy<p[2]+p[4]&&p[0]!=='mast'&&NOBLOCK.indexOf(p[0])<0)};
