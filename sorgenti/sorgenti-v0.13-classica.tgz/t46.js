const {chromium}=require('playwright');(async()=>{const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/sette-mari/www/_t.html');await p.waitForTimeout(1500);await p.click('#bNew');await p.waitForTimeout(2500);await p.evaluate(()=>{__t.auInit();__t.AU.on=true});
const r=await p.evaluate(async()=>{const out=[];for(let i=0;i<4;i++){try{__t.sfx('cra');out.push('ok')}catch(e){out.push(e.message)}await new Promise(r=>setTimeout(r,600))}return out});
console.log(r,er);await b.close()})()
