const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const er=[];
// world 1: relic
let p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('D','m');s.tutDone=1;s.flags.parrot=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
console.log(await p.evaluate(()=>{const P=Pirati;return P.RELICS.map(r=>r.w+'|'+r.f).join('\n')}));
await p.close();
// world 2
p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.Ch2.convert(P.newState('D','m'));s.tutDone=1;s.flags.parrot=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(2500);
console.log(await p.evaluate(()=>{const P=Pirati;return JSON.stringify(Object.keys(P.Ch2.st()))}));
console.log('errs',er);
await b.close()})();
