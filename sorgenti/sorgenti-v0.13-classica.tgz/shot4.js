const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:2400,height:1000},deviceScaleFactor:1})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
const f=process.argv[2]||'/home/claude/out/galeone_giocabile.html';
await p.goto('file:///'+f);await p.waitForTimeout(3500);
const decks=+process.argv[3]||3;
for(let d=0;d<decks;d++){
 await p.evaluate(d=>{const K=Ch4.K;if(Ch4.setDeck&&d!==K.deck)Ch4.setDeck(d,35,d===0?3.95:10.5);Pirati.cam.uz=.34;Pirati.cam.x=(8+28)*44;Pirati.cam.y=(13+9)*44;K.say=[];K.sayT=0;document.getElementById('c4say').style.display='none'},d);
 await p.waitForTimeout(700);
 await p.evaluate(()=>{Pirati.cam.x=(8+28)*44;Pirati.cam.y=(13+9)*44});await p.waitForTimeout(400);
 await p.screenshot({path:'deck'+d+'.png'});}
console.log(er);await b.close()})();
