import sys
p='ch4_inject.js';s=open(p,encoding='utf8').read()
def rep(a,b):
    global s
    assert s.count(a)==1,('FAIL',s.count(a),a[:70]); s=s.replace(a,b)
# A specs
rep("function mkChar(who","""  CH.moro={name:'Moro',skin:'#b98560',hair:'#1a1a1a',coat:'#3a5a8a',coat2:'#27406a',pants:'#3a3028',shirt:'#e8dcc0',hat:'bandana',hatc:'#b02a2a',sword:20,stubble:1,w:1.1,tall:1};
  CH.gigi={name:'Gina',skin:'#e0a888',hair:'#7a2a1a',coat:'#7a4a8a',coat2:'#563468',pants:'#3a2e3a',shirt:'#f0e8d0',hat:'bandana',hatc:'#d0a030',sword:18,w:.9,tall:.92};
  CH.zeno={name:'Zeno',skin:'#8a5a3a',hair:'#111111',coat:'#8a6a2a',coat2:'#5e4818',pants:'#2e2a22',shirt:'#e6dfc8',hat:'tricorn',hatc:'#3a2a1a',trim:'#e0b04a',sword:20,boots:1,mustache:1,w:1.08,tall:1.02};
  CH.barba={name:'Barba',skin:'#c8946c',hair:'#3a2a1a',coat:'#6a3a2a',coat2:'#4a2418',pants:'#2e2a30',shirt:'#e8dcc0',hat:'bandana',hatc:'#2a6a4a',sword:20,stubble:1,w:1.12,tall:1.02};
  CH.lupo={name:'Lupo',skin:'#d0a07c',hair:'#8a8a8a',coat:'#3a6a5a',coat2:'#27483e',pants:'#3a3028',shirt:'#eee6d2',hat:'tricorn',hatc:'#1a2a2a',trim:'#cfcfcf',sword:20,boots:1,w:1,tall:1};
}
function mkChar(who""")
# fix: the closing brace of mkSpecs must precede mkChar: original mkSpecs ended with "}\nfunction mkChar"; we inserted lines before 'function mkChar' after its '}' -> repair
s=s.replace("mustache:1,ladle:1,w:1.22,tall:.95};\n}\n  CH.moro","mustache:1,ladle:1,w:1.22,tall:.95};\n  CH.moro")
# B entities
rep("  K.fol=[mkChar('tito',34,3),mkChar('nives',36,3)];\n  K.cap=[mkChar('pip',44,6,{cap:1,flip:false}),mkChar('dodo',44,11,{cap:1,flip:true})];\n  K.gd=GP.map((wp,i)=>{const e=mkChar('guardia',wp[0][0],wp[0][1],{guard:1,wp,wi:1,st:'patrol',ko:0,seen:0,hitCd:0,alert:0,wait:0});return e});",
"""  K.fol=[mkChar('tito',34,3),mkChar('nives',36,3),mkChar('moro',33,4),mkChar('gigi',35,4),mkChar('zeno',37,4)];
  K.cap=[mkChar('pip',44,6,{cap:1,flip:false}),mkChar('dodo',44,11,{cap:1,flip:true})];
  for(const f of K.fol.concat(K.cap))initAlly(f);
  K.gd=GP.map((wp,i)=>{const e=mkChar('guardia',wp[0][0],wp[0][1],{guard:1,wp,wi:1,st:'patrol',ko:0,seen:0,hitCd:0,alert:0,wait:0,hp:3,maxhp:3,flash:0,swing:0,fight:null,fightT:0});return e});
  K.duels=[[mkChar('guardia',24,11,{duel:1,fixed:1,flip:false,sd:0}),mkChar('barba',26,11,{duel:1,fixed:1,flip:true,sd:1})],[mkChar('lupo',36,5,{duel:1,fixed:1,flip:false,sd:0}),mkChar('guardia',38,5,{duel:1,fixed:1,flip:true,sd:1})]];
  for(const[a,b]of K.duels){a.mate=b;b.mate=a;a.cd=rr(.3,1);b.cd=rr(.6,1.4);a.sw=b.sw=0}""")
rep("function inFree(x,y){","""function initAlly(f){Object.assign(f,{ally:1,hp:3,maxhp:3,downT:0,hitCd:rr(0,.8),swing:0,flash:0,busy:false,tgt:null,sdir:1})}
function inFree(x,y){""")
# C attack
old=s[s.index("function attack(){"):s.index("function leave(){")]
new=r"""function attack(){
  if(!K||K.over||PAUSED||K.atk>0)return;K.atk=.5;K.swingT=.32;K.fx.push({k:'slash',x:P.x,y:P.y,dx:K.fdx,dy:K.fdy,t:0,life:.25});
  if(AU.ctx&&AU.on){noiseBurst(.1,500,.3)}
  for(const g of K.gd){if(g.ko>0)continue;const dx=g.x-P.x,dy=g.y-P.y,d=Math.hypot(dx,dy);
    if(d<96&&(dx*K.fdx+dy*K.fdy)/(d||1)>-.2){
      hitGuard(g,1,dx/(d||1),dy/(d||1));
      if(g.ko<=0&&g.st!=='chase'){g.st='chase';g.alert=3.5}
      if(!K.notes.ko){K.notes.ko=1;say('Biscotto','Resistono a più colpi! Colpiscili ancora, o fatti aiutare dalla ciurma.',5600)}}}
}
function hitGuard(g,n,nx,ny){
  g.hp-=n;g.flash=.25;g.hitCd=Math.max(g.hitCd,.7);sfx('thud');moveEnt(g,nx*16,ny*16);
  K.fx.push({k:'spark',x:g.x,y:g.y-34,t:0,life:.3});
  if(g.hp<=0){g.ko=45;g.st='ko';g.fight=null;K.kos++;K.fx.push({k:'star',x:g.x,y:g.y-70,t:0,life:.9});if(!K.notes.down){K.notes.down=1;say('Biscotto','A terra! Dormirà per un bel po\'.')}}
}
"""
s=s.replace(old,new)
# D guard wake + fight behavior
rep("  if(g.ko>0){g.ko-=dt;g.mv=false;if(g.ko<=0){g.st='patrol';g.alert=0}return}\n  const d=Math.hypot(P.x-g.x,P.y-g.y);\n  const vis=d<300&&los(g.x,g.y-6,P.x,P.y-6);",
"""  g.flash=Math.max(0,g.flash-dt);g.swing=Math.max(0,g.swing-dt);
  if(g.ko>0){g.ko-=dt;g.mv=false;if(g.ko<=0){g.st='patrol';g.alert=0;g.hp=2}return}
  const d=Math.hypot(P.x-g.x,P.y-g.y);
  const vis=d<300&&los(g.x,g.y-6,P.x,P.y-6);
  {const f=g.fight;
   if(f&&f.hp>0&&Math.hypot(f.x-g.x,f.y-g.y)<58&&d>76){
     g.mv=false;g.flip=f.x<g.x;g.fightT-=dt;
     if(g.fightT<=0){g.fightT=1.5;g.swing=.32;f.hp--;f.flash=.3;sfx('thud');K.fx.push({k:'spark',x:(g.x+f.x)/2,y:g.y-34,t:0,life:.3});
       if(f.hp<=0){f.downT=0;g.fight=null;toast(CH[f.who].name+' è a terra! Vai ad aiutarlo.',4200);if(!K.notes.dwn){K.notes.dwn=1;say('Biscotto','Un pirata ferito! Avvicinati e premi «Aiuta».',5200)}}}
     return}
   if(f&&(f.hp<=0||Math.hypot(f.x-g.x,f.y-g.y)>=58))g.fight=null}""")
rep("if(g.st==='chase'&&d<34&&g.hitCd<=0){g.hitCd=1.2;hurtP(g)}","if(g.st==='chase'&&d<34&&g.hitCd<=0){g.hitCd=1.2;g.swing=.32;hurtP(g)}")
# E allies
rep("function stepFollowers(dt){","""function stepAllies(dt){
  for(const f of K.fol){
    f.hitCd=Math.max(0,f.hitCd-dt);f.swing=Math.max(0,f.swing-dt);f.flash=Math.max(0,f.flash-dt);f.busy=false;
    if(f.hp<=0){f.mv=false;f.busy=true;f.downT+=dt;if(f.downT>70){f.hp=1;f.downT=0}continue}
    let best=null,bd=1e9;
    for(const g of K.gd){if(g.ko>0)continue;const d=Math.hypot(g.x-f.x,g.y-f.y);if(d<150&&d<bd&&los(f.x,f.y-6,g.x,g.y-6)&&(g.st==='chase'||d<110)){bd=d;best=g}}
    f.tgt=best;
    if(best){f.busy=true;const dx=best.x-f.x,dy=best.y-f.y,d=bd;f.flip=dx<0;f.dir=dy<-Math.abs(dx)*1.2?'b':'f';
      if(d>40){const m=Math.min(125*dt,d-36);f.mv=moveEnt(f,dx/d*m,dy/d*m);f.wk+=dt*8}else f.mv=false;
      if(d<=46&&f.hitCd<=0){f.hitCd=1.3;f.swing=.32;best.fight=f;best.fightT=Math.max(best.fightT,.5);
        hitGuard(best,1,dx/d,dy/d);if(best.ko>0)say(CH[f.who].name,pick(['Sistemato!','Uno in meno!','Dormi bene, casacca rossa.']),2600)}}
  }}
function sepAll(dt){
  const A=[{e:P,p:1}];for(const f of K.fol)if(f.hp>0)A.push({e:f});for(const g of K.gd)if(g.ko<=0)A.push({e:g});for(const dl2 of K.duels)for(const q of dl2)A.push({e:q,fx:1});
  for(let i=0;i<A.length;i++)for(let j=i+1;j<A.length;j++){
    const a=A[i],b=A[j];if(a.fx&&b.fx)continue;
    let dx=b.e.x-a.e.x,dy=b.e.y-a.e.y,d=Math.hypot(dx,dy);const R=27;if(d>=R)continue;
    if(d<.01){dx=1;dy=0;d=1}const ov=(R-d),nx=dx/d,ny=dy/d;
    let wa=.5,wb=.5;if(a.fx){wa=0;wb=1}else if(b.fx){wa=1;wb=0}else if(a.p){wa=.25;wb=.75}else if(b.p){wa=.75;wb=.25}
    if(wa)moveEnt(a.e,-nx*ov*wa,-ny*ov*wa);if(wb)moveEnt(b.e,nx*ov*wb,ny*ov*wb)}
}
function stepDuels(dt){
  for(const[a,b]of K.duels){for(const e of[a,b]){e.sw=Math.max(0,e.sw-dt);e.cd-=dt;
      if(e.cd<=0){e.cd=rr(1.1,1.8);e.sw=.34;const mx=(a.x+b.x)/2,my=a.y-34;
        K.fx.push({k:'spark',x:mx,y:my,t:0,life:.3});
        if(Math.hypot(P.x-mx,P.y-a.y)<420&&AU.ctx&&AU.on)noiseBurst(.05,1400,.1)}}
    if(!K.notes.duel&&Math.hypot(P.x-a.x,P.y-a.y)<300){K.notes.duel=1;say('Biscotto','Quei due si menano da ore e nessuno cade: è una danza! Lasciali stare.',5600)}}
}
function stepFollowers(dt){""")
rep("  K.fol.forEach((f,i)=>{\n    const want","  K.fol.forEach((f,i)=>{\n    if(f.busy)return;\n    const want")
rep("    stepFollowers(dt);\n  }","    stepAllies(dt);stepFollowers(dt);stepDuels(dt);sepAll(dt);\n  }")
rep("K.atk=Math.max(0,K.atk-dt);","K.atk=Math.max(0,K.atk-dt);K.swingT=Math.max(0,(K.swingT||0)-dt);")
# F nearObj
rep("function nearObj(){let b=null,bd=1e9;for(const o of K.objs){if(!o.on())continue;const d=Math.hypot(o.x-P.x,o.y-P.y);if(d<86&&d<bd){bd=d;b=o}}return b}",
"""function nearObj(){let b=null,bd=1e9;for(const o of K.objs){if(!o.on())continue;const d=Math.hypot(o.x-P.x,o.y-P.y);if(d<86&&d<bd){bd=d;b=o}}
  for(const f of K.fol){if(f.hp>0)continue;const d=Math.hypot(f.x-P.x,f.y-P.y);if(d<82&&d<bd){bd=d;b={id:'help',x:f.x,y:f.y-6,label:'Aiuta '+CH[f.who].name,on:()=>true,use:()=>{f.hp=2;f.downT=0;f.hitCd=1;sfx('ok');K.helped=(K.helped||0)+1;K.fx.push({k:'star',x:f.x,y:f.y-50,t:0,life:.9});say(f.who==='tito'?'Tito':CH[f.who].name,pick(['Grazie, Capitano! Ho preso una bella botta.','Ci sono di nuovo! Grazie.','Un graffio... grazie della mano.']),3600)}}}}
  return b}""")
# G drawing
old=s[s.index("function drawEnt(g,e,t){"):s.index("function drawTop(g,t){")]
new=r"""function swordFx(g,x,y,a,len,col){
  g.save();g.translate(x,y);g.rotate(a);
  g.fillStyle=col||'#dfe6ee';g.strokeStyle='#4a5560';g.lineWidth=1.2;g.beginPath();g.moveTo(5,-2);g.lineTo(5+len,-1);g.lineTo(5+len+5,0);g.lineTo(5+len,1);g.lineTo(5,2);g.closePath();g.fill();g.stroke();
  g.fillStyle='#d9b04a';g.fillRect(3,-6,3,12);g.fillStyle='#4a2c18';g.fillRect(-5,-1.6,8,3.2);g.restore()}
function swingA(base,dir,p){return base+dir*(-1.15+2.3*p)}
function allyHpPips(g,e){
  if(e.hp>=e.maxhp&&!e.flash)return;g.save();g.textAlign='center';g.font='800 12px Nunito,Arial';g.lineWidth=3;g.strokeStyle='rgba(30,10,10,.8)';
  let h='';for(let i=0;i<e.maxhp;i++)h+=i<e.hp?'♥':'♡';g.strokeText(h,e.x,e.y-82);g.fillStyle=e.ally?'#8fe08f':'#ff6f7f';g.fillText(h,e.x,e.y-82);g.restore()}
function drawLying(g,e,t,label){
  g.save();g.translate(e.x,e.y);g.rotate(1.35);drawChar(g,0,0,charO(e,t,{moving:false,noShadow:1}));g.restore();
  g.fillStyle='#fff6dc';g.font='800 14px Nunito,Arial';g.textAlign='center';g.fillText(label,e.x+6,e.y-40+Math.sin(t*3)*3)}
function drawEnt(g,e,t){
  if(e.k==='prop')return drawProp(g,e,t);
  if(e.guard){
    const ko=e.ko>0;
    if(ko){drawLying(g,e,t,'z z z');return}
    if(e.flash>0){g.save();g.globalAlpha=.55+.45*Math.sin(t*60)}
    drawChar(g,e.x,e.y,charO(e,t,e.st==='chase'?{emote:'!'}:null));
    if(e.flash>0)g.restore();
    const sd=e.flip?-1:1,a0=e.flip?Math.PI:0;
    if(e.swing>0)swordFx(g,e.x+sd*6,e.y-26,swingA(a0,sd,1-e.swing/.32),24);
    allyHpPips(g,e);return}
  if(e.duel){
    const jit=Math.sin(t*9+e.ph)*(e.sw>0?2.2:.8);
    drawChar(g,e.x+jit*(e.flip?-1:1),e.y,charO(e,t,{moving:false}));
    const sd=e.flip?-1:1,a0=e.flip?Math.PI:0,p=e.sw>0?1-e.sw/.34:0;
    swordFx(g,e.x+sd*6,e.y-26,e.sw>0?swingA(a0,sd,p):a0+sd*.5,22);return}
  if(e.cap){drawChar(g,e.x,e.y,charO(e,t,{moving:false,emote:'?'}));return}
  if(e.ally&&e.hp<=0){drawLying(g,e,t,'✚');return}
  if(e.ally){
    if(e.flash>0){g.save();g.globalAlpha=.55+.45*Math.sin(t*60)}
    drawChar(g,e.x,e.y,charO(e,t));
    if(e.flash>0)g.restore();
    const sd=e.flip?-1:1,a0=e.flip?Math.PI:0;
    if(e.swing>0)swordFx(g,e.x+sd*6,e.y-26,swingA(a0,sd,1-e.swing/.32),22);
    allyHpPips(g,e);return}
  drawChar(g,e.x,e.y,charO(e,t));
}
"""
s=s.replace(old,new)
# player's sword + spark fx in drawTop
rep("  // indicatore sull'oggetto da usare","""  {const sd=K.fdx<0?-1:1,a0=Math.atan2(K.fdy,K.fdx);
   if(K.swingT>0){swordFx(g,P.x+K.fdx*6,P.y-26,a0+(-1.15+2.3*(1-K.swingT/.32)),30)}
   else swordFx(g,P.x+sd*8,P.y-22,sd>0?.9:Math.PI-.9,26)}
  // indicatore sull'oggetto da usare""")
rep("    else if(q.k==='flash'){","    else if(q.k==='spark'){g.strokeStyle='rgba(255,240,170,'+a+')';g.lineWidth=2.4;g.lineCap='round';for(let i=0;i<6;i++){const an=i*1.05+q.t*3,r1=4+q.t*30,r2=r1+8;g.beginPath();g.moveTo(q.x+Math.cos(an)*r1,q.y+Math.sin(an)*r1);g.lineTo(q.x+Math.cos(an)*r2,q.y+Math.sin(an)*r2);g.stroke()}}\n    else if(q.k==='flash'){")
# cell release -> ally props
rep("for(const c of K.cap){c.cap=0;K.fol.push(c)}","for(const c of K.cap){c.cap=0;initAlly(c);K.fol.push(c)}")
# end card: helped stat
rep("<div><b>'+K.kos+'</b>guardie stordite</div>","<div><b>'+K.kos+'</b>guardie a terra</div>")
open(p,'w',encoding='utf8').write(s)
