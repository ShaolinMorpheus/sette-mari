const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
const ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:2.37,hasTouch:true,isMobile:true});const p=await ctx.newPage();
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;s.tod=7.25;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);await p.evaluate(()=>{Pirati.tp(16.7,47.8)});await p.waitForTimeout(500);
const r=await p.evaluate(()=>{const cv=document.querySelector('canvas'),R=cv.getBoundingClientRect();
 const img=(wx,wy)=>{const[cx,cy]=Pirati.toScreen(wx*44,wy*44);return [Math.round((R.right-cy)*2.37),Math.round((cx+R.top)*2.37)]};
 return {rot:document.body.classList.contains('rot'),p0:img(16.7,47.8),px:img(17.7,47.8),py:img(16.7,48.8),R:[R.left,R.top,R.right,R.bottom]}});
console.log(JSON.stringify(r));
// griglia di punti bloccati sul piano (world) vicino al giocatore
const rows=await p.evaluate(()=>{const o=[];for(let y=45;y<=52;y+=.25){let s=y.toFixed(2).padStart(6)+' ';for(let x=12;x<=22;x+=.25){s+=Pirati.boxFree(x*44,y*44,9,5)?'.':'#'}o.push(s)}return o});
console.log('x 12..22 step .25');console.log(rows.join('\n'));await b.close()})();
