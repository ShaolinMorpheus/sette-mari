import json,base64,io
from PIL import Image,ImageDraw,ImageFont
d=json.load(open('tr_prev.json'))
im=Image.open(io.BytesIO(base64.b64decode(d['prev'].split(',')[1]))).convert('RGB')
print(im.size,d['ch'])
