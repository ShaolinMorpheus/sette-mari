const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.sail=0;});
const out=[];
for(const d of [400,700,900,1100]){
 await p.evaluate((d)=>{const C=Ch3.C;const t=C.ships.find(s=>s.type==='pattuglia');window.__t=t;t.still=true;t.hostile=false;C.p.x=t.x-d;C.p.y=t.y;C.p.hd=-Math.PI/2;C.p.v=0;C.balls.length=0},d);
 await p.waitForTimeout(700);
 out.push(await p.evaluate((d)=>{const C=Ch3.C,t=window.__t;C.p.x=t.x-d;C.p.y=t.y;C.p.hd=-Math.PI/2;C.p.cdL=0;C.p.cdR=0;Ch3.fire(C.p,1,0);return d+':'+Ch3.onScr(t)+':'+(C.balls[0]?C.balls[0].life.toFixed(2):'-')},d));
}
console.log(JSON.stringify(out),errs);await b.close()})()
