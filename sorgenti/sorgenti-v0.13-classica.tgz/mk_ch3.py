import re,sys
src=open('w/index.html').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt: print('PATCH FAIL',n,old[:70]); sys.exit(1)
    src=src.replace(old,new)
rep("function auMusicTick(){\n  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running')return;","function auMusicTick(){\n  if(WORLD===3){Ch3.music();return}\n  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running')return;")
rep("if(window.__W2)return 2;","if(window.__W3)return 3;if(window.__W2)return 2;")
rep("const BLOBS=WORLD===2?BLOBS_2:BLOBS_1;","""const SC3=a=>[a[0]*1.515,a[1]*1.5].concat(a.slice(2));const BLOBS_3=[[10,30,8,7],[26,12,6,4.5],[24,47,7,5],[46,40,7,5],[63,30,6,5],[60,50,6,4],[78,16,6,4.5],[80,42,8,5],].map(SC3).concat([[165,25,8,6],[188,52,10,7],[170,78,7,5],[196,104,8,6],[150,108,9,6],[118,112,8,5],[84,110,10,6],[46,106,8,5],[20,102,7,5]]);
const BLOBS=WORLD===3?BLOBS_3:WORLD===2?BLOBS_2:BLOBS_1;""")
rep("const BEACH=WORLD===2?","const BEACH_3=[[22.45,45,2.6,5],[40.4,21,2,2.4],[62.1,36,2,1.8],[96.4,49,2.5,1.6]];const BEACH=WORLD===3?BEACH_3:WORLD===2?")
rep("const POND=WORLD===2?","const POND=WORLD===3?{x:1.5,y:1.5,rx:.2,ry:.2}:WORLD===2?")
rep("const C0=WORLD===2?","const C0=WORLD===3?{x:17.15,y:45}:WORLD===2?")
rep("const PATHS=WORLD===2?","const PATHS=WORLD===3?[]:WORLD===2?")
rep("const MESA=WORLD===2?","const MESA=WORLD===3?{x:-40,y:-40,rx:1,ry:1,h:1}:WORLD===2?")
rep("const MESA_PTS=WORLD===2?[]:","const MESA_PTS=WORLD!==1?[]:")
rep("const FORESTS=WORLD===2?FORESTS_2:FORESTS_1;","const FORESTS_3=[[10,30,6,5,.9],[26,12,4.5,3,.8],[24,47,5,3.5,.9],[46,40,5,3.5,.9],[63,30,4.5,3.5,.9],[60,50,4.5,2.8,.9],[78,16,4.5,3,.8],[80,42,6,3.5,.9],[90,28,2.8,2.8,.8],[34,31,2.5,2,.7],[72,32,2.2,1.7,.7]].map(SC3).concat([[165,25,5.5,4,.8],[188,52,7,5,.9],[170,78,5,3.5,.8],[196,104,5.5,4,.8],[150,108,6,4,.9],[118,112,5.5,3.5,.8],[84,110,7,4,.9],[46,106,5.5,3.5,.8],[20,102,5,3.5,.8]]);\nconst FORESTS=WORLD===3?FORESTS_3:WORLD===2?FORESTS_2:FORESTS_1;")
rep("const FIX=WORLD===2?FIX_2:FIX_1;","""const FIX_3=Object.assign({},FIX_2,{spawn:[17.15,45],sign:[21.55,43.6],wreck:[-60,-60],plots:{falo:{tx:1,ty:1,w:1,h:1},capanna:{tx:1,ty:1,w:1,h:1},banco:{tx:1,ty:1,w:1,h:1},zattera:{tx:1,ty:1,w:1,h:1}},lookout:[-50,-50],quarry:[-60,-60],boulders:[],raftLaunch:[22,30],smoke:[-60,-60],isl1:[-60,-60],isl2:[-60,-60],bottles:[]});
const FIX=WORLD===3?FIX_3:WORLD===2?FIX_2:FIX_1;""")
rep("  if(WORLD===2)return exclTile2(tx,ty);","  if(WORLD===3)return hyp(tx+.5-21.55,ty+.5-43.6)<2.2;\n  if(WORLD===2)return exclTile2(tx,ty);")
rep("  if(WORLD===2)return genWorld2();","  if(WORLD===3)return genWorld3();\n  if(WORLD===2)return genWorld2();")
gw3=r"""function genWorld3(){
  const r=mulberry(31);
  const taken=new Set(),key=(a,b)=>a+','+b;
  let n=0;
  const order=[];for(let ty=0;ty<MH;ty++)for(let tx=0;tx<MW;tx++)order.push([tx,ty]);
  for(let i=order.length-1;i>0;i--){const j=(r()*(i+1))|0;[order[i],order[j]]=[order[j],order[i]]}
  const okT=(tx,ty)=>walkT[tIdx(tx,ty)]&&!blockT[tIdx(tx,ty)]&&!exclTile(tx,ty);
  for(const[tx,ty]of order){
    if(!okT(tx,ty))continue;
    const e0=elevT[tIdx(tx,ty)];if(e0<WL+.27)continue;
    const fF=forestF(tx+.5,ty+.5),dens=1.4*fF+.06;
    if(r()>dens)continue;
    if(taken.has(key(tx-1,ty))||taken.has(key(tx+1,ty))||taken.has(key(tx,ty-1))||taken.has(key(tx,ty+1)))continue;
    if(taken.has(key(tx-1,ty-1))&&taken.has(key(tx+1,ty+1)))continue;
    taken.add(key(tx,ty));
    const pine=tx>52?r()<.7:r()<.2;
    const e=ent({id:'t'+(n++),type:pine?'pine':'tree',v:(r()*(pine?4:6))|0,x:(tx+.5+(r()-.5)*.3)*TS,y:(ty+.92)*TS,tx,ty,alive:true,grow:1,t:0,wood:pine?2:3,flip:r()<.5});
    addBlock(e,tx,ty,1,1);
  }
  const pal=[];
  for(const[tx,ty]of order){
    const e0=elevT[tIdx(tx,ty)];
    if(!okT(tx,ty)||e0<SAND_LO||e0>SAND_HI)continue;
    if(pal.some(p=>hyp(p[0]-tx,p[1]-ty)<2.6))continue;
    if(r()>.5)continue;
    pal.push([tx,ty]);if(pal.length>=120)break;
  }
  pal.forEach((p,i)=>{const e=ent({id:'p'+i,type:'palm',v:i%3,x:(p[0]+.5)*TS,y:(p[1]+.92)*TS,tx:p[0],ty:p[1],coco:true,cd:0,flip:r()<.5});addBlock(e,p[0],p[1],1,1)});
  {const rk=[];
   for(const[tx,ty]of order){
     if(rk.length>=30)break;
     if(!okT(tx,ty))continue;
     const e0=elevT[tIdx(tx,ty)];if(e0<WL+.3)continue;
     if(rk.some(p=>hyp(p[0]-tx,p[1]-ty)<4))continue;
     rk.push([tx,ty]);
   }
   rk.forEach((p,i)=>{const e=ent({id:'rx'+i,type:'rock',v:(i*3)%5,x:(p[0]+.5)*TS,y:(p[1]+.92)*TS,tx:p[0],ty:p[1],alive:true,hp:0,t:0});addBlock(e,p[0],p[1],1,1)});}
  const deco=(id,spr,x,y,fp,o)=>{const e=ent(Object.assign({id,type:'deco',spr,x:x*TS,y:y*TS},o||{}));if(fp)addBlock(e,fp[0],fp[1],fp[2],fp[3]);return e};
  deco('feedback','sign',FIX.sign[0],FIX.sign[1],[Math.floor(FIX.sign[0]),Math.floor(FIX.sign[1]),1,1],{k:.9,hitw:64,hith:84,label:'Porto di Calvara',inter:'none'});
  for(const id in FIX.plots){const f=FIX.plots[id];
    const e=ent({id:'plot_'+id,type:'plot',pid:id,x:(f.tx+f.w/2)*TS,y:(f.ty+f.h)*TS-2,tx:f.tx,ty:f.ty,tw:f.w,th:f.h,st:0,prog:0});
    addBlock(e,f.tx,f.ty,f.w,f.h);delBlock(e);
  }
  ent({id:'wparrot',type:'wparrot',x:-999,y:-999,alt:90,got:false});
  ent({id:'mraft',type:'mraft',x:-999,y:-999,hd:0});
  FIX.crabN=0;
  fixOccluded((tx,ty)=>{for(let j=-2;j<=2;j++)for(let i=-2;i<=2;i++){const a=tx+i,b=ty+j;if(inMap(a,b)&&elevT[tIdx(a,b)]<WL)return true}return false});
}
"""
rep("const TS=44, MW=99, MH=60,","const TS=44, MW=WORLD===3?210:99, MH=WORLD===3?126:60,")
rep("seaT[ty*MW+tx]=(e<WL-.035&&","seaT[ty*MW+tx]=(e<(WORLD===3?WL+.03:WL-.035)&&")
rep("function genWorld2(){",gw3+"function genWorld2(){")
old="if(!dl.open){if(!P.cl)updatePlayer(dt);updateTime(dt);updateVitals(dt);updateWeather(dt);updateChallenge(dt);Story.tick(dt)}"
rep(old,"if(!dl.open){if(WORLD===3){Ch3.step(dt)}else{if(!P.cl)updatePlayer(dt);updateTime(dt);updateVitals(dt);updateWeather(dt);updateChallenge(dt);Story.tick(dt)}}")
rep("  if(P.mode==='raft')drawRaftHull(g,t);","  if(P.mode==='raft'&&WORLD!==3)drawRaftHull(g,t);")
rep("  list.push(P);if(S.flags.parrot)list.push(PAR);if(P.mode==='raft')list.push(RAFTSAIL);","  if(WORLD===3){for(const q of Ch3.vis())list.push(q)}else{list.push(P);if(S.flags.parrot)list.push(PAR);if(P.mode==='raft')list.push(RAFTSAIL)}")
rep("const key=o=>o===P?P.y:","const key=o=>o.type==='c3'?o.s.y:o===P?P.y:")
rep("    if(e===P){drawPlayer(g,t);continue}","    if(e.type==='c3'){Ch3.drawShip(g,e,t);continue}\n    if(e===P){drawPlayer(g,t);continue}")
rep("  drawWParrot(g,EID.wparrot,t);\n","  drawWParrot(g,EID.wparrot,t);\n  if(WORLD===3)Ch3.drawFx(g,t);\n")
rep("  initInput();initStart();syncPause();\n","  initInput();initStart();syncPause();\n  if(WORLD===3)Ch3.boot();\n")
rep("function saveGame(quiet){\n  if(!S||!S.live)return;","function saveGame(quiet){\n  if(WORLD===3||!S||!S.live)return;")
inj=open('ch3_inject.js').read()
# flag + injection
src=src.replace("<script>\n","<script>window.__W3=1;</script>\n<script>\n",1) if False else src
i=src.index("<script>",src.index("</script>")-0) if False else 0
# metti il flag nell'head e la nuova sezione prima della chiusura del body
src=src.replace("<head>","<head><script>window.__W3=1;</script>",1)
tail="\n})();\n</script>"
k=src.rindex(tail)
src=src[:k]+"\n"+inj+tail+src[k+len(tail):]
open('/home/claude/out/capitolo3_isola.html','w').write(src)
print('ok',len(src))
