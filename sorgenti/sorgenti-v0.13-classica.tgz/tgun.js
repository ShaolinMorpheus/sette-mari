const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(2500);await p.click('#bNew').catch(()=>{});
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(200)}
await p.waitForTimeout(800);
console.log(await p.evaluate(async()=>{const C=Ch3.C,s=C.p;s.hull=1;await new Promise(r=>setTimeout(r,400));const a=[s.gunsOut,document.getElementById('c3gun').innerText.slice(0,60)];
 s.hull=2.6;await new Promise(r=>setTimeout(r,400));return [a,s.gunsOut,s.hull]}));
console.log(er);await b.close()})();
