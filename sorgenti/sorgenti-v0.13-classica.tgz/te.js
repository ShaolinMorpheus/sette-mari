const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage();p.on('pageerror',e=>console.log('PE',e.message));p.on('console',m=>{if(m.type()==='error')console.log('CE',m.text().slice(0,200))});
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(4000);await b.close()})();
