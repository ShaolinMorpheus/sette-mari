const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
const r=await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.t=400;const o=[];for(let i=0;i<5;i++)Ch3.step(.1);
 const g=C.ships.find(s=>s.type==='galeone');o.push(!!g,C.ships.filter(s=>s.type==='scorta').map(s=>s.guard?1:0).join(''));
 // cannons damaged
 C.p.hull=.5;Ch3.step(.05);o.push(C.p.gunsOut);
 const e=C.ships.find(s=>s.type==='pattuglia');C.p.hull=C.p.max;Ch3.step(.05);o.push(C.p.gunsOut);
 // no push: place patrol ahead
 const q=C.ships.find(s=>s.type==='mercante');const qx=q.x,qy=q.y;C.p.x=qx-80;C.p.y=qy;C.p.hd=0;C.p.v=100;for(let i=0;i<30;i++)Ch3.step(.05);o.push(Math.round(Math.hypot(q.x-qx,q.y-qy)));
 // long shot
 C.p.hull=C.p.max;const t=C.ships.find(s=>s.type==='pattuglia'&&!s.dead);C.p.x=t.x-1000;C.p.y=t.y+0;C.p.hd=Math.PI/2*-1;
 C.p.cdL=0;C.p.cdR=0;C.p.hd=-Math.PI/2+0*1; // broadside faces t? try both sides
 const hb=t.hull;Ch3.fire(C.p,1,Math.atan2(t.y-C.p.y,t.x-C.p.x));Ch3.fire(C.p,-1,Math.atan2(t.y-C.p.y,t.x-C.p.x));
 o.push(C.balls.length,C.balls.map(b=>b.life.toFixed(2)).join());return o});
await p.waitForTimeout(500);await p.screenshot({path:'c3e.png'});
console.log(JSON.stringify(r),errs);await b.close()})()
