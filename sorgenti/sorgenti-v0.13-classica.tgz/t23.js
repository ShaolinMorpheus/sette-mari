const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.p.x+=2500;C.p.y+=900;Ch3.step(.05)});await p.waitForTimeout(500);
await p.screenshot({path:'c3c.png',clip:{x:850,y:0,width:250,height:260}});console.log(errs);await b.close()})()
