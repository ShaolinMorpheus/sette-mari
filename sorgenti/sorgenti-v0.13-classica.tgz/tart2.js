const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({dsf:1,w:1900,h:760});
 const ev=async(f,a)=>{try{return await p.evaluate(f,a)}catch(e){return {ERRORE:e.message.split('\n')[0].slice(0,220)}}};
 await p.waitForTimeout(1200);
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);
 await p.waitForTimeout(500);
 await p.evaluate(()=>{Pirati.S.tutDone=1;Pirati.S.tut=null});
 await ev(()=>{const S=Pirati.S;S.flags.axe=1;S.flags.flint=1;S.built={falo:1,capanna:1,banco:1};
   for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}
   for(const k of['legna','pietra','corda','rottami','pesce','bacche'])S.res[k]=30;
   const f=Pirati.EID.plot_falo;Pirati.tp(f.fp[0]+1,f.fp[1]+4)});
 await ev(async()=>{const UI=Pirati.UI;UI.openUpgrades();const c=document.getElementById('sheetCard');
   c.querySelector('[data-dc="orto"]').click();await new Promise(r=>setTimeout(r,200));
   document.getElementById('sheetCard').querySelector('[data-dc="essic"]').click();await new Promise(r=>setTimeout(r,200))});
 await p.evaluate(()=>{(document.getElementById('shNo')||{click(){}}).click();for(const id of['hud','qbanner','dlg','rot']){const e=document.getElementById(id);if(e)e.style.display='none'}});
 await ev(()=>{const S=Pirati.S;S.gard.harv=10;S.gard.pl=[{c:'patata',p:130},{c:'zucca',p:220},{c:'ananas',p:300},{c:'patata',p:200,n:1}];S.dry.sl=[{r:'pesce',nm:'Pesce secco',p:150,t:300},{r:'bacche',nm:'B',p:100,t:200},null]});
 const info=await ev(()=>{const g=n=>{const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k===n);return e&&[Math.round(e.x/44),Math.round(e.y/44)]};
   const f=Pirati.EID.plot_falo,c=Pirati.EID.plot_capanna,bn=Pirati.EID.plot_banco;
   return {orto:g('orto'),essic:g('essic'),falo:f&&f.fp,capanna:c&&c.fp,banco:bn&&bn.fp,camp:Pirati.S.camp}});
 console.log(JSON.stringify(info));
 // camera al centro del campo
 await ev(()=>{Pirati.tp(33,25.5)});
 await p.waitForTimeout(700);
 await p.screenshot({path:'aud/art_campo.png'});
 console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
