const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const out=[];
 const ctx=await b.newContext({viewport:{width:915,height:412},deviceScaleFactor:1,hasTouch:true});
 const p=await ctx.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 const wait=async()=>{await p.waitForFunction(()=>window.Pirati&&window.Pirati.S,null,{timeout:90000}).catch(()=>{});await p.waitForTimeout(1200)};
 const skip=async()=>{for(let i=0;i<14;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS','tutSkip']){const e=document.getElementById(id);if(e&&!e.hidden&&e.offsetParent!==null)e.click()}try{Pirati.UI.dlgAuto&&Pirati.UI.dlgAuto()}catch(e){}});await p.waitForTimeout(120)}};
 // 1. versione nuova: nuova partita, Diario → Novità
 await p.goto('http://localhost:8765/index.html');await wait();
 await p.evaluate(()=>Pirati.startNew('Verifica','m'));await skip();
 await p.evaluate(()=>{Pirati.S.tutDone=1;Pirati.S.tut=null;Pirati.S.day=4;Pirati.saveGame()});
 await p.evaluate(()=>{Pirati.UI._mt='pa';Pirati.UI.openMenu()});await p.waitForTimeout(400);
 out.push(['nuova: menu',JSON.stringify(await p.evaluate(()=>{const b=document.getElementById('mVer');return {btn:b&&b.innerText.replace(/\s+/g,' '),title:document.title}}))]);
 await p.screenshot({path:'aud/ver_menu.png'});
 // 2. clic sul pulsante → stabile
 await Promise.all([p.waitForNavigation({timeout:20000}).catch(()=>{}),p.evaluate(()=>document.getElementById('mVer').click())]);
 await wait();
 out.push(['dopo clic',JSON.stringify(await p.evaluate(()=>({url:location.pathname,title:document.title,ver:localStorage.getItem('sm_ver'),hasFarm:!!(window.Pirati&&window.Pirati.farm)})))]);
 await p.evaluate(()=>{try{Pirati.startContinue()}catch(e){}});await p.waitForTimeout(2500);await skip();
 out.push(['stabile: partita',JSON.stringify(await p.evaluate(()=>{const S=Pirati.S;return S&&S.live?{name:S.name,day:S.day}:{live:false}}))]);
 await p.evaluate(()=>{Pirati.UI._mt='pa';Pirati.UI.openMenu()});await p.waitForTimeout(400);
 out.push(['stabile: menu',JSON.stringify(await p.evaluate(()=>{const b=document.getElementById('mVer');return {btn:b&&b.innerText.replace(/\s+/g,' '),title:document.title,guard:!!(window.Pirati&&window.Pirati.farm)}}))]);
 await p.screenshot({path:'aud/ver_stabile.png'});
 // 3. riapro index.html: deve rimandare a stabile.html (la scelta persiste)
 await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(2500);
 out.push(['index con sm_ver=stabile',JSON.stringify(await p.evaluate(()=>({url:location.pathname,title:document.title})))]);
 // 4. ?nuova forza la nuova
 await p.goto('http://localhost:8765/index.html?nuova');await p.waitForTimeout(2500);
 out.push(['index?nuova',JSON.stringify(await p.evaluate(()=>({url:location.pathname+location.search,title:document.title})))]);
 // 5. dalla stabile, torno alla nuova col pulsante
 await p.goto('http://localhost:8765/stabile.html');await wait();
 await p.evaluate(()=>{try{Pirati.startContinue()}catch(e){}});await p.waitForTimeout(2500);await skip();
 await p.evaluate(()=>{Pirati.UI._mt='pa';Pirati.UI.openMenu()});await p.waitForTimeout(400);
 await Promise.all([p.waitForNavigation({timeout:20000}).catch(()=>{}),p.evaluate(()=>document.getElementById('mVer').click())]);
 await wait();
 out.push(['ritorno alla nuova',JSON.stringify(await p.evaluate(()=>({url:location.pathname,title:document.title,ver:localStorage.getItem('sm_ver'),hasFarm:!!(window.Pirati&&window.Pirati.farm)})))]);
 await p.goto('http://localhost:8765/index.html');await p.waitForTimeout(2000);
 out.push(['index dopo ritorno',JSON.stringify(await p.evaluate(()=>({url:location.pathname,title:document.title})))]);
 console.log(out.map(x=>x.join(': ')).join('\n'));console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
