const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{Pirati.S.tod=12;Pirati.S.up.torch=1;Pirati.S.flags.parrot=1;Pirati.Ch2.addTrust('tito',3);Pirati.Ch2.st().said.rudder=1;Pirati.S.q.c8={st:'active',gi:2};});await clr();
await p.evaluate(()=>{const e=Pirati.EID.cave;Pirati.P.x=e.x;Pirati.P.y=e.y+70});await p.waitForTimeout(300);await p.evaluate(()=>Pirati.act());await p.waitForTimeout(1000);await clr();
await p.evaluate(()=>{Pirati.toggleTorch();Pirati.setWeather&&Pirati.setWeather('storm')});await p.waitForTimeout(500);
const r=await p.evaluate(()=>{const e=Pirati.EID.cvrudder;Pirati.P.x=e.x-60;Pirati.P.y=e.y+14;Pirati.cam.x=e.x-20;Pirati.cam.y=e.y;return 1});await p.waitForTimeout(1500);await p.screenshot({path:'cv4_helm.png'});
console.log('storm in cave', await p.evaluate(()=>[Pirati.S.wx&&Pirati.S.wx.k,Pirati.cave.inside(),Pirati.S.vit.t]));
// take, exit, quest done, reenter
await p.evaluate(()=>{const e=Pirati.EID.cvrudder;Pirati.P.x=e.x-30;Pirati.P.y=e.y+10});await p.waitForTimeout(300);await p.evaluate(()=>Pirati.act());await clr();
await p.evaluate(()=>{const e=Pirati.EID.cavex;Pirati.P.x=e.x;Pirati.P.y=e.y-40});await p.waitForTimeout(300);await p.evaluate(()=>Pirati.act());await p.waitForTimeout(900);await clr();
console.log('out',await p.evaluate(()=>Pirati.cave.inside()));
await p.evaluate(()=>{const e=Pirati.EID.cave;Pirati.P.x=e.x;Pirati.P.y=e.y+70});await p.waitForTimeout(300);await p.evaluate(()=>Pirati.act());await p.waitForTimeout(900);
console.log('reenter after',await p.evaluate(()=>Pirati.cave.inside()));
console.log(er);await b.close()})();
