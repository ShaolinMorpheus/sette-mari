/* ---------------- grafica: la nave in un'unica immagine ---------------- */
const mkRnd=s=>()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const FC={'.':['#cda46a','#c19659'],c:['#b8883a','#a8782e'],q:['#a98258','#9a744c'],k:['#bfae8a','#a69672'],p:['#7a7468','#6b665c'],s:['#8a6a42','#7a5c38'],t:['#b9684a','#a85a40'],a:['#7c8088','#6e727a'],m:['#6a4a30','#5a3e28'],z:['#5a5650','#4e4a46']};
const FDARK={'.':0,c:.1,q:.28,k:.2,p:.42,s:.4,t:.14,a:.3,m:.12,z:.46};
function rrect(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}
function drawStairs(g,gx,gy,up){
  const x0=gx*T+4,y0=gy*T+6,w=3*T-8,h=2*T-12;
  g.fillStyle='#2a160a';g.fillRect(x0-4,y0-4,w+8,h+8);
  for(let i=0;i<6;i++){
    if(up){g.fillStyle=i%2?'#c09458':'#a67a42';g.fillRect(x0,y0+h-(i+1)*h/6,w,h/6);g.fillStyle='rgba(255,240,200,.22)';g.fillRect(x0,y0+h-(i+1)*h/6,w,3)}
    else{const k=i/5;g.fillStyle='rgb('+((130-k*105)|0)+','+((88-k*76)|0)+','+((44-k*40)|0)+')';g.fillRect(x0,y0+i*h/6,w,h/6);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(x0,y0+(i+1)*h/6-3,w,3)}}
  g.strokeStyle='#5a3a1c';g.lineWidth=5;g.beginPath();g.moveTo(x0,y0);g.lineTo(x0,y0+h);g.moveTo(x0+w,y0);g.lineTo(x0+w,y0+h);g.stroke();
  g.fillStyle='#e0b04a';for(const px of[x0,x0+w])for(const py of[y0,y0+h]){g.beginPath();g.arc(px,py,4,0,7);g.fill()}
  g.fillStyle='rgba(255,246,220,.9)';g.font='900 22px Nunito,Arial';g.textAlign='center';g.fillText(up?'▲':'▼',x0+w/2,y0+h/2+8)}
function floorTile(g,ch,x,y,rnd){
  const X=x*T,Y=y*T,col=FC[ch];
  g.fillStyle=col[(x+(ch==='.'?y:0))%2];g.fillRect(X,Y,T,T);
  if(ch==='k'){g.fillStyle=((x+y)%2)?'rgba(255,255,255,.18)':'rgba(0,0,0,.12)';g.fillRect(X,Y,T,T)}
  else if(ch==='t'){
    for(let i=0;i<2;i++)for(let j=0;j<2;j++){g.fillStyle=((i+j+x+y)&1)?'rgba(255,220,180,.10)':'rgba(60,20,10,.10)';g.fillRect(X+i*22,Y+j*22,22,22)}
    g.strokeStyle='rgba(70,32,18,.55)';g.lineWidth=1.6;g.beginPath();g.moveTo(X,Y+22);g.lineTo(X+T,Y+22);g.moveTo(X+22,Y);g.lineTo(X+22,Y+T);g.stroke();
    g.strokeStyle='rgba(255,226,190,.22)';g.lineWidth=1;g.beginPath();g.moveTo(X+1,Y+1);g.lineTo(X+T-1,Y+1);g.moveTo(X+1,Y+1);g.lineTo(X+1,Y+T-1);g.stroke()}
  else if(ch==='a'){
    g.strokeStyle='rgba(20,24,34,.55)';g.lineWidth=1.6;g.beginPath();g.moveTo(X,Y+22);g.lineTo(X+T,Y+22);g.moveTo(X+11,Y);g.lineTo(X+11,Y+22);g.moveTo(X+33,Y+22);g.lineTo(X+33,Y+T);g.stroke();
    g.fillStyle='rgba(255,255,255,.08)';g.fillRect(X+2,Y+2,8,18);
    g.fillStyle='rgba(0,0,0,.09)';for(let i=0;i<3;i++)g.fillRect(X+rnd()*38,Y+rnd()*38,3,2)}
  else if(ch==='m'){
    g.save();g.beginPath();g.rect(X,Y,T,T);g.clip();g.lineWidth=1.4;
    g.strokeStyle='rgba(20,10,2,.4)';for(let i=-4;i<6;i++){g.beginPath();g.moveTo(X+i*11,Y);g.lineTo(X+i*11+T,Y+T);g.stroke()}
    g.strokeStyle='rgba(255,220,160,.13)';for(let i=-4;i<6;i++){g.beginPath();g.moveTo(X+i*11+T,Y);g.lineTo(X+i*11,Y+T);g.stroke()}
    g.restore()}
  else if(ch==='z'){
    const o=((x*5+y*3)%3)*6;g.strokeStyle='rgba(10,10,14,.6)';g.lineWidth=1.8;g.beginPath();g.moveTo(X,Y+22);g.lineTo(X+T,Y+22);g.moveTo(X+10+o,Y);g.lineTo(X+10+o,Y+22);g.moveTo(X+28-o/2,Y+22);g.lineTo(X+28-o/2,Y+T);g.stroke();
    g.fillStyle='rgba(255,255,255,.06)';g.fillRect(X+3,Y+3,9,5)}
  else{
    g.strokeStyle='rgba(60,34,12,.35)';g.lineWidth=1.2;
    for(let i=1;i<4;i++){g.beginPath();g.moveTo(X,Y+i*11);g.lineTo(X+T,Y+i*11);g.stroke()}
    if(ch!=='p'){const o=((x*7+y*13)%3+1)*11;g.strokeStyle='rgba(60,34,12,.28)';g.beginPath();g.moveTo(X+o,Y);g.lineTo(X+o,Y+11);g.moveTo(X+(o+22)%T,Y+22);g.lineTo(X+(o+22)%T,Y+33);g.stroke()}
    if(ch==='c'){g.fillStyle='rgba(255,236,170,.08)';g.fillRect(X,Y,T,11)}}
  if(FDARK[ch]){g.fillStyle='rgba(12,8,24,'+FDARK[ch]+')';g.fillRect(X,Y,T,T)}
}
/* decorazioni appese ai muri */
function drawDecor(g,k,x,y){
  const X=x*T,Y=y*T;g.save();g.lineCap='round';
  if(k==='sconce'){
    const a=X+T/2,b=Y+T/2,gr=g.createRadialGradient(a,b,2,a,b,56);gr.addColorStop(0,'rgba(255,214,120,.5)');gr.addColorStop(1,'rgba(255,214,120,0)');g.fillStyle=gr;g.fillRect(a-56,b-56,112,112);
    g.fillStyle='#241408';g.fillRect(a-8,b+7,16,4);g.fillRect(a-3,b-13,6,6);
    g.fillStyle='#3a2410';g.fillRect(a-8,b-8,16,16);g.fillStyle='rgba(255,226,140,.95)';g.fillRect(a-6,b-6,12,12);g.fillStyle='#fff6c8';g.fillRect(a-2,b-3,4,7)}
  else if(k==='paint'){
    g.fillStyle='#7a5014';g.fillRect(X+6,Y+8,32,28);g.fillStyle='#e0b04a';g.fillRect(X+8,Y+10,28,24);
    const sk=g.createLinearGradient(0,Y+12,0,Y+32);sk.addColorStop(0,'#86c0e4');sk.addColorStop(1,'#e2eef0');g.fillStyle=sk;g.fillRect(X+11,Y+13,22,18);
    g.fillStyle='#2f78a8';g.fillRect(X+11,Y+23,22,8);g.fillStyle='#4a2c18';g.beginPath();g.moveTo(X+14,Y+23);g.lineTo(X+30,Y+23);g.lineTo(X+27,Y+27);g.lineTo(X+17,Y+27);g.closePath();g.fill();
    g.fillRect(X+21,Y+15,1.6,8);g.fillStyle='#fff';g.beginPath();g.moveTo(X+22.6,Y+15);g.lineTo(X+28,Y+22);g.lineTo(X+22.6,Y+22);g.closePath();g.fill()}
  else if(k==='map'){
    g.fillStyle='#d9c48c';g.fillRect(X+5,Y+8,34,28);g.strokeStyle='#7a5a2a';g.lineWidth=2;g.strokeRect(X+5,Y+8,34,28);
    g.strokeStyle='#5a7a4a';g.lineWidth=2;g.beginPath();g.moveTo(X+9,Y+26);g.bezierCurveTo(X+14,Y+14,X+20,Y+30,X+26,Y+18);g.bezierCurveTo(X+30,Y+12,X+34,Y+20,X+35,Y+14);g.stroke();
    g.strokeStyle='#a02a1e';g.lineWidth=1.4;g.setLineDash([3,3]);g.beginPath();g.moveTo(X+11,Y+32);g.lineTo(X+26,Y+24);g.lineTo(X+33,Y+28);g.stroke();g.setLineDash([]);
    g.strokeStyle='#a02a1e';g.lineWidth=2.4;g.beginPath();g.moveTo(X+31,Y+25);g.lineTo(X+36,Y+31);g.moveTo(X+36,Y+25);g.lineTo(X+31,Y+31);g.stroke()}
  else if(k==='flag'){
    g.strokeStyle='#3a2410';g.lineWidth=3;g.beginPath();g.moveTo(X+8,Y+6);g.lineTo(X+8,Y+40);g.stroke();
    for(let i=0;i<3;i++){g.fillStyle=i===1?'#e8b82a':'#b02a22';g.beginPath();g.moveTo(X+8,Y+10+i*8);g.quadraticCurveTo(X+22,Y+6+i*8,X+36,Y+11+i*8);g.lineTo(X+36,Y+19+i*8);g.quadraticCurveTo(X+22,Y+14+i*8,X+8,Y+18+i*8);g.closePath();g.fill()}
    g.fillStyle='#e0b04a';g.beginPath();g.arc(X+8,Y+6,3.4,0,7);g.fill()}
  else if(k==='cross'){
    g.strokeStyle='#d4dbe4';g.lineWidth=3.4;g.beginPath();g.moveTo(X+7,Y+7);g.lineTo(X+37,Y+37);g.moveTo(X+37,Y+7);g.lineTo(X+7,Y+37);g.stroke();
    g.strokeStyle='#e0b04a';g.lineWidth=4;g.beginPath();g.moveTo(X+10,Y+14);g.lineTo(X+16,Y+8);g.moveTo(X+34,Y+14);g.lineTo(X+28,Y+8);g.stroke();
    g.fillStyle='#a02a1e';g.beginPath();g.arc(X+22,Y+22,9,0,7);g.fill();g.strokeStyle='#e0b04a';g.lineWidth=2;g.stroke();g.fillStyle='#e0b04a';g.fillRect(X+21,Y+16,2,12);g.fillRect(X+16,Y+21,12,2)}
  else if(k==='pans'){
    g.fillStyle='#241408';g.fillRect(X+4,Y+7,36,3);
    for(const[px,py,r]of[[12,25,8],[26,27,7],[37,22,5]]){g.strokeStyle='#241408';g.lineWidth=1.4;g.beginPath();g.moveTo(X+px,Y+10);g.lineTo(X+px,Y+py-r);g.stroke();
      g.fillStyle='#7a7a84';g.beginPath();g.arc(X+px,Y+py,r,0,7);g.fill();g.strokeStyle='#2a2a30';g.lineWidth=1.6;g.stroke();g.fillStyle='#3a3a44';g.beginPath();g.arc(X+px,Y+py,r-3,0,7);g.fill();g.fillStyle='rgba(255,255,255,.35)';g.fillRect(X+px-r+2,Y+py-3,3,2)}}
  else if(k==='hams'){
    g.fillStyle='#241408';g.fillRect(X+4,Y+7,36,3);
    for(const[px,py]of[[12,24],[26,26],[37,22]]){g.strokeStyle='#241408';g.lineWidth=1.4;g.beginPath();g.moveTo(X+px,Y+10);g.lineTo(X+px,Y+py-8);g.stroke();
      g.fillStyle='#a8442a';g.beginPath();g.ellipse(X+px,Y+py,7,10,0,0,7);g.fill();g.strokeStyle='#5a1e10';g.lineWidth=1.4;g.stroke();g.fillStyle='rgba(255,200,170,.35)';g.fillRect(X+px-4,Y+py-6,3,8)}
    g.strokeStyle='#8a3a22';g.lineWidth=3;g.beginPath();g.moveTo(X+8,Y+34);g.quadraticCurveTo(X+22,Y+42,X+36,Y+34);g.stroke()}
  else if(k==='chains'){
    for(const px of[14,30]){g.strokeStyle='#8a8f9a';g.lineWidth=2;for(let i=0;i<5;i++){g.beginPath();g.ellipse(X+px,Y+7+i*6,3,4,0,0,7);g.stroke()}
      g.strokeStyle='#5a5f6a';g.lineWidth=3;g.beginPath();g.arc(X+px,Y+39,5,0,7);g.stroke()}
    g.fillStyle='#241408';g.fillRect(X+8,Y+4,28,3)}
  else if(k==='shelf'){
    g.fillStyle='#5a3418';g.fillRect(X+4,Y+30,36,5);g.fillStyle='#8a5a2a';g.fillRect(X+4,Y+30,36,2);
    const cs=['#5aa0c8','#c8603a','#7aa860','#e0b04a'];
    for(let i=0;i<4;i++){g.fillStyle=cs[i];const w=6+(i%2)*2,h=12+(i*5)%7;g.fillRect(X+7+i*9,Y+30-h,w,h);g.fillStyle='rgba(255,255,255,.35)';g.fillRect(X+8+i*9,Y+32-h,2,h-4)}}
  else if(k==='net'){
    g.strokeStyle='#bba070';g.lineWidth=1.4;
    for(let i=-4;i<8;i++){g.beginPath();g.moveTo(X+i*7,Y+4);g.lineTo(X+i*7+30,Y+40);g.stroke();g.beginPath();g.moveTo(X+i*7+30,Y+4);g.lineTo(X+i*7,Y+40);g.stroke()}
    g.fillStyle='#d88a3a';for(const[px,py]of[[10,10],[30,12],[20,30]]){g.beginPath();g.arc(X+px,Y+py,4,0,7);g.fill()}}
  g.restore();
}
function bake(){
  const W=SW*T,H=SH*T,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');
  const rnd=mkRnd(DK*977+13);
  // ombra sull'acqua
  g.save();g.fillStyle='rgba(4,40,70,.30)';
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++)if(G[y][x]!==' ')g.fillRect(x*T+7,y*T+12,T,T);
  g.restore();
  // scafo (legno scuro) dietro a tutto
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++)if(G[y][x]!==' '){g.fillStyle=(x+y)%2?'#4c3220':'#503624';g.fillRect(x*T,y*T,T,T)}
  const near=(x,y,f)=>{for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]])if(isIn(x+dx,y+dy)&&f(G[y+dy][x+dx]))return true;return false};
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++){
    let ch=G[y][x];if(ch===' ')continue;
    if(ch==='D'||ch==='L'||ch==='H'){
      const nb=[[1,0],[-1,0],[0,1],[0,-1]].map(([dx,dy])=>G[y+dy]&&G[y+dy][x+dx]).filter(q=>q&&FLOOR.indexOf(q)>=0);ch=nb[0]||'.'}
    if(ch==='#')continue;
    floorTile(g,ch,x,y,rnd);
  }
  // soglie di ottone sotto le porte
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++){if(G[y][x]==='D'){const X=x*T,Y=y*T;const horiz=G[y][x-1]==='#'||G[y][x+1]==='#';g.fillStyle='rgba(224,176,74,.7)';if(horiz){g.fillRect(X,Y+T/2-2,T,4)}else{g.fillRect(X+T/2-2,Y,4,T)}}}
  /* ---- tappeti e dettagli del pavimento ---- */
  const runner=(x0,y0,w,h,base,trim)=>{g.fillStyle=base;g.fillRect(x0,y0,w,h);g.strokeStyle=trim;g.lineWidth=3;g.strokeRect(x0+5,y0+5,w-10,h-10);g.strokeStyle='rgba(224,176,74,.5)';g.lineWidth=1.4;g.strokeRect(x0+12,y0+12,w-24,h-24);
    g.fillStyle='rgba(224,176,74,.5)';const n=Math.max(2,Math.floor(w/(h*.9)));for(let i=0;i<n;i++){const px=x0+w*(i+.5)/n,py=y0+h/2;g.beginPath();g.moveTo(px,py-9);g.lineTo(px+9,py);g.lineTo(px,py+9);g.lineTo(px-9,py);g.closePath();g.fill()}
    g.fillStyle='rgba(12,8,24,.1)';g.fillRect(x0,y0,w,h);
    g.strokeStyle='rgba(224,176,74,.7)';g.lineWidth=1.6;for(let i=0;i<Math.floor(h/6);i++){g.beginPath();g.moveTo(x0-5,y0+3+i*6);g.lineTo(x0,y0+3+i*6);g.moveTo(x0+w,y0+3+i*6);g.lineTo(x0+w+5,y0+3+i*6);g.stroke()}};
  if(DK===0){
    runner(3*T,5*T,6*T,7*T,'#8a2a2a','#e0b04a');
    runner(12*T+6,8*T+4,19*T-12,2*T-8,'#7a2230','#e0b04a');
    // tappeto tondo nella sala delle carte
    g.fillStyle='#1f4a66';g.beginPath();g.ellipse(26.5*T,14*T,2.3*T,.85*T,0,0,7);g.fill();g.strokeStyle='#e0b04a';g.lineWidth=2.4;g.stroke();g.strokeStyle='rgba(224,176,74,.5)';g.lineWidth=1.2;g.beginPath();g.ellipse(26.5*T,14*T,2*T,.66*T,0,0,7);g.stroke();
    // tappetino nell'armeria
    runner(14*T,13.6*T,3.4*T,.8*T,'#5a2a2a','#c8a050')
  }
  if(DK===1){
    // tappeto di stracci nel dormitorio
    g.fillStyle='#6a4a3a';g.beginPath();g.ellipse(5.5*T,9*T,2.3*T,1.6*T,0,0,7);g.fill();
    for(let i=0;i<5;i++){g.strokeStyle=['#a8503a','#c8b070','#5a7a9a','#7a8a5a','#a8503a'][i];g.lineWidth=5;g.beginPath();g.ellipse(5.5*T,9*T,(2.1-i*.38)*T,(1.4-i*.26)*T,0,0,7);g.stroke()}
    // paglia, catene e macchie nella cella
    g.strokeStyle='rgba(212,180,90,.7)';g.lineWidth=2;for(let i=0;i<34;i++){const x=(42+rnd()*4)*T,y=(4+rnd()*9)*T;g.beginPath();g.moveTo(x,y);g.lineTo(x+(rnd()-.5)*18,y+(rnd()-.5)*12);g.stroke()}
    g.fillStyle='rgba(30,20,10,.25)';g.beginPath();g.ellipse(43.5*T,6.5*T,26,16,.3,0,7);g.fill();g.beginPath();g.ellipse(44*T,11.5*T,24,14,-.2,0,7);g.fill();
    // chiazze di unto vicino ai fornelli
    g.fillStyle='rgba(30,12,4,.22)';g.beginPath();g.ellipse(14*T,14.3*T,50,14,0,0,7);g.fill();
    // panni sui tavoli della mensa: strisce di tovaglia
    for(const x0 of[14,20,26]){g.fillStyle='rgba(180,60,50,.0)'}
  }
  if(DK===2){
    // pozzanghere d'acqua di sentina
    for(const[px,py,rx,ry]of[[38,5,50,22],[16,9.6,70,24],[6,6.5,40,18],[27,3,44,14],[41,11,46,22],[3.6,13.6,38,14]]){
      g.fillStyle='rgba(30,70,100,.38)';g.beginPath();g.ellipse(px*T,py*T,rx,ry,0,0,7);g.fill();g.strokeStyle='rgba(160,210,240,.35)';g.lineWidth=1.6;g.beginPath();g.ellipse(px*T-4,py*T-3,rx*.7,ry*.6,0,3.3,5.8);g.stroke()}
    // contorno dipinto della zona carico
    g.strokeStyle='rgba(240,230,200,.45)';g.lineWidth=3;g.setLineDash([14,10]);g.strokeRect(23.3*T,13.2*T,7.4*T,2.6*T);g.setLineDash([]);
    // pezzi di paglia dalle casse
    g.strokeStyle='rgba(212,180,90,.6)';g.lineWidth=2;for(let i=0;i<26;i++){const x=(23.6+rnd()*6.8)*T,y=(13.3+rnd()*2.4)*T;g.beginPath();g.moveTo(x,y);g.lineTo(x+(rnd()-.5)*14,y+(rnd()-.5)*8);g.stroke()}
    // croce rossa sulla polveriera
    g.strokeStyle='rgba(190,40,30,.55)';g.lineWidth=5;g.beginPath();g.moveTo(15.4*T,13.4*T);g.lineTo(18.6*T,15.6*T);g.moveTo(18.6*T,13.4*T);g.lineTo(15.4*T,15.6*T);g.stroke()
  }
  // scale
  {const st=STAIRS[DK];if(st.d)drawStairs(g,st.d[0]-1,st.d[1]-.5,false);if(st.u)drawStairs(g,st.u[0]-1,st.u[1]-.5,true)}
  // muri: legno più chiaro, bordi e ombra
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++){
    if(G[y][x]!=='#')continue;
    const inner=near(x,y,q=>FLOOR.indexOf(q)>=0||q==='D'||q==='L'||q==='H');
    g.fillStyle=inner?'#6e4628':'#4a2f1a';g.fillRect(x*T,y*T,T,T);
    g.strokeStyle='rgba(20,10,4,.45)';g.lineWidth=1.2;for(let i=1;i<4;i++){g.beginPath();g.moveTo(x*T,y*T+i*11);g.lineTo(x*T+T,y*T+i*11);g.stroke()}
    if(inner){g.fillStyle='rgba(255,230,170,.18)';g.fillRect(x*T,y*T,T,4);
      // pannelli in rilievo
      g.strokeStyle='rgba(255,226,170,.14)';g.lineWidth=1.4;g.strokeRect(x*T+4,y*T+8,T-8,T-14)}
  }
  // zoccolo: fascia scura al piede dei muri interni
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++){
    if(G[y][x]!=='#')continue;
    if(isIn(x,y+1)&&FLOOR.indexOf(G[y+1][x])>=0){g.fillStyle='rgba(40,20,8,.55)';g.fillRect(x*T,y*T+T-7,T,7);g.fillStyle='rgba(224,176,74,.35)';g.fillRect(x*T,y*T+T-8,T,1.6)}}
  // decorazioni
  for(const[k,x,y]of DECOR_BY[DK])if(G[y]&&G[y][x]==='#')drawDecor(g,k,x,y);
  // bordo del pavimento accanto ai muri (ombra morbida)
  for(let y=0;y<SH;y++)for(let x=0;x<SW;x++){
    const ch=G[y][x];if(ch==='#'||ch===' ')continue;
    const n=(dx,dy)=>G[y+dy]&&G[y+dy][x+dx]==='#';
    g.fillStyle='rgba(20,10,4,.28)';
    if(n(0,-1))g.fillRect(x*T,y*T,T,9);
    if(n(-1,0))g.fillRect(x*T,y*T,7,T);
    if(n(1,0))g.fillRect(x*T+T-7,y*T,7,T);
    if(n(0,1))g.fillRect(x*T,y*T+T-5,T,5);
  }
  // cornice dorata del ponte (bordo esterno dello scafo)
  g.strokeStyle='#e0b04a';g.lineWidth=2.5;g.lineCap='round';
  for(const[x,y]of bord){
    if(!isIn(x,y-1))g.beginPath(),g.moveTo(x*T,y*T+2),g.lineTo(x*T+T,y*T+2),g.stroke();
    if(!isIn(x,y+1))g.beginPath(),g.moveTo(x*T,y*T+T-2),g.lineTo(x*T+T,y*T+T-2),g.stroke();
    if(!isIn(x-1,y))g.beginPath(),g.moveTo(x*T+2,y*T),g.lineTo(x*T+2,y*T+T),g.stroke();
    if(!isIn(x+1,y))g.beginPath(),g.moveTo(x*T+T-2,y*T),g.lineTo(x*T+T-2,y*T+T),g.stroke();
  }
  // oblò del cannone lungo lo scafo
  g.fillStyle='#161616';for(const[x,y]of bord){if((x*3+y)%4!==0||x<12||x>38)continue;if(!isIn(x,y-1))g.fillRect(x*T+12,y*T+14,18,12);else if(!isIn(x,y+1))g.fillRect(x*T+12,y*T+14,18,12)}
  // luci calde delle lanterne
  for(const[lx,ly]of LAMPS){const X=(lx+.5)*T,Y=(ly+.5)*T,gr=g.createRadialGradient(X,Y,4,X,Y,150);gr.addColorStop(0,'rgba(255,214,120,.34)');gr.addColorStop(1,'rgba(255,214,120,0)');g.fillStyle=gr;g.fillRect(X-150,Y-150,300,300)}
  // luce del giorno sul ponte aperto
  if(DK===0){const gr=g.createLinearGradient(32*T,0,40*T,0);gr.addColorStop(0,'rgba(255,248,210,0)');gr.addColorStop(.5,'rgba(255,248,210,.13)');gr.addColorStop(1,'rgba(255,248,210,0)');g.fillStyle=gr;g.fillRect(32*T,2*T,8*T,14*T)}
  // atmosfera delle singole stanze
  const tint=(x0,y0,x1,y1,col)=>{g.fillStyle=col;g.fillRect(x0*T,y0*T,(x1-x0+1)*T,(y1-y0+1)*T)};
  if(DK===0){tint(41,2,46,15,'rgba(20,30,60,.12)');tint(12,13,21,15,'rgba(40,50,70,.08)')}
  if(DK===1){tint(41,2,46,15,'rgba(10,20,50,.22)');tint(12,13,21,15,'rgba(255,150,70,.07)')}
  if(DK===2){tint(12,13,21,15,'rgba(120,10,10,.10)');tint(41,2,46,15,'rgba(5,10,30,.2)')}
  {const tn=[0,.2,.38][DK];if(tn){g.fillStyle='rgba(8,12,40,'+tn+')';g.fillRect(0,0,W,H)}}
  SHIPC=c;
}
