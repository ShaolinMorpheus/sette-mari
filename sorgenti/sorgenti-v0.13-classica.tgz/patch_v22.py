#!/usr/bin/env python3
# v0.12j (C): galeone – cappello da comandante, traguardo, registro delle novità
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH22 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:100].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
NEW=open('/home/claude/work/new21.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Galeone: a fine assalto compare la scheda con tre stelle (prigionieri salvi, sei casse d'argento, mai inseguiti prima della campana) e una medaglia di bronzo, argento o oro. Con tutte e tre le stelle arrivano il cappello da comandante nel guardaroba e il traguardo «Assalto perfetto».",
    "Galeone: le battute del pappagallo e di Tito (anche sul mare) sono più piccole e trasparenti, così coprono meno schermo.",
    "Galeone: alcune guardie sono fuori servizio. Due dormono nelle cuccette degli ufficiali e due nel dormitorio, altre due giocano a carte in mensa. Il rumore le sveglia (cannone, rum, sciabolate, la campana d'allarme), ma si possono anche colpire nel sonno.",
    "Galeone: il comandante spagnolo studia le carte nella sala delle carte. Se premi «Usa» vicino a lui ti sfida a duello (facoltativo, 6 cuori, nessun aiuto). Se vinci ottieni la giubba del comandante nel guardaroba e il traguardo «Duellante».",
    "Galeone: vita a bordo. Le lanterne ondeggiano, il legno scricchiola, nella stiva corrono i ratti (scappano se ti avvicini) e ogni tanto un gabbiano passa davanti a un oblò.",
    "Galeone: in mensa c'è una bottiglia di rum da prendere e lanciare (tasto «Lancia»): le guardie vanno a vedere e si fermano a bere. Le guardie sospettose ora mostrano un «?» sopra la testa.",
    "Galeone: la chiave della cella cambia posto a ogni partita (cabina del comandante, alloggi degli ufficiali o armeria) e il pappagallo, il diario e i suggerimenti ti dicono dove cercarla.",
''')
open(P,'w',encoding='utf8').write(src)
print('patch22 ok')
