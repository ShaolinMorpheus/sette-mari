import re,sys
s=open('ch3_inject.js').read()
def rep(old,new):
    global s
    if s.count(old)!=1: print('FAIL',s.count(old),old[:80]); sys.exit(1)
    s=s.replace(old,new)
# 1 end card
rep('<button class="btn" id="eCh">Cambia piano</button>','')
rep("  $('endCard').querySelector('#eCh').onclick=()=>{uShow('endcard',false);intro()};\n","")
# 2 remove planning block
a=s.index("const CREW=[");b=s.index("function boot(){")
new_block=r'''const PLAN0={time:'alba',abb:2,div:1,sal:1,detect:1};

/* ---------------- collisioni ---------------- */
function circ(s){const sp0=SPEC[s.type],c=Math.cos(s.hd),n=Math.sin(s.hd),r=sp0.W*1.05;return[-.6,0,.6].map(f=>[s.x+c*sp0.L*f,s.y+n*sp0.L*f*.9,r])}
function collide(dt){
  const p=C.p;if(p.dead||C.over)return;
  if(C.ramCd>0)C.ramCd-=dt;
  const cp=circ(p),M=48;
  for(const s of C.ships){
    if(s.dead||s.sinking||s.ally)continue;
    const cs=circ(s);let pen=0,hard=false;
    for(const a of cp)for(const b of cs){const d=Math.hypot(a[0]-b[0],a[1]-b[1]),ov=a[2]+b[2]+M-d;if(ov>pen)pen=ov;if(d<a[2]+b[2]-4)hard=true}
    if(pen<=0)continue;
    let dx=s.x-p.x,dy=s.y-p.y;const d=Math.hypot(dx,dy)||1;dx/=d;dy/=d;
    const k=Math.min(1,dt*(hard?9:3))*pen;
    // l'altra nave si scosta di più; se non può, ti spinge indietro
    const ex=s.x+dx*k*.75,ey=s.y+dy*k*.75;
    if(!s.still&&shipOK(s,ex,ey,s.hd)){s.x=ex;s.y=ey}
    const px=p.x-dx*k*.3,py=p.y-dy*k*.3;
    if(shipOK(p,px,py,p.hd)){p.x=px;p.y=py}
    if(hard&&C.ramCd<=0){
      C.ramCd=1.4;p.v*=.4;s.v*=.6;
      if(!C.tut||C.tut.i>=2)hurt(p,C.easy?.25:.5);
      p.flash=.25;sfx('thud');
      for(let i=0;i<5;i++)C.fx.push({k:'chip',x:(p.x+s.x)/2+rr(-20,20),y:(p.y+s.y)/2+rr(-10,10),vx:rr(-120,120),vy:rr(-150,-30),t:0,life:.7});
      toast(C.notes.ram?'Speronamento! Lo scafo si danneggia.':'Speronamento! Scontrarti con una nave danneggia il tuo scafo: tieni le distanze.');C.notes.ram=1;
    }
  }
}

/* ---------------- tutorial ---------------- */
const TUTK='sette-mari-c3tut';
function tutSeen(){try{return localStorage.getItem(TUTK)==='1'}catch(e){return false}}
const TUT=[
  {t:'Al timone',x:'Trascina il pollice sullo schermo: la prua gira verso dove punti. Prova a far girare la nave.',ok:()=>Math.abs(angD(C.tut.hd0,C.p.hd))>.8},
  {t:'Le vele e il vento',x:'I tasti a sinistra regolano la velocità. Il quadrante a destra mostra il vento: con il vento alle spalle vai più veloce, controvento rallenti. Tocca «Tutta».',ok:()=>C.sail===3},
  {t:'Attenzione agli scontri',x:'Scogli, coste e navi sono duri. Se ci vai addosso lo scafo si danneggia (i cuori in alto). Le navi nemiche tengono le distanze: tu falle lo stesso. Vicino al porto il carpentiere ripara lo scafo.',btn:'Ho capito'},
  {t:'Fuoco!',x:'Raggiungi la nave col cerchio azzurro e mettila di fianco: il lato che si illumina è quello che spara. Poi premi «Fuoco!».',ok:()=>C.hits>=1,target:true},
  {t:'La missione',x:'Il convoglio arriva da est. Affonda i galeoni e raccogli le casse d\'argento. Sulla nave con la bandiera bianca ci sono Pip e Dodo: non affondarla! Colpiscila fino all\'avaria, poi premi «Abborda!».',btn:'Salpa!'}
];
function tutPanel(){
  let d=$('c3tut');if(!d){d=document.createElement('div');d.id='c3tut';$('c3').appendChild(d)}return d}
function tutShow(){
  const tt=C.tut;if(!tt)return;const st=TUT[tt.i],d=tutPanel();
  d.style.display='block';
  d.innerHTML='<div class="tth"><b>'+st.t+'</b><span>'+TUT.map((_,k)=>k<tt.i?'●':k===tt.i?'◉':'○').join(' ')+'</span></div><p>'+st.x+'</p><div class="ttb"><button id="ttSkip">Salta</button>'+(st.btn?'<button class="go" id="ttNext">'+st.btn+'</button>':'')+'</div>';
  const pr=(el,fn)=>{if(el)el.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();fn()})};
  pr($('ttSkip'),tutEnd);pr($('ttNext'),tutNext);
  if(st.target&&!tt.tg){
    const p=C.p;let x=p.x+Math.cos(p.hd+.5)*620,y=p.y+Math.sin(p.hd+.5)*620;
    if(!clearAt(x,y,90)){const r2=findSea(x,y);x=r2[0];y=r2[1]}
    const s=mkShip('mercante',x,y,p.hd+1.2,{still:true,tutT:true});C.ships.push(s);tt.tg=s;
  }
}
function tutNext(){if(!C.tut)return;sfx('coin');C.tut.i++;if(C.tut.i>=TUT.length){tutEnd();return}C.tut.hd0=C.p.hd;tutShow()}
function tutEnd(){
  if(!C.tut)return;
  try{localStorage.setItem(TUTK,'1')}catch(e){}
  if(C.tut.tg){C.tut.tg.still=false;C.tut.tg.tutT=false}
  C.tut=null;const d=$('c3tut');if(d)d.style.display='none';
  toast('Buon vento, capitano!');
}
function tutStart(){C.tut={i:0,hd0:C.p.hd,tg:null};tutShow()}
function tutStep(){
  const tt=C.tut;if(!tt)return;const st=TUT[tt.i];
  if(st.ok&&st.ok())tutNext();
}

/* ---------------- musica da battaglia ---------------- */
const BROOT=[50,50,46,45,50,43,45,50];
const BCH=[[62,65,69],[62,65,69],[58,62,65],[57,61,64],[62,65,69],[55,58,62],[57,61,64],[62,65,69]];
const BMEL=[
  [[0,74,2],[2,77,1],[3,76,1],[4,74,2]],
  [[0,69,2],[2,72,1],[3,74,1],[4,76,2]],
  [[0,77,2],[2,76,1],[3,74,1],[4,70,2]],
  [[0,69,1],[1,73,1],[2,76,2],[4,73,2]],
  [[0,74,2],[2,77,1],[3,81,1],[4,77,2]],
  [[0,79,2],[2,77,1],[3,74,1],[4,70,2]],
  [[0,73,1],[1,76,1],[2,77,1],[3,76,1],[4,73,2]],
  [[0,74,3],[3,69,1],[4,74,2]]
];
function drum(t,kind,vol){
  const c=AU.ctx;
  if(kind==='k'||kind==='t'){const o=c.createOscillator(),g=c.createGain();o.type='sine';const f0=kind==='k'?135:200,f1=kind==='k'?42:80;o.frequency.setValueAtTime(f0,t);o.frequency.exponentialRampToValueAtTime(f1,t+.17);g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+.26);o.connect(g);g.connect(AU.mbus);o.start(t);o.stop(t+.28)}
  else{
    if(!AU._nb||AU._nbc!==c){const n=(c.sampleRate*.4)|0,b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;AU._nb=b;AU._nbc=c}
    const s=c.createBufferSource();s.buffer=AU._nb;const f=c.createBiquadFilter();f.type='bandpass';f.frequency.value=1700;f.Q.value=.8;const g=c.createGain();g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.001,t+.16);s.connect(f);f.connect(g);g.connect(AU.mbus);s.start(t);s.stop(t+.2);
  }
}
function battleTick(){
  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running'||!C)return;
  const c=AU.ctx,now=c.currentTime;if(AU.nextT<now-.5)AU.nextT=now+.1;
  let hot=false;
  if(!C.over&&!C.tut){hot=C.balls.length>0||C.ships.some(s=>!s.dead&&(s.hostile||s.alert)&&Math.hypot(s.x-C.p.x,s.y-C.p.y)<1100)}
  const ST=.27;let guard=0;
  while(AU.nextT<now+.7&&guard++<8){
    const t=AU.nextT,st=(AU.beat|0)%48,bar=(st/6)|0,sb=st%6,root=BROOT[bar];
    if(sb===0)drum(t,'k',hot?.3:.2);
    if(sb===3)drum(t,hot?'s':'t',hot?.17:.12);
    if(hot&&sb===4)drum(t,'t',.1);
    if(hot&&sb===5)drum(t,'k',.13);
    if(sb===0||sb===3)mNote(t,root,ST*2.6,.1,'triangle');
    if(sb===3)mNote(t,root+7,ST*1.6,.05,'sine');
    if(sb===0)mPad(t,BCH[bar],ST*6.2,hot?.028:.02);
    if(hot||bar<4)for(const[s0,m,len]of BMEL[bar])if(s0===sb){mNote(t,m,len*ST*1.15,hot?.05:.03,'sawtooth');if(hot)mNote(t,m-12,len*ST*1.1,.03,'square')}
    AU.nextT+=ST;AU.beat=(AU.beat|0)+1;
  }
}
'''
s=s[:a]+new_block+s[b:]
# 3 boot
rep("  newRun(true,PLAN0);C.over=true; // finché non si preme «Salpa»\n  C.paused=true;\n  intro();\n  const old=$('c3easy');\n","  newRun(true,PLAN0);sailUI();\n  if(!tutSeen())tutStart();\n")
rep("window.Ch3={boot,","window.Ch3={music:battleTick,boot,")
# 4 step hooks
rep("  convoy(dt);\n  // IA","  if(!C.tut)convoy(dt);\n  // IA")
rep("    const dp=Math.hypot(p.x-s.x,p.y-s.y);\n    if(s.type==='scorta'&&!s.alert","    if(C.tut||s.still){s.v*=.9;continue}\n    const dp=Math.hypot(p.x-s.x,p.y-s.y);\n    if(s.type==='scorta'&&!s.alert")
# mercante avoid player
rep("      if(flee)steerTo(s,s.x+(s.x-p.x),s.y+(s.y-p.y),dt,1);else steerTo(","      if(flee||dp<400)steerTo(s,s.x+(s.x-p.x),s.y+(s.y-p.y),dt,1);else steerTo(")
# hostile keep distance
rep("const des=dp>520?want:want+side*(Math.PI/2)*.92;","const des=dp>520?want:want+side*(Math.PI/2)*(.92+(dp<380?(380-dp)/380*.9:0));")
rep("moveShip(s,dt,sp0.spd*(dp<300?.45:1)*windK(s.hd));","moveShip(s,dt,sp0.spd*(dp<240?.8:1)*windK(s.hd));")
# collide call after ball loop start: before palle
rep("  // palle di cannone\n","  collide(dt);\n  // palle di cannone\n")
# story gating
rep("if(!C.notes.start&&C.t>1.5){","if(!C.tut&&!C.notes.start&&C.t>1.5){")
rep("  if(!C.notes.found&&C.ships.some(","  if(!C.tut&&!C.notes.found&&C.ships.some(")
rep("  hud();\n}\nfunction alertConvoy","  tutStep();\n  $('c3obj').style.display=C.tut?'none':'block';\n  hud();\n}\nfunction alertConvoy")
# overlay target arrow
rep("if(s.dead||!(s.type==='galeone'&&s.conv||s.type==='prigionieri'&&!s.ally))continue;","if(s.dead||!(s.type==='galeone'&&s.conv&&!C.tut||s.type==='prigionieri'&&!s.ally&&!C.tut||s.tutT))continue;")
rep("g.fillStyle=s.type==='prigionieri'?'#fff':'#ffd23a';g.strokeStyle='#2a1a0e';g.lineWidth=2.5;g.beginPath();g.moveTo(16,0)","g.fillStyle=s.tutT?'#7be3ff':s.type==='prigionieri'?'#fff':'#ffd23a';g.strokeStyle='#2a1a0e';g.lineWidth=2.5;g.beginPath();g.moveTo(16,0)")
# css
rep("body.w3 #trow{","#c3tut{position:absolute;left:50%;transform:translateX(-50%);top:92px;width:min(430px,48%);pointer-events:auto;background:rgba(40,22,8,.9);border:3px solid #b8892e;border-radius:14px;color:#fff6dc;padding:8px 12px;font:700 13px/1.35 var(--f-b,Nunito,sans-serif);display:none;z-index:7}\n#c3tut .tth{display:flex;justify-content:space-between;align-items:center;gap:8px}#c3tut .tth b{font-size:15px;color:#ffd98a}#c3tut .tth span{font-size:11px;letter-spacing:1px;color:#ffd98a}\n#c3tut p{margin:4px 0 6px}#c3tut .ttb{display:flex;gap:8px;justify-content:flex-end}\n#c3tut button{border:2px solid #3a200c;border-radius:10px;background:#f0dfb4;color:#3a200c;font:900 12px var(--f-b,Nunito,sans-serif);padding:6px 12px;cursor:pointer}#c3tut button.go{background:linear-gradient(#ffd98a,#e19a26)}\nbody.w3 #trow{")
open('ch3_inject.js','w').write(s)
m=open('mk_ch3.py').read()
old="rep(\"if(window.__W2)return 2;\""
assert old in m
if 'Ch3.music' not in m:
    m=m.replace(old,"rep(\"function auMusicTick(){\\n  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running')return;\",\"function auMusicTick(){\\n  if(WORLD===3){Ch3.music();return}\\n  if(!AU.ctx||!AU.mbus||!AU.mus||AU.ctx.state!=='running')return;\")\n"+old,1)
open('mk_ch3.py','w').write(m)
