const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({file:'index_test.html'});
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 const url=await p.evaluate(()=>{
  const c=document.createElement('canvas');c.width=1500;c.height=520;const g=c.getContext('2d');g.fillStyle='#1c5a86';g.fillRect(0,0,1500,520);
  const hs=[0,Math.PI/2,Math.PI,-Math.PI/2,-.7];
  [0,1].forEach(row=>hs.forEach((hd,i)=>{
    const x=150+i*300,y=170+row*250;
    S_=Pirati.S;S_.up.sail=row;S_.up.hull=0;
    g.save();g.translate(x,y+8);g.rotate(hd);__T.drawSp(g,__T.SP.raftHull,0,0,.86);g.restore();
    const key={k:i+'_'+row};__T.sailState(key,hd,0,1);
    // lascia che la vela si assesti
    for(let t=0;t<3;t+=.05)__T.sailState(key,hd,t,1);
    const o=__T.sailState(key,hd,3.1,1);
    // il personaggio
    
    __T.drawSailProc(g,x+Math.cos(hd)*13.3,y+8+Math.sin(hd)*13.3,o,3.1,!!row);
  }));
  return c.toDataURL()});
 require('fs').writeFileSync('aud/raft_all.png',Buffer.from(url.split(',')[1],'base64'));
 console.log('ERR',JSON.stringify(errs));await b.close()})();
