const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));p.on('console',m=>{if(m.type()==='error')console.log('CE',m.text())});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>{Pirati.startNew('T','m')});
for(let i=0;i<12;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(500)}
const info=await p.evaluate(()=>Pirati.E.filter(e=>e.type==='loot'&&e.kind===8).map(e=>[e.id,(e.x/44).toFixed(1),(e.y/44).toFixed(1),Pirati.standOK(e)]));
console.log(JSON.stringify(info));
await p.evaluate(()=>{Pirati.fast(1);Pirati.S.flags.axe=1});
await p.evaluate(()=>{for(let i=0;i<12;i++)Pirati.dlgAuto()});await p.waitForTimeout(5500);
const w=await p.evaluate(()=>{const e=Pirati.EID.lt_tools;Pirati.tp(e.x/44+2.5,e.y/44+3.2);return 1});
await p.waitForTimeout(1200);await p.screenshot({path:'chest_closed.png'});
await p.evaluate(()=>{Pirati.EID.lt_tools.got=true;Pirati.EID.lt_line.got=true});await p.waitForTimeout(500);await p.screenshot({path:'chest_open.png'});
// crate: open first one
const id=info[0][0];
const r=await p.evaluate(async id=>{const e=Pirati.EID[id];Pirati.tp(e.x/44,e.y/44+1.2);await new Promise(r=>setTimeout(r,400));const t=Pirati.tinfo();for(let i=0;i<80&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,60))}Pirati.act();await new Promise(r=>setTimeout(r,3000));for(let i=0;i<8;i++)Pirati.dlgAuto();return [t&&t.l,e.got,JSON.stringify(Pirati.S.res)]},id);
console.log(r);await p.screenshot({path:'crate_open.png'});
await b.close()})();
