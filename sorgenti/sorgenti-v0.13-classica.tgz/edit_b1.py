#!/usr/bin/env python3
# B1: correzioni del mare + cantiere + aspetto della nave (ch3_inject.js e ch5_inject.js)
import sys
def load(p): return open(p,encoding='utf8').read()
def make_rep(box):
    def rep(old,new,cnt=1):
        n=box[0].count(old)
        if n!=cnt:
            print('EDIT FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
        box[0]=box[0].replace(old,new)
    return rep

# ======================= ch3_inject.js =======================
B=[load('ch3_inject.js')]; rep=make_rep(B)

rep("(bozza giocabile dentro il motore dell'isola)","(dentro il motore dell'isola)")

# --- 1) battute di Tito sopra la scheda del tutorial ---
rep("body.w3 #trow{left:auto!important;right:12px;top:8px}",
    "body.w3 #trow{left:auto!important;right:12px;top:8px}\nbody.w3 #bcol{bottom:calc(var(--dlgh,0px) + var(--c3tuth,0px) + 12px + var(--sb))}")
rep("  pr($('ttSkip'),tutEnd);pr($('ttNext'),tutNext);\n",
    "  pr($('ttSkip'),tutEnd);pr($('ttNext'),tutNext);\n  try{document.body.style.setProperty('--c3tuth',(d.offsetHeight+14)+'px')}catch(e){}\n")
rep("  C.tut=null;const d=$('c3tut');if(d)d.style.display='none';\n",
    "  C.tut=null;const d=$('c3tut');if(d)d.style.display='none';\n  try{document.body.style.removeProperty('--c3tuth')}catch(e){}\n")

# --- 3) tolta la «bozza giocabile» + argento in cassa al cantiere ---
rep("<span>Il Convoglio · bozza giocabile</span>","<span>Il Convoglio</span>")

# --- sprite: polena sullo scafo, vele e bandiera della Sirena ---
rep("function hullSprite(k){\n  const sp0=SPEC[k],L=sp0.L,w=sp0.W,Wd=Math.ceil(L*2+60),Hd=Math.ceil(w*2+50);",
    "function hullSprite(k,fig){\n  const sp0=SPEC[k],L=sp0.L,w=sp0.W,Wd=Math.ceil(L*2+60+(fig?44:0)),Hd=Math.ceil(w*2+50);")
rep("    g.strokeStyle='rgba(255,230,160,.5)';g.lineWidth=1.4;g.beginPath();g.moveTo(cx+L*.9,cy-1.5);g.lineTo(cx+L+26,cy-1.5);g.stroke();\n  },Wd/2,Hd/2);",
    "    g.strokeStyle='rgba(255,230,160,.5)';g.lineWidth=1.4;g.beginPath();g.moveTo(cx+L*.9,cy-1.5);g.lineTo(cx+L+26,cy-1.5);g.stroke();\n    if(fig)YD.figPaint(g,cx+L+22,cy,fig,1.15);\n  },Wd/2,Hd/2);")
rep("function sailSprite(k){\n  const sp0=SPEC[k],h=sp0.mh,wd=Math.round(h*.66),Wd=wd+40,Hd=h+30;\n  return sp(Wd,Hd,g=>{\n    const cx=Wd*.38,by=Hd-8;\n",
    "function sailSprite(k,sel){\n  const sp0=SPEC[k],h=sp0.mh,wd=Math.round(h*.66),Wd=wd+40,Hd=h+30;\n  return sp(Wd,Hd,g=>{\n    const cx=Wd*.38,by=Hd-8;\n    if(sel){YD.sailPaint(g,cx,by,h,wd,YD.look(sel),1.5);return}\n")
rep("const hs=k=>SPR['h'+k]||(SPR['h'+k]=hullSprite(k)),ss=k=>SPR['s'+k]||(SPR['s'+k]=sailSprite(k));",
    "const hs=(k,s)=>{let f='';if(k==='sirena'&&s&&C&&s===C.p){f=YD.sel().fig;if(f==='nessuna')f=''}const key='h'+k+(f?'@'+f:'');return SPR[key]||(SPR[key]=hullSprite(k,f))},\n  ss=(k,s)=>{let sel=null,key='s'+k;if(k==='sirena'&&s&&C&&s===C.p){sel=YD.sel();key+='@'+sel.sail+'|'+sel.flag}return SPR[key]||(SPR[key]=sailSprite(k,sel))};")
rep("  drawSp(g,hs(s.type),0,0,1);\n","  drawSp(g,hs(s.type,s),0,0,1);\n")
rep("    const spr=ss(s.type);drawSp(g,spr,0,0,1);g.restore()","    const spr=ss(s.type,s);drawSp(g,spr,0,0,1);g.restore()")

# --- cantiere: migliorie applicate alla nuova corsa ---
rep("  C.p=mkShip('sirena',sp[0],sp[1],0,{hull:8,max:8});C.p.isP=true;\n",
    "  const yd=YD.get(),hm=8+yd.h;C.yd=yd;C.cdP=2.1*YD.gunK(yd.g);C.sailK=YD.sailK(yd.s);\n  C.p=mkShip('sirena',sp[0],sp[1],0,{hull:hm,max:hm});C.p.isP=true;\n")
rep("  s[cd]=s===C.p?2.1:3.4;\n","  s[cd]=s===C.p?(C.cdP||2.1):3.4;\n")
rep("g.arc(px,py+6*z,(SPEC.sirena.W+14)*z,an-.5,an-.5+(1-cd/2.1))","g.arc(px,py+6*z,(SPEC.sirena.W+14)*z,an-.5,an-.5+(1-cd/(C.cdP||2.1)))")
rep("*(p.disabled?0:1)*(1-.03*Math.min(C.silver,10));","*(p.disabled?0:1)*(1-.03*Math.min(C.silver,10))*(C.sailK||1);")

# --- 4) scorta armata libera dopo la prima nave nemica affondata ---
rep("n=own?3:(s.type==='galeone'?3:2)","n=own?3:(s.type==='galeone'||s.free?3:2)")
rep("    }else if(s.type==='pattuglia'||(s.type==='scorta'&&s.alert&&!s.guard)){\n      const sp0=SPEC[s.type];\n      if(s.type==='pattuglia'&&!s.hostile&&dp<330*(C.plan?C.plan.detect:1)){s.hostile=true;if(!C.notes.patr){C.notes.patr=1;toast('<b>Tito:</b> «Una pattuglia! Ci ha visti!»')}}\n      if(s.type==='pattuglia'&&s.hostile&&dp>(s.hit?1600:620))s.hostile=false;\n",
    "    }else if(s.type==='pattuglia'||s.free||(s.type==='scorta'&&s.alert&&!s.guard)){\n      const sp0=SPEC[s.type];\n      if((s.type==='pattuglia'||s.free)&&!s.hostile&&dp<(s.free?560:330)*(C.plan?C.plan.detect:1)){s.hostile=true;if(!C.notes.patr&&!s.free){C.notes.patr=1;toast('<b>Tito:</b> «Una pattuglia! Ci ha visti!»')}}\n      if((s.type==='pattuglia'||s.free)&&s.hostile&&dp>(s.hit?1600:(s.free?900:620)))s.hostile=false;\n")
rep("{fire(s,sd);s.cd=rr(2.2,3.8)}","{fire(s,sd);s.cd=s.free?rr(1.8,3):rr(2.2,3.8)}")
rep("if(s.type==='pattuglia')s.hostile=true;if(s.conv)alertConvoy()","if(s.type==='pattuglia'||s.free)s.hostile=true;if(s.conv)alertConvoy()")
rep("const lab=s.ally?'Nave di Pip e Dodo':sp0.name+(s.disabled?' · in avaria':'');","const lab=s.ally?'Nave di Pip e Dodo':(s.nm||sp0.name)+(s.disabled?' · in avaria':'');")
rep("  if(!C.tut&&!C.notes.start&&C.t>1.5){C.notes.start=1;toast('<b>Tito:</b> «Capitano, ci sono navi nemiche in zona. Affondane qualcuna.»')}\n",
    "  if(!C.tut&&!C.notes.start&&C.t>1.5){C.notes.start=1;toast('<b>Tito:</b> «Capitano, ci sono navi nemiche in zona. Affondane qualcuna.»')}\n  if(!C.tut&&!C.convoy&&!C.notes.esc0&&(C.ekills||0)>=1){C.esW=(C.esW||0)+dt;if(C.esW>5){C.notes.esc0=1;spawnEscort()}}\n")
rep("function findSea(x,y){",
"""function spawnEscort(){      // seconda uscita: una scorta armata (più scafo e più cannoni delle pattuglie)
  const p=C.p;let q=null;
  for(let k=0;k<50&&!q;k++){const a=p.hd+rr(-1.2,1.2),d=rr(1700,2300),x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;if(x>300&&y>300&&x<WW-300&&y<WH-300&&clearAt(x,y,100))q=[x,y]}
  if(!q)q=randSea();
  const s=mkShip('scorta',q[0],q[1],Math.atan2(p.y-q[1],p.x-q[0]),{free:true,nm:'Scorta armata'});
  C.ships.push(s);C.esc=s;
  toast('<b>Tito:</b> «Vela rossa '+dirName(q[0]-p.x,q[1]-p.y)+', capitano! È una scorta armata: ha più cannoni e più scafo delle pattuglie. Tienila di prua o di poppa.»',7000);
}
function findSea(x,y){""")

# --- statistiche per l'aspetto della nave ---
rep("if(s.hull<=0){s.dead=true;s.sinking=true;C.kills++;if(s.type!=='mercante')C.ekills=(C.ekills||0)+1;sink(s);",
    "if(s.hull<=0){s.dead=true;s.sinking=true;C.kills++;if(s.type!=='mercante')C.ekills=(C.ekills||0)+1;if(s.type==='pattuglia'||s.type==='scorta'||s.type==='galeone'){try{YD.stat('kills');yAnn(2600)}catch(e){}}sink(s);")
rep("function sink(s){","function yAnn(ms){setTimeout(()=>{try{const n=YD.announce();if(n.length)toast('Nuovo per la nave: <b>'+n.map(x=>x.it.n).join(', ')+'</b>. Lo scegli dal Menu › Guardaroba › Nave.',6500)}catch(e){}},ms||1800)}\nfunction sink(s){")
rep("    C.over=true;boardSfx();toast('<b>Abbordaggio!</b> Tutti sul galeone spagnolo!',2500);\n","    C.over=true;boardSfx();toast('<b>Abbordaggio!</b> Tutti sul galeone spagnolo!',2500);try{YD.stat('gal')}catch(e){}\n")
rep("  s.ally=true;s.conv=false;s.disabled=false;s.hull=s.max;C.pris=2;boardSfx();parEv('board',1);saveCP();\n","  s.ally=true;s.conv=false;s.disabled=false;s.hull=s.max;C.pris=2;boardSfx();parEv('board',1);saveCP();try{YD.stat('pris');yAnn(5200)}catch(e){}\n")

# --- fine corsa: argento in cassa al cantiere ---
rep("  const rows=['Pieno: argento e tutti salvati','Argento e salvataggio, con perdite','Solo salvataggio','Solo argento','Colpo mancato'];\n",
    "  const rows=['Pieno: argento e tutti salvati','Argento e salvataggio, con perdite','Solo salvataggio','Solo argento','Colpo mancato'];\n  let bk=0,ann=[],ybk=0;try{bk=C.silver;YD.bank(bk);ybk=YD.get().b;YD.stat('runs');if(key===0)YD.stat('perfect');ann=YD.announce()}catch(e){}\n  const ybHtml=(bk>0?'<p class=\"sm\">🪙 <b>+'+bk+'</b> casse d\\'argento al cantiere del campo (in cassa: '+ybk+').</p>':'<p class=\"sm\">🪙 Senza argento il cantiere resta fermo: porta le casse al campo per migliorare la nave.</p>')+(ann.length?'<p class=\"sm\">⛵ Nuovo per la nave: <b>'+ann.map(x=>x.it.n).join(', ')+'</b>. Lo trovi nel Menu › Guardaroba › Nave.</p>':'');\n")
rep("<p class=\"sm\">Esito: <b>'+rows[key]+'</b></p><div class=\"row\">","<p class=\"sm\">Esito: <b>'+rows[key]+'</b></p>'+ybHtml+'<div class=\"row\">")

# --- arrivo al varco: argento in cassa ---
rep("  C.over=true;const sv=C.silver;\n  UI.dlg([D('hero',\"Eccolo: il varco.",
    "  C.over=true;const sv=C.silver;\n  try{YD.bank(sv);YD.stat('runs')}catch(e){}\n  UI.dlg([D('hero',\"Eccolo: il varco.")
rep("<div style=\"font-size:30px;margin:6px 0 14px\">Il grande viaggio</div><div>Caricamento…</div>';",
    "<div style=\"font-size:30px;margin:6px 0 14px\">Il grande viaggio</div>'+(sv>0?'<div style=\"font-size:15px;opacity:.85;margin-bottom:12px\">🪙 +'+sv+' casse d\\'argento al cantiere del campo</div>':'')+'<div>Caricamento…</div>';")

# --- 2) frecce sul bordo con la distanza ---
rep("""  for(const s of C.ships){
    if(s.dead||!(s.type==='galeone'&&s.conv&&!C.tut||s.type==='prigionieri'&&!s.ally&&!C.tut||s.tutT))continue;
    const[x,y]=toScreen(s.x,s.y);
    if(x>26&&x<w-26&&y>40&&y<h-26)continue;
    const a=Math.atan2(y-h/2,x-w/2),ex=cl(w/2+Math.cos(a)*(w/2-34),34,w-34),ey=cl(h/2+Math.sin(a)*(h/2-34),50,h-34);
    g.save();g.translate(ex,ey);g.rotate(a);g.fillStyle=s.tutT?'#7be3ff':s.type==='prigionieri'?'#fff':'#ffd23a';g.strokeStyle='#2a1a0e';g.lineWidth=2.5;g.beginPath();g.moveTo(16,0);g.lineTo(-9,-10);g.lineTo(-9,10);g.closePath();g.fill();g.stroke();g.restore();
  }
""","""  {let near=null,nd=1e9;      // nel primo tratto: freccia verso la pattuglia più vicina, se è fuori schermo
   if(!VOY&&!C.convoy&&!C.tut&&!C.go5&&!C.over)for(const s of C.ships){if(s.dead||s.sinking||s.ally||s.conv||!(s.type==='pattuglia'||s.free))continue;const d=Math.hypot(s.x-C.p.x,s.y-C.p.y);if(d<nd){nd=d;near=s}}
   for(const s of C.ships){
    const kd=s.dead?0:s.tutT?'t':(s.type==='galeone'&&s.conv&&!C.tut)?'g':(s.type==='prigionieri'&&!s.ally&&!C.tut)?'p':s===near?'e':0;
    if(!kd)continue;
    const[x,y]=toScreen(s.x,s.y);
    if(x>26&&x<w-26&&y>40&&y<h-26)continue;
    edgeArrow(g,w,h,x,y,kd==='t'?'#7be3ff':kd==='p'?'#ffffff':kd==='e'?'#ff8a7a':'#ffd23a',Math.hypot(s.x-C.p.x,s.y-C.p.y))
   }}
""")
rep("function overlay(){","""function edgeArrow(g,w,h,x,y,col,dist){      // freccia sul bordo (dentro un rettangolo che evita i pulsanti) + distanza in caselle
  const x0=88,x1=w-142,y0=58,y1=h-36,mx=(x0+x1)/2,my=(y0+y1)/2,hx=(x1-x0)/2,hy=(y1-y0)/2;
  const dx=x-w/2,dy=y-h/2,a=Math.atan2(dy,dx),k=Math.min(dx?hx/Math.abs(dx):1e9,dy?hy/Math.abs(dy):1e9),ex=mx+dx*k,ey=my+dy*k;
  g.save();g.translate(ex,ey);g.rotate(a);g.fillStyle=col;g.strokeStyle='#2a1a0e';g.lineWidth=2.5;g.beginPath();g.moveTo(16,0);g.lineTo(-9,-10);g.lineTo(-9,10);g.closePath();g.fill();g.stroke();g.restore();
  distPill(g,ex,ey,a,Math.round(dist/T)+' caselle',col)
}
function distPill(g,ex,ey,a,txt,col){
  const lx=ex-Math.cos(a)*34,ly=ey-Math.sin(a)*34;
  g.save();g.font='800 12px Nunito,Arial';g.textAlign='center';g.textBaseline='middle';
  const tw=g.measureText(txt).width+14,x=lx-tw/2,y=ly-10,r=10;
  g.fillStyle='rgba(24,14,6,.8)';g.beginPath();g.moveTo(x+r,y);g.arcTo(x+tw,y,x+tw,y+20,r);g.arcTo(x+tw,y+20,x,y+20,r);g.arcTo(x,y+20,x,y,r);g.arcTo(x,y,x+tw,y,r);g.closePath();g.fill();
  g.lineWidth=2;g.strokeStyle=col;g.stroke();g.fillStyle='#fff6dc';g.fillText(txt,lx,ly+1);g.restore()
}
function overlay(){""")
# anche la freccia del varco ha la distanza
rep("g.shadowColor='rgba(255,214,90,.9)';g.shadowBlur=14+pl*10;g.fillStyle='#ffd23a';g.strokeStyle='#2a1a0e';g.lineWidth=3;g.beginPath();g.moveTo(24,0);g.lineTo(-12,-15);g.lineTo(-6,0);g.lineTo(-12,15);g.closePath();g.fill();g.stroke();g.restore()}",
    "g.shadowColor='rgba(255,214,90,.9)';g.shadowBlur=14+pl*10;g.fillStyle='#ffd23a';g.strokeStyle='#2a1a0e';g.lineWidth=3;g.beginPath();g.moveTo(24,0);g.lineTo(-12,-15);g.lineTo(-6,0);g.lineTo(-12,15);g.closePath();g.fill();g.stroke();g.restore();distPill(g,ex,ey,a,Math.round(Math.hypot(C.go5.x-C.p.x,C.go5.y-C.p.y)/T)+' caselle','#ffd23a')}")

open('ch3_inject.js','w',encoding='utf8').write(B[0])

# ======================= ch5_inject.js =======================
B=[load('ch5_inject.js')]; rep=make_rep(B)
rep("<span>Il grande viaggio · bozza giocabile</span>","<span>Il grande viaggio</span>")
rep("C.p=mkShip('sirena',c[0]*T,c[1]*T,Math.PI,{hull:8,max:8});C.p.isP=true;",
    "const yd5=YD.get();C.sailK=YD.sailK(yd5.s);C.p=mkShip('sirena',c[0]*T,c[1]*T,Math.PI,{hull:8+yd5.h,max:8+yd5.h});C.p.isP=true;")
open('ch5_inject.js','w',encoding='utf8').write(B[0])
print('edit b1 ok')
