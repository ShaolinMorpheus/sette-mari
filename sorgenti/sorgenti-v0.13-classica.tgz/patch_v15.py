#!/usr/bin/env python3
# v0.12c: traversata lunga mondo 1 (due dorsali), niente scogli sparsi, frecce guida, tempesta dal molo
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH15 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
# niente scogli in mezzo
rep("   blob(66,32,1.4,5.6);blob(72.8,30,1.4,4.4)}","   }")
rep("for(let tries=0;tries<2400&&k<26+I2;tries++){","for(let tries=0;tries<2400&&k<10;tries++){")
# la tempesta parte dal molo
rep("if(!S.flags.sailed&&!STM.on&&P.mode==='raft'&&P.x>CHAL_X*TS)chalStart();","if(!S.flags.sailed&&!STM.on&&P.mode==='raft'&&hyp(P.x-FIX.raftLaunch[0]*TS,P.y-FIX.raftLaunch[1]*TS)>4.5*TS)chalStart();")
rep("setTimeout(()=>UI.toast('Raggiungi la costa a est. Il mare ti spinge indietro.'),1800);","setTimeout(()=>UI.toast('Segui la freccia: la Baia è lontana, sempre verso est.'),1800);")
rep("Sterza con il joystick, aggira i gruppi di scogli e schiva i fulmini.","Sterza con il joystick, segui la freccia verso est e schiva i fulmini.")
# frecce guida lungo la rotta
rep("const CHAL_X=64.6;","""const RW=[[70.4+I2,33.2]];   // tappe del giro lungo
let RW_I=0;
function rwMark(){
  if(WORLD!==1||S.flags.sailed||P.mode!=='raft'){RW_I=0;return null}
  while(RW_I<RW.length-1&&hyp(P.x-RW[RW_I][0]*TS,P.y-RW[RW_I][1]*TS)<3.2*TS)RW_I++;
  const w=RW[RW_I];return{x:w[0]*TS,y:w[1]*TS,r:2.2*TS,up:0};
}
const CHAL_X=64.6;""")
rep("mark:()=>({x:FIX.landing[0]*TS,y:FIX.landing[1]*TS,r:4*TS,up:20})}],\n  onDone(){Story.endChapter()}}","mark:()=>rwMark()||({x:FIX.landing[0]*TS,y:FIX.landing[1]*TS,r:4*TS,up:20})}],\n  onDone(){Story.endChapter()}}")
# omino sempre sul ponte, fisso a prua
rep("g.translate(Math.cos(P.hd)*54,Math.sin(P.hd)*54-6+Math.sin(RT*1.6)*1.2)","g.translate(Math.cos(P.hd)*38,Math.sin(P.hd)*38+7+Math.sin(RT*1.6)*1.5)")
rep('"Editor mappa v2:','"Prima traversata: la Baia dei Fuggiaschi è molto più lontana (mare aperto, circa 4 volte la strada di prima) e si raggiunge sotto la tempesta coi fulmini; la Baia ha la forma della costa ovest dell\'isola vera del Capitolo 2; pochi scogli sparsi.","Zattera: l\'omino resta sempre sul ponte, fisso a prua, anche quando giri.","Editor mappa v3: «Anteprima costa» ridisegna subito sabbia/erba/mare; nuovi editor per galeone (rotta del convoglio e caratteristiche delle navi), interno della nave (mobili, lanterne, decorazioni, dobloni su tutti e tre i ponti) e grande viaggio (tappe, boe, punti di ripresa), dal menu con password.","Editor mappa v2:',1)
rep("Mela e pesce separati: la mela mangia noci, bacche e molluschi;","Mela e pesce separati: il pulsante con la mela ti fa mangiare noci di cocco, bacche e molluschi;")
rep("La mela mangia noci, bacche e molluschi. Il pesce ha","Il pulsante con la mela serve per mangiare: noci di cocco, bacche e molluschi. Il pesce ha")
# tempesta più equa sulla lunga distanza: punti di ripresa, cuori che si rigenerano, fulmini meno fitti
rep("P.x=FIX.raftLaunch[0]*TS;P.y=FIX.raftLaunch[1]*TS;P.hd=0;P.rv=0;\n  UI.dlg([D('hero',\"La zattera regge a malapena","{const k=Math.max(0,Math.min(3,Math.floor(((STM.maxX||0)-FIX.raftLaunch[0]*TS)/(20*TS))));P.x=(FIX.raftLaunch[0]+k*20)*TS;P.y=FIX.raftLaunch[1]*TS}P.hd=0;P.rv=0;\n  UI.dlg([D('hero',\"La zattera regge a malapena")
rep("STM.hp--;STM.inv=1.6;","STM.hp--;STM.rg=0;STM.inv=1.6;")
rep("STM.t+=dt;STM.inv=Math.max(0,STM.inv-dt);","STM.t+=dt;STM.inv=Math.max(0,STM.inv-dt);STM.maxX=Math.max(STM.maxX||0,P.x);STM.rg=(STM.rg||0)+dt;if(STM.hp>0&&STM.hp<STM.max&&STM.rg>16){STM.hp++;STM.rg=0;chalHud()}")
rep("const wob=Math.sin(STM.t*.9)*30,cur=-24;","const wob=Math.sin(STM.t*.9)*30,cur=-16;")
rep("STM.bt=(STM.fails?3.8:2.8)+Math.random()*1.5;","STM.bt=(STM.fails?4.6:3.6)+Math.random()*1.8;")
rep("const STM={on:false,hp:3,inv:0,warn:[],bt:2,t:0,fails:0};","const STM={on:false,hp:3,inv:0,warn:[],bt:2,t:0,fails:0};window.__STM=STM;")
open(P,'w',encoding='utf8').write(src)
print('patch15 ok')
