const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(2000);
console.log('start',await p.evaluate(()=>[!!document.getElementById('bNew'),typeof Ch3]));
await p.click('#bNew');await p.waitForTimeout(4000);await p.screenshot({path:'main.png'});
console.log('hud',await p.evaluate(()=>document.getElementById('objT')&&document.getElementById('objT').textContent));
console.log(await p.evaluate(()=>Object.keys(localStorage)));
await p.evaluate(()=>{document.getElementById('bCap3')});console.log(er);await b.close()})()
