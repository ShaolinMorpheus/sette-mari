const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(2500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.waitForTimeout(1000);
console.log(await p.evaluate(()=>{const S=Pirati.S;S.stat.bottles=1;Pirati.Story.onBottle(Pirati.EID.bt0);return [JSON.stringify(S.flags.bread),Pirati.UI.dlgOpen()]}));
await p.waitForTimeout(500);
for(let i=0;i<6;i++){await p.mouse.click(450,380);await p.waitForTimeout(500)}
await p.evaluate(()=>Pirati.UI.openJournal('a'));await p.waitForTimeout(500);await p.screenshot({path:'arch.png'});
await p.evaluate(()=>{document.getElementById('jx').click()});
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(3000);
for(let i=0;i<5;i++){await p.mouse.click(450,380);await p.waitForTimeout(300)}
console.log(await p.evaluate(()=>{const e=Pirati.E.find(e=>e.id==='lt_pg1');const c=Pirati.S.c2;c.pages=0;Pirati.Story.onLoot(e);return [Pirati.UI.dlgOpen(),c.pages,JSON.stringify(c.pgread)]}));
for(let i=0;i<6;i++){await p.mouse.click(450,380);await p.waitForTimeout(400)}
await p.evaluate(()=>Pirati.UI.openJournal('a'));await p.waitForTimeout(500);await p.screenshot({path:'arch2.png'});
console.log(er);await b.close()})();
