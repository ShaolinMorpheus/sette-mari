const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:1100,height:620}});const p=await ctx.newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<60&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(300)}};
await clr();
await p.evaluate(()=>{Pirati.S.tod=12;Pirati.S.up.torch=1;Pirati.Ch2.addTrust('tito',3);Pirati.Ch2.st().said.rudder=1;Pirati.S.q.c8={st:'active',gi:2}});
// walk to the cave entrance outside
const ent=await p.evaluate(()=>{const e=Pirati.EID.cave;Pirati.P.x=e.x;Pirati.P.y=e.y+70;Pirati.cam.x=Pirati.P.x;Pirati.cam.y=Pirati.P.y;return [Pirati.tinfo(),Math.round(e.x),Math.round(e.y)]});
await p.waitForTimeout(500);console.log('outside',JSON.stringify(ent),await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await p.screenshot({path:'cv_out.png'});
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(900);
console.log('inside',await p.evaluate(()=>[Pirati.cave.inside(),Pirati.torchHours(),document.getElementById('torchb').hidden]));
// walk with joystick to the rudder
await p.evaluate(()=>{const r=Pirati.EID.cvrudder;Pirati.P.x=r.x-30;Pirati.P.y=r.y+10});await p.waitForTimeout(400);
await clr();console.log('tt',await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));console.log('q',await p.evaluate(()=>JSON.stringify(Pirati.S.q.c8)));await p.evaluate(()=>Pirati.act());await p.waitForTimeout(300);console.log('dlg',await p.evaluate(()=>(document.getElementById('dlg')||{}).innerText));await clr();
console.log('rudder',await p.evaluate(()=>[Pirati.Ch2.st().parts.rudder,Pirati.S.q.c8&&Pirati.S.q.c8.st]));
// exit
await p.evaluate(()=>{const e=Pirati.EID.cavex;Pirati.P.x=e.x;Pirati.P.y=e.y-40});await p.waitForTimeout(300);
console.log('tinfo',await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(1200);
console.log('out',await p.evaluate(()=>[Pirati.cave.inside(),Math.round(Pirati.P.x),Math.round(Pirati.P.y),Pirati.S.torchOn,Pirati.torchHours()]));
await p.screenshot({path:'cv_out2.png'});
// save while inside & reload
await p.evaluate(()=>{Pirati.cave.enter();Pirati.saveGame()});await p.waitForTimeout(600);
await p.reload();await p.waitForTimeout(2500);await p.click('#bCont');await p.waitForTimeout(3500);
console.log('reload',await p.evaluate(()=>[Pirati.cave.inside(),document.body.className,Pirati.torchHours()]));await p.screenshot({path:'cv_reload.png'});
console.log(er);await b.close()})();
