const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}
await p.evaluate(()=>{Pirati.S.tod=12;Pirati.Ch2.st().parts.yard=1;const e=Pirati.EID.nave;Pirati.P.x=e.x;Pirati.P.y=e.y+110;Pirati.cam.x=e.x;Pirati.cam.y=e.y-230;Pirati.P.y=e.y-120});await p.waitForTimeout(1500);await p.screenshot({path:'nave_D.png'});
console.log(er);await b.close()})();
