const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({file:'index_test.html'});
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;for(const k of['legna','pietra','corda','rottami'])S.res[k]=500;
  for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];e.st=2;e.prog=1;S.built[id]=1}Pirati.saveGame(true);});
 await p.evaluate(()=>Pirati.startContinue());await p.waitForTimeout(2500);await L.skip(p);
 await p.evaluate(()=>{Pirati.S.tutDone=1;Pirati.UI.openUpgrades();for(const k of['orto','essic'])document.querySelector('[data-dc="'+k+'"]').click();Pirati.saveGame(true)});
 const mv=await p.evaluate(()=>{const o=Pirati.E.find(e=>e.type==='cdeco'&&e.k==='orto');const t=Pirati.E.find(e=>e.type==='tree'&&e.alive);const was=[t.tx,t.ty];__T.delBlock(t);t.tx=o.tx;t.ty=o.ty+2;t.x=(t.tx+.5)*44;t.y=(t.ty+.8)*44;t.fp=[t.tx,t.ty,1,1];__T.reBlock(t);const n=__T.clearFarmArea();return 'albero messo davanti all\'orto a '+t.tx+','+t.ty+' -> spostati '+n+', ora a '+t.tx+','+t.ty});console.log(mv);
 for(let rr=0;rr<2;rr++){
  if(rr===1){await p.evaluate(()=>Pirati.startContinue());await p.waitForTimeout(2500);await L.skip(p);}
  const r=await p.evaluate(()=>{
   const ok=(tx,ty)=>__T.boxFree((tx+.5)*44,(ty+.5)*44,9,5);const out=[];
   const cd=Pirati.E.filter(e=>e.type==='cdeco'&&(e.k==='orto'||e.k==='essic'));
   const o=cd.find(e=>e.k==='orto'),es=cd.find(e=>e.k==='essic'),bn=Pirati.EID.plot_banco;
   out.push('orto centro libero='+ok(o.tx,o.ty-1));
   out.push('essic montanti='+ok(es.tx-1,es.ty)+'/'+ok(es.tx+1,es.ty)+' mezzo='+ok(es.tx,es.ty));
   out.push('banco '+ok(bn.fp[0],bn.fp[1])+'/'+ok(bn.fp[0]+1,bn.fp[1])+'/ lati '+ok(bn.fp[0]-1,bn.fp[1])+'/'+ok(bn.fp[0]+2,bn.fp[1]));
   const boxes=cd.map(e=>[e.x-74,e.y-114,e.x+74,e.y+10]);boxes.push([(bn.fp[0]+1)*44-76,(bn.fp[1]+1)*44-124,(bn.fp[0]+1)*44+76,(bn.fp[1]+1)*44+10]);
   const bad=[];for(const e of Pirati.E){if(!/^(tree|pine|palm|bush|berry|rock)$/.test(e.type))continue;const bb=Pirati.entBox(e);if(bb&&boxes.some(x=>bb[0]<x[2]&&bb[2]>x[0]&&bb[1]<x[3]&&bb[3]>x[1]))bad.push(e.type+'@'+e.tx+','+e.ty)}
   out.push('alberi sopra: '+(bad.join(' ')||'nessuno'));return out.join(' | ')});
  console.log(rr?'DOPO RICARICA:':'SUBITO:',r)}
 console.log('ERR',JSON.stringify(errs));await b.close()})();
