const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>Pirati.startNew('T','m'));
for(let i=0;i<8;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(300)}
let n=0;for(const [d,tod,wx] of [[3,21,'clear'],[3,21,'rain'],[6,21,'clear'],[8,21,'clear'],[10,21,'clear'],[12,21,'clear']]){
 await p.evaluate(([d,t,w])=>{Pirati.S.day=d;Pirati.S.tod=t;Pirati.S.wx={k:w,t:900}},[d,tod,wx]);await p.waitForTimeout(700);
 await p.screenshot({path:'moon'+(n++)+'.png',clip:{x:0,y:60,width:260,height:50}});}
await b.close()})();
