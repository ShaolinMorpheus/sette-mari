#!/usr/bin/env python3
# v0.12n (D4): eventi casuali in mare (codice in ch3_inject.js) -> qui solo il registro delle novità
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH26 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:100].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Incontri in mare: mentre navighi liberamente (dopo il tutorial e prima del convoglio) può capitare un incontro, sempre facoltativo e senza pericoli, al massimo tre per partita. Una balena amica: avvicinati piano e ti saluta con un salto, risputa un baule d'argento e ripara un po' lo scafo. Un naufrago su una zattera: raggiungilo con la nave e ti regala delle casse d'argento. Nelle partite di notte, anche una nave fantasma che non spara e lascia cadere casse d'argento mentre passa. Sulla minimappa e ai bordi dello schermo compare il segnalino. Attenzione: le balene non si colpiscono!",
''')
open(P,'w',encoding='utf8').write(src)
print('patch26 ok')
