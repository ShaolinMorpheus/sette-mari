const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html#w3');await p.waitForTimeout(8000);
const r=await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.ekills=3;C.p.x=3000;C.p.y=3000;let n=0;for(;n<1500&&!C.convoy;n++)Ch3.step(1/30);
 const a=[C.convoy,n];
 // near start edge case
 return a});
console.log(r,er);await b.close()})()
