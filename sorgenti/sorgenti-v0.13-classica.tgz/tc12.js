const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{Pirati.S.tod=20.2;Pirati.P.x=58.5*44-70;Pirati.P.y=32.2*44;Pirati.cam.x=58.5*44;Pirati.cam.y=30*44});await p.waitForTimeout(1500);await clr();await p.screenshot({path:'camp1.png'});
await p.evaluate(()=>{Pirati.S.tod=12;Pirati.P.x=58.5*44;Pirati.P.y=32*44;Pirati.cam.x=57*44;Pirati.cam.y=30*44});await p.waitForTimeout(1200);await p.screenshot({path:'camp2.png'});
console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(500);console.log(await p.evaluate(()=>Pirati.UI.dlgOpen()));await clr();
await p.evaluate(()=>{const e=Pirati.EID.c2t2;Pirati.P.x=e.x;Pirati.P.y=e.y+30});await p.waitForTimeout(400);console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(500);console.log(await p.evaluate(()=>[Pirati.UI.dlgOpen(),Pirati.Ch2.st().tentSeen]));
console.log(er);await b.close()})();
