#!/usr/bin/env python3
# v0.12t: collisione a sagoma per casse/barili/forzieri, vibrazione
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH31 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
rep("function boxFree(x,y,rx,ry){\n  if(window.__leafHit&&window.__leafHit(x,y))return false;","function boxFree(x,y,rx,ry){\n  if(window.__leafHit&&window.__leafHit(x,y))return false;\n  if(typeof OBR!=='undefined'&&OBR.length)for(const o of OBR){if(x+rx>o.x0&&x-rx<o.x1&&y+ry>o.y0&&y-ry<o.y1)return false}")
rep("+T('mFs','⛶','Schermo',FS_TXT())","+T('mVib',HAP.on?'📳':'📴','Vibrazione',HAP.on?'attiva':'spenta','tgl'+(HAP.on?' on':''))+T('mFs','⛶','Schermo',FS_TXT())")
rep("  c.querySelector('#mSnd').onclick=","  c.querySelector('#mVib').onclick=()=>{HAP.on=!HAP.on;try{localStorage.setItem('sm_vib',HAP.on?'1':'0')}catch(_){}setT('mVib',HAP.on?'📳':'📴',HAP.on?'attiva':'spenta');c.querySelector('#mVib').classList.toggle('on',!!HAP.on);if(HAP.on&&buzz([40,40,40])===false)UI.toast('Da qui il telefono non permette la vibrazione (la pagina nel browser o dentro un\\'app la blocca). Nell\\'app Android installata, aggiornata, funziona.',6500)};\n  c.querySelector('#mSnd').onclick=")
rep('''    "Niente erba sui sentieri''','''    "Collisione a sagoma per casse, forzieri e barili: non si attraversa più nemmeno la parte alta del disegno, e restano solidi anche una volta aperti.",
    "Vibrazione del telefono per indizi (Biscotto), missioni, tesori e eventi: si spegne dal menu «Vibrazione».",
    "Niente erba sui sentieri''')
open(P,'w',encoding='utf8').write(src)
print('patch31 ok')
