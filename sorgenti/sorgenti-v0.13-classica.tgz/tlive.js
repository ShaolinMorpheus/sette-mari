const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.built={falo:1,capanna:1,banco:1,zattera:1};for(const id of['falo','capanna','banco','zattera']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}S.res.legna=80;S.res.pietra=20;S.res.corda=20;S.res.rottami=9;S.flags.sailed=1;Pirati.farm.farmInit();Pirati.UI.openUpgrades()});
 await p.waitForTimeout(400);
 await p.evaluate(()=>{document.querySelector('[data-dc="orto"]').click();document.getElementById('shNo')&&document.getElementById('shNo').click()});
 await p.waitForTimeout(300);
 const r=await p.evaluate(async()=>{const S=Pirati.S;S.res.semi=5;S.gard.harv=0;Pirati.farm.gardPlant(0,'patata');Pirati.UI.openGarden();const g=()=>document.querySelector('[data-tm="0"]')&&document.querySelector('[data-tm="0"]').textContent;const a=g();await new Promise(r=>setTimeout(r,4200));return a+' -> '+g()});
 console.log(r,JSON.stringify(errs));await b.close()})();
