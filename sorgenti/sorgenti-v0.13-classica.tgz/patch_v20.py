#!/usr/bin/env python3
# v0.12h (B1): Cantiere navale al campo + Aspetto della nave nel Menu (il codice del mare è in ch3_inject.js)
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH20 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:100].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)

# ---------- alla nave del campo: salpare, cantiere o restare ----------
rep('''if(S.flags.ch2end){let go=false;UI.dlg([D('hero',"La nave ha già compiuto il suo viaggio. Ma il mare è ancora là fuori."),D('hero',"Vuoi riprendere il mare?",{choices:[{t:"Sì: Capitolo 3, la battaglia in mare.",fn:()=>{go=true}},{t:"No, resto qui.",fn:()=>{}}]})],()=>{if(go){try{saveGame()}catch(_){}__go('#w3');location.reload()}});return true}''',
'''if(S.flags.ch2end){let go=false,yd=false;UI.dlg([D('hero',"La nave ha già compiuto il suo viaggio. Ma il mare è ancora là fuori."),D('hero',"Cosa facciamo?",{choices:[{t:"Salpa: Capitolo 3, la battaglia in mare.",fn:()=>{go=true}},{t:"Cantiere: migliora la nave con l'argento.",fn:()=>{yd=true}},{t:"Niente, resto qui.",fn:()=>{}}]})],()=>{if(go){try{saveGame()}catch(_){}__go('#w3');location.reload()}else if(yd)YD.yardSheet()});return true}''')

# ---------- Menu › Guardaroba: Nave e Cantiere ----------
rep('''T('mWo',wI('out'),'Abito',wearName('out'))+'<p class="sm">Cappelli e abiti''',
    '''T('mWo',wI('out'),'Abito',wearName('out'))+(YD.avail()?T('mSh','⛵','Nave',YD.lookName())+T('mYd','⚓','Cantiere navale',YD.yardName()):'')+'<p class="sm">Cappelli e abiti''')
rep('''  {const a=c.querySelector('#mWo');if(a)a.onclick=()=>{uShow('menu',false);wardSheet('out')}}''',
    '''  {const a=c.querySelector('#mWo');if(a)a.onclick=()=>{uShow('menu',false);wardSheet('out')}}
  {const a=c.querySelector('#mSh');if(a)a.onclick=()=>{uShow('menu',false);YD.lookSheet()}}
  {const a=c.querySelector('#mYd');if(a)a.onclick=()=>{uShow('menu',false);YD.yardSheet()}}''')

# ---------- stile: le anteprime sono canvas ----------
rep('.phs img,.phs .no{','.phs img,.phs .no,.phs canvas{')

# ---------- esportazione per i test + codice nuovo ----------
rep("get NV3(){return typeof NV3!=='undefined'?NV3:null},","get NV3(){return typeof NV3!=='undefined'?NV3:null},get YD(){return typeof YD!=='undefined'?YD:null},")
NEW=open('/home/claude/work/new20.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")

# ---------- registro delle novità ----------
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Mare: le battute di Tito non finiscono più nascoste sotto la scheda del tutorial.",
    "Mare: frecce sul bordo dello schermo con la distanza (in caselle) per la nave bersaglio, il galeone, la nave dei prigionieri e la pattuglia più vicina.",
    "Mare: dopo la prima nave nemica affondata arriva una scorta armata, con più scafo e più cannoni delle pattuglie.",
    "Cantiere navale: alla nave del campo l'argento portato dal mare compra cuori di scafo, cannoni più rapidi e vele più veloci. Le migliorie restano per sempre.",
    "Aspetto della nave: vele, bandiera e polena si sbloccano giocando e si scelgono dal Menu › Guardaroba › Nave.",
    "Tolta la scritta «bozza giocabile» dalle schermate finali del mare e del grande viaggio.",
''')
open(P,'w',encoding='utf8').write(src)
print('patch20 ok')
