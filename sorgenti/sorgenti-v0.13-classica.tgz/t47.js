const {chromium}=require('playwright');(async()=>{const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(6000);
const r=await p.evaluate(async()=>{const o={};
 const C0=Ch3.C;C0.tut=null;
 // resume run
 localStorage.setItem('sm_c3cp',JSON.stringify({easy:false,plan:{time:'alba',abb:2,div:1,sal:1,detect:1},pris:2,silver:0}));
 Ch3.newRun(false,{time:'alba',abb:2,div:1,sal:1,detect:1},JSON.parse(localStorage.getItem('sm_c3cp')));
 const C=Ch3.C;C.tut=null;o.pris=C.pris;o.ally=C.ships.filter(s=>s.ally).length;
 for(let i=0;i<60;i++)Ch3.step(1/30);
 o.convoy=C.convoy;o.prisShips=C.ships.filter(s=>s.type==='prigionieri').length;o.gal=C.ships.filter(s=>s.type==='galeone').length;
 // repair
 C.p.hull=1;Ch3.step(.1);o.guns=C.p.gunsOut;
 // fail end card shows resume button
 Ch3.endRun('fuga');o.btn=!!document.getElementById('eCp');return o});
console.log(JSON.stringify(r),er);await b.close()})()
