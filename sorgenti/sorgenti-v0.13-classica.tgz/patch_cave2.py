import json
s=open('base_index.html',encoding='utf8').read()
def rep(a,b,cnt=1):
    global s
    assert s.count(a)==cnt,(s.count(a),a[:80])
    s=s.replace(a,b)
a=s.index("/* ====== LA GROTTA: mappa interna");b=s.index("/* ====== METEO, LUNA, TORCIA E LIVELLO DELLA POZZA ====== */")
s=s[:a]+open('cave_mod2.js',encoding='utf8').read()+"\n"+s[b:]
# gating nella look
a=s.index("  if(e.id==='cave'){caveEnter();return true}")
rep("  if(e.id==='cave'){caveEnter();return true}","  if(e.id==='cave'){caveTry();return true}")
rep("    if(!qAct('c8',2)){UI.dlg([D('hero',\"Un fagotto avvolto in un telo cerato, legato con cura. Non è roba mia, per ora.\"),D('hero',\"Prima devo capire di cosa si tratta. Magari Tito sa qualcosa.\")]);return true}","    if(!caveOpen()){UI.dlg([D('hero',\"Un fagotto avvolto in un telo cerato, legato con cura. Non è roba mia, per ora.\"),D('hero',\"Prima devo capire di cosa si tratta. Magari Tito sa qualcosa.\")]);return true}")
# migrazione una tantum
rep("  EID.plot_zattera.away=P.mode==='raft';placeMoored();\n","  EID.plot_zattera.away=P.mode==='raft';placeMoored();\n  try{if(WORLD===2){const c=C();if(c&&c.parts&&c.parts.rudder&&!c.cvSeen&&!c.cvMig&&!c.parts.yard){c.cvMig=1;c.parts.rudder=0}}}catch(e){}\n",1)
# eco del pappagallo
rep("g.connect(AU.gain);s.start();return}","g.connect(AU.gain);s.start();if(inCave()){for(const[dl,vl]of[[.3,.4],[.62,.2]]){const s2=c.createBufferSource(),g2=c.createGain();s2.buffer=B;s2.playbackRate.value=s.playbackRate.value*.97;g2.gain.value=.9*vl;s2.connect(g2);g2.connect(AU.gain);s2.start(c.currentTime+dl)}}return}")
rep("else if(n==='drip'){tone(1500,620,.11,'sine',.05);tone(2100,900,.08,'sine',.025,.09)}","else if(n==='drip'){tone(1500,620,.11,'sine',.075);tone(2100,900,.08,'sine',.03,.09);for(let k=1;k<=3;k++)tone(1450-k*90,620,.1,'sine',.075*Math.pow(.42,k),.24*k)}\n  else if(n==='bat'){tone(5200,3800,.06,'square',.018);tone(5600,3600,.07,'square',.016,.1);tone(5000,3400,.06,'square',.012,.22)}")
rep("Pirati_placeholder","",0) if False else None
rows=[
["Cra! Una grotta buia... forse è meglio prima informarsi al campo!","Squawk! A dark cave... maybe we should ask around at the camp first!","Kräh! Eine dunkle Höhle... vielleicht erkundigen wir uns erst im Lager!","¡Cra! Una cueva oscura... ¡quizá es mejor informarse primero en el campamento!","Croa ! Une grotte sombre... mieux vaut d'abord se renseigner au camp !"],
["Una grotta buia, muschio sulle pietre. Forse è meglio prima informarsi al campo.","A dark cave, moss on the stones. Maybe it's better to ask around at the camp first.","Eine dunkle Höhle, Moos auf den Steinen. Vielleicht erkundigt man sich besser zuerst im Lager.","Una cueva oscura, musgo en las piedras. Quizá es mejor informarse primero en el campamento.","Une grotte sombre, de la mousse sur les pierres. Mieux vaut d'abord se renseigner au camp."],
["Cra! Pipistrelli!","Squawk! Bats!","Kräh! Fledermäuse!","¡Cra! ¡Murciélagos!","Croa ! Des chauves-souris !"],
]
i=s.index('var PACK=');dec=json.JSONDecoder();arr,end=dec.raw_decode(s[i+len('var PACK='):])
arr+=rows
s=s[:i]+'var PACK='+json.dumps(arr,ensure_ascii=False)+s[i+len('var PACK=')+end:]
rep('    "La grotta ora si può esplorare:','    "Grotta più grande: tre sale, rami, pozze d\'acqua ben riconoscibili, gocce con eco, pipistrelli appesi alle pareti e il timone in fondo. Si entra solo quando la missione del timone è attiva: prima il pappagallo consiglia di informarsi al campo.",\n    "La grotta ora si può esplorare:')
open('base_index.html','w',encoding='utf8').write(s)
print('ok')
