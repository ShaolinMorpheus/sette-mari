const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
const r=await p.evaluate(()=>{const P=Pirati;let o=[];for(let y=24;y<=38;y++){let s='y'+y+': ';for(let x=18;x<34;x++){const t=P.tileInfo(x,y);s+=(t.e*100|0)+(t.walk?'w':t.block?'b':'')+' '}o.push(s)}return o});
console.log(r.join('\n'));await b.close()})();
