const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));p.on('console',m=>{if(m.type()==='error'&&!/Failed to load/.test(m.text()))errs.push(m.text())});
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1500);
const o=[];
for(let n=0;n<3;n++){
 const r=await p.evaluate((n)=>{const C=Ch4,K=C.K;
   if(K.deck!==n){const ob=K.objs.find(q=>q.id===(n>K.deck?'sd':'su'));ob.use()}
   for(let i=0;i<60;i++)C.step(1/30);
   const P=C.P;return {deck:K.deck,gd:K.gd.length,fol:K.fol.map(f=>Math.round(f.x)+','+Math.round(f.y)).join(' '),P:[Math.round(P.x),Math.round(P.y)],objs:K.objs.map(q=>q.id).join(),goal:null}},n);
 o.push(r);await p.waitForTimeout(400);await p.screenshot({path:'d'+n+'.png'})}
console.log(JSON.stringify(o),errs);await b.close()})()
