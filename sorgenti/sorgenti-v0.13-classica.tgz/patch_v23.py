#!/usr/bin/env python3
# v0.12k (D1): modalità foto ricordo (studio, cornici, album)
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH23 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:100].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
NEW=open('/home/claude/work/new23.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")
# la scheda "foto" è più larga: la classe va tolta quando la scheda serve ad altro
rep("const c=$('sheetCard');c.innerHTML=h;uShow('sheet',true);","const c=$('sheetCard');c.classList.remove('phc');c.innerHTML=h;uShow('sheet',true);")
# Menu > Guardaroba > Foto ricordo
rep("T('mYd','⚓','Cantiere navale',YD.yardName()):'')+'<p class=\"sm\">Cappelli e abiti","T('mYd','⚓','Cantiere navale',YD.yardName()):'')+T('mPhoto','📷','Foto ricordo',PHO.sub())+'<p class=\"sm\">Cappelli e abiti")
rep("{const a=c.querySelector('#mWo');if(a)a.onclick=()=>{uShow('menu',false);wardSheet('out')}}","{const a=c.querySelector('#mWo');if(a)a.onclick=()=>{uShow('menu',false);wardSheet('out')}}\n  {const a=c.querySelector('#mPhoto');if(a)a.onclick=()=>{uShow('menu',false);PHO.open()}}")
# suggerimento una tantum dopo aver cambiato look
rep("lookSave();sfx('ok');saveGame();closeSheet();","lookSave();sfx('ok');saveGame();closeSheet();if(!S.flags.phHint){S.flags.phHint=1;setTimeout(()=>UI.toast('Che stile! Puoi farti una foto ricordo da Menu › Guardaroba › Foto ricordo.',5200),600)}")
# esporta lo studio per i test
rep("window.Pirati={","window.Pirati={photo:PHO,")
# registro delle novità
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Foto ricordo (Menu › Guardaroba): una foto del capitano con il cappello e l'abito che indossi, il pappagallo e, nel campo, gli amici con abbastanza fiducia. Scegli lo sfondo (giorno, tramonto, notte, campo con il fuoco) e la cornice (legno, oro, corda, pergamena), scatta con il flash e salva nell'album del gioco (fino a 12 foto). Se il telefono lo permette, puoi anche condividerla. Due nuovi traguardi: «Fotografo» e «Album di viaggio».",
''')
open(P,'w',encoding='utf8').write(src)
print('patch23 ok')
