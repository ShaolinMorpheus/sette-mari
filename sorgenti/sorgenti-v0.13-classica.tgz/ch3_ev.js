/* ---------------- D4: eventi casuali in mare (balena, naufrago, nave fantasma di notte) ---------------- */
// Un solo evento alla volta, mai pericoloso e sempre facoltativo: il premio sono casse d'argento in acqua.
// Compaiono solo nella navigazione libera (dopo il tutorial, prima del convoglio) e al massimo tre per partita.
const EV_COL={whale:'#8fd0ff',ghost:'#9fe8d0',cast:'#ffb347'};
function evNew(){return{cd:rr(44,68),n:0,cur:null,last:'',done:[]}}
function evMk(k,x,y,hd,o){const E=Object.assign({ev:1,k,x,y,hd,t:0,seed:rr(0,9),ent:{type:'c3'},st:'idle',gt:0},o||{});E.ent.s=E;return E}
function evVis(){const E=C&&C.ev&&C.ev.cur;return E&&!E.gone?[E]:[]}
function evEnd(){const E0=C.ev;if(!E0)return;if(E0.cur)E0.done.push(E0.cur.k);E0.cur=null;E0.cd=rr(70,110)}
function evCrate(x,y){
  let cx=x,cy=y;
  if(!clearAt(cx,cy,40)){const r=findSea(cx,cy);cx=r[0];cy=r[1]}
  C.crates.push({x:cx,y:cy,t:rr(0,9),v:'silver',opt:true});
  for(let i=0;i<4;i++)C.fx.push({k:'flash',x:cx+rr(-18,18),y:cy+rr(-18,8),r:8,t:0,life:.5})
}
function evSpawn(k){
  const E0=C&&C.ev;if(!E0||!C.p)return false;
  const p=C.p,tx=Math.cos(p.hd),ty=Math.sin(p.hd);
  for(let i=0;i<140;i++){
    const a=p.hd+rr(-1.2,1.2),d=rr(1050,1550),x=p.x+Math.cos(a)*d,y=p.y+Math.sin(a)*d;
    if(x<450||y<450||x>WW-450||y>WH-450)continue;
    let E=null;
    if(k==='whale'){
      if(!clearAt(x,y,260))continue;
      E=evMk('whale',x,y,rr(0,TAU),{vis:0,cyc:rr(0,2),life:95,jp:0})
    }else if(k==='cast'){
      if(!clearAt(x,y,130))continue;
      E=evMk('cast',x,y,0,{vx:rr(-5,5),vy:rr(-5,5),life:120,rot:rr(-.2,.2)})
    }else{      // nave fantasma: attraversa il mare davanti a te lungo una rotta tutta libera
      if(!clearAt(x,y,100))continue;
      const hd=Math.atan2(p.y+ty*600-y,p.x+tx*600-x);let len=0;
      for(let s=0;s<=3200;s+=120){if(!clearAt(x+Math.cos(hd)*s,y+Math.sin(hd)*s,70))break;len=s}
      if(len<1700)continue;
      E=mkShip('fantasma',x,y,hd,{ev:1,k:'ghost',t:0,st:'idle',gt:0,gh:0,nm:'Nave fantasma',len,x0:x,y0:y,drop:rr(2,3.5),dropped:0,life:140})
    }
    E0.cur=E;
    const dir=dirName(E.x-p.x,E.y-p.y);
    if(k==='whale')toast('<b>Biscotto:</b> «Cra! Uno spruzzo '+dir+'! È una balena! Avvicinati piano: è amica.»',6500);
    else if(k==='cast')toast('<b>Biscotto:</b> «Cra! Qualcuno agita le braccia '+dir+'! Un naufrago! Corriamo a prenderlo!»',6500);
    else toast('<b>Tito:</b> «Brrr… una nave fantasma '+dir+'. Non spara, capitano: sembra che perda qualcosa.»',7000);
    C.lastPT=C.t;
    return true
  }
  return false
}
function evWhale(E,dt,d){
  const p=C.p;E.life-=dt;E.cyc=(E.cyc||0)+dt;
  const T0=14;let u=E.cyc%T0;
  if(E.st==='idle'&&d<900&&u>11.2){E.cyc=Math.floor(E.cyc/T0)*T0+1.5;u=1.5}      // se ti avvicini, resta a galla
  let v=u<1.5?u/1.5:u<11.5?1:u<13?1-(u-11.5)/1.5:0;
  if(E.st==='gift')v=1;
  else if(E.st==='leave')v=Math.max(0,(E.vis||0)-dt/1.7);
  E.vis=v;
  // nuota piano, restando in mare aperto
  if(E.st!=='gift'){
    E.hd+=Math.sin(E.t*.31+E.seed)*.1*dt;
    const sp=E.st==='leave'?70:42,nx=E.x+Math.cos(E.hd)*sp*dt,ny=E.y+Math.sin(E.hd)*sp*dt;
    if(clearAt(nx,ny,150)){E.x=nx;E.y=ny}else E.hd+=1.7*dt
  }
  // il respiro: spruzzo e verso
  const sc=Math.floor((E.t-.7)/4.4);
  if(sc!==E.sc){E.sc=sc;if(v>.85&&d<1100&&AU.ctx&&AU.on){noiseBurst(.55,1700,.06);tone(180,118,.8,'sine',.05)}}
  if(!E.called&&v>.9&&d<1300){E.called=1;if(AU.ctx&&AU.on){tone(150,92,1.2,'sine',.08);tone(228,138,1,'sine',.04,.25)}}
  // un colpo di cannone vicino la spaventa: se ne va senza regalo
  if(E.st==='idle'&&C.balls.some(b=>Math.hypot(b.x-E.x,b.y-E.y)<170)){E.st='leave';toast('<b>Tito:</b> «Ehi! Le balene non si colpiscono! Se n\'è andata offesa.»',5200)}
  // saluto e regalo
  if(E.st==='idle'&&d<330&&v>.55){
    E.st='gift';E.gt=0;E.jp=.01;E.hd=Math.atan2(E.y-p.y,E.x-p.x)+rr(-.5,.5);
    toast('<b>Biscotto:</b> «Cra! La balena salta! Aveva ingoiato un baule d\'argento e adesso lo risputa. Raccogli le casse!»',7000);C.lastPT=C.t;
    if(AU.ctx&&AU.on){tone(120,260,.9,'sine',.09);noiseBurst(.7,900,.1,.5)}
  }else if(E.st==='gift'){
    E.gt+=dt;E.jp=Math.min(2.2,E.gt);
    if(!E.gave&&E.gt>=1){
      E.gave=1;const bx=E.x+Math.cos(E.hd)*50,by=E.y+Math.sin(E.hd)*50;
      for(let i=0;i<2;i++){const a=rr(0,TAU);evCrate(bx+Math.cos(a)*rr(70,120),by+Math.sin(a)*rr(70,120))}
      for(let i=0;i<10;i++)C.fx.push({k:'splash',x:E.x+rr(-90,90),y:E.y+rr(-40,40),r:rr(8,16),t:0,life:.9});
      if(p.hull<p.max){p.hull=Math.min(p.max,p.hull+1);for(let i=0;i<3;i++)C.fx.push({k:'heal',x:p.x+rr(-60,60),y:p.y+rr(-30,20),vx:0,vy:-34,t:0,life:1.2})}
      sfx('quest');try{YD.stat('events')}catch(e){}
    }
    if(E.gt>=2.6)E.st='leave'
  }
  if(E.st==='leave'&&E.vis<=.02)E.gone=true;
  if(E.life<=0&&E.st==='idle')E.st='leave'
}
function evCast(E,dt,d){
  const p=C.p;E.life-=dt;
  if(E.st==='idle'){
    const nx=E.x+E.vx*dt,ny=E.y+E.vy*dt;if(clearAt(nx,ny,80)){E.x=nx;E.y=ny}else{E.vx=-E.vx;E.vy=-E.vy}
    if(d<125){
      E.st='saved';E.gt=0;sfx('pick');
      for(let i=0;i<2;i++){const a=rr(0,TAU);evCrate(E.x+Math.cos(a)*rr(60,110),E.y+Math.sin(a)*rr(40,80))}
      toast('<b>Naufrago:</b> «Grazie, capitano! Questo è tutto ciò che ho salvato: prendilo!»',6500);C.lastPT=C.t;
      try{YD.stat('events')}catch(e){}
      setTimeout(()=>{if(C&&!C.over&&C.ev)parEv('crate',1)},2800)
    }else if(E.life<=0)E.st='saved',E.gt=2.6
  }else{E.gt+=dt;if(E.gt>3.2)E.gone=true}
}
function evGhost(E,dt,d){
  const sp=84;E.life-=dt;
  E.x+=Math.cos(E.hd)*sp*dt;E.y+=Math.sin(E.hd)*sp*dt;E.v=sp;
  const trav=Math.hypot(E.x-E.x0,E.y-E.y0),fin=Math.min(1,E.t/3),fout=cl((E.len-trav)/320,0,1);
  E.gh=Math.min(fin,fout);
  if(!E.seen&&d<1250&&E.gh>.4){E.seen=1;toast('<b>Biscotto:</b> «Cra! Lascia cadere casse d\'argento! I fantasmi non sanno che farsene.»',6500);C.lastPT=C.t;if(AU.ctx&&AU.on){tone(330,240,1.1,'sine',.04);tone(332,246,1.1,'sine',.03,.04)}}
  if(d<1000&&E.dropped<3&&E.gh>.5){
    E.drop-=dt;
    if(E.drop<=0){
      E.drop=rr(4,6);E.dropped++;
      evCrate(E.x-Math.cos(E.hd)*80+rr(-30,30),E.y-Math.sin(E.hd)*80+rr(-30,30));
      if(AU.ctx&&AU.on)tone(660,880,.35,'sine',.05);
      if(E.dropped===1)try{YD.stat('events')}catch(e){}
    }
  }
  if(trav>=E.len-5||(E.gh<=.01&&E.t>8)||E.life<=0){
    if(!E.gone&&d<1700&&E.dropped>0)toast('<b>Tito:</b> «Sparita. Come se non fosse mai esistita…»',4500);
    E.gone=true
  }
}
function evStep(dt){
  const E0=C.ev;if(!E0||C.over||C.go5||C.convoy||!C.p)return;
  const p=C.p;let E=E0.cur;
  if(!E){
    if(E0.n>=3)return;
    E0.cd-=dt;if(E0.cd>0||C.t<40||dl.open||PAUSED)return;
    if(C.t-(C.lastPT||-99)<9)return;      // mai sopra un altro avviso
    if(C.ships.some(s=>!s.dead&&!s.ally&&(s.type==='pattuglia'||s.type==='scorta'||s.type==='galeone')&&Math.hypot(s.x-p.x,s.y-p.y)<1700)){E0.cd=6;return}
    const pt=TPp(21,30);if(Math.hypot(p.x-pt[0],p.y-pt[1])<1300)return;
    const ks=['whale','cast'];if(C.plan&&C.plan.time==='notte')ks.push('ghost','ghost');
    const pool=ks.filter(k=>k!==E0.last),k=pool[(Math.random()*pool.length)|0];
    if(evSpawn(k)){E0.last=k;E0.n++}else E0.cd=8;
    return
  }
  E.t+=dt;const d=Math.hypot(E.x-p.x,E.y-p.y);
  if(E.k==='whale')evWhale(E,dt,d);else if(E.k==='cast')evCast(E,dt,d);else evGhost(E,dt,d);
  if(E.gone||(d>4300&&E.t>25))evEnd()
}
/* ---- disegno ---- */
function whaleDraw(g,s,t){
  const v=s.vis||0;if(v<=.02)return;
  const L=250,W=76,sw=Math.sin(t*1.7+s.seed)*.22,jp=s.jp>0?Math.sin(Math.min(1,s.jp/2.2)*Math.PI):0;
  const c=Math.cos(s.hd),sn=Math.sin(s.hd);
  g.save();g.translate(s.x,s.y+10);
  g.save();g.rotate(s.hd);g.globalAlpha=.22*v;g.fillStyle='#03223d';g.beginPath();g.ellipse(-L*.02,6,L*.5,W*.62,0,0,7);g.fill();g.restore();
  for(let k=0;k<2;k++){const u=(t*.35+k*.5+s.seed)%1;g.strokeStyle='rgba(235,248,255,'+(.4*(1-u)*v*(1+jp))+')';g.lineWidth=3;g.beginPath();g.ellipse(0,2,L*(.34+.3*u),W*(.5+.4*u),s.hd,0,7);g.stroke()}
  g.translate(0,-jp*70);g.rotate(s.hd);g.scale(1+jp*.16,1+jp*.16);g.globalAlpha=v;
  // coda con le pinne
  g.save();g.translate(-L*.4,0);g.rotate(sw);g.fillStyle='#27456e';g.strokeStyle='#10243f';g.lineWidth=2.4;
  g.beginPath();g.moveTo(10,0);g.quadraticCurveTo(-8,-8,-26,-40);g.quadraticCurveTo(-30,-18,-22,-4);g.quadraticCurveTo(-24,0,-22,4);g.quadraticCurveTo(-30,18,-26,40);g.quadraticCurveTo(-8,8,10,0);g.closePath();g.fill();g.stroke();g.restore();
  // corpo
  const bg=g.createLinearGradient(0,-W*.6,0,W*.6);bg.addColorStop(0,'#4d7fb2');bg.addColorStop(.5,'#34608f');bg.addColorStop(1,'#223f68');
  g.fillStyle=bg;g.strokeStyle='#10243f';g.lineWidth=3;
  g.beginPath();g.moveTo(L*.5,0);
  g.bezierCurveTo(L*.46,-W*.5,L*.16,-W*.6,-L*.1,-W*.36);
  g.bezierCurveTo(-L*.24,-W*.22,-L*.34,-W*.09,-L*.42,0);
  g.bezierCurveTo(-L*.34,W*.09,-L*.24,W*.22,-L*.1,W*.36);
  g.bezierCurveTo(L*.16,W*.6,L*.46,W*.5,L*.5,0);
  g.closePath();g.fill();g.stroke();
  // riflesso sul dorso e macchie chiare
  g.fillStyle='rgba(190,225,250,.34)';g.beginPath();g.ellipse(L*.08,-W*.2,L*.3,W*.12,-.04,0,7);g.fill();
  g.fillStyle='rgba(225,240,252,.55)';for(const[px,py,r]of[[L*.3,W*.3,5],[L*.2,W*.36,4],[-L*.02,W*.33,5],[L*.36,-W*.32,3.5]]){g.beginPath();g.arc(px,py,r,0,7);g.fill()}
  // pinne pettorali
  g.fillStyle='#27456e';g.strokeStyle='#10243f';g.lineWidth=2.4;
  for(const sd of[-1,1]){g.save();g.translate(L*.2,sd*W*.5);g.rotate(sd*(.9+Math.sin(t*1.7+s.seed+sd)*.12));g.beginPath();g.ellipse(0,0,34,10,0,0,7);g.fill();g.stroke();g.restore()}
  // occhi e sfiatatoio
  g.fillStyle='#0c1a2c';g.beginPath();g.arc(L*.34,-W*.3,4.2,0,7);g.fill();g.beginPath();g.arc(L*.34,W*.3,4.2,0,7);g.fill();
  g.fillStyle='#fff';g.beginPath();g.arc(L*.345,-W*.31,1.5,0,7);g.fill();g.beginPath();g.arc(L*.345,W*.29,1.5,0,7);g.fill();
  g.fillStyle='#10243f';g.beginPath();g.ellipse(L*.2,0,7,3,0,0,7);g.fill();
  g.restore();
  // spruzzo: un ventaglio d'acqua che sale in verticale
  const sp=(s.t-.7)%4.4;
  if(v>.85&&sp>=0&&sp<1.5&&s.st!=='leave'){
    const u=sp/1.5,bx=s.x+c*L*.2,by=s.y+10+sn*L*.2*.9-jp*70,al=1-Math.max(0,u-.45)/.55,rise=Math.min(1,u*2.2);
    g.save();g.lineCap='round';
    for(let i=-3;i<=3;i++){
      const hmax=(52+22*(3-Math.abs(i)))*(.4+.6*rise);
      g.strokeStyle='rgba(240,250,255,'+(.82*al)+')';g.lineWidth=4.6-Math.abs(i)*.4;
      g.beginPath();
      for(let k=0;k<=10;k++){const q=k/10*Math.min(1,.25+rise),xx=bx+i*20*q*(.5+u),yy=by-hmax*(1-Math.pow(2*q-1,2));if(k)g.lineTo(xx,yy);else g.moveTo(xx,yy)}
      g.stroke()
    }
    g.fillStyle='rgba(245,252,255,'+(.4*al)+')';
    for(let j=0;j<5;j++){g.beginPath();g.arc(bx+(j-2)*15,by-96*rise+Math.sin(j*2+s.t)*5,11+(j%2)*5,0,7);g.fill()}
    g.restore()
  }
  g.restore()
}
function castDraw(g,s,t){
  const sv=s.st==='saved',a=sv?cl(1-(s.gt||0)/3,0,1):1;if(a<=.02)return;
  const bob=Math.sin(t*1.9+s.seed)*2.2,wv=Math.sin(t*7+s.seed);
  g.save();g.globalAlpha=a;g.translate(s.x,s.y+6+bob);
  g.fillStyle='rgba(4,24,44,.25)';g.beginPath();g.ellipse(4,16,46,16,0,0,7);g.fill();
  const u=(t*.5+s.seed)%1;g.strokeStyle='rgba(255,255,255,'+(.5*(1-u))+')';g.lineWidth=2;g.beginPath();g.ellipse(0,14,40+u*26,13+u*8,0,0,7);g.stroke();
  g.save();g.rotate(s.rot||0);
  for(let i=0;i<5;i++){g.fillStyle=i%2?'#a9763e':'#b98a55';g.strokeStyle='#3a200c';g.lineWidth=2;g.fillRect(-32+i*13,-17,12,36);g.strokeRect(-32+i*13,-17,12,36)}
  g.strokeStyle='#e8d9a8';g.lineWidth=3;g.beginPath();g.moveTo(-34,-8);g.lineTo(34,-8);g.moveTo(-34,10);g.lineTo(34,10);g.stroke();
  g.restore();
  // albero con lo straccio bianco
  g.fillStyle='#5a3a1c';g.fillRect(18,-66,4,54);
  const fw=Math.sin(t*5+s.seed)*5;g.fillStyle='#ece4d0';g.strokeStyle='#8a7a5a';g.lineWidth=1.4;
  g.beginPath();g.moveTo(22,-64);g.quadraticCurveTo(36,-64+fw,46,-58+fw*.6);g.lineTo(40,-52);g.quadraticCurveTo(32,-54-fw*.4,22,-48);g.closePath();g.fill();g.stroke();
  // il naufrago: seduto, agita le braccia
  g.lineCap='round';g.strokeStyle='#e8b88a';g.lineWidth=5;
  g.beginPath();g.moveTo(-15,-24);g.lineTo(-25,-44+wv*7);g.moveTo(3,-24);g.lineTo(13,-46-wv*7);g.stroke();
  g.fillStyle='#c4553a';g.strokeStyle='#3a1a10';g.lineWidth=2;g.beginPath();g.ellipse(-6,-14,11,15,0,0,7);g.fill();g.stroke();
  g.strokeStyle='rgba(255,246,226,.85)';g.lineWidth=2.4;for(const yy of[-20,-13,-6]){g.beginPath();g.moveTo(-14,yy);g.lineTo(2,yy);g.stroke()}
  g.fillStyle='#e8b88a';g.strokeStyle='#3a1a10';g.lineWidth=2;g.beginPath();g.arc(-6,-36,9,0,7);g.fill();g.stroke();
  g.fillStyle='#d8b050';g.beginPath();g.ellipse(-6,-42,16,4.6,0,0,7);g.fill();g.stroke();g.beginPath();g.arc(-6,-43,8,Math.PI,0);g.fill();g.stroke();
  g.fillStyle='#2a1a10';g.beginPath();g.arc(-9.5,-36,1.4,0,7);g.fill();g.beginPath();g.arc(-2.5,-36,1.4,0,7);g.fill();
  g.beginPath();g.ellipse(-6,-31,2.6,2.2+Math.abs(wv)*1.4,0,0,7);g.fill();
  if(!sv){
    const by=-86-Math.abs(Math.sin(t*4))*6;g.fillStyle='#ffd23a';g.strokeStyle='#3a2410';g.lineWidth=3;g.beginPath();g.arc(-6,by,12,0,7);g.fill();g.stroke();
    g.fillStyle='#3a2410';g.font='900 18px Nunito,Arial';g.textAlign='center';g.fillText('!',-6,by+6.5);
    if(Math.hypot(C.p.x-s.x,C.p.y-s.y)<900){g.font='800 14px Nunito,Arial';g.lineWidth=4;g.strokeStyle='rgba(10,22,34,.85)';g.fillStyle='#ffd9a0';g.strokeText('Naufrago',0,46);g.fillText('Naufrago',0,46)}
  }
  g.restore()
}
function evDrawShip(g,s,t){
  if(!inV(s.x,s.y,460))return;
  if(s.k==='whale')whaleDraw(g,s,t);else if(s.k==='cast')castDraw(g,s,t)
}
function evMini(c,p,sc){
  const E=C.ev&&C.ev.cur;if(!E||E.gone||E.st!=='idle'||(E.k==='ghost'&&(E.gh||0)<.2))return;
  let dx=(E.x-p.x)*sc,dy=(E.y-p.y)*sc;const dd=Math.hypot(dx,dy),far=dd>98,pl=.5+.5*Math.sin(C.t*5);if(far){dx=dx/dd*98;dy=dy/dd*98}
  c.save();c.translate(dx,dy);c.fillStyle=EV_COL[E.k];c.strokeStyle='#0a1622';c.lineWidth=2;c.beginPath();c.arc(0,0,(far?5:6.5)+pl*1.5,0,7);c.fill();c.stroke();c.restore()
}
function evOverlay(g,w,h){
  const E=C.ev&&C.ev.cur;if(!E||E.gone||E.st!=='idle'||C.over||C.tut||C.go5)return;
  if(E.k==='ghost'&&(E.gh||0)<.15)return;
  const[x,y]=toScreen(E.x,E.y);
  if(x>26&&x<w-26&&y>40&&y<h-26)return;
  edgeArrow(g,w,h,x,y,EV_COL[E.k],Math.hypot(E.x-C.p.x,E.y-C.p.y))
}
function evHint(){
  const E=C.ev&&C.ev.cur,p=C.p;if(!E||E.gone||E.st!=='idle'||Math.hypot(E.x-p.x,E.y-p.y)>2600)return null;
  const dr=dirName(E.x-p.x,E.y-p.y);
  return E.k==='whale'?'Una balena '+dr+'! Avvicinati piano: è amica e porta fortuna.':E.k==='cast'?'Un naufrago '+dr+'! Raggiungilo con la nave.':'La nave fantasma passa '+dr+'. Non spara: guarda se lascia cadere qualcosa.'
}

