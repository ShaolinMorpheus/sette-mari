const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>{Pirati.startNew('T','m')});
for(let i=0;i<12;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(500)}
await p.evaluate(async()=>{for(let i=0;i<80&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,50))}});
const spot=await p.evaluate(async()=>{Pirati.S.flags.lenza=1;const f=Pirati.FIX;
 for(let dy=-14;dy<=14;dy++)for(let dx=-14;dx<=14;dx++){const x=Math.floor(f.spawn[0])+dx,y=Math.floor(f.spawn[1])+dy;const ti=Pirati.tileInfo(x,y);if(!ti.free||ti.sea)continue;Pirati.tp(x+.5,y+.5);await new Promise(r=>setTimeout(r,40));const t=Pirati.tinfo();if(t&&t.l==='Pesca')return[x,y]}return null});
console.log('spot',spot);
await p.evaluate(async()=>{for(let i=0;i<100&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,60))}await new Promise(r=>setTimeout(r,600));for(let i=0;i<100&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,60))}Pirati.tp(12.5,41.5);await new Promise(r=>setTimeout(r,300))});
const r=await p.evaluate(async()=>{
 const res=[];Pirati.act();
 for(let i=0;i<200&&!(Pirati.P.act&&Pirati.P.act.kind==='reel');i++){await new Promise(r=>setTimeout(r,100))}
 const a=Pirati.P.act;res.push(a&&a.kind);
 if(a){window.__z=a.zone;await new Promise(r=>setTimeout(r,600));}
 return res});
console.log(r);await p.screenshot({path:'reel.png'});
const r2=await p.evaluate(async()=>{const a=Pirati.P.act;const c=(a.zone[0]+a.zone[1])/2;a.sp=0;a.ph=c;const b=Pirati.S.res.pesce;Pirati.act();await new Promise(r=>setTimeout(r,200));return[b,Pirati.S.res.pesce,!!Pirati.P.act]});
console.log('after hit',r2);
// cucina
const r3=await p.evaluate(async()=>{const S=Pirati.S;S.res.pesce=3;S.res.legna=5;S.res.coco=3;S.res.molluschi=4;S.res.bacche=3;S.res.arrosto=2;S.vit.h=30;
 const falo=Pirati.EID.plot_falo;falo.st=2;Pirati.UI.openCook(falo);await new Promise(r=>setTimeout(r,200));
 const btn=document.querySelector('[data-rc="zuppa"]');btn.click();await new Promise(r=>setTimeout(r,200));
 return [S.vit.h,S.buff,JSON.stringify(S.rec)]});
console.log('cook',r3);await p.screenshot({path:'cook.png'});
await b.close()})();
