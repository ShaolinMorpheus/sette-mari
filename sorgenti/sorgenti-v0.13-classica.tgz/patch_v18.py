#!/usr/bin/env python3
# v0.12f: la Baia prende vita (dettagli vivi, richieste con scena, amicizie, abiti di Nives, campo che cresce, oggetti di J.)
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH18 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
# disegno degli oggetti nuovi del campo (sprite 'nv_*')
rep("function drawDeco(g,e,t){\n  if(e.hidden)return;\n","function drawDeco(g,e,t){\n  if(e.hidden)return;\n  if(typeof NVDX!=='undefined'&&NVDX[e.spr]){NVDX[e.spr](g,e,t);return}\n")
# ordinamento personalizzato (e.sy)
rep("function sortY(e){\n  if(e.type==='plot')return(e.fp[1]+e.fp[3])*TS;\n","function sortY(e){\n  if(e.sy!=null)return e.sy;\n  if(e.type==='plot')return(e.fp[1]+e.fp[3])*TS;\n")
# luci notturne delle lanterne del campo
rep("lights.push([e.x,e.y-38,150,.75,true]);\n","lights.push([e.x,e.y-38,150,.75,true]);\n    for(const e of E)if(e.type==='deco'&&e.spr==='nv_lant')lights.push([e.x+15,e.y-68,150,.8,true]);\n")
# conversazioni: le scene personali stanno in un gruppo a parte
rep("const qs=hs.filter(h=>!h.x&&!h.offer).map(h=>({t:h.label(),h}));","const qs=hs.filter(h=>!h.x&&!h.offer&&!h.g).map(h=>({t:h.label(),h}));")
rep("const oth=hs.filter(h=>h.x||h.offer).map(h=>({t:h.label(),h}));","const oth=hs.filter(h=>(h.x||h.offer)&&!h.g).map(h=>({t:h.label(),h}));\n  const amc=hs.filter(h=>h.g).map(h=>({t:h.label(),h}));")
rep('  grp(qs,"Missioni…","Di cosa si tratta?");\n','  grp(qs,"Missioni…","Di cosa si tratta?");\n  grp(amc,"Una parola in privato…","Di cosa vuoi parlare?");\n')
# bug storico: act='chat' e' una stringa e 'chat'.sub e' String.prototype.sub (funzione) -> "Chiacchierare" lanciava TypeError e non faceva nulla
rep("if(act&&act.sub){const L=act.sub,Q=act.q;","if(act&&typeof act==='object'&&Array.isArray(act.sub)){const L=act.sub,Q=act.q;")
# cucina di Gnocco: ricette che si sbloccano con l'amicizia
rep("for(const r of Ch2.GN){const ok=hasRes(r.cost);","for(const r of Ch2.GN){if(r.gate&&!r.gate())continue;const ok=hasRes(r.cost);")
rep("get NV(){return typeof NV!=='undefined'?NV:null},","get NV(){return typeof NV!=='undefined'?NV:null},get NV2(){return typeof NV2!=='undefined'?NV2:null},")
NEW=open('/home/claude/work/new18.js',encoding='utf8').read()
rep("/* ---- 12d_kb.js ---- */",NEW+"\n/* ---- 12d_kb.js ---- */")
# registro delle novità
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Corretto: «Chiacchierare un po'» con i personaggi del campo non faceva nulla. Ora funziona e fa crescere la fiducia, una volta al giorno per ciascuno.",
    "La Baia prende vita: bucato che ondeggia, pentola che fuma, Nives che martella sull'incudine e scintille del fuoco la sera.",
    "Richieste del giorno con una scena: il personaggio controlla, assaggia e commenta. Il cibo secco, ben fatto, dà più fiducia. Nuove richieste: pesce secco per Nives, zucca per Gnocco. Per i rifornimenti, pesce secco e frutta secca valgono come arrosto e noci.",
    "Scene di amicizia a 2 e 4 cuori con Ferro, Nives, Gnocco e Tito, ognuna con un premio: cappelli, abiti, una ricetta, l'insegna del banco, la barchetta di Tito.",
    "Nives a 3 cuori, con la tela, ti cuce un abito e un cappello per il guardaroba.",
    "Il campo cresce con la fiducia media: bandierine, lanterne e una tavolata lunga. Ogni pagina del diario di J. porta un oggetto sul suo tavolino e una nuova battuta di Ferro.",
''')
open(P,'w',encoding='utf8').write(src)
print('patch18 ok')
