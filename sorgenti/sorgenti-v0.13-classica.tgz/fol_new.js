/* seguaci: ti stanno intorno, non scappano mai */
const SLOTS=[[-1.0,.9],[1.0,.9],[-1.9,1.7],[1.9,1.7],[0,2.5],[-1.2,-1.0],[1.2,-1.0]];
function stepFollowers(dt){
  const tr=K.tr,last=tr[tr.length-1];
  if(Math.hypot(P.x-last.x,P.y-last.y)>9){tr.push({x:P.x,y:P.y});if(tr.length>260)tr.shift()}
  K.fol.forEach((f,i)=>{
    if(f.busy||f.hp<=0)return;
    const dP=Math.hypot(P.x-f.x,P.y-f.y),stopR=92+i*22,goR=stopR+64;
    if(dP>goR)f.mvMode=true;else if(dP<=stopR)f.mvMode=false;
    if(f.mvMode){
      K.needField=true;
      const n=nextStep(f);let tx=P.x,ty=P.y;if(n&&dP>120){tx=n[0];ty=n[1]}
      const sl=SLOTS[i%SLOTS.length];if(dP<=190){tx=P.x-(K.fdx||0)*0+sl[0]*T*.9;ty=P.y+sl[1]*T*.9}
      const dx=tx-f.x,dy=ty-f.y,d=Math.hypot(dx,dy),sp=150+Math.min(110,Math.max(0,dP-goR)*.35);
      if(d>4){const m=Math.min(sp*dt,d),ok=moveEnt(f,dx/d*m,dy/d*m);f.mv=ok;f.wk+=dt*sp*.05;if(Math.abs(dx)>3)f.flip=dx<0;f.dir=dy<-Math.abs(dx)*1.2?'b':'f'}else f.mv=false;
      f.idleT=0;return}
    /* fermo vicino a te: ti guarda e ogni tanto si sistema */
    f.mv=false;const lx=P.x-f.x;if(Math.abs(lx)>6)f.flip=lx<0;f.dir=P.y<f.y-Math.abs(lx)*1.2?'b':'f';
    f.idleT=(f.idleT||0)-dt;
    if(f.idleT<=0){f.idleT=rr(3,6);f.fx=rr(-14,14);f.fy=rr(-8,8);f.fl=Math.hypot(f.fx,f.fy)/38}
    if(f.fl>0){f.fl-=dt;const wd=Math.hypot(f.fx,f.fy)||1;f.mv=moveEnt(f,f.fx/wd*38*dt,f.fy/wd*38*dt);f.wk+=dt*3;if(!f.mv)f.fl=0}
  });
  /* chi è di guardia al suo posto: non si allontana, non scappa */
  for(const f of(K.stay||[])){
    if(f.dk!==K.deck||f.busy||f.hp<=0)continue;
    if(f.px==null){f.px=f.x;f.py=f.y;f.idleT=rr(1,4)}
    const dp=Math.hypot(f.px-f.x,f.py-f.y);
    if(dp>60){const dx=f.px-f.x,dy=f.py-f.y,d=Math.hypot(dx,dy);f.mv=moveEnt(f,dx/d*100*dt,dy/d*100*dt);f.wk+=dt*5;if(Math.abs(dx)>3)f.flip=dx<0;continue}
    f.mv=false;const lx=P.x-f.x;if(Math.hypot(P.x-f.x,P.y-f.y)<240&&Math.abs(lx)>6)f.flip=lx<0;
    f.idleT-=dt;if(f.idleT<=0){f.idleT=rr(3,6);f.fx=f.px+rr(-20,20);f.fy=f.py+rr(-10,10);f.fl=1}
    if(f.fl>0){const dx=f.fx-f.x,dy=f.fy-f.y,d=Math.hypot(dx,dy);if(d<4)f.fl=0;else{f.mv=moveEnt(f,dx/d*36*dt,dy/d*36*dt);f.wk+=dt*3;if(!f.mv)f.fl=0}}
  }}
