const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<60&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(300)}};
await clr();
console.log(await p.evaluate(()=>{const G=Pirati.cave.G,W=G[0].length,H=G.length;const seen=new Set(['16,10']),q=[[16,10]];let n=0;while(q.length){const[x,y]=q.pop();n++;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const a=x+dx,b=y+dy;if(a<0||b<0||a>=W||b>=H||G[b][a]!==1||seen.has(a+','+b))continue;seen.add(a+','+b);q.push([a,b])}}let tot=0;G.forEach(r=>r.forEach(v=>{if(v===1)tot++}));const rd=Pirati.EID.cvrudder;return {reach:n,tot,rudderTile:[Math.floor(rd.x/44)-12,Math.floor(rd.y/44)-1,G[Math.floor(rd.y/44)-1][Math.floor(rd.x/44)-12]],rows:G.map(r=>r.map(v=>'#.~'[v]).join('')).join('\n')}}));
// gate: quest not active
await p.evaluate(()=>{Pirati.S.tod=12;Pirati.S.up.torch=1;const e=Pirati.EID.cave;Pirati.P.x=e.x;Pirati.P.y=e.y+70;Pirati.cam.x=Pirati.P.x;Pirati.cam.y=Pirati.P.y});await p.waitForTimeout(400);
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(600);
console.log('gate closed:',await p.evaluate(()=>[Pirati.cave.inside(),Pirati.UI.dlgOpen()]));await p.screenshot({path:'cv_gate.png'});
// open: quest active
await p.evaluate(()=>{Pirati.Ch2.addTrust('tito',3);Pirati.Ch2.st().said.rudder=1;Pirati.S.q.c8={st:'active',gi:2}});await clr();
await p.evaluate(()=>Pirati.act());await p.waitForTimeout(1500);
console.log('open:',await p.evaluate(()=>Pirati.cave.inside()));
await p.evaluate(()=>Pirati.toggleTorch());
const X0=12*44,Y0=44;
for(const [n,tx,ty] of [['a',16,9.4],['w',6,3.6],['n',16,4.6],['e',27,3.8],['se',28,9.6]]){
 await p.evaluate(([x,y])=>{Pirati.P.x=x;Pirati.P.y=y;Pirati.cam.x=x;Pirati.cam.y=y},[X0+tx*44,Y0+ty*44]);await p.waitForTimeout(1200);await p.screenshot({path:'cv2_'+n+'.png'});}
console.log('bats',await p.evaluate(()=>0));
console.log(er);await b.close()})();
