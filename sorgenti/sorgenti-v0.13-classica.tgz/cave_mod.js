/* ====== LA GROTTA: mappa interna (solo isola grande) ====== */
var CVX=null;
const CV_W=24,CV_H=11,CV_X0=12,CV_Y0=1;
function inCave(){return WORLD===2&&P.x>=CV_X0*TS&&P.x<(CV_X0+CV_W)*TS&&P.y>=CV_Y0*TS&&P.y<(CV_Y0+CV_H)*TS}
function caveGrid(){
  const G=[];for(let y=0;y<CV_H;y++)G.push(new Array(CV_W).fill(0));
  const ell=(cx,cy,rx,ry,v)=>{for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){const dx=(x+.5-cx)/rx,dy=(y+.5-cy)/ry;if(dx*dx+dy*dy<=1)G[y][x]=v}};
  const cor=(x0,y0,x1,y1,w)=>{const n=Math.ceil(Math.hypot(x1-x0,y1-y0)*3);for(let i=0;i<=n;i++){const t=i/n;ell(x0+(x1-x0)*t,y0+(y1-y0)*t,w,w,1)}};
  cor(12,10.6,12,8,1.7);ell(12,7.3,6.3,2.1,1);
  cor(7.5,7,6.8,4.6,1.25);ell(6.5,3.1,4.3,1.9,1);
  cor(17,7,19.6,5,1.25);cor(19.6,5,19.6,3.5,1.25);ell(20,2.7,3.3,1.7,1);
  ell(9.7,7.3,.62,.62,0);ell(14.5,6.9,.62,.62,0);
  ell(5.6,3.3,1.5,.8,2);                         // pozza
  for(let x=0;x<CV_W;x++)G[0][x]=0;for(let y=0;y<CV_H;y++){G[y][0]=0;G[y][CV_W-1]=0}
  return G;
}
function caveBuild(){
  const G=caveGrid();CVX={G,cr:[],st:[],fl:0,hint:0,light:[],canvas:null};
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){const i=tIdx(CV_X0+x,CV_Y0+y);walkT[i]=G[y][x]===1?1:0}
  const r=mulberry(4242);
  // cristalli e stalagmiti lungo le pareti
  const wallN=(x,y)=>G[y-1]&&G[y-1][x]===0;
  for(let y=1;y<CV_H;y++)for(let x=1;x<CV_W-1;x++){
    if(G[y][x]!==1)continue;
    if(wallN(x,y)&&r()<.28)CVX.st.push({x:(CV_X0+x+.2+r()*.6)*TS,y:(CV_Y0+y+.35+r()*.2)*TS,s:.7+r()*.7,k:r()<.3?1:0});
  }
  [[3.2,5],[8,2.4],[16.5,7.6],[20.5,5.2],[22,2.2],[11.6,9.4]].forEach(p=>{const x=Math.floor(p[0]),y=Math.floor(p[1]);if(G[y]&&G[y][x]===1)CVX.cr.push({x:(CV_X0+p[0])*TS,y:(CV_Y0+p[1])*TS,h:r()})});
  CVX.cr.push({x:(CV_X0+18.3)*TS,y:(CV_Y0+2.2)*TS,h:.2});
  ent({id:'cavex',type:'deco',spr:'cavex',x:(CV_X0+12)*TS,y:(CV_Y0+10.1)*TS,inter:'look',hitw:170,hith:80,label:'Uscita'});
  ent({id:'cvrudder',type:'deco',spr:'cvrudder',x:(CV_X0+20.6)*TS,y:(CV_Y0+2.95)*TS,inter:'look',hitw:110,hith:70,label:'Fagotto'});
}
function caveBake(){
  const G=CVX.G,W=CV_W*TS,H=CV_H*TS,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d'),r=mulberry(99);
  g.fillStyle='#0b0a0c';g.fillRect(0,0,W,H);
  // roccia delle pareti
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){
    if(G[y][x]!==0)continue;
    const px=x*TS,py=y*TS,sh=34+((r()*16)|0);g.fillStyle=`rgb(${sh},${sh-3},${sh-6})`;
    g.beginPath();g.roundRect(px-1,py-1,TS+2,TS+2,10);g.fill();
    for(let i=0;i<5;i++){const s=26+((r()*30)|0);g.fillStyle=`rgb(${s},${s-3},${s-5})`;g.beginPath();g.ellipse(px+r()*TS,py+r()*TS,5+r()*9,3+r()*6,r()*3,0,7);g.fill()}
  }
  // pavimento
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){
    const v=G[y][x];if(v===0)continue;const px=x*TS,py=y*TS;
    if(v===2){g.fillStyle='#1c3340';g.fillRect(px-2,py-2,TS+4,TS+4);continue}
    const b=62+((r()*12)|0);g.fillStyle=`rgb(${b},${b-4},${b-10})`;g.beginPath();g.roundRect(px-2,py-2,TS+4,TS+4,12);g.fill();
  }
  // venature, sassi, muschio
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){
    if(G[y][x]!==1)continue;const px=x*TS,py=y*TS;
    for(let i=0;i<6;i++){const s=54+((r()*30)|0);g.fillStyle=`rgba(${s},${s-4},${s-10},.7)`;g.beginPath();g.ellipse(px+r()*TS,py+r()*TS,3+r()*7,2+r()*4,r()*3,0,7);g.fill()}
    if(r()<.35){g.fillStyle='rgba(30,28,26,.5)';g.beginPath();g.ellipse(px+r()*TS,py+r()*TS,2+r()*3,1.5+r()*2,0,0,7);g.fill()}
    const near=[[1,0],[-1,0],[0,1],[0,-1]].some(d=>{const a=G[y+d[1]];return a&&(a[x+d[0]]===0||a[x+d[0]]===2)});
    if(near&&r()<.7){g.fillStyle=`rgba(${70+((r()*30)|0)},${110+((r()*40)|0)},60,.55)`;for(let i=0;i<3;i++){g.beginPath();g.ellipse(px+r()*TS,py+r()*TS,5+r()*7,3+r()*4,r()*3,0,7);g.fill()}}
  }
  // facciata delle pareti (il lato che guarda a sud) e ombra sul pavimento sotto le pareti
  for(let y=0;y<CV_H-1;y++)for(let x=0;x<CV_W;x++){
    if(G[y][x]!==0)continue;const below=G[y+1][x];if(below===0)continue;
    const px=x*TS,py=y*TS,q=g.createLinearGradient(0,py+TS-30,0,py+TS+16);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(.35,'rgba(0,0,0,.55)');q.addColorStop(1,'rgba(0,0,0,.15)');
    g.fillStyle=q;g.fillRect(px,py+TS-30,TS,46);
    g.strokeStyle='rgba(255,235,200,.10)';g.lineWidth=2;g.beginPath();g.moveTo(px+2,py+TS-30);g.lineTo(px+TS-2,py+TS-30);g.stroke();
  }
  // bordo scuro dove il pavimento tocca le pareti ai lati
  g.save();g.globalCompositeOperation='source-atop';g.restore();
  // pozza: riflessi
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){if(G[y][x]!==2)continue;const px=x*TS,py=y*TS;g.strokeStyle='rgba(140,200,230,.25)';g.lineWidth=1.4;g.beginPath();g.ellipse(px+TS/2,py+TS/2,12,5,0,0,7);g.stroke()}
  CVX.canvas=c;
}
function cavePlace(x,y){P.x=x;P.y=y;P.rv=0;cam.x=P.x;cam.y=P.y;camClamp();if(typeof PAR!=='undefined'&&PAR){PAR.x=P.x+18;PAR.y=P.y-10}}
function caveFade(){CVX.fade=1}
function caveEnter(){
  if(!CVX||P.mode==='raft')return;
  if(typeof cancelAct==='function')cancelAct();
  cavePlace((CV_X0+12)*TS,(CV_Y0+8.7)*TS);caveFade();sfx('thud');
  CVX.hint=1.4;CVX.dripT=2;UI.sync();saveGame();
}
function caveExit(){
  if(!CVX)return;
  const f=nearestFree(Math.floor(CV2.cave[0]),Math.floor(CV2.cave[1])+2,6);
  if(f)cavePlace((f[0]+.5)*TS,(f[1]+.5)*TS);caveFade();P.hd=0;UI.sync();saveGame();
}
function caveStep(dt){
  if(!CVX)return;
  const on=inCave();
  if(on!==CVX.was){CVX.was=on;document.body.classList.toggle('incave',on);UI.sync()}
  if(!on)return;
  if(CVX.fade>0)CVX.fade=Math.max(0,CVX.fade-dt*1.8);
  if(CVX.hint>0){CVX.hint-=dt;if(CVX.hint<=0){
    if(S.up.torch&&S.torchOn){say(PAR,"Cra! Bella fiamma. Si vede tutto.")}
    else if(S.up.torch){say(PAR,"Cra! Che buio! Accendi la torcia!");UI.toast("Qui dentro è buio pesto: accendi la torcia (pulsante a fiamma).",4200)}
    else{say(PAR,"Cra! Buio fitto. Serve una torcia: si fa al Banco!");UI.toast("Qui dentro è buio pesto. Una torcia si costruisce al Banco da lavoro.",4200)}
  }}
  CVX.dripT-=dt;if(CVX.dripT<=0){CVX.dripT=3+Math.random()*5;try{sfx('drip')}catch(e){}}
}
function drawCaveSp(g,e,t){
  if(e.spr==='cavex'){
    g.save();g.translate(e.x,e.y);
    const q=g.createRadialGradient(0,-10,6,0,-6,120);q.addColorStop(0,'rgba(255,248,220,.95)');q.addColorStop(.4,'rgba(255,230,170,.45)');q.addColorStop(1,'rgba(255,220,150,0)');
    g.fillStyle=q;g.beginPath();g.ellipse(0,-6,120,60,0,0,7);g.fill();
    g.restore();return}
  if(e.spr==='cvrudder'){
    g.save();g.translate(e.x,e.y);shadow(g,0,4,34,10,.4);
    g.fillStyle='#55504a';g.beginPath();g.ellipse(0,0,30,11,0,0,7);g.fill();g.fillStyle='#7a746b';g.beginPath();g.ellipse(0,-5,28,10,0,0,7);g.fill();
    if(!(C2s()&&C2s().parts&&C2s().parts.rudder)){
      g.fillStyle='#6b5a2c';g.beginPath();g.roundRect(-22,-26,44,20,6);g.fill();g.strokeStyle='#2c2410';g.lineWidth=2;g.stroke();
      g.fillStyle='#8a7436';g.fillRect(-20,-24,40,5);
      g.strokeStyle='#d7c58f';g.lineWidth=2;g.beginPath();g.moveTo(-8,-26);g.lineTo(-8,-6);g.moveTo(8,-26);g.lineTo(8,-6);g.stroke();
      g.fillStyle='#efe3bd';g.beginPath();g.roundRect(-5,-34,16,11,2);g.fill();g.strokeStyle='#5b4a26';g.lineWidth=1;g.stroke();
      twinkle(g,14,-30,t,6,e.x,'#fff6c0');
    }
    g.restore();return}
}
const C2s=()=>{try{return Ch2.C?Ch2.C():(typeof C==='function'?C():null)}catch(e){return null}};
function drawCaveStalag(g,s,t){
  g.save();g.translate(s.x,s.y);g.scale(s.s,s.s);shadow(g,0,2,10,3,.3);
  g.fillStyle=s.k?'#5a636a':'#6a645c';g.beginPath();g.moveTo(-8,0);g.lineTo(-3,-26);g.lineTo(0,-34);g.lineTo(4,-24);g.lineTo(9,0);g.closePath();g.fill();
  g.fillStyle='rgba(255,255,255,.12)';g.beginPath();g.moveTo(-3,-26);g.lineTo(0,-34);g.lineTo(2,-10);g.closePath();g.fill();
  g.restore();
}
function drawCrystal(g,c,t){
  const hue=c.h<.5?190:270,pul=.75+.25*Math.sin(t*1.7+c.h*9);
  g.save();g.translate(c.x,c.y);shadow(g,0,3,12,4,.35);
  const col=`hsl(${hue},80%,${55+pul*12}%)`;
  for(const[dx,h,w]of[[-7,18,5],[0,28,6.5],[8,14,4.5]]){g.fillStyle=col;g.beginPath();g.moveTo(dx-w,0);g.lineTo(dx-w*.3,-h);g.lineTo(dx+w*.3,-h);g.lineTo(dx+w,0);g.closePath();g.fill();g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.moveTo(dx-w*.3,-h);g.lineTo(dx,-h*.2);g.lineTo(dx-w*.9,0);g.closePath();g.fill()}
  g.restore();
}
function renderCave(t){
  const g=ctx,z=camZoom();
  g.setTransform(1,0,0,1,0,0);g.fillStyle='#050406';g.fillRect(0,0,cv.width,cv.height);
  if(!CVX)return;if(!CVX.canvas)caveBake();
  g.setTransform(DPR*z,0,0,DPR*z,DPR*(VW/2-cam.x*z),DPR*(VH/2-cam.y*z));
  g.imageSmoothingEnabled=true;
  g.drawImage(CVX.canvas,CV_X0*TS,CV_Y0*TS);
  const vx0=cam.x-VW/2/z,vy0=cam.y-VH/2/z,vx1=cam.x+VW/2/z,vy1=cam.y+VH/2/z;
  // pozza: scintillii
  const pw=[(CV_X0+5.6)*TS,(CV_Y0+3.3)*TS];
  g.save();g.globalAlpha=.5+.3*Math.sin(t*2);g.fillStyle='rgba(170,220,255,.5)';g.beginPath();g.ellipse(pw[0]+Math.sin(t*.8)*8,pw[1],10,3,0,0,7);g.fill();g.restore();
  const list=[];
  for(const s of CVX.st)list.push({y:s.y,d:()=>drawCaveStalag(g,s,t)});
  for(const c of CVX.cr)list.push({y:c.y,d:()=>drawCrystal(g,c,t)});
  for(const nm of['cavex','cvrudder']){const e=EID[nm];if(e)list.push({y:e.y+(nm==='cavex'?-80:0),d:()=>drawCaveSp(g,e,t)})}
  list.push({y:P.y,d:()=>drawPlayer(g,t)});
  if(S.flags.parrot)list.push({y:PAR.y+4,d:()=>drawParrotEnt(g,t)});
  list.sort((a,b)=>a.y-b.y);for(const o of list)o.d();
  drawHeading(g,t);
  drawParts(g);
  // buio: quasi nero; torcia e cristalli accendono attorno
  const lights=[];
  const tor=S.up.torch&&S.torchOn;
  lights.push([P.x,P.y-28,tor?60:46,tor?.5:.22,false]);
  if(tor)lights.push([P.x+(P.flip?-21:21),P.y-44,270,1,true]);
  for(const c of CVX.cr)if(c.x>vx0-200&&c.x<vx1+200&&c.y>vy0-200&&c.y<vy1+200)lights.push([c.x,c.y-14,tor?120:105,.36+.1*Math.sin(t*1.7+c.h*9),false,c.h<.5?[90,150,200]:[140,100,210]]);
  const ex=EID.cavex;if(ex)lights.push([ex.x,ex.y-30,240,.85,false,[255,236,180]]);
  if(!LCV)LCV=document.createElement('canvas');
  if(LCV.width!==cv.width||LCV.height!==cv.height){LCV.width=cv.width;LCV.height=cv.height}
  const lg=LCV.getContext('2d'),M=g.getTransform(),base=[6,7,12];
  lg.setTransform(1,0,0,1,0,0);lg.globalCompositeOperation='source-over';lg.fillStyle=rgbs(base);lg.fillRect(0,0,LCV.width,LCV.height);
  lg.setTransform(M);lg.globalCompositeOperation='lighter';
  const tg=[255,232,180];
  for(const l of lights){
    const col=l[5]||tg,ad=[Math.max(0,col[0]-base[0]),Math.max(0,col[1]-base[1]),Math.max(0,col[2]-base[2])];
    const fl=l[4]?(.94+.06*Math.sin(t*13)+.03*Math.sin(t*7.3)):1,R=l[2]*fl,k=Math.min(1,l[3]);
    const q=lg.createRadialGradient(l[0],l[1],R*.08,l[0],l[1],R);
    for(const[o,a]of[[0,1],[.45,.9],[.7,.45],[.88,.14],[1,0]])q.addColorStop(o,`rgba(${ad[0]|0},${ad[1]|0},${ad[2]|0},${a*k})`);
    lg.fillStyle=q;lg.fillRect(l[0]-R,l[1]-R,R*2,R*2);
  }
  g.save();g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='multiply';g.drawImage(LCV,0,0);g.restore();
  if(tor){g.globalCompositeOperation='lighter';const l=lights[1],fl=.9+.1*Math.sin(t*13);const q=g.createRadialGradient(l[0],l[1],3,l[0],l[1],140*fl);q.addColorStop(0,'rgba(255,170,70,.30)');q.addColorStop(1,'rgba(255,120,30,0)');g.fillStyle=q;g.fillRect(l[0]-150,l[1]-150,300,300);g.globalCompositeOperation='source-over'}
  g.setTransform(DPR,0,0,DPR,0,0);
  drawScreenFx(g);drawProgress(g,t);
  if(CVX.fade>0){g.fillStyle=`rgba(0,0,0,${CVX.fade})`;g.fillRect(0,0,VW,VH)}
}
