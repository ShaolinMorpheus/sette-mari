const {chromium}=require('playwright');
const [x0,x1,y0,y1]=process.argv.slice(2).map(Number);
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:844,height:390}})).newPage();
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(1500);
const rows=await p.evaluate(([x0,x1,y0,y1])=>{const P=Pirati,out=[];for(let y=y0;y<y1;y+=.5){let s=String(y.toFixed(1)).padStart(5)+' ';for(let x=x0;x<x1;x+=.5){const f=P.boxFree(x*44,y*44,9,5);if(f){s+='.';continue}const t=P.tileInfo(Math.floor(x),Math.floor(y));s+=t.block?'e':(t.e<.19?'~':'#')}out.push(s)}return out},[x0,x1,y0,y1]);
console.log('x from',x0,'step .5');console.log(rows.join('\n'));await b.close()})();
