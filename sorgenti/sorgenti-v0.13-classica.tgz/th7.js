const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:900,height:420}});const p=await ctx.newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
await p.evaluate(()=>{const S=Pirati.S;S.camp=[{k:'bandiera',tx:31,ty:20}];S.flagMig=0;Pirati.saveGame()});
await p.reload();await p.waitForTimeout(2500);
await p.click('#bCont').catch(()=>{});await p.waitForTimeout(3500);
console.log(await p.evaluate(()=>JSON.stringify([Pirati.S.camp,Pirati.S.flagMig,Pirati.EID.plot_falo.fp,Pirati.E.filter(e=>e.type==='cdeco').map(e=>[e.k,e.tx,e.ty])])));
console.log(er);await b.close()})();
