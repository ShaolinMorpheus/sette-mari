const {chromium}=require('playwright');(async()=>{const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1000);
await p.mouse.click(500,300);await p.waitForTimeout(300);
const z0=await p.evaluate(()=>Ch4.cam.uz);
await p.mouse.move(500,300);await p.mouse.wheel(0,-400);await p.keyboard.press('+');await p.waitForTimeout(300);
const r=await p.evaluate(()=>({uz:Ch4.cam.uz,ctx:Ch4.AU.ctx&&Ch4.AU.ctx.state,mood:Ch4.mood(),beat:Ch4.AU.beat}));
await p.waitForTimeout(3000);
const r2=await p.evaluate(()=>({beat:Ch4.AU.beat,mus:Ch4.AU.mus}));
console.log(z0,JSON.stringify(r),JSON.stringify(r2),errs);await b.close()})()
