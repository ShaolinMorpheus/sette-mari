const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;S.up.sail=1;const e=Pirati.EID.plot_zattera;e.st=2;e.prog=1;S.built.zattera=1;const P=Pirati.P;P.x=(e.fp[0]+1.5)*44;P.y=(e.fp[1]+3.6)*44;Pirati.cam.x=P.x;Pirati.cam.y=P.y-60});
 await p.waitForTimeout(1500);await L.skip(p);await p.screenshot({path:'aud/plot_raft.png'});
 console.log('ERR',JSON.stringify(errs));await b.close()})();
