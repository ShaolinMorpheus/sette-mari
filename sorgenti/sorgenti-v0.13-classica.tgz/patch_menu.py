p='base_index.html';s=open(p).read()
old=s[s.index("  for(const h of hs.filter(h=>!h.x))choices.push({t:h.label(),fn:()=>{act=h}});"):s.index("  const g=Ch2.GREET[w][(Math.random()*3)|0];")]
new='''  for(const h of hs.filter(h=>!h.x&&!h.offer))choices.push({t:h.label(),fn:()=>{act=h}});
  const ex=hs.filter(h=>h.x||h.offer);
  choices.push({t:"Chiacchierare un po'",fn:()=>{act='chat'}});
  const more=[];
  if(ex.length)more.push({t:'ex'});
  if(w==='nives')choices.push({t:"Scambiare materiali",fn:()=>{act='trade'}});
  if(w==='gnocco')choices.push({t:"Fatti cucinare qualcosa",fn:()=>{act='cook'}});
  if(ex.length)choices.push({t:ex.length===1?ex[0].label():"Altro…",fn:()=>{act=ex.length===1?ex[0]:'extra'}});
  choices.push({t:"Niente, a dopo",fn:()=>{}});
'''
s=s.replace(old,new)
s=s.replace("else if(act==='extra')UI.dlg([D(w,\"Cosa facciamo?\"","else if(act==='extra')UI.dlg([D(w,\"Cosa facciamo?\"")
s=s.replace("#dlgChoices .btn{text-align:left;padding:9px 13px;font-size:15px}","#dlgChoices .btn{text-align:left;padding:9px 13px;font-size:15px}\n@media (max-height:520px){#dlgChoices{gap:4px;margin-top:6px}#dlgChoices .btn{padding:5px 11px;font-size:14px}}")
s=s.replace("  const more=[];\n  if(ex.length)more.push({t:'ex'});\n","")
open(p,'w').write(s)
