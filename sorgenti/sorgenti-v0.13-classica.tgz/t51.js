const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420},locale:'it-IT'})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(4000);
console.log(await p.evaluate(()=>{const e=document.getElementById('bCap3');const r=e.getBoundingClientRect();return [r.x,r.y,r.width,r.height,getComputedStyle(e).display,!!e.onclick]}));
await p.evaluate(()=>document.getElementById('bCap3').click());await p.waitForTimeout(5000);
console.log(p.url(),await p.evaluate(()=>typeof Ch3),er);await b.close()})()
