#!/usr/bin/env python3
# v0.12b: editor v2 - terreno, nomi (parte nel gioco base)
import sys,json
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH14 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
B=json.load(open('/home/claude/work/ed_baked.json',encoding='utf8'))
BT={w:B[w].get('t',[]) for w in B}
BN={}
for w in B: BN.update(B[w].get('names',{}))
BN.update(B.get('names',{}) if isinstance(B.get('names'),dict) and 'mv' not in B.get('names',{}) else {})
# nomi (sostituzione globale nei testi)
rep("const pn=s=>{const n=(typeof S!=='undefined'&&S&&S.pname)||'Pappagallo';return String(s).replace(/Biscotto/g,()=>n)};",
"""const NM_BK=%s;
let NMAP=Object.assign({},NM_BK);try{Object.assign(NMAP,JSON.parse(localStorage.getItem('sm_edit_names')||'{}'))}catch(e){}
let NMRE=null;
function nmBuild(){const k=Object.keys(NMAP).filter(a=>a&&NMAP[a]&&NMAP[a]!==a).sort((a,b)=>b.length-a.length);NMRE=k.length?new RegExp('(?<![\\\\p{L}])('+k.map(s=>s.replace(/[.*+?^${}()|[\\]\\\\]/g,'\\\\$&')).join('|')+')(?![\\\\p{L}])','gu'):null}
nmBuild();
const pn=s=>{const n=(typeof S!=='undefined'&&S&&S.pname)||'Pappagallo';s=String(s).replace(/Biscotto/g,()=>n);return NMRE?s.replace(NMRE,m=>NMAP[m]||m):s};""" % json.dumps(BN,ensure_ascii=False))
rep("const fmt=t=>t.replace(/\\{cap\\}/g,capW()).replace(/\\{nome\\}/g,nomeP());","const fmt=t=>pn(t.replace(/\\{cap\\}/g,capW()).replace(/\\{nome\\}/g,nomeP()));")
# terreno
rep("const BEACH_1=[","""const EDT_BK=(%s)[WORLD]||[];
const EDT=EDT_BK.concat((function(){try{const o=JSON.parse(localStorage.getItem('sm_edits_w'+WORLD)||'null');return(o&&o.t)||[]}catch(e){return[]}})());
let EDTON=false;
const BEACH_1=[""" % json.dumps(BT))
rep("  if(dp<1.7)m=Math.min(m,.04+(dp-.55)*.62);\n  return m;",
"""  if(dp<1.7)m=Math.min(m,.04+(dp-.55)*.62);
  if(EDTON)for(const p of EDT){const d=hyp((x-p[1])/p[3],(y-p[2])/p[4]);if(d<1){const w=sstep(1,.55,d);const k=p[0],tg=k==='s'?WL-.55:k==='g'?WL+.33:WL+.15+(NZ.v(x*.9,y*.9)-.5)*.04;m=lerp(m,tg,w)}}
  return m;""")
rep("const tIdx=(tx,ty)=>ty*MW+tx;","""let EDSV=null;
function edtGrids(all){
  if(!EDT.length&&!all)return;
  EDTON=true;let x0=MW,y0=MH,x1=0,y1=0;
  for(const p of EDT){x0=Math.min(x0,Math.floor(p[1]-p[3])-2);x1=Math.max(x1,Math.ceil(p[1]+p[3])+2);y0=Math.min(y0,Math.floor(p[2]-p[4])-2);y1=Math.max(y1,Math.ceil(p[2]+p[4])+2)}
  if(all){x0=0;y0=0;x1=MW-1;y1=MH-1}
  x0=Math.max(0,x0);y0=Math.max(0,y0);x1=Math.min(MW-1,x1);y1=Math.min(MH-1,y1);
  for(let ty=y0;ty<=y1;ty++)for(let tx=x0;tx<=x1;tx++){const i=ty*MW+tx;if(mesaT[i])continue;const e=elev(tx+.5,ty+.5);elevT[i]=e;walkT[i]=e>WL+.075?1:0;seaT[i]=(e<WL-.035&&tx>0&&ty>0&&tx<MW-1&&ty<MH-1)?1:0}
}
function edtPre(){if(!EDT.length)return;EDSV=[elevT.slice(),walkT.slice(),seaT.slice()];edtGrids()}
function edtPost(){if(!EDT.length)return;if(EDSV){elevT.set(EDSV[0]);walkT.set(EDSV[1]);seaT.set(EDSV[2]);EDSV=null}}
const tIdx=(tx,ty)=>ty*MW+tx;""")
rep("  await bakeGround(p=>setP(.08+.84*p));","  edtPre();\n  await bakeGround(p=>setP(.08+.84*p));\n  edtPost();")
rep('<button class="btn" id="nwEd">Editor mappa</button>','<button class="btn" id="nwEd">Editor mappa</button><button class="btn" id="nwE3">Editor galeone</button><button class="btn" id="nwE4">Editor interno nave</button><button class="btn" id="nwE5">Editor viaggio finale</button>')
rep("{const be=c.querySelector('#nwEd');if(be)be.onclick=()=>{uShow('journal',false);setTimeout(edStart,150)}}","{const be=c.querySelector('#nwEd');if(be)be.onclick=()=>{uShow('journal',false);setTimeout(edStart,150)}}\n  for(const[id,h]of[['nwE3','#w3'],['nwE4','#w4'],['nwE5','#w5']]){const b=c.querySelector('#'+id);if(b)b.onclick=()=>{try{localStorage.setItem('sm_edx_auto','1');if(h==='#w4')localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:3,t:0,shots:0,hits:0}))}catch(e){}__go(h);location.reload()}}")
rep("genWorld();pruneUnreachable();unhideLoot();edBoot();","genWorld();pruneUnreachable();unhideLoot();edtGrids();edBoot();")
rep('"Editor mappa (Diario','"Editor mappa v2: pennello «Terreno» (sabbia, erba, mare: allarga la spiaggia o scava il mare, si applica quando esci), pannello «Nomi» per cambiare i nomi dei personaggi nei dialoghi, «Scarica file» per mandare la mappa a Claude.","Editor mappa (Diario',1)
open(P,'w',encoding='utf8').write(src)
print('patch14 ok')
