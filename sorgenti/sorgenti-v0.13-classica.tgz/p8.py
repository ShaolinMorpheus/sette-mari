p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:70],s.count(a))
    s=s.replace(a,b)
i=s.index("  c.innerHTML='<h2>Menu</h2><div class=\"row\"")
j=s.index("\n",i)
new=r"""  const T=(id,ic,l,sub,cls)=>'<button class="mt'+(cls?' '+cls:'')+'" id="'+id+'"><i>'+ic+'</i><span class="ml">'+l+'</span>'+(sub!=null?'<small class="ms">'+sub+'</small>':'')+'</button>';
  const SEC=(t,b)=>'<div class="msec"><h3>'+t+'</h3><div class="mgrid">'+b+'</div></div>';
  c.innerHTML='<h2>Menu</h2>'
   +SEC('Audio e schermo',T('mSnd',AU.on?'🔊':'🔇','Suoni',AU.on?'accesi':'spenti')+T('mMus',AU.mus?'🎵':'🔕','Musica',AU.mus?'accesa':'spenta')+T('mFs','⛶','Schermo',FS_TXT())+T('mTxt','🔠','Testo',TXT_NAMES[txtLevel()])+T('mUnl','🎮','Comandi','sblocca'))
   +SEC('Partita',T('mSave','💾','Salva ora',null)+T('mSlot','📂','Partite salvate',null)+T('mBk','🛟','Copia di sicurezza',null)+T('mJ','📖','Diario e novità',null)+(WORLD===2?T('mC2','⛺','Il campo',null)+T('mC1','🏝️','Torna al Cap. 1',null):''))
   +(S.flags.parrot?SEC('Pappagallo',T('mPn','🦜','Rinomina',pn('Biscotto'))+(Object.keys(S.phats||{}).length?T('mPh','🎩','Cappellino',null):'')):'')
   +SEC('Aiuto',T('mHow','❓','Come si gioca',null)+T('mTut','🧭','Tutorial',null))
   +SEC('Attenzione',T('mRes','⚠️','Ricomincia da capo',null,'warn'))
   +'<div class="mfoot"><button class="btn gold" id="mX">Torna al gioco</button></div><p class="sm" style="margin:6px 0 0;text-align:center">Il gioco salva da solo ogni pochi secondi e quando esci, in questo browser.</p>';
  const setT=(id,ic,sub)=>{const b=c.querySelector('#'+id);b.querySelector('i').textContent=ic;const m=b.querySelector('.ms');if(m)m.textContent=sub};"""
s=s[:i]+new+s[j:]
rep("  c.querySelector('#mMus').onclick=e=>{auInit();muSet(!AU.mus);S.music=AU.mus;e.target.textContent='Musica: '+(AU.mus?'accesa':'spenta');saveGame()};","  c.querySelector('#mMus').onclick=()=>{auInit();muSet(!AU.mus);S.music=AU.mus;setT('mMus',AU.mus?'🎵':'🔕',AU.mus?'accesa':'spenta');saveGame()};")
rep("  c.querySelector('#mSnd').onclick=e=>{auInit();auSet(!AU.on);S.sound=AU.on;e.target.textContent='Suoni: '+(AU.on?'accesi':'spenti')};","  c.querySelector('#mSnd').onclick=()=>{auInit();auSet(!AU.on);S.sound=AU.on;setT('mSnd',AU.on?'🔊':'🔇',AU.on?'accesi':'spenti')};")
rep("  c.querySelector('#mFs').onclick=e=>UI.toggleFs(e.target);","  c.querySelector('#mFs').onclick=()=>UI.toggleFs({set textContent(v){setT('mFs','⛶',v)}});")
rep("  c.querySelector('#mTxt').onclick=e=>{setTxt((txtLevel()+1)%3);e.target.textContent='Testo: '+TXT_NAMES[txtLevel()]};","  c.querySelector('#mTxt').onclick=()=>{setTxt((txtLevel()+1)%3);setT('mTxt','🔠',TXT_NAMES[txtLevel()])};")
rep("  c.querySelector('#mSave').onclick=e=>{saveGame();e.target.textContent='Salvato!'};","  c.querySelector('#mSave').onclick=()=>{saveGame();setT('mSave','✅','Salvato!')};")
rep("  c.querySelector('#mRes').onclick=e=>{if(!ask){ask=true;e.target.textContent='Sicuro? Cancella tutto';e.target.classList.add('gold');return}clearSave();location.reload()};","  c.querySelector('#mRes').onclick=e=>{if(!ask){ask=true;c.querySelector('#mRes .ml').textContent='Sicuro? Cancella tutto';c.querySelector('#mRes').classList.add('on');return}clearSave();location.reload()};\n  {const m1=c.querySelector('#mC1');if(m1)m1.onclick=()=>{uShow('menu',false);Ch2.toCh1()}}")
# css
rep("@media (max-height:440px){#menuCard{max-width:600px}","""#menuCard{max-width:640px;max-height:calc(100dvh - 20px);overflow:auto}
#menuCard h2{margin:0 0 4px}
.msec{margin-top:8px}.msec h3{margin:0 0 4px;font:800 12px var(--f-b);letter-spacing:.08em;text-transform:uppercase;color:#7a4c26;text-align:left}
.mgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:6px}
.mt{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;min-height:62px;padding:6px 4px;border-radius:12px;border:2px solid var(--wood-d);background:linear-gradient(#a96f3b,#7a4c26);color:var(--cream);box-shadow:inset 0 2px 0 rgba(255,220,160,.4),0 3px 0 var(--wood-d);cursor:pointer;font:800 13px var(--f-b);line-height:1.1}
.mt:active{transform:translateY(2px)}.mt i{font-style:normal;font-size:22px;line-height:1}.mt .ml{display:block}.mt .ms{display:block;font:700 11px var(--f-b);opacity:.85}
.mt.warn{background:linear-gradient(#8a4a3a,#5e2a20)}.mt.warn.on{background:linear-gradient(#ff8a70,#d8412f);color:#fff}
.mfoot{display:flex;justify-content:center;margin-top:10px}
@media (max-height:440px){#menuCard{max-width:600px}""")
# neutralize old landscape rules so my grid not affected: old rules target .row, harmless
open(p,'w',encoding='utf8').write(s)
