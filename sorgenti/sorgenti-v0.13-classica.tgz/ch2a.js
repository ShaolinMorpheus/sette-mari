/* ====== CAPITOLO 2 — A: personaggi, fiducia, conversazioni ====== */
Object.assign(CH,{
  ferro:{name:'Ferro',skin:'#d6a07a',hair:'#34343c',coat:'#2e3a54',coat2:'#1c2438',pants:'#33281f',shirt:'#d8d3c3',hat:'tricorn',hatc:'#1a202e',trim:'#9aa2b4',stubble:1,scar:1,sword:20,boots:1,w:1.06,tall:1.03},
  nives:{name:'Nives',skin:'#c68d69',hair:'#3a2216',coat:'#7c4b2a',coat2:'#4c2a14',apron:1,pants:'#46382a',shirt:'#f0e6d0',hat:'bandana',hatc:'#3d7b8c',long:1,hammer:1,w:.98,tall:.99},
  tito:{name:'Tito',skin:'#e6b78f',hair:'#b86a22',coat:'#4c8658',coat2:'#2c5438',pants:'#66523a',shirt:'#f4efe0',hat:'cap',hatc:'#8a5a2a',freckles:1,w:.82,tall:.9},
  gnocco:{name:'Gnocco',skin:'#e7ad88',hair:'#5e3418',coat:'#f1ede0',coat2:'#cbc4ae',apron:1,pants:'#56503f',shirt:'#ffffff',hat:'bandana',hatc:'#f4f0e4',mustache:1,ladle:1,w:1.26,tall:.96}
});
Ch2.NPC={ferro:{at:[59.6,28.6],n:'Ferro'},nives:{at:[62.4,32],n:'Nives'},gnocco:{at:[54.9,31.2],n:'Gnocco'},tito:{at:[65.4,34.9],n:'Tito'}};
Ch2.st=function(){
  const c=S.c2=S.c2||{};
  c.trust=Object.assign({ferro:0,nives:0,tito:0,gnocco:0},c.trust);c.met=c.met||{};c.parts=Object.assign({mast:0,rudder:0,sails:0,yard:0},c.parts);
  c.said=c.said||{};c.talkDay=c.talkDay||{};c.pages=c.pages||0;c.deals=c.deals||0;c.ch=c.ch||{};c.yard=c.yard||{};
  return c;
};
Ch2.tr=w=>Ch2.st().trust[w]||0;
Ch2.addTrust=function(w,n,quiet){
  const c=Ch2.st(),o=c.trust[w]||0,v=clamp(o+n,0,10);c.trust[w]=v;
  if(!quiet&&v!==o)UI.toast((v>o?'Fiducia di ':'Fiducia di ')+Ch2.NPC[w].n+(v>o?' +':' ')+(v-o)+' ('+v+'/10)');
  saveGame(true);
};
Ch2.spawnNpcs=function(){
  for(const w in Ch2.NPC){
    const d=Ch2.NPC[w];let tx=Math.floor(d.at[0]),ty=Math.floor(d.at[1]);
    if(!freeT(tx,ty)){const f=nearestFree(tx,ty,3);if(f){tx=f[0];ty=f[1]}}
    const e=ent({id:'npc_'+w,type:'npc',who:w,x:(tx+.5)*TS,y:(ty+.92)*TS,tx,ty,ph:Math.random()*6,flip:w==='nives'||w==='gnocco'});
    addBlock(e,tx,ty,1,1);
  }
};
function drawNpc(g,e,t){
  const dx=P.x-e.x,dy=P.y-e.y,near=hyp(dx,dy)<TS*5.5;
  const o={k:CH[e.who],dir:'f',flip:near?dx<0:e.flip,t:t+e.ph,walk:0,moving:false,look:near?clamp(dx/160,-1,1):0};
  const m=Ch2.npcMark(e);if(m)o.emote=m;
  drawChar(g,e.x,e.y,o);
}
/* conversazioni: ogni voce di Ch2.QH è un compito che un personaggio può dare o ricevere */
Ch2.QH=[];
Ch2.npcMark=function(e){
  const c=Ch2.st(),w=e.who;
  if(!c.met[w]&&S.q.c5&&S.q.c5.st==='active')return'!';
  for(const h of Ch2.QH)if(h.w===w&&h.active()&&h.ready&&h.ready())return'?';
  for(const h of Ch2.QH)if(h.w===w&&h.offer&&h.offer())return'!';
  return null;
};
const HEARTS=n=>'♥'.repeat(Math.floor(n/2))+(n%2?'♡':'');
Ch2.CHAT={
  ferro:{
    lo:["Non ho tempo per le chiacchiere. Lavora.","Qui si resta vivi con la disciplina. Il resto sono storie.","Ti guardo. Non è un'offesa: è prudenza.","Le navi non si costruiscono con le parole."],
    mid:["Hai fatto più di quanto mi aspettassi. Non lasciare che ti dia alla testa.","Quando una nave salpa, qualcuno resta a terra. È il prezzo. Meglio saperlo prima.","Ho già perso un equipaggio. Non succederà due volte."],
    hi:["Ti affiderei un turno di guardia. È più di quanto dica a molti.","Se parti con me, parti con la mia parola. Valle quanto vale la tua.","Il mare non perdona i bugiardi. Gli uomini, a volte, sì."]},
  nives:{
    lo:["Se un attrezzo si rompe, dì pure che l'ho fatto io: tanto è già colpa mia.","Il segreto di un buon martello? Non prestarlo a Tito.","Ferro dice che parlo troppo. Io dico che lui ascolta male. Siamo pari."],
    mid:["Una nave è come un gatto: se la accarezzi nel verso giusto, ti porta dove vuole lei.","Ho visto troppi addii su queste rive. Non ne voglio altri.","Mi piaci. Non dirlo in giro: perderei il mio fascino scontroso."],
    hi:["Tutti o nessuno: è l'unica regola che mi sono data. E l'unica che non ho mai rotto.","Se la nave parte, voglio che sia piena di gente viva, non di ordini.","Con te si lavora bene. Con Ferro si lavora in fila. È diverso."]},
  tito:{
    lo:["Io non ho visto niente. Qualunque cosa sia successa, non ero io.","Gnocco dice che i granchi sono buoni. Io dico che mi guardano male.","Ho le mani piene di corde e la testa piena di dubbi."],
    mid:["Quando parlano della nave, nessuno nomina mai me. Lo noti anche tu?","A casa avevo una barca piccola. Una barca vera. Poi... lasciamo stare.","Sai tenere un segreto? No, non rispondere: vorrei poter credere di sì."],
    hi:["Ti racconto una cosa, ma non farne un discorso: ho paura che mi lascino qui.","Con te è diverso. Mi fai sentire meno invisibile.","Un giorno costruirò una barca tutta mia. Con una vela blu. Perché il blu non lo ha nessuno."]},
  gnocco:{
    lo:["Se cucini col cuore, anche il pesce secco diventa una festa.","Vuoi sapere il mio segreto? Più sale. Sempre più sale.","Qui il pane non c'è, ma io lo sogno. Con il burro. Con sopra altro burro."],
    mid:["Una volta ho cucinato per un capitano così severo che il brodo si raffreddava da solo. Parlo di Ferro, ovviamente.","Un pasto caldo tiene insieme un gruppo. Non è poco, credimi.","Il mare dà e il mare toglie. Io prendo quello che dà e lo metto in pentola."],
    hi:["Quando partiremo, voglio un fornello a bordo. Anche piccolo. Anche solo per il brodo.","Ti tengo sempre un cucchiaio in più. Nel mio linguaggio, è una dichiarazione d'affetto.","Alla nave serve un cuoco. Alla ciurma serve un cuoco. A me serve la nave. Il cerchio si chiude."]}
};
Ch2.chatLine=function(w){
  const t=Ch2.tr(w),k=t>=6?'hi':t>=3?'mid':'lo',pool=Ch2.CHAT[w][k].concat(t>=3?Ch2.CHAT[w].lo:[]);
  const c=Ch2.st();let i=(Math.random()*pool.length)|0;if(pool.length>1&&c.lastChat&&c.lastChat[w]===i)i=(i+1)%pool.length;
  c.lastChat=c.lastChat||{};c.lastChat[w]=i;return pool[i];
};
Ch2.GREET={
  ferro:["Dimmi.","Ti ascolto.","Cosa c'è?"],
  nives:["Ehi! Serve qualcosa o vuoi solo guardare il mio banco con ammirazione?","Dimmi tutto, forestiero.","Ecco la persona più fastidiosamente utile dell'isola."],
  tito:["Ah! Sei tu. Non mi hai spaventato. Un po'.","Ehi... hai bisogno di qualcosa?","Sì? Ero qui. A non fare niente di losco."],
  gnocco:["Ah, un assaggiatore! Sei qui per mangiare o per rovinarmi la giornata?","Mmh, sento odore di richieste. Dimmi.","Benvenuto alla cucina più piccola e più orgogliosa del mondo."]
};
Ch2.talk=function(e){
  const w=e.who,c=Ch2.st();
  faceTo(e);
  if(!c.met[w]){Ch2.meet(w);return}
  const nm=Ch2.NPC[w].n,hs=Ch2.QH.filter(h=>h.w===w&&h.active());
  let act=null;
  const choices=[];
  for(const h of hs)choices.push({t:h.label(),fn:()=>{act=h}});
  if(w==='nives')choices.push({t:"Scambiare materiali",fn:()=>{act='trade'}});
  if(w==='gnocco')choices.push({t:"Fatti cucinare qualcosa",fn:()=>{act='cook'}});
  choices.push({t:"Chiacchierare un po'",fn:()=>{act='chat'}});
  choices.push({t:"Niente, a dopo",fn:()=>{}});
  const g=Ch2.GREET[w][(Math.random()*3)|0];
  UI.dlg([D(w,g+"  ("+HEARTS(Ch2.tr(w))+")",{choices})],()=>{
    if(act==='trade')Ch2.openTrade();
    else if(act==='cook')Ch2.openCook();
    else if(act==='chat')Ch2.chat(w);
    else if(act&&act.run)act.run();
  });
};
Ch2.chat=function(w){
  const c=Ch2.st();
  UI.dlg([D(w,Ch2.chatLine(w))],()=>{
    if(c.talkDay[w]!==S.day){c.talkDay[w]=S.day;Ch2.addTrust(w,1)}
    else if(Math.random()<.3)UI.toast('Oggi ne avete già parlato a lungo: la fiducia cresce con i fatti.');
    checkAll();
  });
};
Ch2.meet=function(w){
  const c=Ch2.st();
  const done=()=>{c.met[w]=1;Ch2.addTrust(w,1,true);UI.syncObj();checkAll();saveGame()};
  const L={
    nives:[D('nives',"Ah, la nuova arrivata. Ferro ha già fatto il suo discorsetto? Quello del «tre giorni e poi si vede»?"),D('hero',"Più o meno."),D('nives',"Lo fa con tutti. Io sono Nives. Aggiusto, costruisco e, quando serve, minaccio. Soprattutto aggiusto."),D('nives',"Questa è la bancarella: scambio materiali. Portami roba buona e ti tratto bene. Portami roba cattiva e ti tratto comunque bene, ma ti guardo storto."),D('biscotto',"Cra! Storto!"),D('nives',"E questo chi è? Un socio?"),D('hero',"Biscotto. Lavora solo a pagamento, in noci di cocco."),D('nives',"Allora andremo d'accordo.")],
    gnocco:[D('gnocco',"Ehi! Odore di mare, odore di naufragio... e nessun odore di pane. Che disgrazia."),D('gnocco',"Gnocco, cuoco ufficiale e unico. Gli altri dicono che cucino «con fantasia». Io dico: con coraggio."),D('hero',"Cosa c'è oggi nel pentolone?"),D('gnocco',"Quello che ha pescato Tito. Cioè: poco. E tanto sale, per distrarre."),D('gnocco',"Però, davvero: un gruppo sta in piedi finché mangia. Se mi porti cibo vero, ti preparo qualcosa che ricorderai. Nel bene, spero.")],
    tito:[D('tito',"Io non ero lì. Qualunque cosa fosse, non ero lì."),D('hero',"Non ti ho chiesto niente."),D('tito',"Ah. Allora... piacere! Tito. Sistemo le corde, pulisco le barche e osservo. Soprattutto osservo."),D('tito',"Ferro non si fida di te. Ma non si fida neanche di me, e io sono qui da due anni."),D('biscotto',"Cra! Due anni! Tanti!"),D('tito',"Parla! Un pappagallo che parla! Posso accarezzarlo?"),D('biscotto',"Cra. No."),D('tito',"...Credo di essere stato appena rifiutato da un uccello.")]
  }[w];
  if(!L){done();return}
  UI.dlg(L,done);
};
Ch2.metCount=()=>{const c=Ch2.st();return['nives','gnocco','tito'].filter(w=>c.met[w]).length};
