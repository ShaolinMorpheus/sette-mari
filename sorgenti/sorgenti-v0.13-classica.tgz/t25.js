const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
const r=await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.t=400;for(let i=0;i<5;i++)Ch3.step(.1);const g=C.ships.find(s=>s.type==='galeone');const R=Ch3.ROUTE;
 g.prog=R.length-1;g.x=R[R.length-1][0]+100;g.y=R[R.length-1][1];C.p.x=3000;C.p.y=3000;
 for(const s of C.ships)if(s.conv&&s.type!=='galeone')s.dead=true;
 for(let i=0;i<200&&!C.over;i++)Ch3.step(.1);return [C.over,C.escapes,[...document.querySelectorAll('#endCard h2,#endCard p')].map(e=>e.textContent)]});
console.log(JSON.stringify(r),errs);await b.close()})()
