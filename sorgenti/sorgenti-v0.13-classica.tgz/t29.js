const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.sail=0;C.t=400;Ch3.step(.1);const g=C.ships.find(s=>s.type==='galeone');C.p.x=g.x-1000;C.p.y=g.y+200;C.p.v=0});
await p.waitForTimeout(800);await p.screenshot({path:'c3f.png'});console.log(errs);await b.close()})()
