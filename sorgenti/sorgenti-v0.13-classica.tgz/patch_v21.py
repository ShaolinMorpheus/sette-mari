#!/usr/bin/env python3
# v0.12i (B2): novità del mare (cala, forzieri, nebbia, bottiglie con mappa, brigantino) – registro delle novità
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH21 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:100].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Mare: una cala tranquilla dove i pesci saltano e lo scafo si ripara da solo; due forzieri sulle spiagge (si aprono avvicinandosi con la nave) e un banco di nebbia dove le pattuglie ti vedono solo da vicino, con qualche cassa nascosta dentro.",
    "Mare: ogni tanto una bottiglia galleggia in acqua. Dentro c'è la mappa del tesoro: la X su una spiaggia lontana, con una freccia color pergamena, la distanza e il segno sulla minimappa.",
    "Mare: il brigantino dalle vele viola è veloce e scappa, ma si stanca. Se lo affondi lascia 3 casse d'argento.",
    "Aspetto della nave: nuove vele viola e bandiera del tesoro da sbloccare.",
''')
open(P,'w',encoding='utf8').write(src)
print('patch21 ok')
