p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:70],s.count(a))
    s=s.replace(a,b)
a=open('ch2a.js',encoding='utf8').read().replace("{ferro:0,nives:0,tito:0,gnocco:0}","{ferro:1,nives:1,tito:1,gnocco:1}")
b=open('ch2b.js',encoding='utf8').read()
rep("/* ---- motore delle missioni ---- */",a+"\n"+b+"\n/* ---- motore delle missioni ---- */")
# POI entities + NPCs
rep("  // granchi sulle spiagge\n  {const cr=[];\n   for(let ty=4;ty<MH-4;ty++)","""  // punti della storia del capitolo 2
  {const fr=(x,y,R)=>nearestFree(Math.floor(x),Math.floor(y),R||3)||[Math.floor(x),Math.floor(y)];
   const mt=fr(CV2.mast[0],CV2.mast[1]);
   const mast=ent({id:'mast',type:'pine',v:1,x:(mt[0]+.5)*TS,y:(mt[1]+.92)*TS,tx:mt[0],ty:mt[1],alive:true,grow:1,t:0,wood:6,once:1,flip:false,label:'Pino Maestro'});addBlock(mast,mt[0],mt[1],1,1);
   const kc=fr(CV2.knife[0],CV2.knife[1]);ent({id:'lt_knife',type:'loot',kind:10,x:(kc[0]+.5)*TS,y:(kc[1]+.8)*TS,tx:kc[0],ty:kc[1],got:false,label:'Coltello'});
   CV2.pages.forEach((p,i)=>{const f=fr(p[0],p[1]);ent({id:'lt_pg'+i,type:'loot',kind:11,x:(f[0]+.5)*TS,y:(f[1]+.8)*TS,tx:f[0],ty:f[1],got:false,label:'Pagina di diario'})});
   const ec=fr(83,29,4);ent({id:'lt_east',type:'loot',kind:8,x:(ec[0]+.5)*TS,y:(ec[1]+.8)*TS,tx:ec[0],ty:ec[1],got:false,label:'Cassa'});
   const cv=fr(CV2.cave[0],CV2.cave[1],2);deco('cave','cave',(cv[0]+.5),cv[1]+.95,[cv[0]-1,cv[1],3,1],{hitw:150,hith:100,inter:'look',label:'La grotta'});
   [[56.4,33.8,0],[61.6,35.2,1],[52.3,28.4,2]].forEach((q,i)=>{const f=fr(q[0],q[1],2);deco('clue'+i,'clue',f[0]+.5,f[1]+.8,null,{inter:'look',k:i,hitw:60,hith:44,label:'Tracce'})});
   Ch2.spawnNpcs();
  }
  // granchi sulle spiagge
  {const cr=[];
   for(let ty=4;ty<MH-4;ty++)""")
rep("(ty==='loot'&&e.kind===8)){","(ty==='loot'&&e.kind===8&&e.id!=='lt_east')){")
rep("    case'loot':return{l:e.kind===9?'Prendi':'Apri',i:'hand'};","    case'loot':return{l:(e.kind===9||e.kind===10||e.kind===11)?'Prendi':'Apri',i:'hand'};")
# biscotto lines only if parrot in ch2
rep("  lines=(lines||[]).filter(Boolean);\n  if(!lines.length){if(cb)cb();return}","  lines=(lines||[]).filter(Boolean).filter(l=>l.w!=='biscotto'||WORLD!==2||(S&&S.flags&&S.flags.parrot));\n  if(!lines.length){if(cb)cb();return}")
# menu entry
rep('<button class="btn" id="mJ">Diario e novità</button>',"'+(WORLD===2?'<button class=\"btn\" id=\"mC2\">Il campo dei Fuggiaschi</button>':'')+'<button class=\"btn\" id=\"mJ\">Diario e novità</button>")
rep("  c.querySelector('#mHow').onclick=()=>UI.showHow();","  c.querySelector('#mHow').onclick=()=>UI.showHow();\n  {const m2=c.querySelector('#mC2');if(m2)m2.onclick=()=>{uShow('menu',false);Ch2.openStatus()}}")
# end card button ch1 -> ch2
rep("  $('endCard').querySelector('#eGo').onclick=()=>{uShow('endcard',false);Story.afterEnd()};\n  $('endCard').querySelector('#eJ')","  {const x=$('endCard').querySelector('#eGo');if(WORLD===1&&window.CH2_OPEN){const b=document.createElement('button');b.className='btn gold';b.textContent='Continua: Capitolo 2';b.onclick=()=>Ch2.begin();x.parentNode.insertBefore(b,x)}}\n  $('endCard').querySelector('#eGo').onclick=()=>{uShow('endcard',false);Story.afterEnd()};\n  $('endCard').querySelector('#eJ')")
# start screen: slot click with different world, new game in world 2, auto-continue
rep("b.onclick=()=>{SLOT=+b.dataset.s;try{localStorage.setItem(SLOTK,String(SLOT))}catch(_){}applySlot()});","b.onclick=()=>{const n=+b.dataset.s;let w2=false;try{const i=slotInfo(n);w2=!!(i&&i.ch===2)}catch(_){}try{localStorage.setItem(SLOTK,String(n))}catch(_){}if(w2!==(WORLD===2)){location.reload();return}SLOT=n;applySlot()});")
rep("    if(save&&!confirmNew){confirmNew=true;$('bNew').textContent='Sicuro? Cancella il salvataggio';$('bNew').classList.add('gold');return}\n","    if(save&&!confirmNew){confirmNew=true;$('bNew').textContent='Sicuro? Cancella il salvataggio';$('bNew').classList.add('gold');return}\n    if(WORLD===2&&!window.__W2){clearSave();location.reload();return}\n")
rep("  $('verTxt').textContent='Bozza v'+CHANGELOG[0].v+' · '+CHANGELOG[0].d;\n}","  $('verTxt').textContent='Bozza v'+CHANGELOG[0].v+' · '+CHANGELOG[0].d;\n  try{if(sessionStorage.getItem('sette-mari-auto')&&save){sessionStorage.removeItem('sette-mari-auto');startContinue('',null);saveGame()}}catch(_){}\n}")
open(p,'w',encoding='utf8').write(s)
print('ok')
