const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>{Pirati.startNew('T','m')});
for(let i=0;i<12;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(500)}
const r=await p.evaluate(async()=>{
 for(let i=0;i<80&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,50))}
 const S=Pirati.S;for(const id of['falo','capanna','banco','zattera']){const e=Pirati.EID['plot_'+id];e.st=2;e.prog=1;S.built[id]=1}
 S.res={legna:99,pietra:99,corda:99,tela:2,rottami:99,coco:5,bacche:5,molluschi:5,pesce:5,arrosto:5};
 Pirati.UI.openUpgrades();await new Promise(r=>setTimeout(r,200));
 for(const k of['lanterne','bandiera','tavolo','amaca','cartello']){const b=document.querySelector('[data-dc="'+k+'"]');if(b){b.click();await new Promise(r=>setTimeout(r,200))}}
 for(const k of['sail','hull']){const b=document.querySelector('[data-up="'+k+'"]');if(b){b.click();await new Promise(r=>setTimeout(r,200))}}
 const cd=Pirati.E.filter(e=>e.type==='cdeco').map(e=>[e.k,e.tx,e.ty]);
 return {cd,up:JSON.stringify(S.up)}});
console.log(JSON.stringify(r));
await p.evaluate(()=>{document.getElementById('sheet').hidden=true;const f=Pirati.EID.plot_falo;Pirati.tp(f.x/44,f.y/44+2.5);Pirati.S.tod=21;Pirati.S.wx={k:'clear',t:900}});
await p.waitForTimeout(1500);
await p.evaluate(async()=>{for(let i=0;i<60&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,50))}});
await p.waitForTimeout(2500);await p.screenshot({path:'camp_night.png'});
await p.evaluate(()=>{Pirati.S.tod=12});await p.waitForTimeout(2500);await p.screenshot({path:'camp_day.png'});
await b.close()})();
