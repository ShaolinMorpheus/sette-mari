const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
p.on('pageerror',e=>console.log('ERR',e.message));
await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.Ch2.convert(P.newState('D','m'));s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(2000);
const r=await p.evaluate(()=>{const P=Pirati,o={ch:[],fix:{cp:null}};
 for(const id of['lt_hill','lt_isleA','lt_isleB','lt_isleC','lt_isleD']){const e=P.EID[id];if(!e){o.ch.push([id,'MISSING']);continue}
  const tx=Math.floor(e.x/44),ty=Math.floor(e.y/44);const t=P.tileInfo(tx,ty);
  // celle libere attorno
  let free=0;for(let j=-1;j<=1;j++)for(let i=-1;i<=1;i++)if(P.tileInfo(tx+i,ty+j).free)free++;
  o.ch.push([id,+(e.x/44).toFixed(1),+(e.y/44).toFixed(1),{walk:t.walk,block:t.block,sea:t.sea,e:+t.e.toFixed(2),freeAround:free,got:e.got,reach:P.reachable(tx,ty)}])}
 o.spawn=[+(P.P.x/44).toFixed(1),+(P.P.y/44).toFixed(1)];o.prev=P.prev();return o});
console.log(JSON.stringify(r.ch));console.log('player',r.spawn);
fs.writeFileSync('tr_prev.json',JSON.stringify({prev:r.prev,ch:r.ch}));await b.close()})();
