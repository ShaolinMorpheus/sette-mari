#!/usr/bin/env python3
# v0.12p: niente interni (capanna/grotta) disegnati nel mare
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH28 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
rep("    if(ex<vx0-260||ex>vx1+260||ey<vy0-120||ey>vy1+340)continue;\n    list.push(e);",
"    if(ex<vx0-260||ex>vx1+260||ey<vy0-120||ey>vy1+340)continue;\n    {const tx_=Math.floor(ex/TS),ty_=Math.floor((ey-2)/TS);if(huReg(tx_,ty_)||((WORLD===1||WORLD===2)&&tx_>=CV_X0&&tx_<CV_X0+CV_W&&ty_>=CV_Y0&&ty_<CV_Y0+CV_H))continue}\n    list.push(e);")

# pietre/oggetti: sposta anche se la chioma li copre solo in parte
rep("    if(frac(e.x,e.y)<=.35)continue;","    if(frac(e.x,e.y)<=.04)continue;")
rep("if(frac((tx+.5)*TS,(ty+(e.type==='bush'||e.type==='berry'?.9:.8))*TS)>.12)continue;","if(frac((tx+.5)*TS,(ty+(e.type==='bush'||e.type==='berry'?.9:.8))*TS)>.02)continue;")
# essiccatore: i ripiani pronti prima
rep("""    for(let i=0;i<3;i++){
      const s=d.sl[i];h+='<div class="upg" data-z="'+i+'">';""","""    const ord=[0,1,2].sort((a,b)=>{const r=k=>{const q=d.sl[k];return q?(q.p>=q.t?0:1):2};return r(a)-r(b)||a-b});
    for(const i of ord){
      const s=d.sl[i];h+='<div class="upg" data-z="'+i+'">';""")

# ---- menu: Novità = solo log; "Solo per me" = password + editor + prove
ROW_OLD=r"""<div class="row" style="margin:4px 0 10px"><button class="btn" id="nwEd">Editor mappa</button><button class="btn" id="nwE3">Editor galeone</button><button class="btn" id="nwE4">Editor interno nave</button><button class="btn" id="nwE5">Editor viaggio finale</button><button class="btn" id="nwC3">Prova: Capitolo 3 (battaglia)</button><button class="btn" id="nwC4">Prova: assalto al galeone</button><button class="btn" id="nwC5">Prova: Il grande viaggio</button><button class="btn" id="nwVer">'+verLbl()+'</button></div>"""
rep("return'<div class=\"news\">"+ROW_OLD+"'+CHANGELOG.map","return'<div class=\"news\">'+CHANGELOG.map")
rep("let jSeen={};\n",open('/home/claude/work/new27.js',encoding='utf8').read()+"let jSeen={};\n")
rep("+T('mJ','📖','Diario e novità',null)+","+T('mJ','📖','Novità',null)+T('mAdm','🔐','Solo per me',null)+(WORLD>=3?T('mHome','🏝️','Torna all\\'isola','tocca due volte'):'')+")
rep("  c.querySelector('#mJ').onclick=()=>{uShow('menu',false);UI.openJournal('n')};","""  c.querySelector('#mJ').onclick=()=>{uShow('menu',false);UI.openJournal('n')};
  c.querySelector('#mAdm').onclick=()=>{uShow('menu',false);UI.openAdmin()};
  {const mh=c.querySelector('#mHome');if(mh){let arm=0;mh.onclick=()=>{if(!arm){arm=1;setT('mHome','🏝️','Sicuro? Tocca ancora');setTimeout(()=>{arm=0;try{setT('mHome','🏝️','tocca due volte')}catch(e){}},3500);return}try{history.replaceState(null,'',location.pathname)}catch(e){}location.reload()}}}""")

# ---- grotta 1 più ricca
rep("for(const nm of['cavex','cvrudder','cvchest']){const e=EID[nm];","for(const nm of['cavex','cvrudder','cvchest','cvbr0','cvbr1','cvbr2','cvskel','cvsm']){const e=EID[nm];")
rep("function drawCaveSp(g,e,t){\n  if(e.spr==='cvchest'){","function drawCaveSp(g,e,t){\n  if(cave1Sp(g,e,t))return;\n  if(e.spr==='cvchest'){")
rep("  const ex=EID.cavex;if(ex)lights.push(","  cave1Lights(lights,t,vx0,vy0,vx1,vy1);\n  const ex=EID.cavex;if(ex)lights.push(")
rep("if(e.id==='cvchest')return{l:'Apri',i:'hand'};","if(e.id==='cvchest'||e.id==='cvsm')return{l:'Apri',i:'hand'};if(e.id&&e.id.indexOf('cvbr')===0)return{l:'Accendi',i:'fire'};if(e.id==='cvskel')return{l:'Esamina',i:'eye'};")
rep("e in fondo una cassa con l'Elmetto da minatore (guardaroba, anche per lo spaventapasseri) e 30 XP.","e in fondo una cassa con il Tricorno del contrabbandiere (guardaroba, anche per lo spaventapasseri) e 30 XP.") if False else None

rep('{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n','''{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[
    "Mare pulito: le stanze interne di capanna e grotta non si vedono più da fuori quando navighi in alto, quindi niente più capanne, barili e casse in mezzo all'acqua.",
    "La zattera ora serve a qualcosa (isola 1 e 2): in mare aperto galleggiano casse e barili da ripescare passandoci vicino; di giorno ogni tanto spunta una balena che lascia una cassa, e la sera può comparire una nave fantasma con il suo tesoro.",
    "Pietre, rottami e cespugli vengono spostati in punti ben visibili anche se la chioma di un albero li copre solo un po' (isola 1 e isola 2).",
    "Essiccatore: i ripiani pronti da ritirare ora stanno in cima.",
    "Menu: «Novità» contiene solo i log; nuova voce «Solo per me» (con password) con editor e prove delle missioni. Nel mare del galeone il menu ha «Torna all'isola».",
    "Grotta della prima isola più ricca: tre bracieri da accendere con la torcia, un vecchio contrabbandiere con biglietto e cassetta, e la cassa finale che si apre solo a bracieri accesi. Il premio è il Tricorno del contrabbandiere (al posto dell'elmetto da minatore, già convertito per chi lo aveva).",
''')

# ---- la zattera serve a qualcosa: relitti, balena, nave fantasma
import re as _re
_c3=open('/home/claude/work/ch3_inject.js',encoding='utf8').read()
_a=_c3.index('function whaleDraw(g,s,t){');_b=_c3.index('\nfunction ',_a+10)
_wh=_c3[_a:_b].replace('function whaleDraw(','function nvWhaleDraw(')
NEW28=open('/home/claude/work/new28.js',encoding='utf8').read().replace('/*WHALE*/',_wh)
rep("/* ---- 12d_kb.js ---- */",NEW28+"\n/* ---- 12d_kb.js ---- */")
rep("try{cave1Tick(dt)}catch(e){console.error('grotta1',e)}","try{cave1Tick(dt)}catch(e){console.error('grotta1',e)}try{rsTick(dt)}catch(e){console.error('zattera',e)}")
rep("  if(P.mode==='raft')drawRaftHull(g,t);\n  // oggetti ordinati","  if(P.mode==='raft')drawRaftHull(g,t);\n  try{rsDraw(g,t)}catch(e){}\n  // oggetti ordinati")

rep("window.Pirati={photo:PHO,YD,FE,","window.Pirati={RS,rsOpen,rsTick,rsSpawnFl,photo:PHO,YD,FE,")
open(P,'w',encoding='utf8').write(src)
print('patch28 ok')
