const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(6000);
const res=await p.evaluate(()=>{const out={};
 const run=(name,easy,kinds,secs)=>{Ch3.newRun(easy,{time:'alba',abb:2,div:1,sal:1,detect:1});const C=Ch3.C;C.tut=null;C.ships=[];const pl=C.p;pl.x=3600;pl.y=2400;pl.hd=0;
  const tg=[];kinds.forEach((k,i)=>{const s=Ch3.mkShip(k,pl.x+60+i*80,pl.y+420+i*90,Math.PI,{});s.alert=true;s.hostile=true;if(k==='galeone'){s.conv=false;s.guard=true}if(k==='scorta')s.guard=true;C.ships.push(s);tg.push(s)});
  let t=0,sunk=0,tfirst=null;const h0=pl.hull;
  for(;t<secs&&pl.hull>0;t+=1/30){pl.v=0;Ch3.step(1/30);pl.hd=0;pl.x=3600;pl.y=2400;if(pl.cdR<=0)Ch3.fire(pl,1);for(const s of tg){if(s.dead&&!s._c){s._c=1;sunk++;if(tfirst==null)tfirst=t}}}
  out[name]={hull:+pl.hull.toFixed(2),secs:+t.toFixed(1),sunk,tfirst:tfirst&&+tfirst.toFixed(1),total:kinds.length}};
 run('1pattuglia_norm',false,['pattuglia'],60);
 run('3pattuglie_norm',false,['pattuglia','pattuglia','pattuglia'],60);
 run('3pattuglie_facile',true,['pattuglia','pattuglia','pattuglia'],60);
 run('galeone_norm',false,['galeone'],60);
 run('galeone+2scorte_norm',false,['galeone','scorta','scorta'],60);
 return out});
console.log(JSON.stringify(res,null,1),er);await b.close()})()
