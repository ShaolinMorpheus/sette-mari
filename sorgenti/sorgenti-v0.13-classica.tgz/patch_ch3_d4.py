#!/usr/bin/env python3
# D4: eventi casuali in mare -> ch3_inject.js (assert-counting)
import sys
P='/home/claude/work/ch3_inject.js'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('D4 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
NEW=open('/home/claude/work/ch3_ev.js',encoding='utf8').read()
rep("/* ---------------- passo ---------------- */",NEW+"/* ---------------- passo ---------------- */")
rep("  if(!VOY)poiPlace();\n}\nfunction objVis(dt){","  if(!VOY)poiPlace();\n  C.ev=VOY?null:evNew();\n}\nfunction objVis(dt){")
rep("C.poi=null;C.brig=null;C.map=null;C.convoy=true;","C.poi=null;C.ev=null;C.brig=null;C.map=null;C.convoy=true;")
rep("if(!C.tut&&!VOY){convoy(dt);poiStep(dt)}","if(!C.tut&&!VOY){convoy(dt);poiStep(dt);evStep(dt)}")
rep("  if(!VOY)poiMini(c,p,sc);","  if(!VOY)poiMini(c,p,sc);\n  if(!VOY)evMini(c,p,sc);")
rep("  if(!VOY)poiOverlay(g,w,h);","  if(!VOY)poiOverlay(g,w,h);\n  if(!VOY)evOverlay(g,w,h);")
rep("function drawShip(g,e,t){\n  const s=e.s;\n","function drawShip(g,e,t){\n  const s=e.s;\n  if(s.ev&&s.k!=='ghost'){evDrawShip(g,s,t);return}\n")
rep("'! Prendile prima che affondino.';\n","'! Prendile prima che affondino.';\n  {const eh=evHint();if(eh)return eh}\n")
rep("window.Ch3={b2:{poiPlace,","window.Ch3={ev:{spawn:evSpawn,step:evStep,hint:evHint},b2:{poiPlace,")
rep("vis:()=>C?C.ships.concat([C.p])","vis:()=>C?C.ships.concat(evVis(),[C.p])")
open(P,'w',encoding='utf8').write(src)
print('D4 ch3 ok',len(src))
