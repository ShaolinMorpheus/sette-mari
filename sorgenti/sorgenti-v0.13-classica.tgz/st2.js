const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const er=[];
const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.Ch2.convert(P.newState('D','m'));s.tutDone=1;s.flags.parrot=1;s.q={c5:{st:'done',gi:0,p:0},c6:{st:'active',gi:0,p:0}};localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(2500);
const r=await p.evaluate(async()=>{const P=Pirati,out=[];
 const h=P.Ch2.QH.find(q=>q.w==='tito'&&q.label().includes('sud-est'));out.push('qh '+!!h+' active '+h.active());
 h.run();
 for(let i=0;i<12;i++){const t=document.querySelector('#dlg, .dlg');out.push((document.body.innerText.match(/Io non ti ho detto niente|Vai a vederla/)||[''])[0]);break}
 return out});
console.log(r);
// advance dialogs by clicking
for(let i=0;i<40;i++){await p.evaluate(()=>{const b=document.getElementById("dlgBox");b&&b.click()});await p.waitForTimeout(200)}
console.log(await p.evaluate(()=>{const P=Pirati;return {ship:P.Ch2.st().said.ship,gi:P.S?P.S.q.c6.gi:null,tr:P.Ch2.st().trust}}));
console.log('errs',er);await b.close()})();
