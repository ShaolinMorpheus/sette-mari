const {chromium}=require('playwright');
const W=process.argv[2]==='2';
(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:480}})).newPage();
if(W)await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
if(W)await p.evaluate(()=>{const P=Pirati;localStorage.setItem(P.saveKey(),JSON.stringify(P.Ch2.convert(P.newState('D','m'))));P.startContinue('',null)});
else await p.evaluate(()=>Pirati.startNew('T','m'));
await p.waitForTimeout(2000);
const r=await p.evaluate(()=>{const P=Pirati;const cov={};for(const e of P.E){if(e.fp&&e.blocked){for(let j=0;j<e.fp[3];j++)for(let i=0;i<e.fp[2];i++){const k=(e.fp[0]+i)+','+(e.fp[1]+j);cov[k]=(cov[k]||0)+1}}}
 const stale=[],miss=[];for(let y=0;y<60;y++)for(let x=0;x<99;x++){const t=P.tileInfo(x,y);const c=cov[x+','+y]||0;if(t.block!==c)stale.push([x,y,t.block,c])}
 return {stale:stale.slice(0,40),n:stale.length}});
console.log(JSON.stringify(r));await b.close()})();
