/* ====== CAPITOLO 2 — B: missioni, scambi, notte, finali ====== */
const CP={x:57.4*TS,y:30.2*TS};
const qAct=(id,gi)=>{const q=S.q[id];return !!q&&q.st==='active'&&(gi==null||q.gi===gi)};
const qDone=id=>!!S.q[id]&&S.q[id].st==='done';
const costTxt=c=>Object.keys(c).map(k=>c[k]+' '+RNAME[k].toLowerCase()).join(', ');
const C2COST={prova:{legna:10,pietra:6,arrosto:3},vele:{tela:5,corda:4},cantiere:{legna:14,corda:6,rottami:8,pietra:4},rifornimenti:{arrosto:4,coco:6},banchetto:{arrosto:2,molluschi:2,bacche:2,coco:2},attrezzi:{pietra:4,rottami:3}};
/* consegna generica: compare nel menu del personaggio quando la missione è a quel passo */
function dlvH(w,qid,gi,cost,label,ask,after){
  Ch2.QH.push({w,active:()=>qAct(qid,gi),ready:()=>hasRes(cost),label:()=>label,run(){
    if(!hasRes(cost)){UI.dlg([D(w,ask),D(w,"Mi serve: "+costTxt(cost)+".")]);return}
    payRes(cost);UI.sync();sfx('ok');after();
  }});
}
const C=()=>Ch2.st();
/* ---------- missioni principali ---------- */
Object.assign(QDEF,{
c1:{kind:'main',title:"Terra!",blurb:"Una nuova isola. Prima di tutto: l'acqua.",
  goals:[{k:'flag',done:()=>!!S.flags.c2drank,txt:"Trova il laghetto a ovest e bevi",hint:"Il laghetto è poco a nord della spiaggia. Avvicinati e premi «Bevi».",mark:()=>({x:FIX.pond.x*TS,y:FIX.pond.y*TS,up:20})}],
  onDone(){UI.dlg([D('hero',"Acqua dolce. Il mondo torna a mettersi a fuoco."),D('hero',"Il fumo veniva da est. Ma prima un campo mio: fuoco e tetto. Poi andrò a vedere chi c'è.")],()=>startQuest('c2'))}},
c2:{kind:'main',title:"Ricominciare da capo",blurb:"Un fuoco e un tetto, anche su un'isola nuova.",
  goals:[{k:'build',id:'falo',txt:"Costruisci il Falò (piazzola vicino alla spiaggia)",hint:"Servono i materiali che hai con te: raccogli legna e pietra se ne mancano.",mark:()=>pt(plotE('falo'),50)},
         {k:'build',id:'capanna',txt:"Costruisci la Capanna",hint:"La piazzola grande vicino al falò.",mark:()=>pt(plotE('capanna'),70)}],
  onDone(){UI.dlg([D('hero',"Fuoco acceso, tetto sulla testa. Ora vediamo chi fa quel fumo a est.")],()=>startQuest('c3'))}},
c3:{kind:'main',title:"Voci oltre gli alberi",blurb:"A est, un fumo e delle tende: il Campo dei Fuggiaschi.",
  goals:[{k:'reach',x:CP.x,y:CP.y,r:4.6*TS,txt:"Raggiungi il campo a est (segui il sentiero)",hint:"Dalla spiaggia, il sentiero porta a est tra gli alberi.",mark:()=>({x:CP.x,y:CP.y,up:60}),
    dlg:()=>[D('hero',"Un campo vero: tende, una bandiera, una vela stesa ad asciugare. E un uomo con le braccia incrociate che mi aspetta."),
      D('ferro',"Ti ho visto arrivare dalla spiaggia, {cap}. Su un rottame che galleggia. O sei molto testardo, o molto stupido."),
      D('ferro',"Io sono Ferro. Questo campo è mio. Chi sta qui, lavora. Chi lavora, mangia. Chi mente se ne va."),
      D('ferro',"Cosa vuoi?",{choices:[
        {t:"Solo un posto dove restare.",fn:()=>{C().ch.arr='humble';Ch2.addTrust('ferro',1,1)},next:[D('ferro',"Un posto si guadagna. Tre giorni. Poi si vede.")]},
        {t:"Obbedirò agli ordini, se sono giusti.",fn:()=>{C().ch.arr='order';Ch2.addTrust('ferro',2,1)},next:[D('ferro',"Gli ordini non sono giusti o sbagliati. Sono ordini."),D('ferro',"Ma la risposta mi piace. Per ora.")]},
        {t:"Non prendo ordini da nessuno.",fn:()=>{C().ch.arr='proud';Ch2.addTrust('ferro',-1,1);Ch2.addTrust('nives',1,1)},next:[D('ferro',"Allora prenderai la strada del mare. Quando vorrai."),D('ferro',"Fino ad allora, ti guardo.")]}]}),
      D('ferro',"Se vuoi restare, dimostralo. Dieci tronchi, sei pietre, tre pesci arrosto. Portali qui.")]}],
  onDone(){startQuest('c4')}},
c4:{kind:'main',title:"La prova di Ferro",blurb:"Dieci legna, sei pietre, tre pesci arrosto: per Ferro, un benvenuto.",
  goals:[{k:'flag',done:()=>!!C().ch.prova,txt:()=>"Consegna a Ferro: "+costTxt(C2COST.prova),hint:"Parla con Ferro, al centro del campo (vicino alla grande tenda): «Consegna il carico».",mark:()=>pt(EID.npc_ferro,110)}],
  onDone(){startQuest('c5')}},
c5:{kind:'main',title:"Gente del campo",blurb:"Al campo non c'è solo Ferro.",
  goals:[{k:'flag',done:()=>Ch2.metCount()>=3,txt:()=>"Conosci gli altri: Nives, Gnocco e Tito ("+Ch2.metCount()+"/3)",hint:"I personaggi con il «!» sopra la testa hanno qualcosa da dire.",mark:()=>{const e=nearestE(['npc'],n=>!C().met[n.who]&&n.who!=='ferro');return pt(e,110)}}],
  onDone(){UI.dlg([D('hero',"Un capo che non sorride, una fabbra che minaccia, un cuoco che sfida il sale e un ragazzo che non c'era."),D('hero',"Sono una squadra strana. Ma una squadra.")],()=>startQuest('c6'))}},
c6:{kind:'main',title:"La nave senza nome",blurb:"Ferro custodisce un segreto in una cala a sud-est.",
  goals:[{k:'flag',done:()=>!!C().said.ship,txt:"Chiedi a Ferro della nave",hint:"Parla con Ferro: «Chiedi della nave».",mark:()=>pt(EID.npc_ferro,110)},
         {k:'reach',x:CV2.ship[0]*TS,y:(CV2.ship[1]+3.2)*TS,r:5*TS,txt:"Raggiungi la nave, nella cala a sud-est",hint:"Segui il sentiero a sud-est del campo, fino al mare.",mark:()=>({x:CV2.ship[0]*TS,y:(CV2.ship[1]+1)*TS,up:140}),
    dlg:()=>[D('hero',"Una nave vera. Chiglia intera, fiancate sventrate, nessun albero. Sul fasciame, un nome quasi cancellato: «…ena»."),D('hero',"Mancano tre pezzi, ha detto Ferro: l'albero maestro, il timone, le vele."),D('hero',"L'albero lo darà il Pino Maestro, in cima alla collina a nord-est. Il resto... si vedrà.")]}],
  onDone(){startQuest('c7')}},
c7:{kind:'main',title:"L'albero maestro",blurb:"Un pino alto, dritto, antico. Ci vorrà un'ascia buona e molto fiato.",
  goals:[{k:'flag',done:()=>!!C().parts.mast,txt:"Abbatti il Pino Maestro (collina a nord-est): servono molti colpi",hint:"È sulle alture a nord-est. Con l'ascia affilata ci vuole meno tempo.",mark:()=>pt(EID.mast,150)}],
  onDone(){UI.dlg([D('hero',"Cade con un tonfo che si sente in tutta l'isola. Il pezzo più grande è andato."),D('hero',"Restano il timone e le vele.")],()=>startQuest('c8'))}},
c8:{kind:'main',title:"Il timone nascosto",blurb:"Il timone non è sulla nave. Qualcuno sa dove l'hanno messo.",
  goals:[{k:'flag',done:()=>Ch2.tr('tito')>=5,txt:()=>"Guadagnati la fiducia di Tito ("+Ch2.tr('tito')+"/5): parlagli, aiutalo",hint:"Chiacchiera con lui (una volta al giorno dà fiducia) e fai le sue richieste.",mark:()=>pt(EID.npc_tito,110)},
         {k:'flag',done:()=>!!C().said.rudder,txt:"Chiedi a Tito del timone",hint:"Parla con Tito: «Chiedi del timone».",mark:()=>pt(EID.npc_tito,110)},
         {k:'flag',done:()=>!!C().parts.rudder,txt:"Cerca il timone nella grotta (serve una torcia accesa)",hint:"La grotta è a sud-ovest del campo. Costruisci la Torcia nel Banco e accendila (pulsante a fiamma).",mark:()=>pt(EID.cave,100)}],
  onDone(){startQuest('c9')}},
c9:{kind:'main',title:"Le vele di Nives",blurb:"Tela, corda, mani esperte: le vele non si comprano.",
  goals:[{k:'gain',res:'tela',n:5,txt:()=>"Procurati tela di vela ("+Math.min(5,S.res.tela||0)+"/5): scambia con Nives, cerca nelle casse",hint:"Nives scambia tela per altri materiali (Bancarella al campo). Le casse sparse per l'isola ne danno ogni tanto."},
         {k:'flag',done:()=>!!C().parts.sails,txt:()=>"Consegna a Nives: "+costTxt(C2COST.vele),hint:"Parla con Nives: «Consegna il materiale».",mark:()=>pt(EID.npc_nives,110)}],
  onDone(){UI.dlg([D('hero',"Le vele sono pronte. Restano soltanto i lavori sullo scafo.")],()=>startQuest('c10'))}},
c10:{kind:'main',title:"Il cantiere",blurb:"Scafo, albero, timone e vele: tutto va montato.",
  goals:[{k:'flag',done:()=>!!C().parts.yard,txt:()=>"Porta alla nave: "+costTxt(C2COST.cantiere),hint:"Avvicinati alla nave e usa «Esamina».",mark:()=>({x:CV2.ship[0]*TS,y:(CV2.ship[1]+.5)*TS,up:120})}],
  onDone(){startQuest('c11')}},
c11:{kind:'main',title:"La notte prima di salpare",blurb:"La nave è pronta. Il campo si riunisce intorno al fuoco.",
  goals:[{k:'flag',done:()=>!!C().ch.assembly,txt:"Al campo, di sera, per la riunione (dalle 19 in poi)",hint:"Aspetta che faccia sera e torna al campo. Puoi riposare nella Capanna.",mark:()=>({x:CP.x,y:CP.y,up:60})}],
  onDone(){startQuest('c12')}},
c12:{kind:'main',title:"Rifornimenti",blurb:"Nessuno parte a stomaco vuoto.",
  goals:[{k:'flag',done:()=>!!C().ch.supplies,txt:()=>"Consegna a Gnocco: "+costTxt(C2COST.rifornimenti),hint:"Parla con Gnocco: «Consegna il cibo».",mark:()=>pt(EID.npc_gnocco,110)}],
  onDone(){UI.dlg([D('gnocco',"Provviste a bordo, il brodo in pentola. Il resto è fede."),D('hero',"Tutto pronto. La nave aspetta.")],()=>startQuest('c13'))}},
c13:{kind:'main',title:"Salpare",blurb:"Ogni scelta fatta fin qui pesa sulla nave. Ora decidi come partire.",
  goals:[{k:'flag',done:()=>!!S.flags.ch2end,txt:"Vai alla nave e salpa",hint:"Alla nave usa «Esamina». Cosa scegli, e con chi, cambia il finale.",mark:()=>({x:CV2.ship[0]*TS,y:(CV2.ship[1]+.5)*TS,up:120})}]}
});
/* ---------- missioni secondarie ---------- */
Object.assign(QDEF,{
n1:{kind:'side',title:"Il banchetto di Gnocco",blurb:"Gnocco sogna un pasto vero. Per tutti.",avail:()=>qDone('c5'),
  goals:[{k:'flag',done:()=>!!C().ch.banq,txt:()=>"Porta a Gnocco: "+costTxt(C2COST.banchetto),hint:"Parla con Gnocco: «Consegna gli ingredienti».",mark:()=>pt(EID.npc_gnocco,110)}]},
n2:{kind:'side',title:"Gli attrezzi di Nives",blurb:"Il banco di lavoro di Nives ha bisogno di materiale.",avail:()=>qDone('c5'),
  goals:[{k:'flag',done:()=>!!C().ch.attr,txt:()=>"Porta a Nives: "+costTxt(C2COST.attrezzi),hint:"Parla con Nives: «Consegna il materiale».",mark:()=>pt(EID.npc_nives,110)}]},
n3:{kind:'side',title:"Il coltello di Tito",blurb:"Tito ha perso un coltello, ma «non ero io».",avail:()=>!!C().met.tito,
  goals:[{k:'flag',done:()=>!!C().knife,txt:"Cerca il coltello di Tito (sulla costa sud-ovest)",hint:"Brilla poco, tra la sabbia e gli scogli a sud-ovest del campo.",mark:()=>{const e=EID.lt_knife;return e&&!e.got?pt(e,40):null}},
         {k:'flag',done:()=>!!C().ch.knifeBack,txt:"Restituisci il coltello a Tito",hint:"Parla con Tito.",mark:()=>pt(EID.npc_tito,110)}]},
n4:{kind:'side',title:"La lite delle razioni",blurb:"Nives e Gnocco litigano per le razioni. Qualcuno deve decidere.",avail:()=>qDone('c5'),
  goals:[{k:'flag',done:()=>!!C().ch.lite,txt:"Ascolta Gnocco e risolvi la lite",hint:"Parla con Gnocco: «Chiedi della lite».",mark:()=>pt(EID.npc_gnocco,110)}]},
n5:{kind:'side',title:"Chi ha bevuto l'acqua?",blurb:"Dalla cisterna del campo sparisce acqua, ogni notte.",avail:()=>qDone('c7'),
  goals:[{k:'flag',done:()=>(C().clues||0)>=3,txt:()=>"Cerca tre indizi vicino al campo ("+Math.min(3,C().clues||0)+"/3)",hint:"Impronte, ciotole, tracce: guardale da vicino («Esamina»).",mark:()=>{const e=nearestE(['deco'],d=>d.spr==='clue'&&!d.seen);return pt(e,30)}},
         {k:'flag',done:()=>!!C().ch.puppy,txt:"Parla con Tito di quel che hai scoperto",hint:"Parla con Tito: «Parla del furto d'acqua».",mark:()=>pt(EID.npc_tito,110)}]},
n6:{kind:'side',title:"Turni di guardia",blurb:"Di notte qualcuno rovista tra le scorte.",avail:()=>!!S.q.c8,
  onStart(){UI.dlg([D('ferro',"Di notte c'è qualcosa che rovista nelle scorte. Non so cosa sia."),D('ferro',"Fai la guardia: dopo le 21, resta al campo. Quando li vedi, scacciali. Quattro volte.")])},
  goals:[{k:'flag',done:()=>(C().scared||0)>=4,txt:()=>"Scaccia i ladri notturni dal campo ("+Math.min(4,C().scared||0)+"/4): dopo le 21.30",hint:"Resta vicino alla bancarella di notte. Quando compare un'ombra, premi «Scaccia».",mark:()=>pt(EID.c2stall,40)}],
  onDone(){Ch2.addTrust('ferro',2);UI.dlg([D('ferro',"Il campo è più tranquillo. Hai fatto il tuo turno."),D('ferro',"Bene.")])}},
n7:{kind:'side',title:"L'isola orientale",blurb:"A est, oltre il canale, un'isoletta isolata. Si raggiunge solo con la zattera.",avail:()=>qDone('c5'),
  goals:[{k:'reach',x:83*TS,y:29*TS,r:5*TS,txt:"Raggiungi l'isoletta a est con la zattera",hint:"Dalla zattera (spiaggia a ovest) costeggia a nord e poi verso est. Il mare è lungo.",mark:()=>({x:83*TS,y:29*TS,r:4*TS,up:10})},
         {k:'flag',done:()=>!!C().east,txt:"Apri la cassa sull'isoletta",hint:"È proprio al centro.",mark:()=>{const e=EID.lt_east;return e&&!e.got?pt(e,60):null}}]},
n8:{kind:'side',title:"Il diario di J.",blurb:"Quattro pagine sparse, strappate, della stessa mano.",avail:()=>!!S.q.c3||(C().pages||0)>0,
  goals:[{k:'flag',done:()=>(C().pages||0)>=4,txt:()=>"Trova le pagine del diario ("+(C().pages||0)+"/4)",hint:"Sono nascoste in quattro punti lontani dell'isola: brillano di giorno e di notte.",mark:()=>{const e=nearestE(['loot'],l=>l.kind===11&&!l.got);return pt(e,50)}}],
  onDone(){UI.dlg([D('hero',"J. è Giacomo Marrone, il capitano della Sirena. Lo stesso J. delle bottiglie dell'isola dove sono approdato."),D('hero',"Non era un naufrago: ha lasciato un segnale per chi sarebbe arrivato dopo."),D('biscotto',"Cra! Un segnale! Per noi!")])}}
});
/* ---------- consegne e dialoghi con i personaggi ---------- */
dlvH('ferro','c4',0,C2COST.prova,"Consegna il carico di Ferro","Hai il carico?",()=>{
  UI.dlg([D('ferro',"Dieci tronchi. Sei pietre. Tre pesci. Contati."),D('ferro',"Resti. Alle mie condizioni.")],()=>{Ch2.addTrust('ferro',2);C().ch.prova=1;checkAll()})});
Ch2.QH.push({w:'ferro',active:()=>qAct('c6',0),label:()=>"Chiedi della nave",run(){
  UI.dlg([D('hero',"Ferro, ho visto dei pezzi di fasciame in giro. C'è una nave?"),D('ferro',"C'è. In una cala a sud-est. Senza albero, senza timone, senza vele."),D('ferro',"Con tre pezzi e molto lavoro, si parte. Ci sono posti per pochi."),D('hero',"Quanti?"),D('ferro',"Quanti ne decido io."),D('ferro',"Vai a vederla. Poi torna.")],()=>{C().said.ship=1;checkAll()})}});
Ch2.QH.push({w:'tito',active:()=>qAct('c8',1),ready:()=>true,label:()=>"Chiedi del timone",run(){
  UI.dlg([D('hero',"Tito, il timone della nave. Sai dov'è?"),D('tito',"Io? Non so niente. Non ero lì... "),D('tito',"...Va bene. Lo so. Ferro l'ha nascosto nella grotta a sud-ovest, quella con il muschio. Ha detto «per sicurezza»."),D('tito',"Ma non è sicurezza. È che il timone è il modo di decidere chi parte. Ci vuole una torcia, dentro è buio pesto.")],()=>{C().said.rudder=1;Ch2.addTrust('tito',1);checkAll()})}});
dlvH('nives','c9',1,C2COST.vele,"Consegna il materiale per le vele","Le vele?",()=>{
  UI.dlg([D('nives',"Tela buona, corda buona. Dammi una notte."),D('nives',"E se qualcuno dice che le vele sono storte, la storta è la sua testa.")],()=>{Ch2.addTrust('nives',2);C().parts.sails=1;checkAll()})});
dlvH('gnocco','c12',0,C2COST.rifornimenti,"Consegna i rifornimenti","Il cibo?",()=>{
  UI.dlg([D('gnocco',"Quattro arrosti, sei noci. Una dispensa da re. O da naufraghi molto ottimisti."),D('gnocco',"Il brodo lo faccio io.")],()=>{Ch2.addTrust('gnocco',2);C().ch.supplies=1;checkAll()})});
dlvH('gnocco','n1',0,C2COST.banchetto,"Consegna gli ingredienti del banchetto","Gli ingredienti?",()=>{
  UI.dlg([D('gnocco',"Arrosto, molluschi, bacche, cocco. Stasera si mangia come un capitano... ma uno allegro."),D('gnocco',"Da oggi, per te, ricette nuove. Chiedimi di cucinare.")],()=>{Ch2.addTrust('gnocco',2);C().ch.banq=1;C().gn=1;checkAll()})});
dlvH('nives','n2',0,C2COST.attrezzi,"Consegna il materiale degli attrezzi","Il materiale?",()=>{
  UI.dlg([D('nives',"Pietra giusta, ferro vecchio. Con questo ti faccio un lavoro come si deve."),D('nives',"Tieni: te lo restituisco più affilato di prima.")],()=>{
    Ch2.addTrust('nives',2);C().ch.attr=1;
    const k=!S.up.axe?'axe':!S.up.boots?'boots':null;
    if(k){S.up[k]=1;UI.banner('Regalo di Nives',UPGR[k].name);sfx('quest');UI.sync()}else{gain('tela',2,P.x,P.y)}
    checkAll()})});
Ch2.QH.push({w:'tito',active:()=>qAct('n3',1),ready:()=>true,label:()=>"Restituisci il coltello",run(){
  UI.dlg([D('hero',"Credo sia tuo."),D('tito',"Il mio coltello! L'avevo... no. Non l'avevo perso. L'ho lasciato lì."),D('tito',"Sei la prima persona che mi riporta qualcosa invece di toglierlo."),D('tito',"Grazie. Davvero.")],()=>{Ch2.addTrust('tito',3);C().ch.knifeBack=1;checkAll()})}});
Ch2.QH.push({w:'gnocco',active:()=>qAct('n4',0),ready:()=>true,label:()=>"Chiedi della lite",run(){
  UI.dlg([D('gnocco',"Nives dice che il pesce va diviso in parti uguali. Io dico: a chi lavora di più."),D('gnocco',"Lei lavora il ferro. Io lavoro con il fuoco. Chi ha ragione?",{choices:[
    {t:"Gnocco: a chi lavora di più.",fn:()=>{Ch2.addTrust('gnocco',2);Ch2.addTrust('nives',-1);C().ch.liteW='gnocco'},next:[D('gnocco',"Un giudice! Finalmente!"),D('nives',"Non è giusto, ma lo accetto. Per ora.")]},
    {t:"Nives: parti uguali per tutti.",fn:()=>{Ch2.addTrust('nives',2);Ch2.addTrust('gnocco',-1);C().ch.liteW='nives'},next:[D('nives',"Ecco! Qualcuno con la testa sulle spalle."),D('gnocco',"Il mio stomaco protesta. Ma non troppo.")]},
    {t:"Divido io: aggiungo due pesci arrosto dalle mie scorte.",fn:()=>{if((S.res.arrosto||0)>=2){S.res.arrosto-=2;UI.sync();Ch2.addTrust('nives',1);Ch2.addTrust('gnocco',1);C().ch.liteW='both'}else{C().ch.liteW='gnocco';Ch2.addTrust('gnocco',1)}},next:[D('gnocco',"Due pesci... e la pace. Che spettacolo."),D('nives',"Non è un compromesso. È un tributo. Ma lo apprezzo.")]}]})],()=>{C().ch.lite=1;checkAll()})}});
Ch2.QH.push({w:'tito',active:()=>qAct('n5',1),ready:()=>true,label:()=>"Parla del furto d'acqua",run(){
  UI.dlg([D('hero',"Ho trovato impronte piccole, una ciotola e un po' di pelo vicino alla cisterna."),D('tito',"...Io non ero lì."),D('hero',"Tito."),D('tito',"Va bene! C'è un cucciolo. Un cane, o quasi. L'ho trovato sulla spiaggia. Lo tengo nascosto vicino alle barche."),D('tito',"Ferro lo caccerebbe. Dice che le bocche in più sono un problema. Cosa faccio?",{choices:[
    {t:"Mantengo il segreto: lo nascondiamo insieme.",fn:()=>{Ch2.addTrust('tito',3);Ch2.addTrust('ferro',-1);C().ch.puppy='secret'},next:[D('tito',"Davvero? Non lo dirai a nessuno?"),D('hero',"A nessuno. Ma l'acqua gliela porti tu."),D('tito',"Promesso. Il cane si chiama Briciola. È una femmina.")]},
    {t:"Lo dico a Ferro: lo scoprirà comunque.",fn:()=>{Ch2.addTrust('ferro',2);Ch2.addTrust('tito',-3);C().ch.puppy='told'},next:[D('tito',"...Ti credevo diverso."),D('tito',"Va bene. Fai quello che devi.")]},
    {t:"Lo presento a Gnocco: un cane può fare il guardiano.",fn:()=>{Ch2.addTrust('tito',2);Ch2.addTrust('gnocco',1);C().ch.puppy='gnocco'},next:[D('tito',"Gnocco? Ma... sì! Magari gli serve un assaggiatore."),D('gnocco',"Un assaggiatore? Con la coda? È già assunto.")]}]})],()=>{checkAll()})}});
/* ---------- oggetti del mondo ---------- */
Ch2.onMast=function(e){
  C().parts.mast=1;sfx('quest');sparkBurst(e.x,e.y-60,14);
  UI.dlg([D('hero',"Il Pino Maestro è a terra: dritto come una lancia, lungo come la nave."),D('hero',"Il difficile sarà portarlo fino alla cala.")],()=>{checkAll()});
};
Ch2.onLoot=function(e){
  const c=C();
  if(e.id==='lt_knife'){c.knife=1;UI.dlg([D('hero',"Un coltello da marinaio con il manico intagliato. Sul legno, una «T» incisa male."),D('hero',"Ha l'aria di essere stato lasciato qui di proposito.")],()=>checkAll());return true}
  if(e.id&&e.id.indexOf('lt_pg')===0){
    const i=+e.id.slice(5);c.pages=(c.pages||0)+1;
    const T=["«Sirena, giorno 3. Il capitano sono io, ma è l'equipaggio che tiene a galla la barca. Non dimenticarlo, Giacomo.»","«Ho incontrato un uomo, Ferro, sull'isola grande. Dice di essere l'unico sopravvissuto del suo equipaggio. I conti non tornano: la sua nave aveva trenta uomini.»","«Ferro conta i posti, non le persone. Ho visto il suo quaderno: otto posti, nove nomi. Ha cancellato quelli che non gli servono.»","«Se leggi questo, sono già in mare. Sulla Sirena c'è ancora posto. Cerca la stella bassa a ovest e non dire a Ferro dove vai. — Giacomo M.»"];
    sfx('ok');UI.dlg([D('hero',"Pagina "+(c.pages)+"/4 del diario di J."),D('hero',T[i%4])],()=>checkAll());return true}
  if(e.id==='lt_east'){
    c.east=1;gain('tela',3,e.x,e.y);gain('corda',3,e.x,e.y-20);
    S.phats=S.phats||{};const miss=PHATS.find(h=>!S.phats[h.id]);if(miss)S.phats[miss.id]=1;
    UI.dlg([D('hero',"Una cassa dimenticata, piena di tela buona e corda. E sul fondo, un cappellino per Biscotto: "+(miss?miss.n:"un fazzoletto")+"."),D('biscotto',"Cra! Elegante!")],()=>{if(miss)UI.banner('Cappellino per il pappagallo',miss.n);checkAll()});return true}
  return false;
};
Ch2.look=function(e){
  const c=C();
  if(e.spr==='clue'){
    if(!e.seen&&qAct('n5',0)){e.seen=1;c.clues=(c.clues||0)+1;sfx('ok');
      const T=["Impronte piccole nel fango, che finiscono dietro le barche.","Una ciotola graffiata, ancora umida, nascosta tra le casse.","Peli chiari impigliati nella rete della cisterna."];
      UI.dlg([D('hero',T[e.k%3])],()=>checkAll())}
    else UI.toast(e.seen?"Già controllato.":"Tracce di zampe. Forse niente.");
    return true}
  if(e.id==='cave'){
    if(c.parts.rudder){UI.dlg([D('hero',"La grotta è vuota. Il timone è fuori, dove serve.")]);return true}
    if(!qAct('c8',2)){UI.dlg([D('hero',"Una grotta buia, muschio sulle pietre. Meglio non entrare senza motivo."),D('hero',"Magari Tito sa qualcosa di questo posto.")]);return true}
    if(!(S.up.torch&&S.torchOn)){UI.dlg([D('hero',"Buio pesto. Mi serve una torcia accesa. Si costruisce al Banco, si accende col pulsante a fiamma.")]);return true}
    c.parts.rudder=1;c.ch.note=1;sfx('quest');
    UI.dlg([D('hero',"Il timone, avvolto in un telo cerato. E sopra, un biglietto con la grafia di Ferro."),D('hero',"«Otto posti. Tre nomi. Gli altri aspetteranno la prossima nave. — F.»"),D('hero',"«La prossima nave». Non ci sarà nessuna prossima nave."),D('hero',"Ferro non ha mai pensato di portarli tutti.")],()=>{checkAll()});return true}
  if(e.id==='nave'){
    if(S.flags.ch2end){UI.dlg([D('hero',"La nave ha già compiuto il suo viaggio. Qui, ora, c'è solo la sua ombra.")]);return true}
    if(qAct('c10',0)){
      const cost=C2COST.cantiere;
      if(!hasRes(cost)){UI.dlg([D('hero',"Lo scafo è da rimettere in sesto. Mi serve: "+costTxt(cost)+".")]);return true}
      payRes(cost);UI.sync();c.parts.yard=1;sfx('hammer');sparkBurst(e.x,e.y-60,20);e.spr='shipOur';
      UI.dlg([D('hero',"Albero, timone, vele, fasciame. Una chiglia che torna a respirare."),D('hero',"La nave non ha ancora un nome. Ma sta in piedi.")],()=>{checkAll()});return true}
    if(qAct('c13',0)||qAct('c12',0)){
      if(qAct('c12',0)){UI.dlg([D('hero',"La nave è quasi pronta. Mancano le provviste: parla con Gnocco.")]);return true}
      Ch2.launch();return true}
    if(c.parts.yard){UI.dlg([D('hero',"La nave è montata e ben legata.")])}
    else{const p=c.parts;UI.dlg([D('hero',"La nave senza nome. Pezzi a posto: albero "+(p.mast?'sì':'no')+", timone "+(p.rudder?'sì':'no')+", vele "+(p.sails?'sì':'no')+".")])}
    return true}
  return false;
};
/* ---------- commercio e cucina ---------- */
Ch2.OFFERS=[{give:{pesce:3},get:{corda:2}},{give:{coco:2},get:{rottami:1}},{give:{pietra:4},get:{rottami:3}},{give:{legna:4},get:{pietra:2}},{give:{corda:2,rottami:2},get:{tela:1}},{give:{pesce:2,bacche:2},get:{tela:1}},{give:{arrosto:2},get:{tela:2}}];
Ch2.openTrade=function(){
  const draw=()=>{
    const d=Math.floor(Ch2.tr('nives')/3);
    const adj=cst=>{const o=Object.assign({},cst),k=Object.keys(o)[0];o[k]=Math.max(1,o[k]-d);return o};
    let h='<h2>Bancarella di Nives</h2><p>«Roba buona per roba buona.»'+(d?' Sconto fiducia: −'+d+' sul primo materiale.':'')+'</p>';
    Ch2.OFFERS.forEach((o,i)=>{
      const give=adj(o.give);
      h+='<div class="upg" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:center">'+costHtml(give)+'<b>→</b><div class="costs">'+Object.keys(o.get).map(k=>'<span class="cost ok"><svg class="ic"><use href="#i-'+k+'"/></svg>'+o.get[k]+'</span>').join('')+'</div><button class="btn gold" data-t="'+i+'"'+(hasRes(give)?'':' disabled')+'>Scambia</button></div>';
    });
    h+='<div class="row"><button class="btn" id="shNo">Chiudi</button></div>';
    sheetFor(h,cc=>{cc.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>{
      const o=Ch2.OFFERS[+b.dataset.t],give=adj(o.give);if(!hasRes(give)){sfx('no');return}
      payRes(give);for(const k in o.get)gain(k,o.get[k],P.x,P.y-30,true);sfx('ok');UI.sync();
      const c=C();c.deals=(c.deals||0)+1;if(c.deals%3===0)Ch2.addTrust('nives',1);
      Story.onGain();saveGame();draw();
    })});
  };
  draw();
};
Ch2.GN=[
  {id:'brodo',n:"Brodo di Gnocco",d:"Caldo, salato, ricostituente. Dà energia.",cost:{pesce:2,coco:1},h:50,t:25,buff:360},
  {id:'fuggiasco',n:"Piatto del Fuggiasco",d:"Il capolavoro di Gnocco: sazia, dà energia, rallenta la sete.",cost:{arrosto:2,molluschi:2,bacche:1},h:85,t:30,buff:480,bres:480},
  {id:'torta',n:"Torta di bacche e cocco",d:"Dolce e fresca. La sete scende più lenta.",cost:{bacche:4,coco:2},h:40,t:30,bres:480}
];
Ch2.openCook=function(){
  const c=C();
  if(!c.gn){UI.dlg([D('gnocco',"Cucinare per te? Con quello che hai? Portami prima un vero banchetto.")]);return}
  const draw=()=>{
    let h='<h2>La cucina di Gnocco</h2><p>«Mangia, e poi dimmi se ho esagerato col sale.»</p>';
    for(const r of Ch2.GN){const ok=hasRes(r.cost);
      h+='<div class="upg"><h3>'+r.n+'</h3><p class="sm">'+r.d+' (+'+r.h+' fame, +'+r.t+' sete)</p>'+costHtml(r.cost)+'<button class="btn gold" data-g="'+r.id+'"'+(ok?'':' disabled')+'>Mangia</button></div>'}
    h+='<div class="row"><button class="btn" id="shNo">Chiudi</button></div>';
    sheetFor(h,cc=>{cc.querySelectorAll('[data-g]').forEach(b=>b.onclick=()=>{
      const r=Ch2.GN.find(x=>x.id===b.dataset.g);if(!r||!hasRes(r.cost)){sfx('no');return}
      if(S.vit.h>88){UI.toast('Hai ancora poca fame: aspetta un po\'.');sfx('no');return}
      payRes(r.cost);S.vit.h=Math.min(100,S.vit.h+r.h);S.vit.t=Math.min(100,S.vit.t+r.t);
      if(r.buff)S.buff=Math.max(S.buff||0,r.buff);if(r.bres)S.bres=Math.max(S.bres||0,r.bres);
      S.flags.ate=1;sfx('eat');addXp(10);vitFx('+'+r.h+' fame');UI.sync();
      const k=C();k.cooked=(k.cooked||0)+1;if(k.cooked%2===0)Ch2.addTrust('gnocco',1);
      Story.onEat('arrosto');saveGame();draw();
    })});
  };
  draw();
};
/* ---------- ladri notturni ---------- */
Ch2.scare=function(e){
  if(e.flee)return;e.flee=true;e.fleeT=0;sfx('crab');float(e.x,e.y-50,'Via!','#fff');
  const c=C();c.scared=(c.scared||0)+1;
  if(qAct('n6',0))UI.toast('Ladri scacciati: '+Math.min(4,c.scared)+'/4');
  checkAll();
};
function drawThief(g,e,t){
  if(e.gone)return;
  const f=e.flee,w=Math.sin(t*(f?18:11)+e.ph)*1.8;
  g.save();g.translate(e.x,e.y);if(e.dx<0)g.scale(-1,1);shadow(g,0,2,17,5,.32);
  g.strokeStyle='#4a4a52';g.lineWidth=6;g.lineCap='round';g.beginPath();g.moveTo(-14,-14);g.quadraticCurveTo(-26,-18+w,-30,-8);g.stroke();
  g.strokeStyle='#d8d4cc';g.lineWidth=2.2;for(let i=0;i<3;i++){g.beginPath();g.arc(-19-i*3.4,-15+i*1.8+w*.3,2.6,0,6.3);g.stroke()}
  g.fillStyle='#7a7a84';g.beginPath();g.ellipse(0,-14,16,10,0,0,7);g.fill();
  g.fillStyle='#55555d';for(const lx of[-8,8]){g.fillRect(lx-2,-6,4,8+w*.4*(lx<0?1:-1))}
  g.fillStyle='#8a8a94';g.beginPath();g.ellipse(14,-20,8,7,0,0,7);g.fill();
  g.fillStyle='#2b2b32';g.beginPath();g.ellipse(16,-21,7,3.2,0,0,7);g.fill();
  g.fillStyle='#fff';g.beginPath();g.arc(15,-21,1.2,0,7);g.arc(19,-21,1.2,0,7);g.fill();
  g.fillStyle='#1a1a1e';g.beginPath();g.arc(21,-18,1.6,0,7);g.fill();
  g.fillStyle='#7a7a84';g.beginPath();g.moveTo(10,-26);g.lineTo(11,-32);g.lineTo(15,-26);g.fill();g.beginPath();g.moveTo(16,-26);g.lineTo(19,-32);g.lineTo(21,-25);g.fill();
  g.restore();
}
Ch2._th=0;
Ch2.tick=function(dt){
  const c=C();
  // riunione serale
  if(qAct('c11',0)&&!UI.dlgOpen()&&!c.ch.assembly&&(S.tod>=19||S.tod<5)&&hyp(P.x-CP.x,P.y-CP.y)<9*TS)Ch2.assembly();
  // la nave ricostruita
  const nv=EID.nave;if(nv){const sp=c.parts.yard?'shipOur':'wreck';if(nv.spr!==sp)nv.spr=sp}
  // ladri
  const night=S.tod>=21.5||S.tod<5,act=qAct('n6',0);
  const ths=E.filter(e=>e.type==='thief'&&!e.gone);
  if(act&&night&&ths.length<2&&hyp(P.x-CP.x,P.y-CP.y)<20*TS){
    Ch2._th-=dt;
    if(Ch2._th<=0){
      Ch2._th=14+Math.random()*10;
      const a=Math.random()*6.28,tx=Math.floor(CP.x/TS+Math.cos(a)*11),ty=Math.floor(CP.y/TS+Math.sin(a)*8);
      const f=nearestFree(tx,ty,4);
      if(f){const e=E.find(x=>x.type==='thief'&&x.gone);
        const d={x:(f[0]+.5)*TS,y:(f[1]+.8)*TS,gone:false,flee:false,ph:Math.random()*6,dx:1,hx:(f[0]+.5)*TS,hy:(f[1]+.8)*TS};
        if(e)Object.assign(e,d);else ent(Object.assign({id:'th'+E.length,type:'thief',tx:f[0],ty:f[1]},d));
        UI.toast('Un\'ombra si muove tra le casse…');}
    }
  }
  for(const e of ths){
    if(!e.flee){
      const sx=62*TS,sy=31*TS,d=hyp(sx-e.x,sy-e.y);
      if(d<TS*.9){
        const ks=['pesce','arrosto','bacche','coco','molluschi'].filter(k=>(S.res[k]||0)>0),k=ks[(Math.random()*ks.length)|0];
        if(k){const n=Math.min(S.res[k],2);S.res[k]-=n;UI.sync();UI.toast('Un ladro ti ha portato via '+n+' '+RNAME[k].toLowerCase()+'!')}
        e.flee=true;e.fleeT=0;sfx('crab');
      }else{e.dx=sx<e.x?-1:1;e.x+=(sx-e.x)/d*75*dt;e.y+=(sy-e.y)/d*75*dt}
    }else{
      e.fleeT+=dt;const a=Math.atan2(e.y-CP.y,e.x-CP.x);e.dx=Math.cos(a)<0?-1:1;
      e.x+=Math.cos(a)*150*dt;e.y+=Math.sin(a)*150*dt;
      if(e.fleeT>5||!night){e.gone=true;e.x=e.y=-999}
    }
  }
  if(!night)for(const e of ths)if(!e.flee){e.flee=true;e.fleeT=0}
};
/* ---------- scene del capitolo: riunione, partenza, finali ---------- */
Ch2.assembly=function(){
  const c=C();c.ch.assembly='pending';
  UI.dlg([D('ferro',"Tutti qui. Subito."),D('ferro',"La nave è pronta. Parto all'alba. Porto chi serve."),D('nives',"«Chi serve». Bella espressione, Ferro. Dici «chi serve» e intendi «chi ubbidisce»."),D('gnocco',"Intanto io ho cucinato per tutti. E per tutti, intendo tutti."),D('tito',"Io non ci sono. Faccio finta di non esserci."),D('ferro',"Silenzio. {cap}, tu hai portato più di tutti. Parla."),D('hero',"Cosa dico?",{choices:[
    {t:"Partiamo tutti insieme, o nessuno.",fn:()=>{c.ch.assembly='all';['nives','tito','gnocco'].forEach(w=>Ch2.addTrust(w,1,1));Ch2.addTrust('ferro',-1,1)},next:[D('nives',"Ecco! Qualcuno con il cervello."),D('ferro',"...Sul ponte c'è posto. Ma io decido la rotta."),D('gnocco',"Le provviste per tutti. Ci penso io.")]},
    {t:"Decide Ferro: è lui il capo.",fn:()=>{c.ch.assembly='ferro';Ch2.addTrust('ferro',2,1);Ch2.addTrust('nives',-1,1);Ch2.addTrust('tito',-1,1)},next:[D('ferro',"Giusto. Chi sa comandare, comanda."),D('nives',"Mi dispiace, {cap}. Mi aspettavo di meglio."),D('tito',"Io non c'ero. Non c'ero, vero?")]},
    {t:"Decidiamo a voto, tutti.",fn:()=>{c.ch.assembly='vote';Ch2.addTrust('nives',1,1);Ch2.addTrust('tito',1,1);Ch2.addTrust('gnocco',1,1);Ch2.addTrust('ferro',-2,1)},next:[D('ferro',"Un voto. Qui."),D('ferro',"Va bene. Una volta sola."),D('nives',"Hai fatto arrabbiare Ferro. Per me sei già un eroe.")]}]})
  ],()=>{c.ch.assembly=c.ch.assembly==='pending'?'all':c.ch.assembly;UI.toast('Domattina, la nave. Prima i rifornimenti.');checkAll()});
};
Ch2.launch=function(){
  const c=C();let act=null;
  const t=Ch2.tr;
  const night=S.tod>=22||S.tod<4.5;
  UI.dlg([D('hero',"La nave è pronta, con provviste e vele. Una decisione, e non si torna indietro."),D('hero',"Come salpo?",{choices:[
    {t:"Con Ferro, come da ordini.",fn:()=>{act='ferro'}},
    {t:"Con tutti: nessuno resta a terra.",fn:()=>{act='all'}},
    {t:"Da solo, di notte: sono io che decido.",fn:()=>{act='solo'}},
    {t:"Non ancora.",fn:()=>{act=null}}]})],()=>{
    if(act==='all'&&t('nives')+t('tito')+t('gnocco')<15){UI.dlg([D('hero',"Per portarli tutti ci vuole fiducia. Non ne ho ancora abbastanza: parlo con loro, li aiuto, faccio le loro richieste.")]);return}
    if(act==='solo'&&!night){UI.dlg([D('hero',"Partire da solo richiede il buio. Dalle 22 all'alba, quando il campo dorme.")]);return}
    if(act)Ch2.ending(act);
  });
};
Ch2.ENDS={
  ferro:{t:"L'Ordine di Ferro",n:1},ferro2:{t:"Il passeggero clandestino",n:2},all:{t:"Tutti a bordo",n:3},fire:{t:"Il fuoco di Ferro",n:4},solo:{t:"La fuga",n:5}
};
Ch2.ending=function(k){
  const c=C();
  if(k==='ferro'&&t_(c,'tito')>=6&&c.ch.note)k='ferro2';
  if(k==='all'&&Ch2.tr('ferro')<5)k='fire';
  const P_=Ch2.pre();
  const L={
    ferro:[D('hero',"All'alba, la nave lascia la cala con Ferro al timone. Il cielo è pulito. Ogni ordine, eseguito."),D('hero',"Sulla riva, tre sagome immobili. Nives alza una mano. Non la abbassa finché non spariamo."),D('ferro',"Si sopravvive con la disciplina. Il resto sono storie."),D('hero',"Guardo la riva finché non diventa una linea. Una nave in ordine. Un campo vuoto.")],
    ferro2:[D('hero',"All'alba, la nave lascia la cala con Ferro al timone. Sulla riva, tre sagome immobili. Nives alza una mano."),D('hero',"Poi, un barile si muove. Ne esce Tito, rosso fino alle orecchie."),D('tito',"Io non c'ero. Non ero lì. Ma adesso sono qui."),D('ferro',"Alle corde."),D('hero',"È la cosa più vicina a una concessione che Ferro abbia mai fatto. Tito sorride come un sole."),D('hero',"Una nave quasi in ordine. Un campo quasi vuoto.")],
    all:[D('hero',"Alle prime luci, il ponte è pieno: Nives con il martello, Gnocco con il pentolone, Tito arrampicato sulle sartie."),D('ferro',"Un ponte pieno. Non l'avevo mai visto. Conto uno a uno."),D('ferro',"...Alle vele."),D('nives',"Hai sentito? Ha detto «alle vele» e non «silenzio». È un record."),D('gnocco',"Brodo per tutti. Oggi, doppio sale."),D('hero',"La baia si allontana. Nessuno è rimasto a riva.")],
    fire:[D('hero',"All'alba, la nave è pronta con tutti a bordo, tranne uno."),D('ferro',"Una nave piena di indisciplinati non arriverà lontano."),D('hero',"Ferro resta sulla riva con la torcia in mano. La lascia cadere sul campo: le tende, la bancarella, la bandiera. Il fuoco sale."),D('nives',"Perché?!"),D('ferro',"Così nessuno tornerà."),D('hero',"Salpiamo con il fuoco alle spalle. Nives non gli rivolgerà più la parola. Gnocco cucinerà in silenzio, per giorni.")],
    solo:[D('hero',"Nel buio, uno dopo l'altro, taglio gli ormeggi. La nave scivola via come se avesse aspettato questo da sempre."),D('hero',"Sulla riva, una sola luce: Ferro, con la lanterna. Non grida. Alza la lanterna una volta. Poi la spegne."),D('biscotto',"Cra... non ci voleva."),D('hero',(c.pages||0)>=4?"Sul fondo del timone ho scritto le parole di Giacomo: «Cerca la stella bassa a ovest». È dove andrò.":"Davanti a me, il mare. Dietro, tutto il resto.")]
  }[k];
  c.endings=c.endings||{};
  UI.dlg(L,()=>{c.endings[k]=1;S.flags.ch2end=k;sfx('quest');setTimeout(()=>Ch2.endCard(k),700);checkAll();saveGame()});
};
const t_=(c,w)=>(c.trust&&c.trust[w])||0;
Ch2.pre=function(){try{saveGame();localStorage.setItem(saveKey()+'-preend',JSON.stringify(S))}catch(e){}};
Ch2.endCard=function(k){
  const c=C(),e=Ch2.ENDS[k],n=Object.keys(c.endings||{}).length;
  const heart=w=>'<div><b>'+HEARTS(Ch2.tr(w))+'</b>'+Ch2.NPC[w].n+'</div>';
  $('endCard').innerHTML='<div class="seas"><b>Capitolo 2</b><span>La Baia dei Fuggiaschi · completato</span></div><h2>'+e.t+'</h2><p>La baia resta alle spalle. Davanti, il mare aperto.</p><div class="stats">'+['ferro','nives','tito','gnocco'].map(heart).join('')+'<div><b>'+(c.pages||0)+'/4</b>pagine</div><div><b>'+n+'/5</b>finali visti</div></div><p class="sm">Il Capitolo 3 è in arrivo. Intanto puoi tornare indietro e provare un altro finale: ogni scelta e ogni fiducia contano.</p><div class="row"><button class="btn gold" id="eGo">Continua a esplorare</button><button class="btn" id="eRe">Rigioca la partenza</button></div>';
  $('endCard').querySelector('#eGo').onclick=()=>uShow('endcard',false);
  $('endCard').querySelector('#eRe').onclick=()=>{
    try{const k0=saveKey(),raw=localStorage.getItem(k0+'-preend');if(!raw)return;const s=JSON.parse(raw);s.flags.ch2end=0;s.c2.endings=Object.assign({},c.endings);localStorage.setItem(k0,JSON.stringify(s));sessionStorage.setItem('sette-mari-auto','1');S.live=false;location.reload()}catch(e){}
  };
  uShow('endcard',true);
};
/* ---------- il campo, in sintesi (Menu) ---------- */
Ch2.openStatus=function(){
  const c=C(),p=c.parts,ok=v=>v?'✔':'—';
  let h='<h2>Il campo dei Fuggiaschi</h2><p class="sm">Fiducia con i personaggi (cresce parlando ogni giorno e con le missioni).</p><div class="stats">'+['ferro','nives','tito','gnocco'].map(w=>'<div><b>'+HEARTS(Ch2.tr(w))+'</b>'+Ch2.NPC[w].n+'</div>').join('')+'</div>';
  h+='<p>La nave: albero '+ok(p.mast)+' · timone '+ok(p.rudder)+' · vele '+ok(p.sails)+' · cantiere '+ok(p.yard)+'</p><p class="sm">Pagine del diario di J.: '+(c.pages||0)+'/4 · Finali visti: '+Object.keys(c.endings||{}).length+'/5</p><div class="row"><button class="btn" id="shNo">Chiudi</button></div>';
  sheetFor(h);
};
/* ---------- passaggio dal Capitolo 1 ---------- */
Ch2.convert=function(s){
  const n=newState(s.name,s.hero);
  const f=s.flags||{},keep={};for(const k of['parrot','hat','compass','lenza','axe','pick','flint'])if(f[k])keep[k]=1;
  Object.assign(n.flags,keep,{ch1:1,moved:1,acted:1,wreckSeen:1,raftTold:1,sailed:1});
  n.ch=2;n.res=Object.assign(n.res||{},s.res);n.up=Object.assign(n.up||{},s.up);
  n.pname=s.pname;n.phat=s.phat;n.phats=s.phats;n.rec=s.rec;n.xpt=s.xpt;n.cOpen=s.cOpen;n.hints=s.hints;
  n.stat=Object.assign(n.stat||{},s.stat,{built:(s.stat&&s.stat.built)||0});
  n.built={zattera:1};n.es={plot_zattera:{st:2,p:1}};n.q={};n.fog='';n.raftAt=null;n.camp=[];
  n.px=FIX_2.spawn[0]*TS;n.py=FIX_2.spawn[1]*TS;n.hd=0;n.mode='walk';
  n.day=(s.day||1)+1;n.tod=7;n.vit={t:80,h:75};n.torchOn=false;n.tutDone=1;n.tut=null;
  n.c2={};n.sound=s.sound;n.music=s.music;
  return n;
};
Ch2.begin=function(){
  try{
    saveGame();const key=saveKey(),raw=localStorage.getItem(key);if(!raw)return;
    localStorage.setItem(key+'-ch1bak',raw);
    localStorage.setItem(key,JSON.stringify(Ch2.convert(JSON.parse(raw))));
    sessionStorage.setItem('sette-mari-auto','1');S.live=false;location.reload();
  }catch(e){UI.toast('Impossibile avviare il Capitolo 2 su questo browser.')}
};
Ch2.onBegin=function(){
  const c=C();
  if(EID.nave)EID.nave.spr=c.parts.yard?'shipOur':'wreck';
  if(!S.q.c1){
    setTimeout(()=>{UI.banner('Capitolo 2','La Baia dei Fuggiaschi');
      UI.dlg([D('hero',"Mi sveglio con la faccia nella sabbia. Un'altra spiaggia, un altro mare."),D('hero',"Alle spalle, il fumo di ieri. Davanti, una baia, e tende tra gli alberi. Ma ho la gola secca."),D('biscotto',"Cra! Acqua! Poi tutto il resto!")],()=>startQuest('c1'))},400);
  }
};
