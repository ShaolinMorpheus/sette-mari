const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1000,height:500}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.removeItem('sm_c34')}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2500);
const r=await p.evaluate(async()=>{const K=Ch4.K,P=Ch4.P,out=[];const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 K.fol.concat(K.stay).forEach(f=>{f.x=-999;f.y=-999;f.hp=0;f.downT=-1e9});
 K.gd.forEach(g=>g.ko=1e9);K.duels.forEach(d=>d.forEach(q=>q.ko=1e9));
 const g=K.gd[0];const reset=()=>{g.ko=0;g.hp=3;g.st='patrol';g.wait=1e6;g.react=0;g.x=Ch4.cx(24);g.y=(Ch4.OY+9.92)*44;g.face=0;g.flip=false;g.fight=null;g.alert=0};
 // A: dietro, 140px
 reset();P.x=g.x-140;P.y=g.y;await sleep(1200);out.push(['A dietro 140px: stato',g.st]);
 // backstab da vicino
 P.x=g.x-60;P.y=g.y;K.fdx=1;K.fdy=0;K.atk=0;Ch4.atk();await sleep(100);out.push(['A colpo alle spalle: ko',g.ko>0,'back',K.back]);
 // B: davanti 200px
 reset();P.x=g.x+200;P.y=g.y;await sleep(900);out.push(['B davanti 200px: stato',g.st]);
 // C: frontale, spada: 2 colpi
 reset();K.sword=true;g.st='chase';g.alert=5;P.x=g.x+50;P.y=g.y;K.fdx=-1;K.fdy=0;K.atk=0;Ch4.atk();out.push(['C colpo1 con sciabola hp',g.hp]);K.atk=0;await sleep(100);Ch4.atk();out.push(['C colpo2 hp/ko',g.hp,g.ko>0]);
 // D: cannone esca
 reset();g.wait=0;P.x=Ch4.cx(36);P.y=Ch4.cy(14);g.x=Ch4.cx(30);g.y=(Ch4.OY+9.92)*44;
 // porta la guardia sul ponte aperto: stessa ponte, posizione vicino
 g.x=Ch4.cx(33);g.y=(Ch4.OY+9.5)*44;g.face=Math.PI;g.flip=true;Ch4.tp(37,14.5);K.lureCd=0;const o=K.objs.find(q=>q.id==='lure36');o.use();Ch4.tp(34,3);await sleep(300);
 out.push(['D dopo il cannone: stato',g.st,'dest',Math.round(g.sx/44-8),Math.round(g.sy/44-13)]);
 const d0=Math.hypot(g.x-g.sx,g.y-g.sy);await sleep(2500);out.push(['D distanza dalla meta: prima',Math.round(d0),'dopo 2.5s',Math.round(Math.hypot(g.x-g.sx,g.y-g.sy)),g.st]);
 return out});
for(const x of r)console.log(JSON.stringify(x));console.log(er);await b.close()})();
