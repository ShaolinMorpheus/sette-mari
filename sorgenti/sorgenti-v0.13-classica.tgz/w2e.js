const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const w2 of [0,1]){const p=await b.newPage({viewport:{width:900,height:480}});
if(w2)await p.addInitScript(()=>{window.__W2=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
const r=await p.evaluate(()=>{const cnt={};for(const e of Pirati.E)cnt[e.type]=(cnt[e.type]||0)+1;return cnt});
console.log(w2?'W2':'W1',JSON.stringify(r));await p.close()}
await b.close()})();
