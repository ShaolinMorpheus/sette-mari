/* ====== LA GROTTA: mappa interna (solo isola grande) ====== */
var CVX=null;
const CV_W=33,CV_H=12,CV_X0=12,CV_Y0=1;
function inCave(){return WORLD===2&&P.x>=CV_X0*TS&&P.x<(CV_X0+CV_W)*TS&&P.y>=CV_Y0*TS&&P.y<(CV_Y0+CV_H)*TS}
function caveOpen(){const c=C();if(!c||!c.parts||c.parts.rudder)return false;return qAct('c8',2)||!!(S.q.c8&&S.q.c8.st==='done')}
function caveGrid(){
  const G=[];for(let y=0;y<CV_H;y++)G.push(new Array(CV_W).fill(0));
  const ell=(cx,cy,rx,ry,v)=>{for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){const dx=(x+.5-cx)/rx,dy=(y+.5-cy)/ry;if(dx*dx+dy*dy<=1)G[y][x]=v}};
  const cor=(x0,y0,x1,y1,w)=>{const n=Math.ceil(Math.hypot(x1-x0,y1-y0)*3);for(let i=0;i<=n;i++){const t=i/n;ell(x0+(x1-x0)*t,y0+(y1-y0)*t,w,w,1)}};
  cor(16,11.8,16,9.6,1.7);ell(16,9,6.6,2.2,1);                       // ingresso e sala sud
  cor(10.5,9,7.4,6.6,1.3);cor(7.4,6.6,6.5,4.8,1.3);ell(6.2,3.4,5.2,2.2,1);ell(2.9,6.1,1.8,1.4,1);   // ramo ovest
  cor(16,7.6,16,5,1.3);ell(16,3.5,5,2.1,1);                          // sala nord
  cor(22,9,25.5,7.3,1.3);cor(25.5,7.3,27.3,5.2,1.3);ell(28.3,3.3,4,2.1,1);   // ramo est (timone)
  cor(20,3.4,24.5,3.3,1);                                           // collegamento tra le sale nord
  cor(22.5,9.6,26.5,10,1.1);ell(28.6,9.6,2.8,1.5,1);                 // nicchia sud-est
  ell(12.8,9.1,.62,.62,0);ell(19.4,9.2,.62,.62,0);ell(16,3.6,.62,.62,0);
  CV_POOLS.forEach(p=>ell(p[0],p[1],p[2],p[3],2));
  for(let x=0;x<CV_W;x++)G[0][x]=0;for(let y=0;y<CV_H;y++){G[y][0]=0;G[y][CV_W-1]=0}
  return G;
}
const CV_POOLS=[[4.8,3.3,2,.9],[18.4,2.9,1.5,.7],[29.7,10,1.1,.55],[11.2,10.4,1.2,.6]];
function caveBuild(){
  const G=caveGrid();CVX={G,cr:[],st:[],bats:[],drops:[],rings:[],fade:0,hint:0,dripT:3,batSay:0};
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){const i=tIdx(CV_X0+x,CV_Y0+y);walkT[i]=G[y][x]===1?1:0}
  const r=mulberry(4242);
  const wallN=(x,y)=>G[y-1]&&G[y-1][x]===0;
  const roost=[];
  for(let y=1;y<CV_H;y++)for(let x=1;x<CV_W-1;x++){
    if(G[y][x]!==1||!wallN(x,y))continue;
    roost.push([x,y]);
    if(r()<.26)CVX.st.push({x:(CV_X0+x+.2+r()*.6)*TS,y:(CV_Y0+y+.35+r()*.2)*TS,s:.7+r()*.7,k:r()<.3?1:0});
  }
  [[3.2,5.4],[9,2.2],[13.2,10.3],[19.4,2.3],[24,7.7],[30.6,2.3],[28.5,9.4],[21.5,10.4],[16.2,5.3],[26.2,2.4],[2.6,6.3]].forEach(p=>{const x=Math.floor(p[0]),y=Math.floor(p[1]);if(G[y]&&G[y][x]===1)CVX.cr.push({x:(CV_X0+p[0])*TS,y:(CV_Y0+p[1])*TS,h:r()})});
  // pipistrelli appesi alle pareti
  const rr=roost.slice();for(let i=rr.length-1;i>0;i--){const j=(r()*(i+1))|0;[rr[i],rr[j]]=[rr[j],rr[i]]}
  const used=[];for(const q of rr){if(CVX.bats.length>=8)break;if(used.some(u=>Math.hypot(u[0]-q[0],u[1]-q[1])<5)||Math.hypot(q[0]-16,q[1]-11)<6)continue;used.push(q);
    const hx=(CV_X0+q[0]+.5)*TS,hy=(CV_Y0+q[1]+.1)*TS;CVX.bats.push({hx,hy,x:hx,y:hy,st:0,t:0,ph:r()*6,cd:0,wx:hx,wy:hy,dur:0,vx:0,vy:0})}
  ent({id:'cavex',type:'deco',spr:'cavex',x:(CV_X0+16)*TS,y:(CV_Y0+11.3)*TS,inter:'look',hitw:170,hith:80,label:'Uscita'});
  ent({id:'cvrudder',type:'deco',spr:'cvrudder',x:(CV_X0+28.6)*TS,y:(CV_Y0+3.7)*TS,inter:'look',hitw:110,hith:70,label:'Fagotto'});
}
function caveBake(){
  const G=CVX.G,W=CV_W*TS,H=CV_H*TS,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d'),r=mulberry(99);
  g.fillStyle='#0b0a0c';g.fillRect(0,0,W,H);
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){
    if(G[y][x]!==0)continue;
    const px=x*TS,py=y*TS,sh=34+((r()*16)|0);g.fillStyle=`rgb(${sh},${sh-3},${sh-6})`;
    g.beginPath();g.roundRect(px-1,py-1,TS+2,TS+2,10);g.fill();
    for(let i=0;i<5;i++){const s=26+((r()*30)|0);g.fillStyle=`rgb(${s},${s-3},${s-5})`;g.beginPath();g.ellipse(px+r()*TS,py+r()*TS,5+r()*9,3+r()*6,r()*3,0,7);g.fill()}
  }
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){
    const v=G[y][x];if(v===0)continue;const px=x*TS,py=y*TS;
    const b=64+((r()*6)|0);g.fillStyle=`rgb(${b},${b-4},${b-10})`;g.beginPath();g.roundRect(px-6,py-6,TS+12,TS+12,22);g.fill();
  }
  for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++){
    if(G[y][x]!==1)continue;const px=x*TS,py=y*TS;
    for(let i=0;i<6;i++){const s=54+((r()*30)|0);g.fillStyle=`rgba(${s},${s-4},${s-10},.7)`;g.beginPath();g.ellipse(px+r()*TS,py+r()*TS,3+r()*7,2+r()*4,r()*3,0,7);g.fill()}
    if(r()<.35){g.fillStyle='rgba(30,28,26,.5)';g.beginPath();g.ellipse(px+r()*TS,py+r()*TS,2+r()*3,1.5+r()*2,0,0,7);g.fill()}
    const near=[[1,0],[-1,0],[0,1],[0,-1]].some(d=>{const a=G[y+d[1]];return a&&(a[x+d[0]]===0||a[x+d[0]]===2)});
    if(near&&r()<.7){g.fillStyle=`rgba(${70+((r()*30)|0)},${110+((r()*40)|0)},60,.55)`;for(let i=0;i<3;i++){g.beginPath();g.ellipse(px+r()*TS,py+r()*TS,5+r()*7,3+r()*4,r()*3,0,7);g.fill()}}
  }
  for(let y=0;y<CV_H-1;y++)for(let x=0;x<CV_W;x++){
    if(G[y][x]!==0)continue;const below=G[y+1][x];if(below===0)continue;
    const px=x*TS,py=y*TS,q=g.createLinearGradient(0,py+TS-30,0,py+TS+16);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(.35,'rgba(0,0,0,.55)');q.addColorStop(1,'rgba(0,0,0,.15)');
    g.fillStyle=q;g.fillRect(px,py+TS-30,TS,46);
    g.strokeStyle='rgba(255,235,200,.10)';g.lineWidth=2;g.beginPath();g.moveTo(px+2,py+TS-30);g.lineTo(px+TS-2,py+TS-30);g.stroke();
  }
  // pozze: bordo di pietra bagnata chiaro, acqua blu-verde, riflessi: si capisce subito che è acqua (e che non si cammina)
  const wt=[];for(let y=0;y<CV_H;y++)for(let x=0;x<CV_W;x++)if(G[y][x]===2)wt.push([x,y]);
  for(const[x,y]of wt){g.fillStyle='rgba(20,18,16,.55)';g.beginPath();g.arc(x*TS+TS/2,y*TS+TS/2+3,TS*.86,0,7);g.fill()}
  for(const[x,y]of wt){g.fillStyle='#a9aca3';g.beginPath();g.arc(x*TS+TS/2,y*TS+TS/2,TS*.84,0,7);g.fill()}
  for(const[x,y]of wt){g.fillStyle='#6f7b78';g.beginPath();g.arc(x*TS+TS/2,y*TS+TS/2,TS*.76,0,7);g.fill()}
  for(const[x,y]of wt){const cx=x*TS+TS/2,cy=y*TS+TS/2,q=g.createRadialGradient(cx,cy-4,2,cx,cy,TS*.74);q.addColorStop(0,'#3f9fb6');q.addColorStop(.6,'#1f6f8c');q.addColorStop(1,'#134a63');g.fillStyle=q;g.beginPath();g.arc(cx,cy,TS*.72,0,7);g.fill()}
  for(const[x,y]of wt){const cx=x*TS+TS/2,cy=y*TS+TS/2;g.strokeStyle='rgba(190,235,250,.35)';g.lineWidth=1.5;g.beginPath();g.ellipse(cx-4,cy-2,13,4.5,0,0,7);g.stroke();g.strokeStyle='rgba(190,235,250,.2)';g.beginPath();g.ellipse(cx+5,cy+6,8,2.6,0,0,7);g.stroke()}
  CVX.wt=wt;
  CVX.canvas=c;
}
function cavePlace(x,y){P.x=x;P.y=y;P.rv=0;cam.x=P.x;cam.y=P.y;camClamp();if(typeof PAR!=='undefined'&&PAR){PAR.x=P.x+18;PAR.y=P.y-10}}
function caveEnter(){
  if(!CVX||P.mode==='raft')return;
  if(typeof cancelAct==='function')cancelAct();
  try{C().cvSeen=1}catch(e){}
  cavePlace((CV_X0+16)*TS,(CV_Y0+9.9)*TS);CVX.fade=1;sfx('thud');
  CVX.hint=1.4;CVX.dripT=2;CVX.batSay=0;UI.sync();saveGame();
}
function caveExit(){
  if(!CVX)return;
  const f=nearestFree(Math.floor(CV2.cave[0]),Math.floor(CV2.cave[1])+2,6);
  if(f)cavePlace((f[0]+.5)*TS,(f[1]+.5)*TS);CVX.fade=1;P.hd=0;UI.sync();saveGame();
}
function caveTry(){   // dal pulsante «Entra» fuori dalla grotta
  if(caveOpen()){caveEnter();return}
  const c=C();
  if(c&&c.parts&&c.parts.rudder){UI.dlg([D('hero',"La grotta è vuota. Il timone è fuori, dove serve.")]);return}
  if(S.flags.parrot)say(PAR,"Cra! Una grotta buia... forse è meglio prima informarsi al campo!",4.2);
  else UI.dlg([D('hero',"Una grotta buia, muschio sulle pietre. Forse è meglio prima informarsi al campo.")]);
}
function caveFloorPick(cx,cy,R){
  const G=CVX.G,tx=Math.floor(cx/TS)-CV_X0,ty=Math.floor(cy/TS)-CV_Y0,c=[];
  for(let j=-5;j<=5;j++)for(let i=-5;i<=5;i++){const a=tx+i,b=ty+j;if(G[b]&&G[b][a]===1&&Math.hypot(i,j)*TS<R)c.push([(CV_X0+a+.5)*TS,(CV_Y0+b+.5)*TS])}
  return c.length?c[(Math.random()*c.length)|0]:null;
}
function caveStep(dt){
  if(!CVX)return;
  const on=inCave();
  if(on!==CVX.was){CVX.was=on;document.body.classList.toggle('incave',on);UI.sync()}
  if(!on)return;
  if(CVX.fade>0)CVX.fade=Math.max(0,CVX.fade-dt*1.8);
  const tor=S.up.torch&&S.torchOn;
  if(CVX.hint>0){CVX.hint-=dt;if(CVX.hint<=0){
    if(tor){say(PAR,"Cra! Bella fiamma. Si vede tutto.")}
    else if(S.up.torch){say(PAR,"Cra! Che buio! Accendi la torcia!");UI.toast("Qui dentro è buio pesto: accendi la torcia (pulsante a fiamma).",4200)}
    else{say(PAR,"Cra! Buio fitto. Serve una torcia: si fa al Banco!");UI.toast("Qui dentro è buio pesto. Una torcia si costruisce al Banco da lavoro.",4200)}
  }}
  // gocce che cadono nelle pozze, con eco
  CVX.dripT-=dt;
  if(CVX.dripT<=0&&CVX.wt&&CVX.wt.length){CVX.dripT=2.2+Math.random()*4;const w=CVX.wt[(Math.random()*CVX.wt.length)|0];CVX.drops.push({x:(CV_X0+w[0]+.2+Math.random()*.6)*TS,y:(CV_Y0+w[1]+.5)*TS,t:0})}
  for(const d of CVX.drops){d.t+=dt;if(!d.hit&&d.t>.45){d.hit=1;CVX.rings.push({x:d.x,y:d.y,t:0});if(hyp(d.x-P.x,d.y-P.y)<700)try{sfx('drip')}catch(e){}}}
  CVX.drops=CVX.drops.filter(d=>d.t<.5);
  for(const q of CVX.rings)q.t+=dt;CVX.rings=CVX.rings.filter(q=>q.t<1.6);
  // pipistrelli
  for(const b of CVX.bats){
    b.t+=dt;b.cd-=dt;
    const d=hyp(P.x-b.hx,P.y-b.hy);
    if(b.st===0){
      if(b.cd<=0&&d<(tor?150:90)){b.st=1;b.t=0;b.dur=3.5+Math.random()*3;b.wt=0;b.wx=b.x;b.wy=b.y-30;try{sfx('bat')}catch(e){}
        if(!CVX.batSay&&S.flags.parrot){CVX.batSay=1;setTimeout(()=>{if(inCave())say(PAR,"Cra! Pipistrelli!")},500)}}
    }else if(b.st===1){
      b.wt-=dt;if(b.wt<=0){b.wt=.7+Math.random()*.8;const w=caveFloorPick(b.x,b.y,260);if(w){b.wx=w[0];b.wy=w[1]-34-Math.random()*20}}
      if(b.t>b.dur)b.st=2;
    }else{b.wx=b.hx;b.wy=b.hy}
    if(b.st>0){
      const dx=b.wx-b.x,dy=b.wy-b.y,m=Math.hypot(dx,dy)||1,sp=b.st===1?130:110;
      b.vx+=(dx/m*sp-b.vx)*Math.min(1,dt*3.2);b.vy+=(dy/m*sp-b.vy)*Math.min(1,dt*3.2);
      b.x+=b.vx*dt+Math.sin(b.t*9+b.ph)*18*dt;b.y+=b.vy*dt+Math.cos(b.t*7+b.ph)*14*dt;
      if(b.st===2&&hyp(b.x-b.hx,b.y-b.hy)<10){b.st=0;b.x=b.hx;b.y=b.hy;b.vx=b.vy=0;b.cd=7+Math.random()*6}
    }
  }
}
function drawBat(g,b,t){
  if(b.st===0){
    g.save();g.translate(b.hx,b.hy);
    g.fillStyle='#2a2430';g.beginPath();g.ellipse(0,4,5,8,0,0,7);g.fill();
    g.fillStyle='#3a3242';g.beginPath();g.ellipse(0,-1,4,3.4,0,0,7);g.fill();
    g.fillStyle='#2a2430';g.beginPath();g.moveTo(-3,-3);g.lineTo(-4.5,-8);g.lineTo(-1,-4);g.moveTo(3,-3);g.lineTo(4.5,-8);g.lineTo(1,-4);g.fill();
    g.restore();return}
  const f=Math.sin(t*24+b.ph);
  g.save();g.translate(b.x,b.y);
  g.fillStyle='rgba(0,0,0,.22)';g.beginPath();g.ellipse(0,34,7,2.4,0,0,7);g.fill();
  g.fillStyle='#2a2430';
  for(const sg of[-1,1]){g.beginPath();g.moveTo(sg*2,0);g.quadraticCurveTo(sg*14,-10*f-4,sg*21,-2*f+4);g.quadraticCurveTo(sg*14,2,sg*11,5);g.quadraticCurveTo(sg*7,2,sg*5,6);g.quadraticCurveTo(sg*3,3,sg*2,6);g.closePath();g.fill()}
  g.fillStyle='#3a3242';g.beginPath();g.ellipse(0,2,3.4,5,0,0,7);g.fill();
  g.fillStyle='#2a2430';g.beginPath();g.moveTo(-2.5,-2);g.lineTo(-3.5,-6);g.lineTo(-.5,-3);g.moveTo(2.5,-2);g.lineTo(3.5,-6);g.lineTo(.5,-3);g.fill();
  g.fillStyle='#ffdd88';g.fillRect(-1.8,-.5,1,1);g.fillRect(.8,-.5,1,1);
  g.restore();
}
function drawCaveSp(g,e,t){
  if(e.spr==='cavex'){
    g.save();g.translate(e.x,e.y);
    const q=g.createRadialGradient(0,-10,6,0,-6,120);q.addColorStop(0,'rgba(255,248,220,.95)');q.addColorStop(.4,'rgba(255,230,170,.45)');q.addColorStop(1,'rgba(255,220,150,0)');
    g.fillStyle=q;g.beginPath();g.ellipse(0,-6,120,60,0,0,7);g.fill();
    g.restore();return}
  if(e.spr==='cvrudder'){
    g.save();g.translate(e.x,e.y);shadow(g,0,4,34,10,.4);
    g.fillStyle='#55504a';g.beginPath();g.ellipse(0,0,30,11,0,0,7);g.fill();g.fillStyle='#7a746b';g.beginPath();g.ellipse(0,-5,28,10,0,0,7);g.fill();
    if(!(C()&&C().parts&&C().parts.rudder)){
      g.fillStyle='#6b5a2c';g.beginPath();g.roundRect(-22,-26,44,20,6);g.fill();g.strokeStyle='#2c2410';g.lineWidth=2;g.stroke();
      g.fillStyle='#8a7436';g.fillRect(-20,-24,40,5);
      g.strokeStyle='#d7c58f';g.lineWidth=2;g.beginPath();g.moveTo(-8,-26);g.lineTo(-8,-6);g.moveTo(8,-26);g.lineTo(8,-6);g.stroke();
      g.fillStyle='#efe3bd';g.beginPath();g.roundRect(-5,-34,16,11,2);g.fill();g.strokeStyle='#5b4a26';g.lineWidth=1;g.stroke();
      twinkle(g,14,-30,t,6,e.x,'#fff6c0');
    }
    g.restore();return}
}
function drawCaveStalag(g,s,t){
  g.save();g.translate(s.x,s.y);g.scale(s.s,s.s);shadow(g,0,2,10,3,.3);
  g.fillStyle=s.k?'#5a636a':'#6a645c';g.beginPath();g.moveTo(-8,0);g.lineTo(-3,-26);g.lineTo(0,-34);g.lineTo(4,-24);g.lineTo(9,0);g.closePath();g.fill();
  g.fillStyle='rgba(255,255,255,.12)';g.beginPath();g.moveTo(-3,-26);g.lineTo(0,-34);g.lineTo(2,-10);g.closePath();g.fill();
  g.restore();
}
function drawCrystal(g,c,t){
  const hue=c.h<.5?190:270,pul=.75+.25*Math.sin(t*1.7+c.h*9);
  g.save();g.translate(c.x,c.y);shadow(g,0,3,12,4,.35);
  const col=`hsl(${hue},80%,${55+pul*12}%)`;
  for(const[dx,h,w]of[[-7,18,5],[0,28,6.5],[8,14,4.5]]){g.fillStyle=col;g.beginPath();g.moveTo(dx-w,0);g.lineTo(dx-w*.3,-h);g.lineTo(dx+w*.3,-h);g.lineTo(dx+w,0);g.closePath();g.fill();g.fillStyle='rgba(255,255,255,.35)';g.beginPath();g.moveTo(dx-w*.3,-h);g.lineTo(dx,-h*.2);g.lineTo(dx-w*.9,0);g.closePath();g.fill()}
  g.restore();
}
function renderCave(t){
  const g=ctx,z=camZoom();
  g.setTransform(1,0,0,1,0,0);g.fillStyle='#050406';g.fillRect(0,0,cv.width,cv.height);
  if(!CVX)return;if(!CVX.canvas)caveBake();
  g.setTransform(DPR*z,0,0,DPR*z,DPR*(VW/2-cam.x*z),DPR*(VH/2-cam.y*z));
  g.imageSmoothingEnabled=true;
  g.drawImage(CVX.canvas,CV_X0*TS,CV_Y0*TS);
  const vx0=cam.x-VW/2/z,vy0=cam.y-VH/2/z,vx1=cam.x+VW/2/z,vy1=cam.y+VH/2/z;
  // pozze: riflessi che scorrono e cerchi dalle gocce
  for(const w of CVX.wt||[]){
    const cx=(CV_X0+w[0]+.5)*TS,cy=(CV_Y0+w[1]+.5)*TS;if(cx<vx0-60||cx>vx1+60||cy<vy0-60||cy>vy1+60)continue;
    const ph=w[0]*1.7+w[1]*2.3;
    g.save();g.globalAlpha=.35+.3*Math.sin(t*1.6+ph);g.strokeStyle='#cdeeff';g.lineWidth=1.4;g.beginPath();g.ellipse(cx+Math.sin(t*.9+ph)*7,cy+Math.cos(t*.7+ph)*4,10,3,0,0,7);g.stroke();g.restore();
  }
  for(const q of CVX.rings){const k=q.t/1.6;g.save();g.globalAlpha=(1-k)*.7;g.strokeStyle='#d8f2ff';g.lineWidth=1.6;g.beginPath();g.ellipse(q.x,q.y,4+k*22,2+k*9,0,0,7);g.stroke();g.restore()}
  for(const d of CVX.drops){const k=d.t/.45;if(k<1){g.fillStyle='rgba(190,230,250,.9)';g.beginPath();g.ellipse(d.x,d.y-60+60*k*k,1.6,3,0,0,7);g.fill()}}
  const list=[];
  for(const s of CVX.st)list.push({y:s.y,d:()=>drawCaveStalag(g,s,t)});
  for(const c of CVX.cr)list.push({y:c.y,d:()=>drawCrystal(g,c,t)});
  for(const b of CVX.bats)list.push({y:b.st===0?b.hy:b.y+30,d:()=>drawBat(g,b,t)});
  for(const nm of['cavex','cvrudder']){const e=EID[nm];if(e)list.push({y:e.y+(nm==='cavex'?-80:0),d:()=>drawCaveSp(g,e,t)})}
  list.push({y:P.y,d:()=>drawPlayer(g,t)});
  if(S.flags.parrot)list.push({y:PAR.y+4,d:()=>drawParrotEnt(g,t)});
  list.sort((a,b)=>a.y-b.y);for(const o of list)o.d();
  drawHeading(g,t);
  drawParts(g);
  const lights=[];
  const tor=S.up.torch&&S.torchOn;
  lights.push([P.x,P.y-28,tor?60:46,tor?.5:.22,false]);
  if(tor)lights.push([P.x+(P.flip?-21:21),P.y-44,270,1,true]);
  for(const c of CVX.cr)if(c.x>vx0-200&&c.x<vx1+200&&c.y>vy0-200&&c.y<vy1+200)lights.push([c.x,c.y-14,tor?120:105,.36+.1*Math.sin(t*1.7+c.h*9),false,c.h<.5?[90,150,200]:[140,100,210]]);
  const ex=EID.cavex;if(ex)lights.push([ex.x,ex.y-20,150,.6,false,[255,236,180]]);
  if(!LCV)LCV=document.createElement('canvas');
  if(LCV.width!==cv.width||LCV.height!==cv.height){LCV.width=cv.width;LCV.height=cv.height}
  const lg=LCV.getContext('2d'),M=g.getTransform(),base=[6,7,12];
  lg.setTransform(1,0,0,1,0,0);lg.globalCompositeOperation='source-over';lg.fillStyle=rgbs(base);lg.fillRect(0,0,LCV.width,LCV.height);
  lg.setTransform(M);lg.globalCompositeOperation='lighter';
  const tg=[255,232,180];
  for(const l of lights){
    const col=l[5]||tg,ad=[Math.max(0,col[0]-base[0]),Math.max(0,col[1]-base[1]),Math.max(0,col[2]-base[2])];
    const fl=l[4]?(.94+.06*Math.sin(t*13)+.03*Math.sin(t*7.3)):1,R=l[2]*fl,k=Math.min(1,l[3]);
    const q=lg.createRadialGradient(l[0],l[1],R*.08,l[0],l[1],R);
    for(const[o,a]of[[0,1],[.45,.9],[.7,.45],[.88,.14],[1,0]])q.addColorStop(o,`rgba(${ad[0]|0},${ad[1]|0},${ad[2]|0},${a*k})`);
    lg.fillStyle=q;lg.fillRect(l[0]-R,l[1]-R,R*2,R*2);
  }
  g.save();g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='multiply';g.drawImage(LCV,0,0);g.restore();
  if(tor){g.globalCompositeOperation='lighter';const l=lights[1],fl=.9+.1*Math.sin(t*13);const q=g.createRadialGradient(l[0],l[1],3,l[0],l[1],140*fl);q.addColorStop(0,'rgba(255,170,70,.30)');q.addColorStop(1,'rgba(255,120,30,0)');g.fillStyle=q;g.fillRect(l[0]-150,l[1]-150,300,300);g.globalCompositeOperation='source-over'}
  g.setTransform(DPR,0,0,DPR,0,0);
  drawScreenFx(g);drawProgress(g,t);
  if(CVX.fade>0){g.fillStyle=`rgba(0,0,0,${CVX.fade})`;g.fillRect(0,0,VW,VH)}
}
