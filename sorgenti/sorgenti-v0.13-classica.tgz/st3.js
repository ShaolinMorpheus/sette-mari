const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();const er=[];
const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.Ch2.convert(P.newState('D','m'));s.tutDone=1;s.flags.parrot=1;s.q={c5:{st:'done',gi:0,p:0}};localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});
await p.waitForTimeout(2500);
let found='';
for(let i=0;i<60&&!found;i++){
 await p.evaluate(()=>{Pirati.talk()});await p.waitForTimeout(150);
 const t=await p.evaluate(()=>{const e=document.getElementById('dlgBox');return e?e.innerText:''});
 const all=[];
 for(let k=0;k<6;k++){all.push(await p.evaluate(()=>{const e=document.getElementById('dlgBox');return e?e.innerText.replace(/\n/g,' '):''}));await p.evaluate(()=>document.getElementById('dlgBox').click());await p.waitForTimeout(120)}
 const j=all.join(' | ');if(/cassa ancora chiusa|Una!/.test(j))found=j;
 for(let k=0;k<8;k++){await p.evaluate(()=>{const b=document.getElementById('dlgBox');b&&b.click()});await p.waitForTimeout(80)}
 await p.evaluate(()=>{Pirati.S&&0});await p.waitForTimeout(100)}
console.log(found||'not seen');console.log(er);await b.close()})();
