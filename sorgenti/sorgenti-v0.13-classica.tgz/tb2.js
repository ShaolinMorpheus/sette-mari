const L=require('./aud/lib.js');
(async()=>{const {b,p}=await L.boot();
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 console.log(await p.evaluate(()=>{const o={};for(const t of['tree','pine','palm','bush','berry','rock']){const e=Pirati.E.find(x=>x.type===t);o[t]=e?JSON.stringify(e,(k,v)=>typeof v==='function'?undefined:v).slice(0,330):null}return JSON.stringify(o,null,1)}));await b.close()})();
