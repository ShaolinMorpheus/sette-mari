const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:2400,height:1000},deviceScaleFactor:1})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));p.on('console',m=>{if(m.type()==='error')er.push('C:'+m.text())});
await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({silver:0,pris:0,hull:10,max:10,kills:0,t:0}))}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(3500);
const decks=+process.argv[2]||3;
for(let d=0;d<decks;d++){
 await p.evaluate(d=>{const K=Ch4.K;Ch4.setDeck(d,35,d===0?3.95:10.5);Ch4.cam.uz=.34;Ch4.cam.x=(8+28)*44;Ch4.cam.y=(13+9)*44;K.say=[];K.sayT=0;K.routesT=0;document.getElementById('c4say').style.display='none'},d);
 await p.waitForTimeout(600);
 await p.evaluate(()=>{Ch4.cam.x=(8+28)*44;Ch4.cam.y=(13+9)*44});await p.waitForTimeout(300);
 await p.screenshot({path:'deck'+d+'.png'});}
console.log(er);await b.close()})();
