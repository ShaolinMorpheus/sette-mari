const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{Pirati.hut.enter()});await p.waitForTimeout(1500);await clr();
console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())), await p.evaluate(()=>Pirati.P.mode));
await p.evaluate(()=>{const X0=Pirati.hut.X0;Pirati.P.x=(X0+14)*44;Pirati.P.y=(1+7.4)*44});await p.waitForTimeout(500);
console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
console.log(er);await b.close()})();
