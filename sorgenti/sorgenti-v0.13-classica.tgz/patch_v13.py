#!/usr/bin/env python3
# v0.12.1: lanterne solo con la miglioria del banco; arrivo in mare nel Capitolo 2
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH13 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
# --- lanterne dell'editor: nascoste finche' non si fa la miglioria «Lanterne» al banco ---
rep("  if(e.spr==='lamp'){drawCDeco(g,e.lk,t);return}","  if(e.spr==='lamp'){if(!e.hid)drawCDeco(g,e.lk,t);return}")
rep("(e.type==='deco'&&e.spr==='lamp'))lights.push(","(e.type==='deco'&&e.spr==='lamp'&&!e.hid))lights.push(")
rep("function campBuild0(d){\n  S.camp=S.camp||[];const placed=[];\n","function campBuild0(d){\n  S.camp=S.camp||[];const placed=[];\n  if(d.k==='lanterne'&&E.some(e=>e.type==='deco'&&e.spr==='lamp')){if(!S.camp.some(o=>o.k==='lanterne'))S.camp.push({k:'lanterne',tx:0,ty:0,w:1});lampSync();return 1}\n")
rep("  for(const o of(S.camp||[]))campAdd(o.k,o.tx,o.ty);\n  // la bandiera","  for(const o of(S.camp||[])){if(o.w)continue;campAdd(o.k,o.tx,o.ty)}\n  // la bandiera")
rep("    for(const o of cam.filter(o=>o.k==='lanterne')){","    if(E.some(e=>e.type==='deco'&&e.spr==='lamp'))return;\n    for(const o of cam.filter(o=>o.k==='lanterne')){")
rep("function campBuild(d){\n","const lampsOn=()=>!!(S&&(S.camp||[]).some(o=>o.k==='lanterne'));\nfunction lampSync(){const on=lampsOn()||(typeof ED!=='undefined'&&ED.on);for(const e of E){if(e.type!=='deco'||e.spr!=='lamp')continue;e.hid=!on;if(e.hid&&e.blocked)delBlock(e);else if(!e.hid&&!e.blocked&&e.fp)reBlock(e)}}\nfunction campBuild(d){\n")
rep("    if(frameN%3===0)drawMini();","    if(frameN%3===0)drawMini();\n    if(frameN%20===0)lampSync();")
rep('{k:\'lanterne\',n:"Lanterne",d:"Quattro lanterne attorno al campo: all\'imbrunire fanno luce."','{k:\'lanterne\',n:"Lanterne",d:"Le lanterne del campo e dei sentieri: all\'imbrunire fanno luce."')
# --- Capitolo 2: si arriva in zattera, dal mare aperto, e si sbarca sulla spiaggia ---
rep("  n.px=FIX_2.spawn[0]*TS;n.py=FIX_2.spawn[1]*TS;n.hd=0;n.mode='walk';","  n.px=96.5*TS;n.py=57*TS;n.hd=Math.PI;n.mode='raft';")
rep("  n.c2={};n.sound=s.sound;n.music=s.music;","  n.c2={sea:1};n.sound=s.sound;n.music=s.music;")
rep("  if(!S.q.c1){\n    setTimeout(()=>{UI.banner('Capitolo 2','La Baia dei Fuggiaschi');","  if(S.c2&&S.c2.sea){setTimeout(()=>{UI.banner('Capitolo 2','Il mare aperto');UI.dlg([D('hero',\"Il fumo di ieri è dietro di me. Davanti, un mare più grande di quanto sembrasse.\"),D('hero',\"Da qualche parte c'è una baia, con delle tende. Seguo la costa e tengo gli scogli alla larga.\"),D('biscotto',\"Cra! Si naviga! Io faccio la vedetta, tu fai tutto il resto!\")],()=>{if(!S.q.c0)startQuest('c0')})},400);return}\n  if(!S.q.c1){\n    setTimeout(()=>{UI.banner('Capitolo 2','La Baia dei Fuggiaschi');")
rep("    if(hyp(P.x-FIX.landing[0]*TS,P.y-FIX.landing[1]*TS)<3.2*TS)Story.onLanding();\n","    if(hyp(P.x-FIX.landing[0]*TS,P.y-FIX.landing[1]*TS)<3.2*TS)Story.onLanding();\n    else if(WORLD===2&&S.c2&&S.c2.sea&&hyp(P.x-19.4*TS,P.y-31.2*TS)<3.8*TS)Ch2.land();\n")
rep("Ch2.onBegin=function(){","Ch2.land=function(){\n  if(!S.c2||!S.c2.sea)return;S.c2.sea=0;\n  leaveRaft(nearestFree(23,32,6),true);sfx('quest');\n  setTimeout(()=>{UI.banner('Capitolo 2','La Baia dei Fuggiaschi');\n    UI.dlg([D('hero',\"Terra. Un'altra spiaggia, un altro mare. Mi tremano ancora le gambe.\"),D('hero',\"Davanti, una baia, e tende tra gli alberi.\"),D('hero',\"Su una duna, a pochi passi, una sagoma. Un uomo con le braccia incrociate, fermo, che mi guarda. Sbatto le palpebre e non c'è più.\"),D('biscotto',\"Cra! Visto! Non visto! Prima acqua, poi tutto il resto!\")],()=>startQuest('c1'))},500);\n};\nCh2.onBegin=function(){")
rep("s1:{kind:'side',title:\"Pesca\"","c0:{kind:'main',title:\"Il mare aperto\",blurb:\"Una costa da seguire fino alla baia.\",\n  goals:[{k:'flag',done:()=>!(S.c2&&S.c2.sea),txt:\"Segui la costa fino alla baia dei Fuggiaschi\",hint:\"Naviga con la zattera tenendo la costa vicina e aggira gli scogli. La baia è sulla spiaggia ad ovest dell'isola.\",mark:()=>({x:19.4*TS,y:31.2*TS,r:4*TS,up:20})}]},\ns1:{kind:'side',title:\"Pesca\"")
rep('"Armadio della capanna: ora si apre','"Lanterne: non ce ne sono più all\\\'inizio, né sulla prima né sulla seconda isola. Compaiono solo con la miglioria «Lanterne» del banco da lavoro, nei punti che hai disegnato con l\\\'editor.",\n    "Capitolo 2: dopo la conferma e il caricamento ci si ritrova in zattera, in mare aperto, e si naviga a lungo lungo la costa fino alla spiaggia della baia, dove si sbarca.",\n    "Armadio della capanna: ora si apre')
open(P,'w',encoding='utf8').write(src)
print('patch13 ok')
