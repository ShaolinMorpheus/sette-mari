const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({});
 await p.waitForTimeout(1200);
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);
 await p.waitForTimeout(500);
 const r=await p.evaluate(()=>{const S=Pirati.S;S.built={falo:1,capanna:1,banco:1};Pirati.UI.openUpgrades();const c=document.getElementById('sheetCard');return {html:c.innerHTML.slice(0,300),n:c.querySelectorAll('[data-dc]').length,hidden:document.getElementById('sheet').hidden,toasts:document.getElementById('toasts').innerText}});
 console.log(JSON.stringify(r));console.log(errs);await b.close()})();
