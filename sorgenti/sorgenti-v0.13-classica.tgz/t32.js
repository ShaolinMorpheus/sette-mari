const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
const r=await p.evaluate(()=>{const C=Ch3.C,T=44;C.tut=null;C.easy=true;const o=[];const s=C.p;o.push(Math.round(s.x/T*10)/10,Math.round(s.y/T*10)/10);
 // sail north into pier from south at x=25T
 s.x=25*T;s.y=47.5*T;s.hd=-Math.PI/2;s.v=150;C.sail=3;
 for(let i=0;i<120;i++){s.hd=-Math.PI/2;Ch3.step(.05)}
 o.push(Math.round(s.x/T*10)/10,Math.round(s.y/T*10)/10,Math.round(s.hull*10)/10);return o});
await p.screenshot({path:'c3i.png'});console.log(JSON.stringify(r),errs);await b.close()})()
