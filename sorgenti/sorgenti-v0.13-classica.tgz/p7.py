import re
p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:70],s.count(a))
    s=s.replace(a,b)
# ---- dock spot
rep("  for(let j=-3;j<=3;j++)for(let i=-3;i<=3;i++){\n    const x=tx+i,y=ty+j;if(!freeT(x,y)||(WORLD!==2&&x>=64))continue;      // l'altra isola resta fuori portata, per ora\n    const d=hyp((x+.5)*TS-P.x,(y+.5)*TS-P.y);if(d<bd&&d<1.7*TS){bd=d;best=[x,y]}",
    "  for(let j=-4;j<=4;j++)for(let i=-4;i<=4;i++){\n    const x=tx+i,y=ty+j;if(!freeT(x,y)||(WORLD!==2&&x>=64))continue;      // l'altra isola resta fuori portata, per ora\n    const d=hyp((x+.5)*TS-P.x,(y+.5)*TS-P.y);if(d<bd&&d<2.6*TS){bd=d;best=[x,y]}")
rep("  forestF,exclTile,WORLD,","  dockSpot,forestF,exclTile,WORLD,")
# ---- shared inventory
rep("Ch2.toCh1=function(){","""Ch2.share=function(d,s0){
  d.res=Object.assign({},d.res,s0.res);d.up=Object.assign({},d.up);for(const k in (s0.up||{}))d.up[k]=Math.max(d.up[k]||0,s0.up[k]||0);
  for(const k of['phats','phat','rec','xpt','cOpen','pname','hints','sound','music'])if(s0[k]!=null)d[k]=s0[k];
  d.stat=Object.assign({},d.stat);for(const k in (s0.stat||{}))if(typeof s0.stat[k]==='number')d.stat[k]=Math.max(d.stat[k]||0,s0.stat[k]);
  d.vit=Object.assign({},s0.vit);d.flags=d.flags||{};for(const k of['parrot','hat','compass','lenza','axe','pick','flint'])if(s0.flags&&s0.flags[k])d.flags[k]=1;
  return d;
};
Ch2.toCh1=function(){""")
rep("    localStorage.setItem(key+'-ch2sv',localStorage.getItem(key));\n    localStorage.setItem(key,bak);","    const cur=localStorage.getItem(key);localStorage.setItem(key+'-ch2sv',cur);\n    localStorage.setItem(key,JSON.stringify(Ch2.share(JSON.parse(bak),JSON.parse(cur))));")
rep("    localStorage.setItem(key,sv||JSON.stringify(Ch2.convert(JSON.parse(raw))));","    localStorage.setItem(key,sv?JSON.stringify(Ch2.share(JSON.parse(sv),JSON.parse(raw))):JSON.stringify(Ch2.convert(JSON.parse(raw))));")
# ---- overview labels world 2
rep("  lab('Laghetto',POND.x*TS,POND.y*TS,'#8fd8ff');\n  lab('Relitto'","""  if(WORLD===2){
    lab('Laghetto',POND.x*TS,POND.y*TS,'#8fd8ff');lab('Campo dei Fuggiaschi',CP.x,CP.y,'#ffd9a0');lab('La nave',CV2.ship[0]*TS,CV2.ship[1]*TS-40,'#ffe27a');lab('Grotta',CV2.cave[0]*TS,CV2.cave[1]*TS,'#e0e0e0');lab('Pino Maestro',CV2.mast[0]*TS,CV2.mast[1]*TS,'#b9e8a0');lab('Spiaggia della zattera',FIX.raftLaunch[0]*TS,FIX.raftLaunch[1]*TS,'#ffe27a',16);
    g.fillStyle='#fff';g.strokeStyle='#2a1a0e';g.lineWidth=2.4;g.beginPath();g.arc(X(FIX.lookout[0]*TS),Y(FIX.lookout[1]*TS),6,0,7);g.fill();g.stroke();return;
  }
  lab('Laghetto',POND.x*TS,POND.y*TS,'#8fd8ff');
  lab('Relitto'""")
rep('UI.showOverview=function(','UI.showOverview=function(') if False else None
rep('"L\'isola vista dall\'alto. A est, oltre il mare, sale del fumo: è lì che bisogna arrivare."','WORLD===2?"La baia vista dall\'alto: il campo, la nave, la grotta e il Pino Maestro.":"L\'isola vista dall\'alto. A est, oltre il mare, sale del fumo: è lì che bisogna arrivare."')
# ---- map in one page (CSS)
rep("#mapCard{max-width:700px;text-align:center}","#mapCard{max-width:700px;text-align:center;display:flex;flex-direction:column;max-height:calc(100dvh - 20px);overflow:hidden;padding-top:8px;padding-bottom:8px}#mapCard h2{margin:0 0 2px;font-size:20px}#mapCard #mapTxt{margin:4px 0;font-size:13px;line-height:1.25}#mapCard .btn{padding:6px 14px;align-self:center;flex:none}")
rep("#mapCv{width:100%;max-height:56vh;object-fit:contain;","#mapCv{width:100%;flex:1 1 auto;min-height:0;max-height:none;object-fit:contain;")
# ---- climb animation
rep("function drawPlayer(g,t,alpha){\n  const hs=heroSpec();","function drawPlayer(g,t,alpha){\n  if(P.cl&&P.cl.a!=null){alpha=(alpha==null?1:alpha)*P.cl.a}\n  const hs=heroSpec();")
rep("  drawChar(g,P.x,P.y,{k:hs,dir:P.dir,","  if(P.cl&&P.cl.dy)g.translate(0,P.cl.dy);\n  drawChar(g,P.x,P.y,{k:hs,dir:P.cl&&P.cl.ph===2?'b':P.dir,")
rep("function step(dt){\n  if(!dl.open){updatePlayer(dt);","function step(dt){\n  if(P.cl)updateClimb(dt);\n  if(!dl.open){if(!P.cl)updatePlayer(dt);")
rep("function step(dt){","""function updateClimb(dt){
  const c=P.cl;c.t+=dt;
  if(c.ph===0){   // cammina fino alla scaletta
    const dx=c.bx-P.x,dy=c.by-P.y,d=hyp(dx,dy);
    if(d<6||c.t>1.2){P.x=c.bx;P.y=c.by;c.ph=2;c.t=0;P.dir='b'}
    else{const sp=170*dt;P.x+=dx/d*sp;P.y+=dy/d*sp;P.moving=true;P.walk+=dt*9;P.flip=dx<0}
  }else{
    const T=c.dn?1.2:1.5,k=Math.min(1,c.t/T);P.moving=true;P.walk+=dt*7;
    const e=c.dn?1-k:k;c.dy=-e*120;c.a=c.dn?Math.min(1,k*3):Math.max(0,1-Math.max(0,(k-.7))/.3);
    if(Math.floor(c.t*5)!==c.st){c.st=Math.floor(c.t*5);sfx('tap')}
    if(k>=1){const cb=c.cb;P.cl=null;P.moving=false;P.dir=c.dn?'f':P.dir;if(cb)cb()}
  }
}
UI.climb=function(e,dn,cb){
  if(P.cl)return;cancelAct();stopMove();JOY.x=JOY.y=0;
  const bx=e.x+(e.cx||0),by=e.y+10;
  P.cl={ph:dn?2:0,t:0,bx,by,dn:!!dn,cb,dy:dn?-120:0,a:dn?0:1};
  if(dn){P.x=bx;P.y=by}
};
function step(dt){""")
rep("  if(P.cl)updateClimb(dt);\n  if(!dl.open){if(!P.cl)updatePlayer(dt);","  if(P.cl)updateClimb(dt);\n  if(!dl.open){if(!P.cl)updatePlayer(dt);")
# lookout use
a="""  else if(e.id==='lookout'){
    if(!S.flags.lookout){"""
b="""  else if(e.id==='lookout'){
    if(!P.cl){UI.climb(e,false,()=>{const back=()=>UI.climb(e,true,null);Story._lookup(e,back)});return}
    if(!S.flags.lookout){"""
rep(a,b)
rep("Story.marker=function(){","""Story._lookup=function(e,back){
  const done=()=>back();
  if(!S.flags.lookout){
    S.flags.lookout=1;revealAll(0,0,MW-1,MH-1);sfx('ok');
    UI.dlg(WORLD===2?[D('hero',"Da quassù la baia si vede tutta: il campo, la cala con la nave, la collina del Pino Maestro."),D('hero',"E il mare, tutto intorno. Questa è un'isola grande. Ma con una nave, il mondo è più grande ancora.")]:[D('hero',"Il vento, quassù, si sente tutto. E si vede tutto."),D('hero',"L'isola è più grande di quanto pensassi. E laggiù, a est, oltre il mare... fumo. Una colonna sottile, ogni sera.")],()=>{UI.showOverview(done)});
  }else UI.showOverview(done);
};
Story.marker=function(){""")
open(p,'w',encoding='utf8').write(s)
