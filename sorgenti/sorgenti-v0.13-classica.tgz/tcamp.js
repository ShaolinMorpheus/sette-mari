const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({file:'index_test.html'});
 await p.evaluate(()=>Pirati.startNew('T','m'));await L.skip(p);
 await p.evaluate(()=>{const S=Pirati.S;S.tutDone=1;S.tut=null;const F=__T.FIX,P=Pirati.P;P.x=(F.oldcamp[0]+1.5)*44;P.y=(F.oldcamp[1]+3)*44;Pirati.cam.x=P.x;Pirati.cam.y=P.y-80;Pirati.S.tod=12});
 await p.waitForTimeout(1500);await L.skip(p);await p.screenshot({path:'aud/camp_new.png'});
 console.log(await p.evaluate(()=>{const c=Pirati.EID.lt_old;return c?c.x/44+','+c.y/44:'no'}),JSON.stringify(errs));await b.close()})();
