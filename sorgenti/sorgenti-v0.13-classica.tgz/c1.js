const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:420}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>{Pirati.startNew('T','m')});
for(let i=0;i<12;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(500)}
const r=await p.evaluate(()=>{const P=Pirati.P;const out=[];Pirati.fast(1);
 Pirati.S.flags.lenza=1;
 const cr=Pirati.E.filter(e=>e.type==='crab'&&e.id.startsWith('ci'));
 return cr.map(e=>({id:e.id,x:e.x/44,y:e.y/44,hx:e.hx/44,alive:e.alive,stun:e.stun,walk:Pirati.tileInfo(Math.floor(e.x/44),Math.floor((e.y-4)/44))}))});
console.log(JSON.stringify(r));
await b.close()})();
