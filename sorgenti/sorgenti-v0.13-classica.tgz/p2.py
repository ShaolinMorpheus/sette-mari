p='w/index.html';s=open(p,encoding='utf8').read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(a[:60],s.count(a))
    s=s.replace(a,b)
code=r'''
/* ====== CAPITOLO 2 — il mondo: la Baia dei Fuggiaschi ====== */
function exclTile2(tx,ty){
  const x=tx+.5,y=ty+.5;
  if(hyp(x-FIX.camp[0],(y-FIX.camp[1])*1.15)<6.6)return true;
  if(pathDist(x,y)<1.5)return true;
  if(hyp(x-FIX.spawn[0],y-FIX.spawn[1])<3.4)return true;
  if(x>19&&x<28.5&&y>26.5&&y<35.5)return true;
  if(hyp(x-FIX.smoke[0],(y-FIX.smoke[1])*1.1)<10)return true;
  if(hyp(x-CV2.ship[0],(y-CV2.ship[1])*1.25)<6.5)return true;
  if(hyp(x-FIX.lookout[0],y-FIX.lookout[1])<3)return true;
  if(hyp(x-FIX.quarry[0],y-FIX.quarry[1])<4.5)return true;
  for(const k of['mast','cave','knife'])if(hyp(x-CV2[k][0],y-CV2[k][1])<2.4)return true;
  for(const b of CV2.pages)if(hyp(x-b[0],y-b[1])<1.8)return true;
  if(inPoly(x,y,MESA_PTS.map(p=>[MESA.x+(p[0]-MESA.x)*1.35,MESA.y+(p[1]-MESA.y)*1.5])))return true;
  if(hyp((x-POND.x)/(POND.rx+1.3),(y-POND.y)/(POND.ry+1.3))<1)return true;
  return false;
}
function genWorld2(){
  const r=mulberry(21);
  const taken=new Set(),key=(a,b)=>a+','+b;
  let n=0;
  const order=[];for(let ty=0;ty<MH;ty++)for(let tx=0;tx<MW;tx++)order.push([tx,ty]);
  for(let i=order.length-1;i>0;i--){const j=(r()*(i+1))|0;[order[i],order[j]]=[order[j],order[i]]}
  const okT=(tx,ty)=>walkT[tIdx(tx,ty)]&&!blockT[tIdx(tx,ty)]&&!exclTile(tx,ty);
  const nearSea2=(tx,ty)=>{for(let j=-2;j<=2;j++)for(let i=-2;i<=2;i++){const a=tx+i,b=ty+j;if(inMap(a,b)&&elevT[tIdx(a,b)]<WL)return true}return false};
  // alberi
  for(const[tx,ty]of order){
    if(!okT(tx,ty))continue;
    const e0=elevT[tIdx(tx,ty)];if(e0<WL+.27)continue;
    const fF=forestF(tx+.5,ty+.5),dens=.64*fF+.05;
    if(r()>dens)continue;
    if(taken.has(key(tx-1,ty))||taken.has(key(tx+1,ty))||taken.has(key(tx,ty-1))||taken.has(key(tx,ty+1)))continue;
    if(taken.has(key(tx-1,ty-1))&&taken.has(key(tx+1,ty+1)))continue;
    taken.add(key(tx,ty));
    const hill=tx>52||ty<20,pine=hill?r()<.78:r()<.18;
    const e=ent({id:'t'+(n++),type:pine?'pine':'tree',v:(r()*(pine?4:6))|0,x:(tx+.5+(r()-.5)*.3)*TS,y:(ty+.92)*TS,tx,ty,alive:true,grow:1,t:0,wood:pine?2:3,flip:r()<.5});
    addBlock(e,tx,ty,1,1);
  }
  // palme sulle spiagge
  const pal=[];
  for(const[tx,ty]of order){
    const e0=elevT[tIdx(tx,ty)];
    if(!okT(tx,ty)||e0<SAND_LO||e0>SAND_HI)continue;
    if(pal.some(p=>hyp(p[0]-tx,p[1]-ty)<3.1))continue;
    if(r()>.5)continue;
    pal.push([tx,ty]);if(pal.length>=70)break;
  }
  pal.forEach((p,i)=>{const e=ent({id:'p'+i,type:'palm',v:i%3,x:(p[0]+.5)*TS,y:(p[1]+.92)*TS,tx:p[0],ty:p[1],coco:true,cd:0,flip:r()<.5});addBlock(e,p[0],p[1],1,1)});
  // massi della cava e rocce sparse sulle alture
  FIX.boulders.forEach((b,i)=>{const tx=Math.floor(b[0]),ty=Math.floor(b[1]);const e=ent({id:'r'+i,type:'rock',v:i%5,x:b[0]*TS,y:(ty+.92)*TS,tx,ty,alive:true,hp:0,t:0});addBlock(e,tx,ty,1,1)});
  {const rk=[];
   for(const[tx,ty]of order){
     if(rk.length>=16)break;
     if(!okT(tx,ty))continue;
     const e0=elevT[tIdx(tx,ty)];if(e0<WL+.34||forestF(tx+.5,ty+.5)>.3)continue;
     if(rk.some(p=>hyp(p[0]-tx,p[1]-ty)<6))continue;
     if(E.some(e=>e.type==='rock'&&hyp(e.tx-tx,e.ty-ty)<5))continue;
     rk.push([tx,ty]);
   }
   rk.forEach((p,i)=>{const e=ent({id:'rx'+i,type:'rock',v:(i*3)%5,x:(p[0]+.5)*TS,y:(p[1]+.92)*TS,tx:p[0],ty:p[1],alive:true,hp:0,t:0});addBlock(e,p[0],p[1],1,1)});}
  // cespugli: liane e bacche
  const bs=[];
  for(const[tx,ty]of order){
    if(!okT(tx,ty))continue;
    const f=forestF(tx+.5,ty+.5),e0=elevT[tIdx(tx,ty)];
    if(e0<WL+.3||f<.08||f>.95)continue;
    if(bs.some(p=>hyp(p[0]-tx,p[1]-ty)<3.1))continue;
    if(r()>.5)continue;
    bs.push([tx,ty]);if(bs.length>=70)break;
  }
  bs.forEach((p,i)=>{
    const berry=i%2===1;
    ent({id:(berry?'y':'b')+i,type:berry?'berry':'bush',v:i%3,x:(p[0]+.5)*TS,y:(p[1]+.9)*TS,tx:p[0],ty:p[1],ready:true,t:0});
  });
  // rottami sulla sabbia, pozze di marea
  const sand=order.filter(([tx,ty])=>walkT[tIdx(tx,ty)]&&!blockT[tIdx(tx,ty)]&&elevT[tIdx(tx,ty)]>WL+.08&&elevT[tIdx(tx,ty)]<WL+.17&&pathDist(tx+.5,ty+.5)>1.2);
  const pick=(arr,k,sep,f)=>{const out=[];for(const t of arr){if(!f(t))continue;if(out.some(p=>hyp(p[0]-t[0],p[1]-t[1])<sep))continue;out.push(t);if(out.length>=k)break}return out};
  const sw=pick(sand,26,5,t=>!exclTile(t[0],t[1]));
  sw.forEach((p,i)=>ent({id:'d'+i,type:'debris',x:(p[0]+.5)*TS,y:(p[1]+.8)*TS,tx:p[0],ty:p[1],got:false}));
  const rp=pick(order.filter(([tx,ty])=>walkT[tIdx(tx,ty)]&&!blockT[tIdx(tx,ty)]&&elevT[tIdx(tx,ty)]<WL+.13&&nearSea2(tx,ty)&&!exclTile(tx,ty)),26,5.6,()=>true);
  rp.forEach((p,i)=>{const e=ent({id:'m'+i,type:'rockpool',x:(p[0]+.5)*TS,y:(p[1]+.8)*TS,tx:p[0],ty:p[1],ready:true,t:0});addBlock(e,p[0],p[1],1,1)});
  // decorazioni fisse
  const deco=(id,spr,x,y,fp,o)=>{const e=ent(Object.assign({id,type:'deco',spr,x:x*TS,y:y*TS},o||{}));if(fp)addBlock(e,fp[0],fp[1],fp[2],fp[3]);return e};
  deco('mesa','mesa',MESA.x,MESA.y+MESA.ry*.92,null,{nohit:1});
  deco('feedback','sign',FIX.sign[0],FIX.sign[1],[Math.floor(FIX.sign[0]),Math.floor(FIX.sign[1]),1,1],{k:.9,hitw:64,hith:84,label:'Cartello dei capitani',inter:'sign'});
  deco('lookout','lookout',FIX.lookout[0],FIX.lookout[1],[Math.floor(FIX.lookout[0]),Math.floor(FIX.lookout[1]),1,1],{k:.95,hitw:90,hith:160,inter:'climb',label:'La vedetta'});
  // piazzole di costruzione
  for(const id in FIX.plots){const f=FIX.plots[id];
    const e=ent({id:'plot_'+id,type:'plot',pid:id,x:(f.tx+f.w/2)*TS,y:(f.ty+f.h)*TS-2,tx:f.tx,ty:f.ty,tw:f.w,th:f.h,st:0,prog:0});
    addBlock(e,f.tx,f.ty,f.w,f.h);
  }
  ent({id:'wparrot',type:'wparrot',x:-999,y:-999,alt:90,got:false});
  ent({id:'mraft',type:'mraft',x:-999,y:-999,hd:0});
  // casse sparse per la mappa (una sola volta ciascuna)
  {const cs=[],okSpot=(s0)=>{if(hyp(s0[0]-FIX.spawn[0],s0[1]-FIX.spawn[1])<8)return false;for(const f of cs)if(hyp(f[0]-s0[0],f[1]-s0[1])<10)return false;
      for(const e of E)if((e.type==='loot'||e.type==='deco'||e.type==='plot')&&hyp(e.x/TS-s0[0],e.y/TS-s0[1])<4)return false;return true};
   for(let k=0,tries=0;k<16&&tries<2500;tries++){const s0=sand[((r()*sand.length)|0)];if(!okSpot(s0)||exclTile(s0[0],s0[1]))continue;cs.push(s0);
     ent({id:'lt_cr'+k,type:'loot',kind:8,x:(s0[0]+.5)*TS,y:(s0[1]+.8)*TS,tx:s0[0],ty:s0[1],got:false,label:'Cassa'});k++}}
  // scenografia del Campo dei Fuggiaschi e della Cala
  Ch2.decor(deco);
  // granchi sulle spiagge
  {const cr=[];
   for(let ty=4;ty<MH-4;ty++)for(let tx=3;tx<MW-3;tx++){
     if(cr.length>=30)break;
     if(!walkT[tIdx(tx,ty)]||blockT[tIdx(tx,ty)]||exclTile(tx,ty)||elevT[tIdx(tx,ty)]>WL+.23||!nearSea2(tx,ty))continue;
     if(hyp(tx+.5-FIX.spawn[0],ty+.5-FIX.spawn[1])<6)continue;
     if(cr.some(c=>hyp(c[0]-tx,c[1]-ty)<6))continue;
     if(E.some(e=>e.type!=='deco'&&e.type!=='reef'&&e.x>0&&hyp(e.x-(tx+.5)*TS,e.y-(ty+.7)*TS)<TS*1.05))continue;
     cr.push([tx,ty]);
   }
   FIX.crabN=cr.length;
   cr.forEach((c,i)=>ent({id:'cb'+i,type:'crab',x:(c[0]+.5)*TS,y:(c[1]+.7)*TS,hx:(c[0]+.5)*TS,vx:0,ph:i*1.7,t:i*.9}));
  }
  // scogli nel mare aperto
  {const rr2=mulberry(33);let k=0;
   for(let tries=0;tries<3000&&k<34;tries++){
     const tx=3+((rr2()*93)|0),ty=3+((rr2()*54)|0);
     if(!seaT[tIdx(tx,ty)]||blockT[tIdx(tx,ty)]||elevT[tIdx(tx,ty)]>WL-.14)continue;
     if(hyp(tx-FIX.raftLaunch[0],ty-FIX.raftLaunch[1])<9)continue;
     if(hyp(tx-CV2.ship[0],ty-50.5)<9)continue;
     if(E.some(e=>e.type==='reef'&&hyp(e.tx-tx,e.ty-ty)<3.2))continue;
     const e=ent({id:'rf'+k,type:'reef',v:k%5,x:(tx+.5)*TS,y:(ty+.8)*TS,tx,ty});addBlock(e,tx,ty,1,1);k++;
   }}
  fixOccluded(nearSea2);
}
'''
rep("\n/* ---- 07_audio.js ---- */",code+"\n/* ---- 07_audio.js ---- */")
# Ch2 namespace with decor stub placed before 06_world so genWorld2 can call it at runtime (defined later is fine since called at boot)
rep("const Story={};","const Story={};\nconst Ch2={};")
open(p,'w',encoding='utf8').write(s)
print('ok')
