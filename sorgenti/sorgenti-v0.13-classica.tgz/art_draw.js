/* ---------------- arredi: sprite statici in cache + effetti dinamici ---------------- */
const PAD=100,PC={};
const WD={edge:'#2a160a'};
/* scatola in prospettiva: B = linea di terra davanti, fd = profondità del piano, h = altezza */
function bx(g,x,B,w,fd,h,top,front,o){
  o=o||{};
  g.fillStyle=front;g.fillRect(x,B-h,w,h);
  if(!o.noPlank){g.fillStyle='rgba(0,0,0,.15)';for(let yy=B-h+9;yy<B-3;yy+=9)g.fillRect(x,yy,w,1.4)}
  g.fillStyle='rgba(0,0,0,.28)';g.fillRect(x,B-h,w,3);
  g.fillStyle=top;g.fillRect(x,B-h-fd,w,fd);
  g.fillStyle='rgba(255,240,200,.26)';g.fillRect(x,B-h-fd,w,3);g.fillRect(x,B-h-fd,2.5,fd);
  g.fillStyle='rgba(0,0,0,.2)';g.fillRect(x+w-3,B-h-fd,3,fd+h);
  g.fillStyle='rgba(0,0,0,.2)';g.fillRect(x,B-4,w,4);
  g.strokeStyle=WD.edge;g.lineWidth=2;g.strokeRect(x+1,B-h-fd+1,w-2,h+fd-2);
  g.strokeStyle='rgba(0,0,0,.35)';g.lineWidth=1.4;g.beginPath();g.moveTo(x+1,B-h);g.lineTo(x+w-1,B-h);g.stroke();
}
const PK={};
const ell=(g,x,y,rx,ry,f,s,lw)=>{g.beginPath();g.ellipse(x,y,rx,ry,0,0,7);if(f){g.fillStyle=f;g.fill()}if(s){g.strokeStyle=s;g.lineWidth=lw||1.4;g.stroke()}};
const candle=(g,x,y)=>{g.fillStyle='#f4efe0';g.fillRect(x-2,y-8,4,8);g.fillStyle='#ffd23a';g.beginPath();g.ellipse(x,y-11,2.2,3.4,0,0,7);g.fill();const gr=g.createRadialGradient(x,y-10,1,x,y-10,16);gr.addColorStop(0,'rgba(255,220,120,.55)');gr.addColorStop(1,'rgba(255,220,120,0)');g.fillStyle=gr;g.fillRect(x-16,y-26,32,32)};
const plate=(g,x,y)=>{ell(g,x,y,8,4,'#f4efe0','#6a5a3a',1);ell(g,x,y,4.5,2.2,'rgba(0,0,0,.12)')};
const mug=(g,x,y)=>{g.fillStyle='#c8a050';g.fillRect(x-3,y-8,7,8);g.strokeStyle='#3a2410';g.lineWidth=1.2;g.strokeRect(x-3,y-8,7,8);g.beginPath();g.arc(x+5,y-4,2.6,-1.4,1.4);g.stroke();ell(g,x+.5,y-8,3.5,1.6,'#5a2a14')};
PK.bed=(g,gw,gd)=>{
  g.fillStyle='#3a200c';g.fillRect(4,0,gw-8,gd-4);
  g.fillStyle='#5a3418';g.fillRect(4,0,gw-8,18);g.fillStyle='#8a5a2a';g.fillRect(4,0,gw-8,5);
  g.fillStyle='#e0b04a';for(const px of[7,gw-15]){g.fillRect(px,-20,8,26);ell(g,px+4,-22,6,5,'#f2c04a','#8a6a1a',1.2)}
  g.fillStyle='#f1e7cf';g.fillRect(9,20,gw-18,gd-36);
  for(const px of[13,gw/2+3]){rrect(g,px,22,gw/2-18,18,6);g.fillStyle='#fffdf4';g.fill();g.strokeStyle='rgba(120,100,70,.55)';g.lineWidth=1;g.stroke()}
  g.fillStyle='#b8402e';g.fillRect(9,46,gw-18,gd-62);g.fillStyle='#e0b04a';g.fillRect(9,46,gw-18,3);
  g.fillStyle='rgba(255,255,255,.12)';g.fillRect(9,49,gw-18,5);
  g.fillStyle='#e0b04a';for(let i=0;i<5;i++)g.fillRect(16+i*((gw-40)/4),58,6,6);
  g.fillStyle='rgba(0,0,0,.18)';g.fillRect(9,gd-20,gw-18,5);
  g.fillStyle='#5a3418';g.fillRect(4,gd-17,gw-8,13);g.fillStyle='#8a5a2a';g.fillRect(4,gd-17,gw-8,3);
  g.strokeStyle=WD.edge;g.lineWidth=2;g.strokeRect(4,0,gw-8,gd-4)};
PK.bunk=(g,gw,gd,e)=>{
  const B=gd-4,col=e.c||'#a8503a';
  g.fillStyle='#4a2c14';g.fillRect(3,B-34,7,34);g.fillStyle='#8a5a2a';g.fillRect(3,B-34,7,3);g.strokeStyle=WD.edge;g.lineWidth=1.6;g.strokeRect(3,B-34,7,34);
  bx(g,8,B,gw-12,16,12,'#8a6030','#5a3418');
  g.fillStyle='#efe3c4';g.fillRect(11,B-12-16+2,gw-18,12);
  g.fillStyle=col;g.fillRect(34,B-12-16+2,gw-40,12);g.fillStyle='rgba(0,0,0,.18)';g.fillRect(34,B-12-16+2+8,gw-40,4);g.fillStyle='rgba(255,255,255,.2)';g.fillRect(34,B-12-16+2,gw-40,2);
  rrect(g,13,B-12-16+3,18,10,4);g.fillStyle='#fffdf4';g.fill();g.strokeStyle='rgba(120,100,70,.6)';g.lineWidth=1;g.stroke();
  g.fillStyle='#e0b04a';ell(g,6.5,B-37,3,2.4,'#e0b04a')};
function tbl(g,gw,gd,e,topC,frontC,h){
  const B=gd-4,fd=gd-18;
  g.fillStyle='#2e1a0a';g.fillRect(5,B-h,6,h);g.fillRect(gw-11,B-h,6,h);
  bx(g,2,B-3,gw-4,fd,h-3,topC,frontC);
  const ty=B-3-(h-3)-fd;return{ty,fd}}
PK.table=(g,gw,gd,e)=>{
  const{ty,fd}=tbl(g,gw,gd,e,'#b8864c','#6a4220',16),cy0=ty+fd/2+3;
  if(e.t==='prep'){
    g.fillStyle='#e6d6a8';g.fillRect(gw*.12,ty+4,gw*.3,fd-8);g.strokeStyle='#8a6a3a';g.lineWidth=1.2;g.strokeRect(gw*.12,ty+4,gw*.3,fd-8);
    g.fillStyle='#7aa860';ell(g,gw*.2,cy0,5,3,'#7aa860');ell(g,gw*.28,cy0+1,4,3,'#d8603a');ell(g,gw*.34,cy0-1,4,2.6,'#e0b04a');
    g.strokeStyle='#cfd6de';g.lineWidth=2;g.beginPath();g.moveTo(gw*.14,cy0+7);g.lineTo(gw*.26,cy0+5);g.stroke();
    g.fillStyle='#34343c';g.fillRect(gw*.62,cy0-6,gw*.24,14);ell(g,gw*.74,cy0-6,gw*.12,5,'#4a4a54','#1a1a20',1.6);ell(g,gw*.74,cy0-6,gw*.09,3.4,'#7a3a1a');
    g.fillStyle='#34343c';g.fillRect(gw*.86,cy0-4,8,3)}
  else{plate(g,gw*.28,cy0);plate(g,gw*.72,cy0);mug(g,gw*.46,cy0+1);candle(g,gw*.54,cy0+2)}};
PK.longtable=(g,gw,gd,e)=>{
  const t=e.t||'mess';
  const top=t==='council'?'#8a5a30':t==='dice'?'#a87a46':'#b8864c',front=t==='council'?'#4a2c14':'#6a4220';
  const h=t==='council'?20:16,{ty,fd}=tbl(g,gw,gd,e,top,front,h);
  if(t==='mess'){const n=Math.floor(gw/44);for(let i=0;i<n;i++){const x=gw*(i+.5)/n;plate(g,x-8,ty+fd*.42);mug(g,x+10,ty+fd*.5);if(i%2)ell(g,x+2,ty+fd*.72,6,3,'#d8b070','#8a6030',1)}}
  else if(t==='dice'){g.fillStyle='#2e6a46';rrect(g,gw*.14,ty+3,gw*.72,fd-6,5);g.fill();g.strokeStyle='#e0b04a';g.lineWidth=1.6;g.stroke();
    for(const[dx,dy]of[[.4,.45],[.55,.58]]){g.fillStyle='#fffdf4';g.fillRect(gw*dx,ty+fd*dy-4,9,9);g.strokeStyle='#3a2410';g.lineWidth=1;g.strokeRect(gw*dx,ty+fd*dy-4,9,9);g.fillStyle='#222';g.fillRect(gw*dx+2,ty+fd*dy-2,2,2);g.fillRect(gw*dx+5,ty+fd*dy+1,2,2)}
    for(const[dx,dy]of[[.25,.5],[.7,.4],[.72,.65]])ell(g,gw*dx,ty+fd*dy,4,2.4,'#f2c04a','#8a6a1a',1);
    mug(g,gw*.2,ty+fd*.75)}
  else{g.fillStyle='#e6d6a8';g.save();g.translate(gw*.2,ty+5);g.fillRect(0,0,gw*.5,fd-10);g.strokeStyle='#7a5a2a';g.lineWidth=1.2;g.strokeRect(0,0,gw*.5,fd-10);g.strokeStyle='#5a7a4a';g.lineWidth=1.6;g.beginPath();g.moveTo(8,fd-18);g.bezierCurveTo(30,4,60,fd-14,gw*.5-10,8);g.stroke();g.strokeStyle='#a02a1e';g.lineWidth=2;g.beginPath();g.moveTo(gw*.35,6);g.lineTo(gw*.35+8,14);g.moveTo(gw*.35+8,6);g.lineTo(gw*.35,14);g.stroke();g.restore();
    candle(g,gw*.1,ty+fd*.7);candle(g,gw*.9,ty+fd*.7);g.strokeStyle='#e8e0c8';g.lineWidth=2;g.beginPath();g.moveTo(gw*.78,ty+fd*.7);g.lineTo(gw*.84,ty+fd*.35);g.stroke()}};
PK.maptable=(g,gw,gd,e)=>{
  const{ty,fd}=tbl(g,gw,gd,e,'#6a4a2a','#3a2410',20);
  g.fillStyle='#2f78a8';rrect(g,gw*.08,ty+3,gw*.84,fd-6,3);g.fill();g.strokeStyle='#e0b04a';g.lineWidth=1.6;g.stroke();
  g.fillStyle='#d8c58a';for(const[a,b,r]of[[.25,.45,9],[.5,.55,12],[.72,.4,8]])ell(g,gw*a,ty+fd*b,r,r*.55,'#d8c58a','#7a5a2a',1);
  g.strokeStyle='#a02a1e';g.lineWidth=1.4;g.setLineDash([3,3]);g.beginPath();g.moveTo(gw*.18,ty+fd*.7);g.lineTo(gw*.5,ty+fd*.45);g.lineTo(gw*.8,ty+fd*.65);g.stroke();g.setLineDash([]);
  ell(g,gw*.86,ty+fd*.3,7,7,'#f4efe0','#3a2410',1.2);g.fillStyle='#a02a1e';g.beginPath();g.moveTo(gw*.86,ty+fd*.3-6);g.lineTo(gw*.86+2.5,ty+fd*.3);g.lineTo(gw*.86-2.5,ty+fd*.3);g.fill();
  g.fillStyle='#d83a2a';for(const[a,b]of[[.3,.4],[.62,.5]]){g.beginPath();g.arc(gw*a,ty+fd*b,2.4,0,7);g.fill()}
  candle(g,gw*.04,ty+fd*.5)};
PK.chair=(g,gw,gd,e)=>{
  const d=e.d||'d',wood='#7a4c22',cush='#a02a1e';
  const seat=(x,y,w,h)=>{g.fillStyle='#4a2a12';g.fillRect(x+1,y+h-1,4,8);g.fillRect(x+w-5,y+h-1,4,8);g.fillStyle=wood;g.fillRect(x,y,w,h);g.fillStyle=cush;g.fillRect(x+2,y+2,w-4,h-4);g.fillStyle='rgba(255,255,255,.2)';g.fillRect(x+2,y+2,w-4,3);g.strokeStyle=WD.edge;g.lineWidth=1.6;g.strokeRect(x+.8,y+.8,w-1.6,h-1.6)};
  const back=(x,y,w,h)=>{g.fillStyle=wood;g.fillRect(x,y,w,h);g.fillStyle='rgba(255,236,190,.25)';g.fillRect(x,y,w,2);g.strokeStyle=WD.edge;g.lineWidth=1.6;g.strokeRect(x+.8,y+.8,w-1.6,h-1.6);g.fillStyle='rgba(0,0,0,.28)';for(let i=1;i<3;i++){if(w>h)g.fillRect(x+i*w/3,y+2,1.5,h-4);else g.fillRect(x+2,y+i*h/3,w-4,1.5)}};
  if(d==='d'){back(11,6,22,12);seat(11,18,22,18)}
  else if(d==='u'){seat(11,10,22,18);back(10,28,24,11)}
  else if(d==='l'){seat(9,14,22,20);back(31,6,8,30)}
  else{seat(13,14,22,20);back(5,6,8,30)}};
PK.bench=(g,gw,gd)=>{const B=gd-8;g.fillStyle='#2e1a0a';g.fillRect(8,B-8,5,8);g.fillRect(gw-13,B-8,5,8);bx(g,3,B-7,gw-6,14,3,'#a87a46','#6a4220')};
PK.wardrobe=(g,gw,gd)=>{
  const B=gd-4;bx(g,2,B,gw-4,gd-16,66,'#c89a5a','#7a4c22',{noPlank:1});
  const x=2,w=gw-4,y=B-66;
  g.fillStyle='#5a3418';g.fillRect(x,y,w,7);g.fillStyle='#e0b04a';g.fillRect(x,y+7,w,2);
  for(let i=0;i<2;i++){const px=x+5+i*(w/2-1);g.strokeStyle='#3a200c';g.lineWidth=1.8;g.strokeRect(px,y+14,w/2-9,42);g.fillStyle='rgba(255,236,190,.1)';g.fillRect(px+3,y+17,w/2-15,15);g.strokeStyle='rgba(0,0,0,.3)';g.strokeRect(px+3,y+17,w/2-15,15);g.strokeRect(px+3,y+35,w/2-15,15)}
  g.fillStyle='#3a200c';g.fillRect(gw/2-1.5,y+9,3,47);
  g.fillStyle='#f2c04a';for(const px of[gw/2-9,gw/2+6])ell(g,px,y+36,2.6,2.6,'#f2c04a','#8a6a1a',1);
  g.fillStyle='#4a2a12';g.fillRect(x+4,B-5,8,5);g.fillRect(x+w-12,B-5,8,5)};
PK.bookshelf=(g,gw,gd)=>{
  const B=gd-4,w=gw-4,h=62;bx(g,2,B,w,gd-18,h,'#c89a5a','#4a2a12',{noPlank:1});
  const y=B-h;g.fillStyle='#241408';g.fillRect(6,y+6,w-8,h-12);
  const cs=['#b02a22','#2f78a8','#5a8a46','#e0b04a','#7a4a8a','#c8603a','#3a5a6a','#d8d0b8'],rnd=mkRnd(gw*7+gd);
  for(let r=0;r<3;r++){const ry=y+6+r*18;let x=8;while(x<w-8){const bw=3+((rnd()*5)|0),bh=11+((rnd()*5)|0);g.fillStyle=cs[(rnd()*cs.length)|0];g.fillRect(x,ry+16-bh,bw,bh);g.fillStyle='rgba(255,255,255,.22)';g.fillRect(x,ry+16-bh,1.2,bh);x+=bw+1}
    g.fillStyle='#8a5a2a';g.fillRect(6,ry+16,w-8,3)}
  g.fillStyle='#e0b04a';g.fillRect(2,y,w,3)};
PK.globe=(g,gw,gd)=>{
  const cx0=gw/2;ell(g,cx0,gd-7,13,4.5,'#3a200c','#1a0c04',1.2);g.fillStyle='#6a4220';g.fillRect(cx0-2,gd-24,4,17);
  g.strokeStyle='#e0b04a';g.lineWidth=2.6;g.beginPath();g.arc(cx0,gd-30,15,Math.PI*.75,Math.PI*2.25);g.stroke();
  const gr=g.createRadialGradient(cx0-5,gd-36,2,cx0,gd-30,14);gr.addColorStop(0,'#6fb4e0');gr.addColorStop(1,'#1f5a8a');g.fillStyle=gr;g.beginPath();g.arc(cx0,gd-30,12.5,0,7);g.fill();
  g.fillStyle='#7aa860';g.beginPath();g.ellipse(cx0-3,gd-33,5,3.4,.4,0,7);g.ellipse(cx0+4,gd-27,3.6,2.6,-.3,0,7);g.fill();
  g.strokeStyle='rgba(255,255,255,.3)';g.lineWidth=.8;g.beginPath();g.ellipse(cx0,gd-30,12.5,5,0,0,7);g.stroke();g.strokeStyle=WD.edge;g.lineWidth=1.2;g.beginPath();g.arc(cx0,gd-30,12.5,0,7);g.stroke()};
PK.chest=(g,gw,gd,e)=>{
  const B=gd-6,med=e.med;
  bx(g,6,B,gw-12,14,13,med?'#e8e0cc':'#9a6632',med?'#d8d0b8':'#6a3e1c');
  const x=6,w=gw-12,ty=B-13-14;
  g.fillStyle=med?'#c8c0a8':'#8a8f9a';g.fillRect(x+4,ty,5,27);g.fillRect(x+w-9,ty,5,27);
  if(med){g.fillStyle='#d83a2a';g.fillRect(gw/2-2.5,ty+3,5,13);g.fillRect(gw/2-6.5,ty+7,13,5)}
  else{g.fillStyle='#f2c04a';g.fillRect(gw/2-4,B-13-3,8,9);g.strokeStyle='#8a6a1a';g.lineWidth=1;g.strokeRect(gw/2-4,B-13-3,8,9);g.fillStyle='#3a2410';g.fillRect(gw/2-1,B-13+1,2,3)}};
PK.desk=(g,gw,gd)=>{
  const{ty,fd}=tbl(g,gw,gd,{},'#b07a3e','#7a4c22',24);
  g.fillStyle='rgba(0,0,0,.28)';for(let i=0;i<3;i++){g.fillRect(14+i*(gw-28)/3,gd-4-3-18,(gw-28)/3-8,13);}
  g.fillStyle='#f2c04a';for(let i=0;i<3;i++)ell(g,14+i*(gw-28)/3+((gw-28)/3-8)/2,gd-4-3-12,2.4,2.4,'#f2c04a');
  g.fillStyle='#f4efe0';g.fillRect(gw*.12,ty+6,28,fd-12);g.strokeStyle='#8a7a5a';g.lineWidth=1;g.strokeRect(gw*.12,ty+6,28,fd-12);g.fillStyle='rgba(60,40,20,.5)';for(let i=0;i<4;i++)g.fillRect(gw*.12+4,ty+10+i*5,20,1.4);
  g.fillStyle='#e6d6a8';g.fillRect(gw*.34,ty+9,22,12);g.strokeStyle='#8a7a5a';g.strokeRect(gw*.34,ty+9,22,12);
  ell(g,gw*.62,ty+fd*.5,5,3.4,'#1a1a20','#5a5a64',1);g.strokeStyle='#f4efe0';g.lineWidth=2;g.beginPath();g.moveTo(gw*.64,ty+fd*.5);g.lineTo(gw*.7,ty+fd*.22);g.stroke();
  g.fillStyle='#d8412f';g.beginPath();g.arc(gw*.78,ty+fd*.55,3.4,0,7);g.fill();candle(g,gw*.9,ty+fd*.7)};
PK.barrel=(g,gw,gd,e)=>{
  const bx0=gw/2,by=gd-8,pw=!!e.powder;
  g.fillStyle=pw?'#3e3830':'#7a4c22';g.fillRect(bx0-14,by-30,28,30);
  g.fillStyle=pw?'#2a2620':'#5a3418';g.fillRect(bx0+6,by-30,8,30);g.fillStyle='rgba(255,236,190,.18)';g.fillRect(bx0-14,by-30,5,30);
  g.fillStyle=pw?'#b82a22':'#4a2a12';for(const yy of[-24,-8])g.fillRect(bx0-14,by+yy,28,3.4);
  g.strokeStyle='rgba(0,0,0,.28)';g.lineWidth=1;for(const xx of[-7,0,7]){g.beginPath();g.moveTo(bx0+xx,by-30);g.lineTo(bx0+xx,by);g.stroke()}
  ell(g,bx0,by-30,14,7,pw?'#4e463c':'#9a6632','#2a160a',2);ell(g,bx0,by-30,10,4.6,'rgba(0,0,0,.18)');
  g.strokeStyle='#2a160a';g.lineWidth=2;g.strokeRect(bx0-14,by-30,28,30);
  if(pw){g.fillStyle='#e8e0cc';g.beginPath();g.arc(bx0,by-16,4.4,0,7);g.fill();g.fillRect(bx0-2.6,by-13,5.2,3.4);g.fillStyle='#241408';g.fillRect(bx0-2.4,by-17.6,1.8,2);g.fillRect(bx0+.6,by-17.6,1.8,2)}};
PK.sack=(g,gw,gd)=>{
  const x=gw/2,y=gd-6;g.fillStyle='#b8a070';g.beginPath();g.moveTo(x-14,y);g.bezierCurveTo(x-20,y-14,x-12,y-26,x-5,y-31);g.lineTo(x+5,y-31);g.bezierCurveTo(x+12,y-26,x+20,y-14,x+14,y);g.closePath();g.fill();g.strokeStyle='#3a2a14';g.lineWidth=2;g.stroke();
  g.fillStyle='rgba(255,240,200,.28)';g.beginPath();g.ellipse(x-6,y-14,4,9,.2,0,7);g.fill();
  g.strokeStyle='#6a4a1a';g.lineWidth=3;g.beginPath();g.moveTo(x-6,y-28);g.lineTo(x+6,y-28);g.stroke();g.fillStyle='#8a6a2a';g.beginPath();g.moveTo(x-7,y-31);g.lineTo(x-11,y-37);g.lineTo(x-3,y-33);g.moveTo(x+7,y-31);g.lineTo(x+11,y-37);g.lineTo(x+3,y-33);g.fill()};
PK.coil=(g,gw,gd)=>{const x=gw/2,y=gd/2+3;ell(g,x,y+3,19,10,'rgba(0,0,0,.25)');for(let i=0;i<4;i++)ell(g,x,y-i*1.2,17-i*3.4,9-i*1.8,i%2?'#b89a5a':'#a08444','#4a3414',1.4);ell(g,x,y-4,4,2,'#2a1c08')};
PK.bucket=(g,gw,gd)=>{const x=gw/2,y=gd-8;g.fillStyle='#7a4c22';g.beginPath();g.moveTo(x-11,y-22);g.lineTo(x+11,y-22);g.lineTo(x+8,y);g.lineTo(x-8,y);g.closePath();g.fill();g.strokeStyle='#2a160a';g.lineWidth=2;g.stroke();
  g.fillStyle='#8a8f9a';g.fillRect(x-10,y-16,20,2.6);g.fillRect(x-8.6,y-6,17,2.6);ell(g,x,y-22,11,4.4,'#2f5a7a','#2a160a',1.6);g.strokeStyle='#8a8f9a';g.lineWidth=1.6;g.beginPath();g.arc(x,y-22,11,Math.PI,0);g.stroke()};
PK.stove=(g,gw,gd)=>{
  const B=gd-4;g.fillStyle='#2a2a30';g.fillRect(gw-30,B-110,14,84);g.fillStyle='#4a4a54';g.fillRect(gw-33,B-114,20,8);g.strokeStyle='#14141a';g.lineWidth=1.6;g.strokeRect(gw-30,B-110,14,84);
  bx(g,3,B,gw-6,gd-18,32,'#5a5a64','#34343c',{noPlank:1});
  g.fillStyle='#1a1a20';g.beginPath();g.moveTo(14,B-4);g.lineTo(14,B-16);g.arc(26,B-16,12,Math.PI,0);g.lineTo(38,B-4);g.closePath();g.fill();g.strokeStyle='#6a6a74';g.lineWidth=1.6;g.stroke();
  g.fillStyle='#8a8f9a';ell(g,gw-52,B-32-14,10,4,'#2a2a30','#6a6a74',1.4);for(const px of[gw-70,gw-52])ell(g,px,B-32-12,9,3.6,'#14141a','#6a6a74',1.2);
  g.fillStyle='#8a5a2a';g.fillRect(gw-12,B-32-26,3,18)};
PK.rack=(g,gw,gd,e)=>{
  const B=gd-6;g.fillStyle='#5a3418';g.fillRect(4,B-46,gw-8,46);g.strokeStyle=WD.edge;g.lineWidth=2;g.strokeRect(4,B-46,gw-8,46);g.fillStyle='rgba(255,236,190,.18)';g.fillRect(4,B-46,gw-8,3);
  g.fillStyle='#3a200c';g.fillRect(4,B-40,gw-8,5);g.fillRect(4,B-14,gw-8,5);
  const n=Math.floor((gw-16)/14);
  for(let i=0;i<n;i++){const x=12+i*((gw-24)/(n-1)),k=i%3;
    if(k===1){g.fillStyle='#6a4220';g.fillRect(x-2,B-44,4,42);g.fillStyle='#2e2e36';g.fillRect(x-1.4,B-62,2.8,20);g.fillStyle='#8a5a2a';g.fillRect(x-3,B-30,6,10)}
    else{g.fillStyle='#d4dbe4';g.fillRect(x-2,B-62,4,38);g.fillStyle='#ffffff';g.fillRect(x-2,B-62,1.4,38);g.fillStyle='#e0b04a';g.fillRect(x-7,B-25,14,4);g.fillStyle='#4a2c18';g.fillRect(x-2.4,B-21,5,14);ell(g,x,B-6,3.4,3.4,'#e0b04a','#8a6a1a',1)}}};
PK.armor=(g,gw,gd)=>{
  const x=gw/2,B=gd-5;g.fillStyle='#3a200c';g.fillRect(x-14,B-5,28,5);g.fillRect(x-2.5,B-52,5,48);
  g.fillStyle='#9aa2b0';g.beginPath();g.moveTo(x-13,B-48);g.lineTo(x+13,B-48);g.lineTo(x+10,B-22);g.lineTo(x-10,B-22);g.closePath();g.fill();g.strokeStyle='#2a2e38';g.lineWidth=1.8;g.stroke();
  g.fillStyle='rgba(255,255,255,.4)';g.fillRect(x-9,B-46,5,22);g.fillStyle='#5a6070';g.fillRect(x-10,B-34,20,2.4);
  ell(g,x-16,B-46,6,5,'#b4bcc8','#2a2e38',1.4);ell(g,x+16,B-46,6,5,'#b4bcc8','#2a2e38',1.4);
  g.fillStyle='#8a929e';g.beginPath();g.arc(x,B-58,10,Math.PI,0);g.lineTo(x+10,B-52);g.lineTo(x-10,B-52);g.closePath();g.fill();g.stroke();g.fillStyle='#14141a';g.fillRect(x-7,B-57,14,3.4);
  g.fillStyle='#b02a22';g.beginPath();g.moveTo(x-1,B-68);g.quadraticCurveTo(x+14,B-76,x+10,B-60);g.lineTo(x+2,B-62);g.closePath();g.fill();
  g.fillStyle='#a02a1e';g.fillRect(x-9,B-22,18,12);g.fillStyle='#e0b04a';g.fillRect(x-9,B-22,18,2)};
PK.cannon=(g,gw,gd,e)=>{
  const dd=e.d>0?1:-1,cx0=gw/2,cy0=gd/2;
  // affusto di legno + ruote
  g.fillStyle='#5a3418';g.fillRect(cx0-12,cy0-10,24,26);g.strokeStyle=WD.edge;g.lineWidth=1.8;g.strokeRect(cx0-12,cy0-10,24,26);
  g.fillStyle='#2a1a0a';for(const px of[cx0-16,cx0+10])g.fillRect(px,cy0+2,6,16);
  // canna
  const y0=dd>0?cy0-14:cy0-8,y1=dd>0?cy0+20:cy0+14;
  const gr=g.createLinearGradient(cx0-8,0,cx0+8,0);gr.addColorStop(0,'#3a3a42');gr.addColorStop(.35,'#6a6a74');gr.addColorStop(1,'#14141a');
  g.fillStyle=gr;g.fillRect(cx0-8,Math.min(y0,y1),16,Math.abs(y1-y0));g.strokeStyle='#0a0a0e';g.lineWidth=1.6;g.strokeRect(cx0-8,Math.min(y0,y1),16,Math.abs(y1-y0));
  g.fillStyle='#8a8f9a';g.fillRect(cx0-10,dd>0?y1-5:y1-1+(dd<0?-0:0),20,6);
  const my=dd>0?y1+1:y0-1;g.fillStyle='#0a0a0e';ell(g,cx0,my,6,3,'#0a0a0e');
  ell(g,cx0,dd>0?y0-2:y1+2,6,6,'#2a2a32','#0a0a0e',1.4);
  g.fillStyle='rgba(255,255,255,.25)';g.fillRect(cx0-5,Math.min(y0,y1)+3,2.4,Math.abs(y1-y0)-8);
  g.strokeStyle='#8a6a3a';g.lineWidth=2;g.beginPath();g.moveTo(cx0-12,cy0+14);g.quadraticCurveTo(cx0,cy0+22,cx0+12,cy0+14);g.stroke()};
function spr(e){
  const key=e.kind+'|'+e.gw+'x'+e.gh+'|'+(e.c||'')+(e.t||'')+(e.d||'')+(e.plain?'p':'')+(e.powder?'w':'')+(e.med?'m':'');
  let c=PC[key];
  if(!c){const gw=e.gw*T,gd=e.gh*T;c=document.createElement('canvas');c.width=gw+16;c.height=gd+PAD+10;const g=c.getContext('2d');g.translate(8,PAD);g.lineCap='round';PK[e.kind](g,gw,gd,e);PC[key]=c}
  return c}
function drawMast(g,e,t,x0,y0,gw,gd){
  const bx0=x0+T/2,by=y0+T-6;
  g.save();if(P.y<by&&P.y>by-200&&Math.abs(P.x-bx0)<60)g.globalAlpha=.4;
  g.fillStyle='rgba(10,8,20,.28)';g.beginPath();g.ellipse(bx0,by,20,9,0,0,7);g.fill();
  g.fillStyle='#3a2410';g.beginPath();g.ellipse(bx0,by,16,8,0,0,7);g.fill();g.strokeStyle='#e0b04a';g.lineWidth=2;g.beginPath();g.ellipse(bx0,by,16,8,0,0,7);g.stroke();
  g.fillStyle='#6a4426';g.fillRect(bx0-8,by-190,16,190);g.fillStyle='rgba(255,230,170,.25)';g.fillRect(bx0-8,by-190,4,190);g.fillStyle='rgba(0,0,0,.2)';g.fillRect(bx0+4,by-190,4,190);
  g.strokeStyle='#2a160a';g.lineWidth=2;g.strokeRect(bx0-8,by-190,16,190);
  g.fillStyle='#4a2a12';for(const yy of[-30,-70,-110,-150])g.fillRect(bx0-8,by+yy,16,5);
  g.fillStyle='#e8dcc0';g.fillRect(bx0-46,by-176,92,22);g.strokeRect(bx0-46,by-176,92,22);g.fillStyle='#d8c79a';g.fillRect(bx0-46,by-154,92,6);
  g.fillStyle='#b02a22';g.fillRect(bx0-12,by-175,24,20);g.fillStyle='#e8b82a';g.fillRect(bx0-12,by-169,24,8);
  g.strokeStyle='rgba(40,26,12,.8)';g.lineWidth=1.6;g.beginPath();g.moveTo(bx0,by-170);g.lineTo(bx0-50,by-8);g.moveTo(bx0,by-170);g.lineTo(bx0+50,by-8);g.stroke();
  g.lineWidth=1;for(let i=1;i<6;i++){const yy=by-170+i*27,xo=50*i/6.3;g.beginPath();g.moveTo(bx0-xo,yy);g.lineTo(bx0+xo,yy);g.stroke()}
  g.restore()}
function drawProp(g,e,t){
  const gw=e.gw*T,gd=e.gh*T,x0=wx(e.gx),y0=wy(e.gy),k=e.kind;
  if(k==='mast')return drawMast(g,e,t,x0,y0,gw,gd);
  g.save();
  if(k==='crate'){g.fillStyle='rgba(10,8,20,.0)';drawSilverChest(g,x0+T/2,y0+T-4,t,e.gx+e.gy,!!K[e.obj]);g.restore();return}
  if(k!=='coil'&&k!=='bench'&&k!=='chair'){g.fillStyle='rgba(10,8,20,.26)';g.beginPath();g.ellipse(x0+gw/2,y0+gd-3,gw*.48,Math.max(5,gd*.15),0,0,7);g.fill()}
  g.drawImage(spr(e),x0-8,y0-PAD);
  /* effetti dinamici */
  const o=e.obj;
  if(k==='chest'&&o==='k1'&&!K.key1){const a=.5+.5*Math.sin(t*5);g.fillStyle='rgba(255,246,200,'+a+')';g.beginPath();g.arc(x0+gw-10,y0+gd-34,3+a*2,0,7);g.fill()}
  if(k==='chest'&&o==='med'&&!K.medUsed){const a=.5+.5*Math.sin(t*4);g.fillStyle='rgba(255,255,255,'+(.4+.5*a)+')';g.beginPath();g.arc(x0+gw-9,y0+gd-36,2.6+a*2,0,7);g.fill()}
  if(k==='barrel'&&e.red){if(!K.key2){g.fillStyle='#d8412f';g.beginPath();g.arc(x0+T/2+4,y0+T-8-31,3.5,0,7);g.fill();const a=.5+.5*Math.sin(t*5);g.fillStyle='rgba(255,246,200,'+a+')';g.beginPath();g.arc(x0+T/2+10,y0+T-8-38,3+a*2,0,7);g.fill()}else{g.fillStyle='#d8412f';g.beginPath();g.arc(x0+T/2+4,y0+T-8-31,3.5,0,7);g.fill()}}
  if(k==='stove'){const f=.5+.3*Math.sin(t*9);g.fillStyle='rgba(255,150,60,'+f+')';g.beginPath();g.moveTo(x0+18,y0+gd-8);g.quadraticCurveTo(x0+26,y0+gd-24-f*4,x0+34,y0+gd-8);g.fill();g.fillStyle='rgba(255,230,120,'+(f+.2)+')';g.beginPath();g.moveTo(x0+23,y0+gd-8);g.quadraticCurveTo(x0+26,y0+gd-18,x0+29,y0+gd-8);g.fill()}
  if(k==='table'&&e.t==='prep'){for(let i=0;i<3;i++){const ph=(t*.9+i*.33)%1;g.fillStyle='rgba(240,240,240,'+(.45*(1-ph))+')';g.beginPath();g.arc(x0+gw*.74+Math.sin(t*2+i)*4,y0+gd-4-19-14-ph*30,4+ph*5,0,7);g.fill()}}
  if(k==='rack'&&o==='sword'&&!K.sword){const a=.5+.5*Math.sin(t*4);g.fillStyle='rgba(255,236,150,'+(.3+.5*a)+')';g.save();g.translate(x0+gw/2,y0+gd-52);g.rotate(t*.6);g.fillRect(-1.4,-8,2.8,16);g.fillRect(-8,-1.4,16,2.8);g.restore()}
  if(k==='cannon'&&o==='lure'){const a=.5+.5*Math.sin(t*4);const rdy=(K.lureCd||0)<=0;g.fillStyle=rdy?'rgba(255,170,60,'+(.4+.5*a)+')':'rgba(180,180,190,.35)';g.beginPath();g.arc(x0+T/2,y0+T/2+(e.d>0?24:-20),3.4+a*(rdy?2:0),0,7);g.fill()}
  if(k==='maptable'&&K.routesT>0){g.fillStyle='rgba(255,240,170,'+(.2+.2*Math.sin(t*6))+')';g.fillRect(x0+4,y0+gd-60,gw-8,36)}
  g.restore();
}
