const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
const p=await b.newPage({viewport:{width:844,height:390},hasTouch:true,isMobile:true});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});await p.waitForTimeout(1500);
const r=await p.evaluate(async()=>{
 const f=Pirati.EID.plot_capanna,o={};
 o.fp=f.fp;o.blockedBefore=f.blocked;
 const tx=f.fp[0]+Math.floor(f.fp[2]/2),ty=f.fp[1]+Math.floor(f.fp[3]/2);
 Pirati.tp(tx+.5,ty+.5);await new Promise(r=>setTimeout(r,300));
 o.inside=[+(Pirati.P.x/44).toFixed(1),+(Pirati.P.y/44).toFixed(1),tx,ty];
 // costruisci stando dentro
 Object.assign(Pirati.S.res,{legna:50,corda:50,pietra:50,tela:50,rottami:50});
 return o});
console.log(JSON.stringify(r));
// costi cliccabili con corda 0
await p.evaluate(()=>{Pirati.S.res.corda=0;Pirati.UI.openPlot(Pirati.EID.plot_capanna)});await p.waitForTimeout(400);
const k=await p.$('.cost[data-k="corda"]');if(k){await k.click();await p.waitForTimeout(300);console.log('WHR',await p.evaluate(()=>document.querySelector('.whr')&&document.querySelector('.whr').textContent));await p.screenshot({path:'tm6_cost.png'})}else console.log('no cost');
await p.evaluate(()=>{Object.assign(Pirati.S.res,{legna:50,corda:50,pietra:50,tela:50,rottami:50});Pirati.S.built.falo=1;Pirati.S.flags.moved=1;Pirati.UI.openPlot(Pirati.EID.plot_capanna)});await p.waitForTimeout(400);
await p.click('#shGo');await p.waitForTimeout(600);
console.log('act',await p.evaluate(()=>JSON.stringify({act:!!Pirati.P.act,kind:Pirati.P.act&&Pirati.P.act.kind,pos:[+(Pirati.P.x/44).toFixed(1),+(Pirati.P.y/44).toFixed(1)]})));
await p.waitForTimeout(10000);
console.log('done',await p.evaluate(()=>{const f=Pirati.EID.plot_capanna;return JSON.stringify({st:f.st,blocked:f.blocked,pos:[+(Pirati.P.x/44).toFixed(1),+(Pirati.P.y/44).toFixed(1)]})}));
// audio
await p.evaluate(()=>{Pirati.AU.ctx&&0});
await p.close();await b.close()})();
