const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
await p.evaluate(()=>{const C=Ch3.C;C.tut=null;C.sail=0;C.p.x+=1500;C.p.hull=.5;});
await p.waitForTimeout(900);await p.screenshot({path:'c3g.png'});
console.log(await p.evaluate(()=>{const C=Ch3.C;C.t=400;Ch3.step(.1);return C.ships.filter(s=>s.type==='scorta').length}),errs);await b.close()})()
