const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:420}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>{Pirati.startNew('T','m')});
for(let i=0;i<12;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(500)}
const r=await p.evaluate(async()=>{const res=[];
 for(const id of['ci20','ci21']){const e=Pirati.EID[id];
  for(const [dx,dy] of [[-40,0],[40,0],[0,-30],[0,40]]){
   Pirati.tp((e.x+dx)/44,(e.y+dy)/44);await new Promise(r=>setTimeout(r,60));
   const ti=Pirati.tinfo();res.push([id,dx,dy,Math.round(e.x),Math.round(e.y),Pirati.P.x|0,Pirati.P.y|0,ti&&ti.l,e.stun,e.alive])}}
 return res});
console.log(r.map(x=>x.join(' ')).join('\n'));
await b.close()})();