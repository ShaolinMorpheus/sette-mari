const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/capitolo3_isola.html');await p.waitForTimeout(8000);
const r=await p.evaluate(()=>{const C=Ch3.C,R=Ch3.ROUTE,T=44;let md=1e9;for(let i=0;i<R.length-1;i++){for(let k=0;k<=10;k++){const x=R[i][0]+(R[i+1][0]-R[i][0])*k/10,y=R[i][1]+(R[i+1][1]-R[i][1])*k/10;md=Math.min(md,Math.hypot(x-C.p.x,y-C.p.y))}}
 let len=0;for(let i=0;i<R.length-1;i++)len+=Math.hypot(R[i+1][0]-R[i][0],R[i+1][1]-R[i][1]);
 return {n:R.length,first:R[0].map(v=>Math.round(v/T)),last:R[R.length-1].map(v=>Math.round(v/T)),minDistToStart:Math.round(md/T),lenTiles:Math.round(len/T),secs:Math.round(len/34),minDist:0}});
console.log(JSON.stringify(r),errs);await b.close()})()
