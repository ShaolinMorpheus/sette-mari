const {chromium}=require('playwright');(async()=>{const b=await chromium.launch({args:['--autoplay-policy=no-user-gesture-required']});const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.removeItem('sm_c34')}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2500);
const r=await p.evaluate(async()=>{const out=[];Ch4.auInit();await new Promise(r=>setTimeout(r,500));
 const real=Ch4.AU.ctx,realBus=Ch4.AU.mbus;
 for(const[dk,lv]of[[0,0],[1,0],[2,0],[0,1],[0,2]]){
  const off=new OfflineAudioContext(1,44100*20,44100);Ch4.AU.ctx=off;Ch4.AU.mbus=off.destination;Ch4.AU._nb=null;
  window.__c4m={deck:dk,lvl:lv};
  for(let b=0;b<72;b++)Ch4.mtick(.05+b*.27,b);
  const buf=await off.startRendering();const d=buf.getChannelData(0);let pk=0,sq=0;for(let i=0;i<d.length;i++){const v=Math.abs(d[i]);if(v>pk)pk=v;sq+=d[i]*d[i]}
  out.push(['deck',dk,'lvl',lv,'peak',pk.toFixed(3),'rms',Math.sqrt(sq/d.length).toFixed(4)])}
 Ch4.AU.ctx=real;Ch4.AU.mbus=realBus;return out});
for(const x of r)console.log(JSON.stringify(x));console.log(er);await b.close()})();
