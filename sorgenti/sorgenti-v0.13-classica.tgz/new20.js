/* ====== NOVITÀ v0.12h (B1): Cantiere navale e Aspetto della nave ======
   - l'argento portato dal mare finisce in cassa al cantiere del campo e compra migliorie che restano per sempre
   - vele, bandiera e polena da sbloccare giocando e da scegliere dal Menu (come i cappelli)
   Tutto vive in localStorage (come il resto del mare): sm_yard = cassa e livelli, sm_ship = statistiche e scelta. */
const YD=(function(){
  const KY='sm_yard',KS='sm_ship';
  const rd=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k)||'null');return v&&typeof v==='object'?v:d}catch(e){return d}};
  const wr=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
  const lim=(v,a,b)=>Math.max(a,Math.min(b,v|0));
  const Y={};
  let _sel=null;

  /* ---------- cantiere: cassa e migliorie ---------- */
  Y.UP=[
    {id:'h',n:'Scafo rinforzato',ic:'♥',max:4,cost:[3,5,7,9],d:'Un cuore di scafo in più a ogni livello: la nave regge più colpi.'},
    {id:'g',n:'Cannoni rapidi',ic:'💥',max:3,cost:[4,6,8],d:'I cannoni si ricaricano più in fretta: più colpi in ogni scontro.'},
    {id:'s',n:'Vele veloci',ic:'⛵',max:3,cost:[4,6,8],d:'La Sirena corre di più, anche con l\'argento a bordo.'}
  ];
  Y.gunK=l=>1-.14*lim(l,0,3);         // moltiplicatore del tempo di ricarica
  Y.sailK=l=>1+.06*lim(l,0,3);        // moltiplicatore della velocità
  Y.eff=(id,l)=>id==='h'?(l?'+'+l+(l===1?' cuore':' cuori'):'nessuno'):id==='g'?(l?'ricarica −'+Math.round((1-Y.gunK(l))*100)+'%':'nessuna'):(l?'+'+Math.round((Y.sailK(l)-1)*100)+'% di velocità':'nessuna');
  Y.get=()=>{const o=rd(KY,{});return{b:Math.max(0,o.b|0),tot:Math.max(0,o.tot|0),h:lim(o.h,0,4),g:lim(o.g,0,3),s:lim(o.s,0,3)}};
  Y.put=o=>{wr(KY,o);_sel=null};
  Y.bank=n=>{n=n|0;const o=Y.get();if(n>0){o.b+=n;o.tot+=n;Y.put(o)}return o};
  Y.buy=id=>{
    const u=Y.UP.find(x=>x.id===id),o=Y.get();if(!u)return false;
    const l=o[id];if(l>=u.max)return false;const c=u.cost[l];if(o.b<c)return false;
    o.b-=c;o[id]=l+1;Y.put(o);return true};
  Y.yardName=()=>{const o=Y.get();return'🪙 '+o.b+' in cassa'};

  /* ---------- aspetto: tabelle ---------- */
  Y.SAIL=[
    {id:'crema',n:'Vele color crema',hint:'',c:['#fff3d2','#d8c79a'],emb:'#c8402e',own:()=>true},
    {id:'rosse',n:'Vele rosse',hint:'Affonda 3 navi nemiche.',c:['#f0765e','#a8321f'],emb:'#fff0cf',own:s=>s.kills>=3},
    {id:'blu',n:'Vele blu mare',hint:'Salva Pip e Dodo.',c:['#8ccdf2','#3b78b8'],emb:'#fff3d2',own:s=>s.pris>=1},
    {id:'strisce',n:'Vele a strisce',hint:'Porta 10 casse d\'argento al cantiere.',c:['#fff3d2','#d8c79a'],emb:'#c8402e',pat:'stripes',pc:'#5b8fd0',own:(s,y)=>y.tot>=10},
    {id:'nere',n:'Vele nere',hint:'Abborda il galeone spagnolo.',c:['#5a5a6c','#262632'],emb:'#e8e8f2',own:s=>s.gal>=1},
    {id:'viola',n:'Vele viola',hint:'Affonda il brigantino dalle vele viola.',c:['#d2aef6','#7a46c0'],emb:'#ffe08a',own:s=>s.brig>=1},
    {id:'oro',n:'Vele dorate',hint:'Compra tutte le migliorie del cantiere.',c:['#ffeaa6','#d9a528'],emb:'#8a2a1c',own:(s,y)=>y.h>=4&&y.g>=3&&y.s>=3}
  ];
  Y.FLAG=[
    {id:'rossa',n:'Bandiera rossa',hint:'',col:'#e0523f',own:()=>true},
    {id:'stella',n:'Bandiera con la stella',hint:'Affonda la tua prima nave nemica.',col:'#2f6fc0',sym:'star',own:s=>s.kills>=1},
    {id:'scacchi',n:'Bandiera a scacchi',hint:'Torna in porto 3 volte dal mare.',col:'#f4f4f4',sym:'check',own:s=>s.runs>=3},
    {id:'perla',n:'Bandiera della sirena',hint:'Compra una miglioria al cantiere.',col:'#1f9aa8',sym:'pearl',own:(s,y)=>y.h+y.g+y.s>=1},
    {id:'mappa',n:'Bandiera del tesoro',hint:'Trova 2 tesori con le mappe delle bottiglie.',col:'#ead7a4',sym:'x',own:s=>s.maps>=2},
    {id:'teschio',n:'Bandiera del teschio',hint:'Affonda 15 navi nemiche.',col:'#202028',sym:'skull',own:s=>s.kills>=15}
  ];
  Y.FIG=[
    {id:'nessuna',n:'Nessuna polena',hint:'',own:()=>true},
    {id:'delfino',n:'Delfino',hint:'Affonda 8 navi nemiche.',own:s=>s.kills>=8},
    {id:'pappagallo',n:'Pappagallo',hint:'Fai un «Colpo perfetto»: tutto l\'argento, tutti salvi, scafo quasi intatto.',own:s=>s.perfect>=1},
    {id:'sirena',n:'Sirena',hint:'Porta 20 casse d\'argento al cantiere.',own:(s,y)=>y.tot>=20},
    {id:'stella',n:'Stella dorata',hint:'Compra 3 migliorie al cantiere.',own:(s,y)=>y.h+y.g+y.s>=3}
  ];
  const KINDS=[['sail','Vele',Y.SAIL],['flag','Bandiera',Y.FLAG],['fig','Polena',Y.FIG]];

  /* ---------- aspetto: stato (statistiche, scelta, novità) ---------- */
  const SH0=()=>({sel:{sail:'crema',flag:'rossa',fig:'nessuna'},st:{kills:0,pris:0,gal:0,runs:0,perfect:0,maps:0,brig:0},seen:{'sail:crema':1,'flag:rossa':1,'fig:nessuna':1}});
  Y.ship=()=>{const o=rd(KS,null),b=SH0();if(!o)return b;return{sel:Object.assign(b.sel,o.sel||{}),st:Object.assign(b.st,o.st||{}),seen:Object.assign(b.seen,o.seen||{})}};
  Y.shipPut=o=>{wr(KS,o);_sel=null};
  Y.stat=(k,n)=>{const o=Y.ship();o.st[k]=(o.st[k]|0)+(n==null?1:n);Y.shipPut(o);return o.st[k]};
  const owned=(list,id,sh,yd)=>{const it=list.find(x=>x.id===id);return !!it&&it.own(sh.st,yd)};
  Y.sel=()=>{
    if(_sel)return _sel;
    const sh=Y.ship(),yd=Y.get(),s=sh.sel;
    _sel={sail:owned(Y.SAIL,s.sail,sh,yd)?s.sail:'crema',flag:owned(Y.FLAG,s.flag,sh,yd)?s.flag:'rossa',fig:owned(Y.FIG,s.fig,sh,yd)?s.fig:'nessuna'};
    return _sel};
  Y.look=sel=>{sel=sel||Y.sel();return{sail:Y.SAIL.find(x=>x.id===sel.sail)||Y.SAIL[0],flag:Y.FLAG.find(x=>x.id===sel.flag)||Y.FLAG[0],fig:Y.FIG.find(x=>x.id===sel.fig)||Y.FIG[0]}};
  Y.setSel=(kind,id)=>{const sh=Y.ship();sh.sel[kind]=id;Y.shipPut(sh)};
  Y.lookName=()=>{const L=Y.look();return L.sail.n+' · '+L.flag.n+(L.fig.id!=='nessuna'?' · '+L.fig.n:'')+(Y.hasNew()?' ✨':'')};
  Y.hasNew=()=>{const sh=Y.ship(),yd=Y.get();return KINDS.some(([k,t,list])=>list.some(it=>it.own(sh.st,yd)&&!sh.seen[k+':'+it.id]))};
  /* restituisce le cose appena sbloccate (e le segna come viste): da chiamare dove il giocatore le vede annunciare */
  Y.announce=()=>{
    const sh=Y.ship(),yd=Y.get(),out=[];
    for(const[k,t,list]of KINDS)for(const it of list){const key=k+':'+it.id;if(it.own(sh.st,yd)&&!sh.seen[key]){sh.seen[key]=1;out.push({kind:k,it})}}
    if(out.length)Y.shipPut(sh);
    return out};
  Y.tellNew=(ms)=>{const n=Y.announce();if(n.length)setTimeout(()=>{try{UI.toast('Nuovo per la nave: '+n.map(x=>x.it.n).join(', ')+'. Lo scegli dal Menu › Guardaroba › Nave.',5600)}catch(e){}},ms||900);return n};
  Y.avail=()=>{try{return WORLD>=3||!!(S&&S.flags&&S.flags.ch2end)||!!localStorage.getItem(KY)||!!localStorage.getItem(KS)}catch(e){return false}};

  /* ---------- disegno: usato dal mare (sprite della Sirena) e dalle anteprime ---------- */
  const star=(g,cx,cy,R,r)=>{g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,q=i%2?r:R;g[i?'lineTo':'moveTo'](cx+Math.cos(a)*q,cy+Math.sin(a)*q)}g.closePath();g.fill()};
  /* bandierina in cima all'albero: (x,y) è la cima, sz la scala */
  Y.flagPaint=function(g,x,y,col,sym,sz){
    sz=sz||1;g.save();g.translate(x,y);g.scale(sz,sz);
    const fp=()=>{g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(14,-6,26,-2);g.lineTo(22,8);g.quadraticCurveTo(10,4,0,6);g.closePath()};
    fp();g.fillStyle=col;g.fill();
    if(sym==='check'){g.save();fp();g.clip();g.fillStyle='#1c1c24';for(let i=0;i<5;i++)for(let j=0;j<2;j++)if((i+j)%2===0)g.fillRect(i*6-2,j*6-4,6,6);g.restore()}
    else if(sym==='star'){g.fillStyle='#ffd23a';star(g,12,2.4,4,1.7)}
    else if(sym==='pearl'){g.fillStyle='#fff';g.beginPath();g.arc(12,2.2,3.1,0,7);g.fill();g.fillStyle='rgba(120,200,220,.9)';g.beginPath();g.arc(11.2,1.4,1,0,7);g.fill()}
    else if(sym==='x'){g.strokeStyle='#c8402e';g.lineWidth=2.4;g.lineCap='round';g.beginPath();g.moveTo(8.6,-.6);g.lineTo(15.4,5.4);g.moveTo(15.4,-.6);g.lineTo(8.6,5.4);g.stroke()}
    else if(sym==='skull'){g.fillStyle='#f4f4f4';g.beginPath();g.arc(12,1.5,3.3,0,7);g.fill();g.fillRect(10.4,3.2,3.2,2.1);g.fillStyle='#202028';g.beginPath();g.arc(10.8,1.1,.95,0,7);g.arc(13.2,1.1,.95,0,7);g.fill()}
    fp();g.strokeStyle='rgba(40,25,10,.65)';g.lineWidth=1;g.stroke();
    g.restore()};
  /* vela della Sirena (stessa forma di sempre): cx = albero, by = base, h = altezza, wd = larghezza, L = aspetto, fs = scala bandierina */
  Y.sailPaint=function(g,cx,by,h,wd,L,fs){
    const S0=L.sail,yt=by-h*.9,yb=by-h*.18;
    const sg=g.createLinearGradient(cx,by-h*.9,cx+wd,by-h*.2);sg.addColorStop(0,S0.c[0]);sg.addColorStop(1,S0.c[1]);
    const path=()=>{g.beginPath();g.moveTo(cx+3,yt);g.quadraticCurveTo(cx+wd*1.1,yt+h*.12,cx+wd*.92,yb-h*.04);g.lineTo(cx+wd*.74,yb+3);g.lineTo(cx+wd*.58,yb-4);g.lineTo(cx+wd*.4,yb+4);g.lineTo(cx+wd*.22,yb-3);g.lineTo(cx+3,yb+2);g.closePath()};
    g.fillStyle=sg;path();g.fill();
    if(S0.pat==='stripes'){g.save();path();g.clip();g.fillStyle=S0.pc;g.globalAlpha=.9;const n=6,w1=wd*1.1/n;for(let i=1;i<n;i+=2)g.fillRect(cx+3+i*w1,yt-8,w1,yb-yt+16);g.restore()}
    g.strokeStyle='rgba(70,54,28,.65)';g.lineWidth=1.4;path();g.stroke();
    g.strokeStyle='rgba(120,90,50,.28)';g.lineWidth=1;for(let i=1;i<5;i++){g.beginPath();g.moveTo(cx+3,yt+(yb-yt)*i/5);g.quadraticCurveTo(cx+wd*.55,yt+(yb-yt)*i/5+h*.06,cx+wd*.9,yt+(yb-yt)*i/5);g.stroke()}
    g.fillStyle='#5a3a22';g.fillRect(cx-4,yt-3,wd*1.0,5);          // verga
    g.fillStyle=S0.emb;g.globalAlpha=.9;                            // emblema della sirena
    g.beginPath();g.moveTo(cx+wd*.2,yt+h*.2);g.quadraticCurveTo(cx+wd*.5,yt+h*.12,cx+wd*.78,yt+h*.24);g.lineTo(cx+wd*.7,yt+h*.4);g.quadraticCurveTo(cx+wd*.45,yt+h*.46,cx+wd*.26,yt+h*.4);g.closePath();g.fill();
    g.fillStyle=S0.id==='nere'?'#262632':'#fff';g.beginPath();g.arc(cx+wd*.48,yt+h*.31,wd*.07,0,7);g.fill();
    g.globalAlpha=1;
    Y.flagPaint(g,cx,by-h,L.flag.col,L.flag.sym,fs||1)};
  /* polena sulla punta del bompresso: (x,y) è la punta, davanti = +x */
  Y.figPaint=function(g,x,y,id,sz){
    if(!id||id==='nessuna')return;
    sz=sz||1;g.save();g.translate(x,y);g.scale(sz,sz);g.lineJoin='round';g.lineWidth=1.8;g.strokeStyle='#2a1608';
    if(id==='delfino'){
      g.fillStyle='#4f9fdc';g.beginPath();g.moveTo(-16,5);g.quadraticCurveTo(-14,-9,-2,-9);g.quadraticCurveTo(8,-9,14,-3);g.lineTo(21,-5);g.lineTo(17,0);g.lineTo(21,4);g.quadraticCurveTo(10,5,2,6);g.quadraticCurveTo(-8,8,-16,5);g.closePath();g.fill();g.stroke();
      g.fillStyle='#bfe3fa';g.beginPath();g.ellipse(-2,2.6,9,2.6,0,0,7);g.fill();
      g.fillStyle='#fff';g.beginPath();g.arc(11,-2.4,1.6,0,7);g.fill();g.fillStyle='#10202c';g.beginPath();g.arc(11.4,-2.4,.75,0,7);g.fill()
    }else if(id==='pappagallo'){
      g.fillStyle='#2f9f4a';g.beginPath();g.moveTo(-12,-4);g.quadraticCurveTo(-22,-1,-20,5);g.lineTo(-10,3);g.closePath();g.fill();g.stroke();
      g.fillStyle='#d8312b';g.beginPath();g.ellipse(-3,0,12,8.5,0,0,7);g.fill();g.stroke();
      g.fillStyle='#ffc93a';g.beginPath();g.moveTo(6,-5);g.quadraticCurveTo(18,-2,15,5);g.quadraticCurveTo(10,2,6,3);g.closePath();g.fill();g.stroke();
      g.fillStyle='#fff';g.beginPath();g.arc(3,-3,2.3,0,7);g.fill();g.fillStyle='#111';g.beginPath();g.arc(3.7,-3,1,0,7);g.fill()
    }else if(id==='sirena'){
      g.fillStyle='#2fb6a8';g.beginPath();g.moveTo(-17,6);g.quadraticCurveTo(-19,-3,-8,-3);g.lineTo(0,1);g.quadraticCurveTo(-4,8,-17,6);g.closePath();g.fill();g.stroke();
      g.fillStyle='#e9a83a';g.beginPath();g.arc(-1,-1,8.2,0,7);g.fill();g.stroke();
      g.fillStyle='#f6cfa6';g.beginPath();g.arc(2,-1,6,0,7);g.fill();
      g.fillStyle='#2a1608';g.beginPath();g.arc(4.6,-2.4,.95,0,7);g.arc(4.6,1,.95,0,7);g.fill()
    }else if(id==='stella'){
      g.fillStyle='#ffd23a';star(g,0,0,12,5.2);g.stroke();
      g.fillStyle='rgba(255,255,255,.7)';g.beginPath();g.arc(-2,-3,2,0,7);g.fill()
    }
    g.restore()};
  /* anteprima della nave (di profilo) con l'aspetto scelto */
  Y.preview=function(cv,sel){
    const g=cv.getContext('2d'),W=cv.width,H=cv.height,L=Y.look(sel);
    g.clearRect(0,0,W,H);
    let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#cfeefb');q.addColorStop(.62,'#9fd8ef');q.addColorStop(.63,'#46a3d0');q.addColorStop(1,'#1f6ea6');g.fillStyle=q;g.fillRect(0,0,W,H);
    g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=2;g.lineCap='round';
    for(let i=0;i<7;i++){const y=H*.69+(i%4)*12,x=((i*61)%W)-10;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+12,y-5,x+24,y);g.quadraticCurveTo(x+36,y+5,x+48,y);g.stroke()}
    const dk=Math.round(H*.76);
    q=g.createLinearGradient(0,dk-8,0,dk+38);q.addColorStop(0,'#9a3524');q.addColorStop(.6,'#8a2a1c');q.addColorStop(1,'#4a140c');
    g.fillStyle=q;g.strokeStyle='#1c0f06';g.lineWidth=2.4;g.beginPath();
    g.moveTo(30,dk-10);g.lineTo(30,dk+6);g.quadraticCurveTo(54,dk+34,108,dk+37);g.lineTo(232,dk+35);g.quadraticCurveTo(286,dk+26,308,dk-4);g.lineTo(308,dk-10);g.closePath();g.fill();g.stroke();
    g.strokeStyle='#f4e2b0';g.lineWidth=2.6;g.beginPath();g.moveTo(34,dk+2);g.quadraticCurveTo(60,dk+26,110,dk+29);g.lineTo(230,dk+27);g.quadraticCurveTo(282,dk+19,303,dk-3);g.stroke();
    g.fillStyle='#161616';for(let i=0;i<4;i++)g.fillRect(96+i*34,dk+8,12,8);
    g.fillStyle='#6a3e1c';g.strokeStyle='#241008';g.lineWidth=1.8;g.fillRect(30,dk-26,38,18);g.strokeRect(30,dk-26,38,18);g.fillStyle='#ffd45a';g.fillRect(40,dk-21,8,8);g.fillRect(52,dk-21,8,8);
    g.fillStyle='#cfa066';g.fillRect(30,dk-10,278,5);g.strokeStyle='#3a200c';g.lineWidth=1.4;g.strokeRect(30,dk-10,278,5);
    g.strokeStyle='#5a3a1c';g.lineWidth=5;g.beginPath();g.moveTo(292,dk-8);g.lineTo(318,dk-13);g.stroke();
    const h=Math.round(H*.6),wd=Math.round(h*.66);
    for(const mx of[96,186]){g.fillStyle='#4a2c18';g.fillRect(mx-3,dk-10-h,6,h);Y.sailPaint(g,mx,dk-10,h,wd,L,1.5)}
    Y.figPaint(g,318,dk-13,L.fig.id,1)};
  const chipPaint=(cv,kind,id)=>{
    const g=cv.getContext('2d');g.clearRect(0,0,cv.width,cv.height);
    const L=Y.look({sail:kind==='sail'?id:'crema',flag:kind==='flag'?id:'rossa',fig:kind==='fig'?id:'nessuna'});
    if(kind==='sail'){g.save();g.translate(9,58);g.scale(.5,.5);Y.sailPaint(g,0,0,100,66,L,1.3);g.restore()}
    else if(kind==='flag'){g.strokeStyle='#4a2c18';g.lineWidth=3;g.lineCap='round';g.beginPath();g.moveTo(9,6);g.lineTo(9,52);g.stroke();Y.flagPaint(g,9,13,L.flag.col,L.flag.sym,1.7)}
    else{const c0={delfino:2.5,pappagallo:-2,sirena:-4.5,stella:0}[id]||0;Y.figPaint(g,28-c0*1.25,29,id,1.25)}};

  /* ---------- schede ---------- */
  Y.lookSheet=function(){
    const sh=Y.ship(),yd=Y.get();
    const sec=(kind,title,list)=>{
      const own=list.filter(x=>x.own(sh.st,yd)),lock=list.filter(x=>!x.own(sh.st,yd));
      return'<h3>'+title+'</h3><div class="phs">'+own.map(x=>'<button data-yk="'+kind+':'+x.id+'">'+(x.id==='nessuna'?'<span class="no">🚫</span>':'<canvas width="56" height="56" data-yp="'+kind+':'+x.id+'"></canvas>')+x.n+(sh.seen[kind+':'+x.id]?'':' ✨')+'</button>').join('')+'</div>'
        +(lock.length?'<ul class="wl">'+lock.map(x=>'<li><b>🔒 '+x.n+'</b>'+x.hint+'</li>').join('')+'</ul>':'')};
    const h='<h2>Aspetto della nave</h2><p class="sm">Vele, bandiera e polena si sbloccano giocando in mare e portando l\'argento al cantiere. Quello che scegli si vede subito in mare.</p>'
      +'<canvas id="ypv" width="340" height="190" style="display:block;width:100%;max-width:300px;height:auto;margin:4px auto 10px;border-radius:14px;border:3px solid var(--wood-d)"></canvas>'
      +sec('sail','Vele',Y.SAIL)+sec('flag','Bandiera',Y.FLAG)+sec('fig','Polena',Y.FIG)
      +'<div class="row"><button class="btn" id="shNo">Chiudi</button></div>';
    sheetFor(h,c=>{
      const upd=()=>{const s=Y.sel();Y.preview(c.querySelector('#ypv'),s);c.querySelectorAll('[data-yk]').forEach(b=>{const[k,i]=b.dataset.yk.split(':');b.classList.toggle('sel',s[k]===i)})};
      c.querySelectorAll('canvas[data-yp]').forEach(cv=>{const[k,i]=cv.dataset.yp.split(':');chipPaint(cv,k,i)});
      c.querySelectorAll('[data-yk]').forEach(b=>b.onclick=()=>{const[k,i]=b.dataset.yk.split(':');Y.setSel(k,i);sfx('ok');upd()});
      upd();
      Y.announce();       // aprendo la scheda le novità si considerano viste
    })};
  Y.yardSheet=function(){
    const draw=()=>{
      const o=Y.get();
      let h='<h2>Cantiere navale</h2><p class="sm">L\'argento che porti dal mare compra migliorie per la Sirena. Restano per sempre, anche se rigiochi.</p>'
        +'<div style="font:900 17px var(--f-b);margin:6px 0 2px">🪙 Argento in cassa: <span id="ybk">'+o.b+'</span></div>';
      for(const u of Y.UP){
        const l=o[u.id],mx=l>=u.max,c=mx?0:u.cost[l];
        const pips=Array.from({length:u.max},(_,i)=>i<l?'●':'○').join(' ');
        h+='<div class="upg"><h3>'+u.ic+' '+u.n+' <span style="font-size:15px;letter-spacing:2px;color:#a8741a">'+pips+'</span></h3><p class="sm">'+u.d+'</p>'
          +'<p class="sm"><b>Ora:</b> '+Y.eff(u.id,l)+(mx?'':' · <b>Dopo:</b> '+Y.eff(u.id,l+1))+'</p>'
          +(mx?'<span class="tick">✔ Al massimo</span>':'<button class="btn gold" data-yb="'+u.id+'"'+(o.b>=c?'':' disabled')+'>Migliora · 🪙 '+c+'</button>'+(o.b>=c?'':'<div class="req">Ti servono ancora '+(c-o.b)+' casse d\'argento.</div>'))+'</div>'}
      h+='<div class="row"><button class="btn" id="yLook">Aspetto della nave</button><button class="btn" id="shNo">Chiudi</button></div>';
      sheetFor(h,c=>{
        c.querySelectorAll('[data-yb]').forEach(b=>b.onclick=()=>{
          const id=b.dataset.yb,u=Y.UP.find(x=>x.id===id);
          if(!Y.buy(id)){sfx('no');return}
          sfx('hammer');try{UI.banner('Cantiere navale',u.n+' · livello '+Y.get()[id])}catch(e){}
          Y.tellNew(1200);draw()});
        c.querySelector('#yLook').onclick=()=>Y.lookSheet()})};
    draw()};
  return Y;
})();
