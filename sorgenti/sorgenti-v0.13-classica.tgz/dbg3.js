const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({});
 await p.waitForTimeout(1200);
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);
 await p.waitForTimeout(500);
 const r=await p.evaluate(async()=>{const S=Pirati.S;S.built={falo:1,capanna:1,banco:1};for(const k of['legna','pietra','corda','rottami'])S.res[k]=30;
  Pirati.UI.openUpgrades();document.getElementById('sheetCard').querySelector('[data-dc="orto"]').click();await new Promise(r=>setTimeout(r,200));
  (document.getElementById('shNo')||{click(){}}).click();
  const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k==='orto');Pirati.tp(e.x/44,(e.y+30)/44);await new Promise(r=>setTimeout(r,300));
  const out={};out.semi=S.res.semi;out.act=Pirati.act();await new Promise(r=>setTimeout(r,300));
  out.txt=document.getElementById('sheetCard').innerText.replace(/\s+/g,' ').slice(0,400);out.btns=document.getElementById('sheetCard').querySelectorAll('[data-pl]').length;
  for(let i=0;i<3;i++){const b=document.getElementById('sheetCard').querySelector('[data-pl="'+i+':patata"]');out['b'+i]=!!b;if(b){b.click();await new Promise(r=>setTimeout(r,100))}out['t'+i]=document.getElementById('sheetCard').innerText.replace(/\s+/g,' ').slice(60,330)}
  return out});
 console.log(JSON.stringify(r));console.log(errs);await b.close()})();
