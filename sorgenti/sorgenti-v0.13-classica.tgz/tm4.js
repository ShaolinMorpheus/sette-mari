const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const w2 of [0,1]){
const p=await b.newPage({viewport:{width:844,height:390},hasTouch:true,isMobile:true});
p.on('pageerror',e=>console.log('ERR',e.message));
if(w2)await p.addInitScript(()=>{window.__W2=1;window.CH2_OPEN=1});
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(w2=>{const P=Pirati;let s=P.newState('T','m');s.tutDone=1;s.flags.ch1b=1;if(w2)s=P.Ch2.convert(s);localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)},w2);await p.waitForTimeout(1500);
await p.evaluate(()=>Pirati.UI.openBigMap());await p.waitForTimeout(500);
const bx=await p.evaluate(()=>{const r=document.getElementById('mapCv').getBoundingClientRect();return [r.left+r.width*.5,r.top+r.height*.5]});
await p.mouse.click(bx[0],bx[1]);await p.waitForTimeout(300);
console.log(w2,'mark',await p.evaluate(()=>JSON.stringify(Pirati.S.mapMark)),'P',await p.evaluate(()=>[Pirati.P.x/44,Pirati.P.y/44].map(v=>+v.toFixed(1))));
await p.screenshot({path:'tm4_'+w2+'.png'});await p.close()}
await b.close()})();
