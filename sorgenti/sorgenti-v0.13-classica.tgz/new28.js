/* ====== NOVITÀ v0.12p: la zattera serve a qualcosa ======
   Navigando attorno alle isole (isola 1 e 2): relitti galleggianti da recuperare (casse e barili),
   di giorno ogni tanto spunta una balena che lascia una cassa, di sera una nave fantasma con un tesoro.
   Tutto è fatto di cose temporanee: niente va nel salvataggio tranne un contatore giornaliero. */
/*WHALE*/
const RS={fl:[],ev:null,cd:35,fcd:14,hint:0};
const rsRegion=(tx,ty)=>huReg(tx,ty)||((WORLD===1||WORLD===2)&&tx>=CV_X0&&tx<CV_X0+CV_W&&ty>=CV_Y0&&ty<CV_Y0+CV_H);
function rsOpen(x,y,m){                      // acqua aperta attorno al punto (m tile di margine)
  const tx=Math.floor(x/TS),ty=Math.floor(y/TS);
  for(let j=-m;j<=m;j++)for(let i=-m;i<=m;i++){const a=tx+i,b=ty+j;if(a<1||b<1||a>=MW-1||b>=MH-1||!seaT[b*MW+a]||rsRegion(a,b))return false}
  return true;
}
function rsPathOpen(x,y,hd,len,m){for(let d=0;d<=len;d+=TS*.8)if(!rsOpen(x+Math.cos(hd)*d,y+Math.sin(hd)*d,m))return false;return true}
function rsToday(){const f=S.flags;if(!f.rsN||f.rsN.d!==S.day)f.rsN={d:S.day,n:0,g:0,w:0};return f.rsN}
function rsSpawnFl(k,x,y){
  if(x==null){
    for(let i=0;i<14;i++){const a=Math.random()*6.283,d=(6+Math.random()*7)*TS,px=P.x+Math.cos(a)*d,py=P.y+Math.sin(a)*d;
      if(rsOpen(px,py,2)&&!RS.fl.some(o=>Math.hypot(o.x-px,o.y-py)<TS*3)){x=px;y=py;break}}
    if(x==null)return false}
  RS.fl.push({k:k||(Math.random()<.55?'crate':'barrel'),x,y,t:0,ph:Math.random()*6,life:k&&k!=='crate'&&k!=='barrel'?200:140});return true;
}
function rsReward(o){
  const T=rsToday();let msg='';
  const r=Math.random();
  if(o.k==='ghost'){gain('rottami',4,o.x,o.y-30);gain('coco',2,o.x,o.y-50);try{addXp(25);float(P.x,P.y-90,'+25 XP','#9fe8d0')}catch(e){}msg='Il tesoro della nave fantasma: rottami, noci e un brivido.'}
  else if(o.k==='whale'){gain('rottami',3,o.x,o.y-30);gain('bacche',3,o.x,o.y-50);try{addXp(20);float(P.x,P.y-90,'+20 XP','#8fd0ff')}catch(e){}msg='La balena ti ha lasciato una cassa: rottami e bacche.'}
  else if(r<.5){gain('rottami',2+((Math.random()*3)|0),o.x,o.y-30);msg='Un relitto: qualche rottame buono.'}
  else if(r<.8){gain(o.k==='barrel'?'coco':'bacche',2,o.x,o.y-30);msg=o.k==='barrel'?'Un barile: noci di cocco ancora buone.':'Una cassa: bacche asciutte.'}
  else{gain('rottami',1,o.x,o.y-30);try{addXp(8);float(P.x,P.y-90,'+8 XP','#ffe27a')}catch(e){}msg='Una cassa col sale di mare: poco, ma meglio di niente.'}
  sfx('ok');sparkBurst(o.x,o.y-20,10);UI.toast(msg,3800);
}
function rsEvPos(kind){
  for(let i=0;i<60;i++){
    const a=Math.random()*6.283,d=(5+Math.random()*5)*TS,x=P.x+Math.cos(a)*d,y=P.y+Math.sin(a)*d;
    const hd=a+Math.PI+(Math.random()-.5)*1.1,len=(kind==='whale'?8:6)*TS;
    if(rsOpen(x,y,2)&&rsPathOpen(x,y,hd,len,2))return{x,y,hd};
  }
  return null;
}
function rsTick(dt){
  if(!(WORLD===1||WORLD===2)||!S||!S.live||P.mode!=='raft'||inRoom()){RS.ev=null;return}
  if(UI.dlgOpen())return;
  if(!RS.hint&&!S.flags.rsHint){RS.hint=1;S.flags.rsHint=1;UI.toast('In mare aperto si trovano relitti galleggianti: avvicinati per ripescarli. A volte spunta una balena, la sera una nave fantasma.',7000)}
  const T=rsToday(),dark=skyLight(S.tod).dark;
  // relitti
  RS.fcd-=dt;if(RS.fcd<=0){RS.fcd=18+Math.random()*16;if(RS.fl.filter(o=>o.k==='crate'||o.k==='barrel').length<3&&T.n<6)rsSpawnFl()}
  for(let i=RS.fl.length-1;i>=0;i--){const o=RS.fl[i];o.t+=dt;
    const d=Math.hypot(o.x-P.x,o.y-P.y);
    if(d<TS*1.05&&(o.k==='crate'||o.k==='barrel'?T.n<8:true)){if(o.k==='crate'||o.k==='barrel')T.n++;rsReward(o);RS.fl.splice(i,1);continue}
    if(o.t>o.life||d>TS*40)RS.fl.splice(i,1)}
  // incontri
  const E=RS.ev;
  if(!E){
    RS.cd-=dt;
    if(RS.cd<=0){
      RS.cd=60+Math.random()*70;
      const h=S.tod,wantGhost=(h>=19||h<5)&&T.g<1&&Math.random()<.7,wantWhale=h>=6.5&&h<18.5&&T.w<3;
      const k=wantGhost?'ghost':wantWhale?'whale':null;
      if(k){const q=rsEvPos(k);if(!q)RS.cd=7;if(q){RS.ev={k,x:q.x,y:q.y,hd:q.hd,t:0,vis:0,jp:0,seed:Math.random()*9,gh:0,done:0,st:'in'};
        if(k==='ghost'){T.g++;UI.toast('Una nave fantasma in lontananza…',4200);if(S.flags.parrot)say(PAR,'Cra! Una nave fantasma! Brr, che brividi!',4)}
        else{T.w++;UI.toast('Una balena!',3000);if(S.flags.parrot)say(PAR,'Cra! Una balena! Che bestione!',4)}}}
    }
    return;
  }
  E.t+=dt;
  const sp=E.k==='whale'?30:20;
  E.x+=Math.cos(E.hd)*sp*dt;E.y+=Math.sin(E.hd)*sp*dt;
  const fadeIn=Math.min(1,E.t/2.5),fadeOut=E.t>(E.k==='whale'?15:26)?Math.max(0,1-(E.t-(E.k==='whale'?15:26))/2.5):1;
  E.vis=E.gh=Math.min(fadeIn,fadeOut);
  if(!rsOpen(E.x,E.y,1)){E.t=Math.max(E.t,E.k==='whale'?15:26)}      // se la rotta finisce vicino alla terra: sparisce subito
  if(E.k==='whale'){
    if(E.t>5.5&&E.t<7.7)E.jp=E.t-5.5;else E.jp=0;
    if(!E.done&&E.t>=7.7){E.done=1;rsSpawnFl('whale',E.x+Math.cos(E.hd)*60,E.y+Math.sin(E.hd)*60);sfx('splash')}
  }else{
    if(!E.done&&E.t>9){E.done=1;const a=E.hd+1.57;rsSpawnFl('ghost',E.x+Math.cos(a)*TS*2.3,E.y+Math.sin(a)*TS*2.3);UI.toast('La nave fantasma ha lasciato una cassa tra le onde.',4200)}
  }
  if(E.vis<=0&&E.t>6)RS.ev=null;
}
function rsFlDraw(g,o,t){
  const bob=Math.sin(t*1.8+o.ph)*2.2,al=Math.min(1,o.t/1.2)*Math.min(1,(o.life-o.t)/2);
  g.save();g.globalAlpha=al;g.translate(o.x,o.y+bob);
  g.strokeStyle='rgba(230,245,255,.55)';g.lineWidth=2;for(let k=0;k<2;k++){const u=(t*.5+k*.5+o.ph)%1;g.globalAlpha=al*(1-u)*.6;g.beginPath();g.ellipse(0,6,16+u*16,5+u*5,0,0,7);g.stroke()}
  g.globalAlpha=al;
  const gh=o.k==='ghost';
  if(gh||o.k==='whale'){g.save();g.globalCompositeOperation='lighter';const q=g.createRadialGradient(0,-8,2,0,-8,46);q.addColorStop(0,gh?'rgba(150,255,220,.55)':'rgba(255,225,130,.5)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(-46,-54,92,92);g.restore()}
  g.rotate(Math.sin(t*1.2+o.ph)*.07);
  if(o.k==='barrel'){
    g.fillStyle='#7a4e26';g.strokeStyle='#241408';g.lineWidth=2;g.beginPath();g.ellipse(0,-9,12,15,0,0,7);g.fill();g.stroke();
    g.strokeStyle='#c9a23a';g.lineWidth=2.4;g.beginPath();g.moveTo(-11,-14);g.lineTo(11,-14);g.moveTo(-11,-4);g.lineTo(11,-4);g.stroke();
  }else{
    g.fillStyle=gh?'#4f7a6e':'#7d5229';g.strokeStyle='#241408';g.lineWidth=2.2;g.fillRect(-15,-20,30,20);g.strokeRect(-15,-20,30,20);
    g.fillStyle=gh?'#9fe8d0':'#caa23a';g.fillRect(-15,-12,30,3.5);g.fillRect(-10,-20,4,20);g.fillRect(6,-20,4,20);
  }
  g.restore();
  g.save();g.globalAlpha=al;twinkle(g,o.x+16,o.y-30+bob,t,7,o.ph,gh?'#bfffe8':'#ffe27a');g.restore();
}
function rsGhostDraw(g,E,t){
  const a=E.gh;if(a<=.01)return;
  const bob=Math.sin(t*1.4+E.seed)*2;
  g.save();g.translate(E.x,E.y+bob);
  g.save();g.globalCompositeOperation='lighter';const q=g.createRadialGradient(0,0,10,0,0,230);q.addColorStop(0,'rgba(140,255,215,'+(.3*a)+')');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(-230,-230,460,460);g.restore();
  g.rotate(E.hd);g.globalAlpha=.8*a;
  g.fillStyle='#3a5a58';g.strokeStyle='#142624';g.lineWidth=3;
  g.beginPath();g.moveTo(110,0);g.quadraticCurveTo(80,-44,-20,-46);g.lineTo(-104,-34);g.lineTo(-110,0);g.lineTo(-104,34);g.lineTo(-20,46);g.quadraticCurveTo(80,44,110,0);g.closePath();g.fill();g.stroke();
  g.fillStyle='rgba(6,20,24,.9)';g.beginPath();g.moveTo(-8,-30);g.lineTo(8,-6);g.lineTo(-2,6);g.lineTo(18,26);g.lineTo(30,10);g.lineTo(12,-14);g.closePath();g.fill();
  g.strokeStyle='#8fa8a0';g.lineWidth=3;g.beginPath();g.moveTo(-10,0);g.lineTo(-10,0);g.stroke();
  g.fillStyle='#6a7a74';g.fillRect(-4,-3,8,6);                               // albero maestro, spezzato
  g.globalAlpha=.7*a;g.fillStyle='#cfe8de';g.strokeStyle='#5d7a72';g.lineWidth=2;
  for(const[x,w]of[[40,26],[-18,34],[-62,26]]){g.beginPath();g.moveTo(x,-3);g.lineTo(x+4,-w);g.lineTo(x-3,-w+9);g.lineTo(x+8,-w+17);g.lineTo(x+6,-3);g.closePath();g.fill();g.stroke()}
  g.restore();
}
function rsDraw(g,t){
  if(!(WORLD===1||WORLD===2)||P.mode!=='raft')return;
  for(const o of RS.fl)rsFlDraw(g,o,t);
  const E=RS.ev;if(!E)return;
  if(E.k==='whale')nvWhaleDraw(g,Object.assign({},E,{st:'idle'}),t);else rsGhostDraw(g,E,t);
}
