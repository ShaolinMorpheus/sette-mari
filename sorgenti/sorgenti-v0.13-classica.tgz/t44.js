const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/sette-mari/www/_t.html');await p.waitForTimeout(1500);await p.click('#bNew');await p.waitForTimeout(2500);
const r=await p.evaluate(()=>{const T=__t,S=T.S;const ids=Object.keys(T.QDEF);const main=ids.filter(i=>T.QDEF[i].kind==='main'),side=ids.filter(i=>T.QDEF[i].kind==='side');
 const o={main,side:side.slice(0,3),act:T.activeIds(),track:S.track};
 T.startQuest(main[0]);T.startQuest(side[0]);T.startQuest(side[1]);o.a=[S.track,S.side,T.activeIds()];
 const h=T.journalBody();o.card=(h.match(/<em[^>]*>[^<]*<\/em>/g)||[]);
 S.side=side[1];T.UI.syncObj();o.obj=document.getElementById('objG').textContent;o.after=[S.track,S.side];
 return o});
console.log(JSON.stringify(r),er);await b.close()})()
