#!/usr/bin/env python3
# v0.11.1: lanterne sull'isola (laghetto + sentieri), voga a sinistra, mare piu' scorrevole
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH11b FAIL (%d trovati, attesi %d):'%(n,cnt),old[:90].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)

# 1) generazione delle lanterne alla fine di genWorld (dopo tutto il resto: non sposta nulla di esistente)
rep("  FIX.occFix={moved,hidden};\n}\n\n/* ====== CAPITOLO 2",
"""  FIX.occFix={moved,hidden};
  if(WORLD===1)genLamps();
}
// lanterne sull'isola: una vicino all'acqua del laghetto e una fila lungo i sentieri fino al relitto e fino alla zattera
function genLamps(){
  const lamps=[];
  const nearE=(x,y,r)=>E.some(o=>o.type!=='crab'&&o.type!=='mraft'&&o.type!=='wparrot'&&o.type!=='reef'&&o.x>0&&hyp(o.x/TS-x,o.y/TS-.55-y)<r);
  const okT=(tx,ty,wet)=>{
    if(!inMap(tx,ty)||!walkT[tIdx(tx,ty)]||blockT[tIdx(tx,ty)]||elevT[tIdx(tx,ty)]<WL+.1)return false;
    const x=tx+.5,y=ty+.5;
    if(hyp((x-POND.x)/(POND.rx+(wet?.55:.9)),(y-POND.y)/(POND.ry+(wet?.55:.9)))<1)return false;
    if(pathDist(x,y)<.95)return false;
    for(const o of E)if(o.type==='plot'&&o.fp&&tx>=o.fp[0]-1&&tx<=o.fp[0]+o.fp[2]&&ty>=o.fp[1]-1&&ty<=o.fp[1]+o.fp[3])return false;
    if(nearE(x,y,1.05))return false;
    for(const l of lamps)if(hyp(l[0]-tx,l[1]-ty)<3.4)return false;
    return true;
  };
  const put=(x,y,wet)=>{
    let best=null,bd=1e9;
    for(let j=-3;j<=3;j++)for(let i=-3;i<=3;i++){
      const tx=Math.floor(x)+i,ty=Math.floor(y)+j,d=hyp(tx+.5-x,ty+.5-y);
      if(d<bd&&d<=2.6&&okT(tx,ty,wet)){bd=d;best=[tx,ty]}
    }
    if(!best)return;
    lamps.push(best);
    const e=ent({id:'lamp'+lamps.length,type:'deco',spr:'lamp',x:(best[0]+.5)*TS,y:(best[1]+.8)*TS,nohit:1});
    e.lk={x:e.x,y:e.y,k:'lanterne'};
    addBlock(e,best[0],best[1],1,1);
  };
  const along=(pts,s0,step,gap,side)=>{
    let tot=0;for(let i=0;i<pts.length-1;i++)tot+=hyp(pts[i+1][0]-pts[i][0],pts[i+1][1]-pts[i][1]);
    let acc=0,next=s0;
    for(let i=0;i<pts.length-1;i++){
      const a=pts[i],b=pts[i+1],len=hyp(b[0]-a[0],b[1]-a[1]);
      while(next<=acc+len&&next<=tot-gap){
        const u=(next-acc)/len,nx=-(b[1]-a[1])/len,ny=(b[0]-a[0])/len;
        put(a[0]+(b[0]-a[0])*u+nx*side*1.55,a[1]+(b[1]-a[1])*u+ny*side*1.55,false);
        side=-side;next+=step;
      }
      acc+=len;
    }
  };
  // vicino all'acqua, a nord del laghetto
  put(POND.x+.9,POND.y-POND.ry-.85,true);
  // verso il relitto del Cormorano (sud-ovest) e verso la zattera (est)
  along([[33.5,27.6],[31,29.5],[27,34],[22,39],[17.6,43.4],[15.4,46.2]],4.2,5.4,.6,1);
  put(23.6,46.9,false);
  along([[33.5,27.6],[40,30],[48,31.4],[55.5,31]],4.6,5.4,.6,-1);
  FIX.lamps=lamps.length;
}

/* ====== CAPITOLO 2""")

# 2) disegno: la stessa lanterna dell'accampamento
rep("function drawDeco(g,e,t){\n  if(e.hidden)return;\n","function drawDeco(g,e,t){\n  if(e.hidden)return;\n  if(e.spr==='lamp'){drawCDeco(g,e.lk,t);return}\n")

# 3) luce di notte
rep("    for(const e of E)if(e.type==='cdeco'&&e.k==='lanterne')lights.push([e.x,e.y-38,150,.75,true]);",
    "    for(const e of E)if((e.type==='cdeco'&&e.k==='lanterne')||(e.type==='deco'&&e.spr==='lamp'))lights.push([e.x,e.y-38,150,.75,true]);")

# 3b) menu: dai sotto-menu (cappellino, guardaroba, partite...) si torna indietro al menu invece di chiudere tutto
rep("function uShow(id,on){$(id).hidden=!on;","let _menuHid=-1e9;\nfunction uShow(id,on){if(id==='menu'&&!on)_menuHid=performance.now();$(id).hidden=!on;")
rep("  const c=$('sheetCard');c.innerHTML=h;uShow('sheet',true);\n  const no=c.querySelector('#shNo');if(no)no.onclick=closeSheet;",
    "  const fromMenu=performance.now()-_menuHid<400;\n  const c=$('sheetCard');c.innerHTML=h;uShow('sheet',true);\n  const no=c.querySelector('#shNo');if(no)no.onclick=closeSheet;\n  if(fromMenu){const bk=document.createElement('button');bk.className='btn';bk.id='shBk';bk.textContent='← Indietro';bk.onclick=()=>{closeSheet();UI.openMenu()};\n    if(no&&no.parentNode)no.parentNode.insertBefore(bk,no);else{const r=document.createElement('div');r.className='row';r.appendChild(bk);c.appendChild(r)}}")
# 4) novita'

rep("const CHANGELOG=[\n","""const CHANGELOG=[
  {v:"0.11.1",d:"7 nov 2026",t:"Lanterne sull'isola e viaggio più scorrevole",n:[
    "Lanterne sull'isola: una vicino all'acqua, a nord del laghetto, e due file lungo i sentieri, fino al relitto sulla spiaggia e fino alla zattera. Di notte fanno luce e si cammina senza torcia.",
    "Il grande viaggio: «Voga!» e «Perlustra» ora stanno accanto al tasto di fuoco, sul lato delle azioni (con i comandi invertiti passano a destra, insieme a «Fuoco!»).",
    "Galeone: tra una stanza e l'altra ci sono porte a battente stile saloon, a un'anta sola, che si aprono lontano da chi arriva e poi oscillano finché si richiudono. Le zone lontane dal tuo personaggio sono un po' più scure, con un anello d'ombra sfumato, ora più visibile. Le porte non si invertono più a metà passaggio e si chiudono dolcemente dopo che sei passato. Le ante delle porte sono solide: si aprono solo se le spingi e si spalancano oltre 90°, così non restano attaccate a te; se dietro c'è un npc lo spingi via con l'anta. Nel galeone l'obiettivo resta sempre visibile in un box in alto. Nuove scale: gradini in legno con fianchi, corrimano e pali d'ottone.",
    "Menu: dai sotto-menu (cappellino del pappagallo, guardaroba, partite) c'è «← Indietro» che torna al menu, senza chiuderlo tutto.",
    "Il grande viaggio: tolti i muri invisibili e rimessi a posto gli scontri con la costa.",
    "Il grande viaggio: nei Sargassi la nave va più veloce, anche sulle alghe; «Voga!» dura più a lungo e si ricarica prima."
  ]},
""")
# --- tutti i menu/schede si aprono dall'inizio (scroll a zero) e Conferma/Costruisci a destra, Annulla/Chiudi a sinistra ---
rep("if(on){for(const k in TANK)TANK[k]=0;JOY.x=JOY.y=0;if(UI.inputReset)UI.inputReset()}}",
    "if(on){for(const k in TANK)TANK[k]=0;JOY.x=JOY.y=0;if(UI.inputReset)UI.inputReset();_topScroll($(id))}}\nfunction _topScroll(el){const f=()=>{try{el.scrollTop=0;el.querySelectorAll('*').forEach(x=>{if(x.scrollTop)x.scrollTop=0})}catch(_){}};f();requestAnimationFrame(f);setTimeout(f,60)}")
rep("  if(wire)wire(c);\n}\nUI.openPlot=",
    "  c.querySelectorAll('.row').forEach(r=>{[...r.querySelectorAll(':scope>.btn.gold')].forEach(b=>r.appendChild(b))});\n  if(wire)wire(c);\n}\nUI.openPlot=")
# --- entrando/uscendo dalla capanna la telecamera resta agganciata subito (niente scivolata) ---
rep("function hutPlace(x,y){P.x=x;P.y=y;P.rv=0;cam.x=P.x;cam.y=P.y;camClamp();","function hutPlace(x,y){P.x=x;P.y=y;P.rv=0;cam.x=P.x;cam.y=P.y-18;camClamp();window.__camSnap=.9;")
rep("function camFollow(dt){\n  const z=camZoom();","function camFollow(dt){\n  if(window.__camSnap>0){window.__camSnap-=dt;cam.x=P.x;cam.y=P.y-18;camLead[0]=camLead[1]=0;dlgOff=0;camClamp();return}\n  const z=camZoom();")
# --- il ladro (procione) cammina solo sulla terraferma: aggira l'acqua e non la attraversa ---
rep("}else{e.dx=sx<e.x?-1:1;e.x+=(sx-e.x)/d*75*dt;e.y+=(sy-e.y)/d*75*dt}",
    "}else{e.dx=sx<e.x?-1:1;if(!_thStep(e,Math.atan2(sy-e.y,sx-e.x),75*dt)){e.stk=(e.stk||0)+dt;if(e.stk>4){e.flee=true;e.fleeT=0}}else e.stk=0}")
rep("e.x+=Math.cos(a)*150*dt;e.y+=Math.sin(a)*150*dt;\n      if(e.fleeT>5||!night)",
    "if(!_thStep(e,a,150*dt)){e.fleeT+=dt*3}\n      if(e.fleeT>5||!night)")
rep("Ch2.tick=function(dt){","function _thStep(e,a,len){for(const o of[0,.5,-.5,1,-1,1.6,-1.6]){const nx=e.x+Math.cos(a+o)*len,ny=e.y+Math.sin(a+o)*len;if(!solidPx(nx,ny)&&!solidPx(nx,ny+6)){e.x=nx;e.y=ny;return true}}return false}\nCh2.tick=function(dt){")
# --- niente punti cardinali nelle istruzioni per salpare (a schermo non coincidevano) ---
rep('Sterza e vai verso est.','Sterza e segui il fumo.',2)
rep('Il mare aperto, verso ovest: da lì','Il mare aperto: da lì',2)
rep('Salpa verso est, seguendo il fumo','Salpa seguendo il fumo',1)
rep('Costruisci la Zattera sulla spiaggia a est','Costruisci la Zattera sulla spiaggia, oltre il campo',1)
rep('La piazzola tratteggiata è sulla spiaggia est:','La piazzola tratteggiata è sulla spiaggia:',1)
rep('Salpa verso est</button>','Salpa</button>',1)
rep("Per ora a est c'è soltanto l'altra isola.","Per ora c'è soltanto l'altra isola.",2)
rep('Il fumo sale da est.',"Il fumo sale all'orizzonte.",2)
rep(' (a est)','',2)
rep('A est, il fumo. Tutto','Laggiù, il fumo. Tutto',1)
rep('Fumo a est! Ogni sera!',"Fumo all'orizzonte! Ogni sera!",1)
rep('fumo a est',"fumo all'orizzonte",2)
# --- torcia: il pulsante c'e' sempre dopo averla costruita; lampeggia con una freccia finche' non lo tocchi; di giorno avvisa ---
rep(".sbtn.lit{background",".sbtn.dim{opacity:.6;filter:saturate(.5)}\n.sbtn.thint{position:relative;animation:thp 1s ease-in-out infinite}\n.sbtn.thint::after{content:'';position:absolute;left:50%;top:-26px;margin-left:-11px;border:11px solid transparent;border-top:15px solid #ff8a1f;filter:drop-shadow(0 0 4px #fff);animation:thb .8s ease-in-out infinite}\n@keyframes thp{0%,100%{box-shadow:0 0 0 0 rgba(255,150,40,.0),0 3px 8px rgba(0,0,0,.4)}50%{box-shadow:0 0 0 9px rgba(255,150,40,.75),0 3px 8px rgba(0,0,0,.4)}}\n@keyframes thb{0%,100%{transform:translateY(0)}50%{transform:translateY(8px)}}\n.sbtn.lit{background")
rep("const tb=$('torchb');tb.hidden=!(S.up.torch&&torchHours());tb.classList.toggle('lit',!!S.torchOn);",
    "const tb=$('torchb');tb.hidden=!S.up.torch;tb.classList.toggle('lit',!!S.torchOn);tb.classList.toggle('dim',!torchHours()&&!S.torchOn);tb.classList.toggle('thint',!!S.up.torch&&!S.flags.torchSeen);")
rep("  if(!torchHours()){UI.toast('Di giorno la torcia non serve: si usa dal tramonto all\\'alba.');return false}",
    "  S.flags.torchSeen=1;UI.sync();\n  if(!torchHours()){UI.toast('Di giorno non puoi accenderla: la torcia si usa dal tramonto all\\'alba.');return false}")
# --- capanna: di sera candele accese in tutte le stanze ---
rep("[P.x,P.y-28,56,.16,false,[255,230,190]]];\n","[P.x,P.y-28,56,.16,false,[255,230,190]]];\n  const cdK=Math.min(1,dk*1.7),cds=HU_CANDLES.filter(c=>HUT.G[c[1]]&&HUT.G[c[1]][c[0]]===1);\n  if(cdK>.05)for(const c of cds)lights.push([X(c[0]+.5),Y(c[1]+.5)-16,205,.78*cdK,true,[255,186,96]]);\n")
rep("  g.save();g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='multiply';g.drawImage(LCV,0,0);g.restore();\n  g.setTransform(DPR,0,0,DPR,0,0);\n  drawScreenFx(g);drawProgress(g,t);",
    "  g.save();g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='multiply';g.drawImage(LCV,0,0);g.restore();\n  for(const c of cds)hutCandle(g,X(c[0]+.5),Y(c[1]+.5),t+c[0]*1.7+c[1],cdK);\n  g.setTransform(DPR,0,0,DPR,0,0);\n  drawScreenFx(g);drawProgress(g,t);")
rep("function renderHut(t){","const HU_CANDLES=[[2,4],[6,4],[8,6],[5,7],[10,3],[17,3],[11,7],[16,7],[20,4],[26,4],[22,6],[24,7],[3,5],[12,2]];\nfunction hutCandle(g,x,y,t,k){\n  g.save();g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(x,y+4,8,3,0,0,7);g.fill();\n  g.fillStyle='#8a6a2c';g.fillRect(x-6,y+1,12,4);g.fillStyle='#c9a24a';g.fillRect(x-6,y+1,12,1.5);g.fillStyle='#6a4e1c';g.fillRect(x-1.5,y-9,3,10);\n  g.fillStyle='#f4ead0';g.fillRect(x-3,y-17,6,10);g.fillStyle='#d8c9a2';g.fillRect(x+1,y-17,2,10);\n  if(k>.04){const f=.8+.2*Math.sin(t*13)+.08*Math.sin(t*5.1),a=Math.min(1,k*1.3);\n   g.globalCompositeOperation='lighter';const q=g.createRadialGradient(x,y-22,1,x,y-22,26);q.addColorStop(0,`rgba(255,200,110,${.55*a*f})`);q.addColorStop(1,'rgba(255,160,60,0)');g.fillStyle=q;g.fillRect(x-28,y-50,56,56);\n   g.globalCompositeOperation='source-over';g.fillStyle=`rgba(255,150,40,${a})`;g.beginPath();g.ellipse(x,y-21,3,5.2*f,0,0,7);g.fill();g.fillStyle=`rgba(255,238,150,${a})`;g.beginPath();g.ellipse(x,y-20,1.6,3.2*f,0,0,7);g.fill()}\n  g.restore()}\nfunction renderHut(t){")
# --- armadio della capanna: scegli cappello e abito tuoi e il cappellino del pappagallo ---
rep("const fromMenu=performance.now()-_menuHid<400;","const _sb=window.__sheetBack;window.__sheetBack=null;const fromMenu=!!_sb||performance.now()-_menuHid<400;")
rep("bk.onclick=()=>{closeSheet();UI.openMenu()}","bk.onclick=()=>{closeSheet();(_sb||UI.openMenu)()}")
rep("function hutLook(e){\n  const id=e.id;\n","function phatSheet(){\n  const own=PHATS.filter(h=>(S.phats||{})[h.id]);\n  sheetFor('<h2>Cappellino</h2><p>Scegli cosa fargli indossare.</p><div class=\"phs\"><button data-ph=\"\" class=\"'+(!S.phat?'sel':'')+'\"><span class=\"no\">🚫</span>Nessuno</button>'+own.map(h=>'<button data-ph=\"'+h.id+'\" class=\"'+(S.phat===h.id?'sel':'')+'\"><img alt=\"\" src=\"'+phatImg(h.id)+'\">'+h.n+'</button>').join('')+'</div><div class=\"row\"><button class=\"btn\" id=\"shNo\">Chiudi</button></div>',cc=>{\n    cc.querySelectorAll('[data-ph]').forEach(b=>b.onclick=()=>{S.phat=b.dataset.ph||null;sfx('ok');saveGame();closeSheet()});\n  });\n}\nfunction openHutWardrobe(){\n  const hasP=!!S.flags.parrot;\n  sheetFor('<h2>Armadio</h2><p>Cosa vuoi cambiare?</p><div class=\"row\" style=\"flex-direction:column\"><button class=\"btn\" id=\"awH\">🎩 Il mio cappello</button><button class=\"btn\" id=\"awO\">🧥 Il mio abito</button>'+(hasP?'<button class=\"btn\" id=\"awP\">🦜 Cappellino del pappagallo</button>':'')+'<button class=\"btn\" id=\"shNo\">Chiudi</button></div>',c=>{\n    c.querySelector('#awH').onclick=()=>{closeSheet();window.__sheetBack=openHutWardrobe;wardSheet('hat')};\n    c.querySelector('#awO').onclick=()=>{closeSheet();window.__sheetBack=openHutWardrobe;wardSheet('out')};\n    const ap=c.querySelector('#awP');if(ap)ap.onclick=()=>{closeSheet();window.__sheetBack=openHutWardrobe;phatSheet()};\n  });\n}\nfunction hutLook(e){\n  const id=e.id;\n  if(id==='h_ward'){openHutWardrobe();return}\n")
rep('{v:"0.11.1",d:"7 nov 2026"','{v:"0.11.2",d:"8 nov 2026",t:"Capanna con candele, torcia più chiara e tante rifiniture",n:[\n    "Capanna: salendo la prima volta la telecamera non scivola più (il personaggio compare subito al suo posto). Di sera tutte e tre le stanze sono illuminate da candele accese.",\n    "Dopo il galeone: con l\'argento a bordo il mare è libero e hai un nuovo obiettivo, «Raggiungi il varco del grande viaggio». Lo segui con una freccia gialla accanto alla nave e un segnalino sulla minimappa; arrivato, si apre un messaggio e parte il Capitolo 4.",\n    "Zattera: la piazzola e il riquadro «Zattera» restano nascosti finché non si sblocca. In capanna ci sono meno candele (solo le essenziali, luce più morbida). Sulla zattera l\'omino sta in punta, davanti.",\n    "Il grande viaggio: la nave fantasma ora ti insegue da lontano, senza sparare. Quando punti la prua verso di lei si dissolve fino a diventare attraversabile, poi sparisce e ricompare dietro di te. Ha uno scafo squarciato, l\'albero spezzato e alghe appese.",\n    "Il grande viaggio: percorsi nuovi, più vari e senza ripassare negli stessi punti. Nel mare delle Tempeste una rotta a curve larghe con i gorghi ai lati; nel mare di Nebbia le nove boe di Giacomo disegnano una serpentina con un passaggio stretto tra due isolotti.",\n    "Armadio della capanna: ora si apre una scheda per scegliere il tuo cappello, il tuo abito e il cappellino del pappagallo.",\n    "Torcia: dopo averla costruita il pulsante resta sempre visibile e lampeggia con una freccia finché non lo tocchi. Di giorno avvisa che non puoi accenderla; dal tramonto funziona.",\n    "Conferme e schede: «Costruisci», «Conferma» e gli altri pulsanti principali stanno a destra, «Annulla» e «Chiudi» a sinistra.",\n    "Menu e schede si aprono sempre dall\'inizio, mai già scorsi in basso.",\n    "Il procione ladro cammina solo sulla terraferma e aggira l\'acqua.",\n    "Il viaggio tra le due isole è più lungo: due gruppi di scogli da aggirare e, alla prima traversata, fulmini segnalati da un cerchio rosso da schivare. In zattera nella seconda isola non si vede più la mappa della grotta. Zattera e ritorno alla prima isola: le istruzioni non parlano più di est e ovest, ma del fumo e del mare aperto."\n  ]},\n  {v:"0.11.1",d:"7 nov 2026"')
# --- in zattera la grotta (regione in alto a sinistra della mappa) non scatta: si vede il mare ---
rep("function inCave(){return WORLD===2&&","function inCave(){return WORLD===2&&P.mode!=='raft'&&")
# --- traversata piu' lunga: due gruppi di scogli da aggirare (niente muri) + fulmini alla prima volta ---
rep("  for(let tries=0;tries<2400&&k<26+I2;tries++){",
"""  const rpath=[[61.2,31.4],[63.8,24.5],[69.5,23.2],[76,25],[79.4,33.2]],dPath=(x,y)=>{let m=1e9;for(let i=0;i<rpath.length-1;i++){const[ax,ay]=rpath[i],[bx,by]=rpath[i+1],vx=bx-ax,vy=by-ay,u=clamp(((x-ax)*vx+(y-ay)*vy)/(vx*vx+vy*vy),0,1);m=Math.min(m,Math.hypot(x-ax-vx*u,y-ay-vy*u))}return m};
  {let w=0;const blob=(cx,cy,rx,ry)=>{for(let ty=Math.floor(cy-ry);ty<=Math.ceil(cy+ry);ty++)for(let tx=Math.floor(cx-rx);tx<=Math.ceil(cx+rx);tx++){const d=((tx+.5-cx)/rx)**2+((ty+.5-cy)/ry)**2;if(d>1||(d>.55&&((tx*5+ty*11)%4===0)))continue;if(!seaT[tIdx(tx,ty)]||blockT[tIdx(tx,ty)])continue;const e=ent({id:'rw'+(w++),type:'reef',v:(tx*7+ty*3)%5,x:(tx+.5)*TS,y:(ty+.8)*TS,tx,ty});addBlock(e,tx,ty,1,1)}};
   blob(66,32,1.4,5.6);blob(72.8,30,1.4,4.4)}
  for(let tries=0;tries<2400&&k<26+I2;tries++){""")
rep("    if(tx<66&&Math.abs(ty-31.4)<5)continue;\n    const cl=tx<=72+I2?Math.abs(ty+.5-lane(tx+.5)):9;\n    if(cl<2.9)continue;","    if(dPath(tx+.5,ty+.5)<3.4)continue;")
rep("Sterza con il joystick e aggira gli scogli.","Sterza con il joystick, aggira i gruppi di scogli e schiva i fulmini.")
rep("  const storm=w.k==='storm'&&WX.i>.6;\n  if(!storm){EX.warn.length=0;EX.sheltered=0;return}","  const realStorm=w.k==='storm'&&WX.i>.6,cross=P.mode==='raft'&&WORLD===1&&!S.flags.sailed&&P.x>62*TS&&P.y>18*TS&&P.y<44*TS,storm=realStorm||cross;\n  if(!storm){EX.warn.length=0;EX.sheltered=0;return}")
rep("      EX.rb+=dt;const wob=Math.sin(EX.rb*.8)*18;\n      if(raftOK(P.x,P.y+wob*dt))P.y+=wob*dt;\n      EX.bt-=dt;\n      if(EX.bt<=0){\n        EX.bt=6+Math.random()*5;","      EX.rb+=dt;const wob=realStorm?Math.sin(EX.rb*.8)*18:0;\n      if(wob&&raftOK(P.x,P.y+wob*dt))P.y+=wob*dt;\n      EX.bt-=dt;\n      if(EX.bt<=0){\n        EX.bt=realStorm?6+Math.random()*5:2.6+Math.random()*2.4;")

# --- v0.11.3: link di prova spostati nella pagina Novità (password); zattera solo dopo l'isola ---
rep('<span>·</span><button id="bCap3" class="lnk">Capitolo 3 (bozza)</button><span>·</span><button id="bCap4" class="lnk">Assalto al galeone (prova)</button><span>·</span><button id="bCap5" class="lnk">Il grande viaggio (prova)</button>','')
rep("  $('bCap3').onclick=()=>{__go('#w3');location.reload()};\n  $('bCap5').onclick=()=>{__go('#w5');location.reload()};\n  $('bCap4').onclick=()=>{try{localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:3,t:0,shots:0,hits:0}))}catch(e){}__go('#w4');location.reload()};\n","")
rep('<button class="btn" id="nwC4">Prova: assalto al galeone</button>','<button class="btn" id="nwC3">Prova: Capitolo 3 (battaglia)</button><button class="btn" id="nwC4">Prova: assalto al galeone</button><button class="btn" id="nwC5">Prova: Il grande viaggio</button>')
rep("  const go=c.querySelector('#nwGo');\n","  {const b3=c.querySelector('#nwC3');if(b3)b3.onclick=()=>{__go('#w3');location.reload()};const b5=c.querySelector('#nwC5');if(b5)b5.onclick=()=>{__go('#w5');location.reload()}}\n  const go=c.querySelector('#nwGo');\n")
rep("function reqOk(id){const p=PLOTS[id];return p.req.every(r=>S.built[r])&&(!p.needFlag||S.flags[p.needFlag])}","function raftReady(){return !!(S.built.falo&&S.built.capanna&&S.built.banco&&S.up.torch&&S.q.m10)}\nwindow.__raftReady=raftReady;window.__reqOk=id=>reqOk(id);window.__reqMsg=id=>reqMsg(id);\nfunction reqOk(id){const p=PLOTS[id];return p.req.every(r=>S.built[r])&&(!p.needFlag||S.flags[p.needFlag])&&(id!=='zattera'||raftReady())}")
rep("function reqMsg(id){const p=PLOTS[id];","function reqMsg(id){const p=PLOTS[id];if(id==='zattera'&&!raftReady()&&(!p.needFlag||S.flags[p.needFlag])&&p.req.every(r=>S.built[r]))return\"Non sei ancora pronto a salpare: costruisci falò, capanna, banco da lavoro e torcia, e porta a termine le missioni dell'isola.\";")
rep('"Armadio della capanna: ora si apre','"Zattera: non si può più costruire subito. Prima servono falò, capanna, banco da lavoro e torcia, e bisogna aver portato avanti le missioni dell\\\'isola (fino al Pino Alto). I link di prova (Capitolo 3, galeone, Il grande viaggio) non sono più nel menu iniziale: si trovano in Diario → Novità, con la password.",\n    "Armadio della capanna: ora si apre')

# --- v0.11.3b: piazzola zattera invisibile se non sbloccata; meno candele; omino a prua ---
rep("function isInter(e){\n  switch(e.type){","function isInter(e){\n  if(e.type==='plot'&&e.pid==='zattera'&&e.st===0&&!raftReady())return false;\n  switch(e.type){")
rep("if(id==='zattera'&&!reqOk(id)&&!near)return;","if(id==='zattera'&&!reqOk(id))return;")
rep("if(e.type==='plot'&&e.pid==='zattera'&&e.st<2&&!e.away&&FOG[","if(e.type==='plot'&&e.pid==='zattera'&&e.st<2&&!e.away&&raftReady()&&FOG[")
rep("const HU_CANDLES=[[2,4],[6,4],[8,6],[5,7],[10,3],[17,3],[11,7],[16,7],[20,4],[26,4],[22,6],[24,7],[3,5],[12,2]];","const HU_CANDLES=[[6,4],[11,7],[17,3],[16,7],[22,6],[26,4]];")
rep("lights.push([X(c[0]+.5),Y(c[1]+.5)-16,205,.78*cdK,true,[255,186,96]])","lights.push([X(c[0]+.5),Y(c[1]+.5)-16,150,.55*cdK,true,[255,186,96]])")
rep("if(P.mode==='raft'){g.translate(0,-6+Math.sin(RT*1.6)*1.2)}","if(P.mode==='raft'){g.translate(Math.cos(P.hd)*54,Math.sin(P.hd)*54-6+Math.sin(RT*1.6)*1.2)}")

rep("function boxFree(x,y,rx,ry){\n","function boxFree(x,y,rx,ry){\n  if(window.__leafHit&&window.__leafHit(x,y))return false;\n")
open(P,'w',encoding='utf8').write(src)
print('patch11b ok')
