const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1500);
const r=await p.evaluate(()=>{const C=Ch4,K=C.K,P=C.P;const o=[];const pos=()=>K.fol.map(f=>Math.round(f.x/10)+':'+Math.round(f.y/10)).join(' ');
 o.push(pos());for(let i=0;i<300;i++)C.step(1/30);o.push(pos());
 C.tp(3,13);const ps=P.x;for(let i=0;i<900;i++)C.step(1/30);
 o.push(K.fol.map(f=>Math.round(Math.hypot(f.x-P.x,f.y-P.y))).join(','));return o});
console.log(JSON.stringify(r),errs);await b.close()})()
