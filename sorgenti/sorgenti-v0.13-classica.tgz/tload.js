const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();
for(const h of['','#w3']){const p=await (await b.newContext({viewport:{width:915,height:412}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html'+h);await p.waitForTimeout(2500);
try{await p.evaluate(()=>{const s=document.getElementById('bNew')||document.getElementById('bPlay');if(s)s.click()})}catch(e){}
await p.waitForTimeout(1500);console.log('hash',h||'-',er)}
await b.close()})();
