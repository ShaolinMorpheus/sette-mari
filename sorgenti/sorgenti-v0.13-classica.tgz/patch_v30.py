#!/usr/bin/env python3
# v0.12s: niente erba sui sentieri e nel campo (isola 1 e 2)
import sys
P='/home/claude/work/base_index.html'
src=open(P,encoding='utf8').read()
def rep(old,new,cnt=1):
    global src
    n=src.count(old)
    if n!=cnt:
        print('PATCH30 FAIL (%d trovati, attesi %d):'%(n,cnt),old[:110].replace('\n','\\n')); sys.exit(1)
    src=src.replace(old,new)
rep("""    const nT2=Math.round(nT*1.8);""","""    const dcE=hyp(tx+.5-C0.x,(ty+.5-C0.y)*1.15)+(n1-.5)*2.2,dirtZ=Math.max(sstep(1.5,.8,dp),sstep(6.6,4.8,dcE));   // sentieri e campo: terra battuta, senza erba
    const nT2=dirtZ>.8?0:Math.round(nT*1.8*(1-dirtZ));""")
rep("    if(gT>.55&&s<.38&&!onPath&&fF<.5&&r()<.055)reed(","    if(dirtZ<.05&&gT>.55&&s<.38&&!onPath&&fF<.5&&r()<.055)reed(")
rep("    if(gT<.5&&s>.12&&r()<.12){","    if(dirtZ<.3&&gT<.5&&s>.12&&r()<.12){")
rep("    if(gT>.6&&!onPath&&r()<.06+.03*(1-fF)){","    if(dirtZ<.3&&gT>.6&&!onPath&&r()<.06+.03*(1-fF)){")
rep('''    "Erba più ricca:''','''    "Niente erba sui sentieri e nel campo (isola 1 e 2): restano terra e sabbia pulite.",
    "Erba più ricca:''')
open(P,'w',encoding='utf8').write(src)
print('patch30 ok')
