const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await b.newPage({viewport:{width:900,height:480}});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:60000});
await p.evaluate(()=>{Pirati.startNew('T','m')});
for(let i=0;i<12;i++){await p.evaluate(()=>{for(const id of['intro','dlgBox','tutS']){const e=document.getElementById(id);if(e&&!e.hidden)e.click()}});await p.waitForTimeout(500)}
await p.evaluate(async()=>{for(let i=0;i<80&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,50))}Pirati.S.tod=12;Pirati.S.wx={k:'clear',t:900};Pirati.boardRaft();});
await p.waitForTimeout(1500);await p.evaluate(async()=>{for(let i=0;i<60&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,50))}});await p.waitForTimeout(800);
await p.screenshot({path:'raft1.png'});
await p.evaluate(()=>{Pirati.S.up.sail=1;Pirati.S.up.hull=1});await p.waitForTimeout(800);await p.screenshot({path:'raft2.png'});
await b.close()})();
