const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420},deviceScaleFactor:2})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(2500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.waitForTimeout(1000);await p.evaluate(()=>Pirati.UI.openMenu());await p.waitForTimeout(400);
const out=[];for(let i=0;i<4;i++){await p.click('#mGfx');await p.waitForTimeout(200);out.push(await p.evaluate(()=>[document.querySelector('#mGfx .ms').textContent,localStorage.getItem('sette-mari-gfx'),Pirati.quality]))}
console.log(out,er);
await p.evaluate(()=>localStorage.setItem('sette-mari-gfx','alta'));
await p.goto('file:///home/claude/out/index_final.html#w3');await p.reload();await p.waitForTimeout(3000);console.log(await p.evaluate(()=>document.body.className));
console.log(er);await b.close()})();
