const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
// NPC ring
const n=await p.evaluate(()=>{const e=Pirati.E.find(x=>x.type==='npc');Pirati.S.tod=12;Pirati.P.x=e.x-50;Pirati.P.y=e.y+30;Pirati.cam.x=e.x;Pirati.cam.y=e.y;return [e.who,Math.round(e.x),Math.round(e.y)]});
await p.waitForTimeout(900);await p.screenshot({path:'ring1.png'});console.log(n,await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
// thief
await p.evaluate(()=>{Pirati.S.tod=23;const e=Pirati.E.find(x=>x.type==='npc');Pirati.E.push({id:'thx',type:'thief',x:e.x+120,y:e.y+80,gone:false,flee:false,ph:1,dx:1,hx:0,hy:0,tx:0,ty:0});Pirati.P.x=e.x+90;Pirati.P.y=e.y+80;});
await p.waitForTimeout(1200);
console.log('thief',await p.evaluate(()=>{const t=Pirati.E.find(x=>x.id==='thx');return [t.flee,Pirati.Ch2.st().scared]}));
console.log(er);await b.close()})();
