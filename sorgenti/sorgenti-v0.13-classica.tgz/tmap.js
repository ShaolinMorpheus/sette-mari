const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1200,height:700}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({silver:0,pris:0,hull:10,max:10,kills:0,t:0}))}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2500);
const res=await p.evaluate(()=>{
 const out=[];const K=Ch4.K;K.cell=true;K.hold=true;K.key1=true;K.key2=true;
 const spawn=[[35,3.95],[37,9.4],[37,2.4]];
 for(let n=0;n<3;n++){
  Ch4.setDeck(n,spawn[n][0],spawn[n][1],true);
  const f=Ch4.bfsFrom(Ch4.P.x,Ch4.P.y),T=Ch4.T,W=Ch4.MW,MH=Ch4.MH;
  const reach=(x,y)=>{const tx=Math.floor(x/T),ty=Math.floor(y/T);return f[tx+ty*W]>=0};
  // objects
  for(const o of K.objs){let ok=false;for(let ty=0;ty<MH&&!ok;ty++)for(let tx=0;tx<W;tx++){if(f[tx+ty*W]<0)continue;const x=(tx+.5)*T,y=(ty+.5)*T;if(Math.hypot(x-o.x,y-o.y)<70){ok=true;break}}
    if(!ok)out.push('deck'+n+' obj NON raggiungibile: '+o.id+' @'+((o.x/T-Ch4.OX)|0)+','+((o.y/T-Ch4.OY)|0))}
  // guard waypoints
  Ch4.GP_BY[n].forEach((wp,i)=>{for(const[gx,gy]of wp){const x=Ch4.cx(gx),y=(Ch4.OY+gy+.92)*T;if(!reach(x,y-10))out.push('deck'+n+' ronda'+i+' wp ('+gx+','+gy+') NON raggiungibile')}});
  // coins
  for(const c of Ch4.DECKS[n].coins){if(!reach(c.x,c.y))out.push('deck'+n+' doblone '+c.id+' NON raggiungibile')}
  // stairs
  for(const o of K.objs)if(o.id==='su'||o.id==='sd'){if(!reach(o.x,o.y+10))out.push('deck'+n+' scala '+o.id+' ?')}
  out.push('deck'+n+' celle raggiungibili: '+f.reduce((a,v)=>a+(v>=0?1:0),0));
 }
 return out});
console.log(res.join('\n'));console.log(er);await b.close()})();
