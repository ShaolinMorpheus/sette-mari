const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{localStorage.setItem('sm_c34',JSON.stringify({pris:0,silver:0,hull:8,max:8,kills:0,t:0}))}catch(e){}});
await p.goto('file:///home/claude/out/index_final.html#w4');await p.waitForTimeout(2500);
const r=await p.evaluate(async()=>{const K=Ch4.K,P=Ch4.P;const out=[];const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 K.gd.forEach(g=>g.ko=1e9);
 const dist=()=>K.fol.map(f=>Math.round(Math.hypot(P.x-f.x,P.y-f.y)));
 out.push(['start',dist()]);
 Ch4.tp(6,9);
 for(let i=0;i<5;i++){await sleep(2000);out.push(['t+'+(i+1)*2+'s',dist()])}
 // cammina a destra attraverso il corridoio: simula movimento col player
 for(let i=0;i<60;i++){P.x+=5;await sleep(33)}
 out.push(['dopo camminata',dist()]);
 // fermati: nessuno deve oscillare. misura spostamento medio in 3s
 const p0=K.fol.map(f=>[f.x,f.y]);await sleep(3000);
 out.push(['spostamento fermo (px)',K.fol.map((f,i)=>Math.round(Math.hypot(f.x-p0[i][0],f.y-p0[i][1])))]);
 // avvicinati a uno: non deve scappare
 const f0=K.fol[0];const d0=Math.hypot(P.x-f0.x,P.y-f0.y);for(let i=0;i<40;i++){const dx=f0.x-P.x,dy=f0.y-P.y,d=Math.hypot(dx,dy);if(d<30)break;P.x+=dx/d*5;P.y+=dy/d*5;await sleep(33)}
 const d1=Math.hypot(P.x-f0.x,P.y-f0.y);await sleep(1500);out.push(['avvicinamento',Math.round(d0),Math.round(d1),'dopo',Math.round(Math.hypot(P.x-f0.x,P.y-f0.y))]);
 return out});
console.log(JSON.stringify(r));console.log(er);await b.close()})();
