const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(2500);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(450,200);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(2500);
await p.evaluate(()=>{const c=Pirati.S.c2;Pirati.S.flags.ch2end='ferro';c.endings={ferro:1};c.parts.yard=1;Pirati.saveGame()});
await p.reload();await p.waitForTimeout(2500);
await p.click('#bCont').catch(e=>console.log('nocont'));await p.waitForTimeout(3000);console.log(await p.evaluate(()=>[Pirati.S.flags.ch2end,Pirati.S.c2&&Pirati.S.c2.cineMig,Pirati.S.c2&&Pirati.S.c2.parts.yard]));
await b.close()})();
