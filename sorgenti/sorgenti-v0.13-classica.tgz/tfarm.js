const L=require('./aud/lib.js');
(async()=>{const {b,p,errs}=await L.boot({});
 const ev=async(f)=>{try{return await p.evaluate(f)}catch(e){return {ERRORE:e.message.split('\n')[0].slice(0,220)}}};
 await p.waitForTimeout(1200);
 await p.evaluate(()=>Pirati.startNew('Test','m'));await L.skip(p);
 await p.waitForTimeout(500);
 await p.evaluate(()=>{window.__cd=async()=>{for(let i=0;i<60&&Pirati.dlgOpen;i++){Pirati.dlgAuto();await new Promise(r=>setTimeout(r,80))}};Pirati.S.tutDone=1;Pirati.S.tut=null});
 const out=[];
 // --- preparazione: costruzioni base e risorse ---
 const r0=await ev(()=>{const S=Pirati.S,F=Pirati.farm;
   S.flags.axe=1;S.flags.flint=1;S.built={falo:1,capanna:1,banco:1};
   for(const id of['falo','capanna','banco']){const e=Pirati.EID['plot_'+id];if(e){e.st=2;e.prog=1}}
   for(const k of['legna','pietra','corda','rottami','pesce','bacche'])S.res[k]=30;
   Pirati.UI.sync();
   const f=Pirati.EID.plot_falo;Pirati.tp(f.fp[0]+1,f.fp[1]+4);
   return {camp:S.camp||[],falo:!!f,res:S.res.legna}});
 out.push(['prep',JSON.stringify(r0)]);
 // --- costruzione dal banco ---
 const r1=await ev(async()=>{const UI=Pirati.UI,S=Pirati.S;UI.openUpgrades();
   const c=document.getElementById('sheetCard');const res={};
   res.hasBtn=!!c.querySelector('[data-dc="orto"]')&&!!c.querySelector('[data-dc="essic"]');
   try{c.querySelector('[data-dc="orto"]').click();}catch(e){res.e1=String(e)}
   await new Promise(r=>setTimeout(r,200));
   res.toast=document.getElementById('toasts').innerText;
   try{document.getElementById('sheetCard').querySelector('[data-dc="essic"]').click();}catch(e){res.e2=String(e)+' | '+document.getElementById('sheetCard').innerText.slice(0,200)}
   await new Promise(r=>setTimeout(r,200));
   res.camp=JSON.stringify(S.camp);res.semi=S.res.semi;res.gard=JSON.stringify(S.gard);
   res.ents=Pirati.E.filter(e=>e.type==='cdeco'&&(e.k==='orto'||e.k==='essic')).map(e=>[e.k,Math.round(e.x),Math.round(e.y)]);
   return res});
 out.push(['costruzione',JSON.stringify(r1)]);
 await p.evaluate(()=>{Pirati.UI.sync();(document.getElementById('shNo')||{click(){}}).click();});
 // --- il bersaglio vicino all'orto ---
 const r2=await ev(async()=>{const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k==='orto');Pirati.tp(e.x/44,(e.y+30)/44);await new Promise(r=>setTimeout(r,300));
   const t=Pirati.tinfo();return {label:t&&t.l,e:!!e}});
 out.push(['bersaglio orto',JSON.stringify(r2)]);
 const shot=async(n)=>{await p.waitForTimeout(250);await p.screenshot({path:'aud/fw_'+n+'.png'})};
 await shot('orto_vuoto');
 // --- piantare, crescere, raccogliere ---
 const r3=await ev(async()=>{const S=Pirati.S,F=Pirati.farm,out={};
   try{
   out.paused0=Pirati.paused;out.dlg0=Pirati.dlgOpen;out.tinfo0=JSON.stringify(Pirati.tinfo());out.act=await window.__cd();Pirati.act();await new Promise(r=>setTimeout(r,300));
   const q=()=>document.getElementById('sheetCard');out.title=(q().querySelector('h2')||{}).textContent;
   out.plantBtns=q().querySelectorAll('[data-pl]').length;out.semi0=S.res.semi;
   for(let i=0;i<3;i++){const bt=q().querySelector('[data-pl="'+i+':patata"]');out['b'+i]=!!bt;if(bt){bt.click();await new Promise(r=>setTimeout(r,100))}}
   out.semiAfter=S.res.semi;out.pl=JSON.stringify(S.gard.pl);
   out.noSeed=q().querySelector('[data-z="3"]').innerText.replace(/\s+/g,' ');
   }catch(e){out.err=String(e)+' | '+document.getElementById('sheetCard').innerText.replace(/\s+/g,' ').slice(0,200)}
   return out});
 out.push(['piantare',JSON.stringify(r3)]);
 await p.evaluate(()=>{(document.getElementById('shNo')||{click(){}}).click();Pirati.farm.farmAdvance(100)});
 await shot('orto_crescita');
 const r4=await ev(()=>{const S=Pirati.S;Pirati.farm.farmAdvance(120);const mid=JSON.stringify(S.gard.pl.map(p=>p&&Math.round(p.p)));Pirati.farm.farmAdvance(100);return {mid,after:JSON.stringify(S.gard.pl.map(p=>p&&[Math.round(p.p),p.n]))}});
 out.push(['crescita',JSON.stringify(r4)]);
 await p.waitForTimeout(1500);   // lascia scattare il tick: avviso «pronto»
 await shot('orto_pronto');
 const r5=await ev(async()=>{const S=Pirati.S,out={};
   out.notified=JSON.stringify(S.gard.pl.map(p=>p&&p.n));
   await window.__cd();Pirati.act();await new Promise(r=>setTimeout(r,300));
   const c=document.getElementById('sheetCard');
   out.all=!!c.querySelector('#gdAll');
   c.querySelector('#gdAll').click();await new Promise(r=>setTimeout(r,200));
   out.patata=S.res.patata;out.semi=S.res.semi;out.harv=S.gard.harv;out.pl=JSON.stringify(S.gard.pl);
   out.wown=JSON.stringify(S.wown||{});
   return out});
 out.push(['raccolto',JSON.stringify(r5)]);
 await shot('orto_dopo');
 // --- sblocchi: 3 raccolti = zucca ---
 const r6=await ev(()=>{const S=Pirati.S;(document.getElementById('shNo')||{click(){}}).click();return {crops:Pirati.farm.gardCrops(),next:Pirati.farm.gardNext()}});
 out.push(['sblocchi dopo 3 raccolti',JSON.stringify(r6)]);
 // --- essiccatore ---
 const r7=await ev(async()=>{const S=Pirati.S,F=Pirati.farm,out={};
   const e=Pirati.E.find(x=>x.type==='cdeco'&&x.k==='essic');Pirati.tp(e.x/44,(e.y+30)/44);await new Promise(r=>setTimeout(r,300));
   out.label=(Pirati.tinfo()||{}).l;
   await window.__cd();Pirati.act();await new Promise(r=>setTimeout(r,300));
   const c=document.getElementById('sheetCard');out.title=(c.querySelector('h2')||{}).textContent;
   c.querySelector('[data-dp="0:pesce"]').click();await new Promise(r=>setTimeout(r,100));
   document.getElementById('sheetCard').querySelector('[data-dp="1:bacche"]').click();await new Promise(r=>setTimeout(r,100));
   out.res=[S.res.pesce,S.res.bacche];out.sl=JSON.stringify(S.dry.sl);
   return out});
 out.push(['essiccatore appendere',JSON.stringify(r7)]);
 await p.evaluate(()=>{(document.getElementById('shNo')||{click(){}}).click();Pirati.farm.farmAdvance(150)});
 await shot('essic_meta');
 const r8=await ev(()=>{const S=Pirati.S,F=Pirati.farm,out={};
   S.tod=12;                       // di giorno
   F.farmAdvance(200);out.day=JSON.stringify(S.dry.sl.map(s=>s&&Math.round(s.p)));
   Pirati.setWeather&&Pirati.setWeather('rain',100);Pirati.WX.i=1;
   const b=S.dry.sl.map(s=>s&&s.p);F.farmAdvance(50);
   out.rainStopped=JSON.stringify(S.dry.sl.map((s,i)=>s&&s.p-b[i]));
   Pirati.WX.i=0;
   return out});
 out.push(['essiccatore sole e pioggia',JSON.stringify(r8)]);
 await p.evaluate(()=>{Pirati.S.tod=12;Pirati.farm.farmAdvance(200)});
 await p.waitForTimeout(1500);
 await shot('essic_pronto');
 const r9=await ev(async()=>{const S=Pirati.S,out={};
   await window.__cd();Pirati.act();await new Promise(r=>setTimeout(r,300));
   const c=document.getElementById('sheetCard');
   c.querySelector('[data-dt="0"]').click();await new Promise(r=>setTimeout(r,100));
   document.getElementById('sheetCard').querySelector('[data-dt="1"]').click();await new Promise(r=>setTimeout(r,100));
   out.res=[S.res.pescesec,S.res.fruttasec];out.sl=JSON.stringify(S.dry.sl);
   (document.getElementById('shNo')||{click(){}}).click();
   // mangiare: pesce secco dal pulsante del pesce
   S.vit.h=20;Pirati.UI.sync();
   out.eat=Pirati.eatFish();out.h=Math.round(S.vit.h);out.pescesecLeft=S.res.pescesec;
   S.vit.h=20;out.eat2=Pirati.eat();out.h2=Math.round(S.vit.h);out.fruttaLeft=S.res.fruttasec;
   return out});
 out.push(['ritiro e cibo secco',JSON.stringify(r9)]);
 // --- ricette nuove ---
 const r10=await ev(()=>{const S=Pirati.S;S.res.patata=3;S.res.zucca=2;S.res.ananas=2;S.res.coco=4;S.res.pescesec=3;S.vit.h=5;S.vit.t=50;
   Pirati.UI.openCook(Pirati.EID.plot_falo);const c=document.getElementById('sheetCard');
   const ids=[...c.querySelectorAll('[data-rc]')].map(b=>b.dataset.rc+(b.disabled?'(off)':''));
   c.querySelector('[data-rc="spezzatino"]').click();
   const o={ids,h:Math.round(S.vit.h),buff:S.buff,bres:S.bres,res:[S.res.pescesec,S.res.patata,S.res.zucca],rec:Object.keys(S.rec||{}).length+'/'+Pirati.farm.RECIPES.length};
   (document.getElementById('shNo')||{click(){}}).click();return o});
 out.push(['ricette',JSON.stringify(r10)]);
 // --- salvataggio e ricarica ---
 const r11=await ev(()=>{const S=Pirati.S;Pirati.saveGame();const j=JSON.parse(localStorage.getItem(Pirati.saveKey()));return {gard:!!j.gard,dry:!!j.dry,camp:j.camp.map(o=>o.k).join(','),wown:Object.keys(j.wown||{}).join(',')}});
 out.push(['salvataggio',JSON.stringify(r11)]);
 console.log(out.map(x=>x.join(': ')).join('\n'));
 console.log('ERRORI',JSON.stringify(errs));
 await b.close()})();
