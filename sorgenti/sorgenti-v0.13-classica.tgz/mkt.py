c=open('/home/claude/sette-mari/www/index.html',encoding='utf8').read()
a="let jSeen={};\n"
c=c.replace(a,a+"window.__t={get S(){return S},QDEF,startQuest,UI,activeIds,SP,say,PAR,get sfx(){return sfx},AU,auInit,E,P,computeTarget,get TARGET(){return TARGET},campTile,DECOR};\n")
open('/home/claude/sette-mari/www/_t.html','w',encoding='utf8').write(c)
