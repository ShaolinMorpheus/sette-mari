const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:900,height:420}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(2500);await p.click('#bCap4');await p.waitForTimeout(3500);
console.log(await p.evaluate(()=>[location.hash,document.body.className]),er);await p.screenshot({path:'b4_2.png'});await b.close()})();
