const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<16;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.waitForTimeout(1500);
console.log(await p.evaluate(()=>[Pirati.WORLD,Pirati.hut.X0,!!Pirati.EID.plot_capanna]));
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{const e=Pirati.EID.plot_capanna;e.st=2;e.prog=1;Pirati.S.built.capanna=1;const f=e.fp;Pirati.P.x=(f[0]+f[2]/2)*44;Pirati.P.y=(f[1]+f[3]+.6)*44;Pirati.cam.x=Pirati.P.x;Pirati.cam.y=Pirati.P.y});await p.waitForTimeout(800);
console.log(await p.evaluate(()=>JSON.stringify(Pirati.tinfo())));
await clr();console.log('dlg',await p.evaluate(()=>[Pirati.UI.dlgOpen(),Pirati.act()]));await p.waitForTimeout(1200);await clr();
console.log('inside',await p.evaluate(()=>[Pirati.hut.inside(),Pirati.P.x/44,Pirati.P.y/44]));
await p.evaluate(()=>{Pirati.cam.uz=.55});await p.waitForTimeout(600);
await p.screenshot({path:'hut_w1.png'});
// camminata vera: tasto giu fino alla porta
await p.keyboard.down('ArrowDown');await p.waitForTimeout(1500);await p.keyboard.up('ArrowDown');
console.log(await p.evaluate(()=>[Pirati.P.x/44,Pirati.P.y/44,JSON.stringify(Pirati.tinfo())]));
console.log(er);await b.close()})();
