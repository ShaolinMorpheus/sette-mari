const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1100,height:620}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file:///home/claude/out/index_final.html');await p.waitForTimeout(1800);await p.click('#bNew');
for(let i=0;i<14;i++){await p.mouse.click(550,300);await p.waitForTimeout(250)}
await p.evaluate(()=>Pirati.Ch2.begin());await p.waitForTimeout(5000);
const clr=async()=>{for(let i=0;i<80&&await p.evaluate(()=>Pirati.UI.dlgOpen());i++){await p.mouse.click(550,560);await p.waitForTimeout(250)}};
await clr();
await p.evaluate(()=>{Pirati.hut.enter();Pirati.cam.uz=.55});await p.waitForTimeout(1500);await clr();
for(const [n,x,y,tod] of [['b',14,4.5,12],['a',4.5,4.5,12],['c',22.5,4.5,12],['n',14,4.5,22]]){await p.evaluate(([x,y,tod])=>{const X0=Pirati.hut.X0;Pirati.S.tod=tod;Pirati.P.x=(X0+x)*44;Pirati.P.y=(1+y)*44;Pirati.cam.x=Pirati.P.x;Pirati.cam.y=Pirati.P.y},[x,y,tod]);await p.waitForTimeout(900);await p.screenshot({path:'hut_'+n+'.png'})}
console.log(er);await b.close()})();
