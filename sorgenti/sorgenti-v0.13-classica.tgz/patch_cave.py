import re,json
s=open('base_index.html',encoding='utf8').read()
def rep(a,b,cnt=1):
    global s
    assert s.count(a)==cnt,(s.count(a),a[:70])
    s=s.replace(a,b)
mod=open('cave_mod.js',encoding='utf8').read().replace('C2s()','C()').replace("const C()=>","const C2s=()=>")
# remove helper C2s definition line (now unused)
mod=re.sub(r"const C2s=\(\)=>\{[^\n]*\n","",mod)
rep("/* ====== METEO, LUNA, TORCIA E LIVELLO DELLA POZZA ====== */",mod+"\n/* ====== METEO, LUNA, TORCIA E LIVELLO DELLA POZZA ====== */")
rep("deco('cave','cave',(cv[0]+.5),cv[1]+.95,[cv[0]-1,cv[1],3,1],{hitw:150,hith:100,inter:'look',label:'La grotta'});","deco('cave','cave',(cv[0]+.5),cv[1]+.95,[cv[0]-1,cv[1],3,1],{hitw:150,hith:100,inter:'look',label:'La grotta'});caveBuild();")
rep("  if(!WATERC)return;\n","  if(!WATERC)return;\n  if(inCave()){renderCave(t);return}\n")
rep("const torchHours=()=>!!S&&(S.tod>=19.5||S.tod<6.3);","const torchHours=()=>!!S&&(inCave()||S.tod>=19.5||S.tod<6.3);")
rep("  torchTick();\n  if(window.auWeather)","  torchTick();caveStep(dt);\n  if(window.auWeather)")
rep("const x=tx+i,y=ty+j;if(!freeT(x,y)||(WORLD!==2&&x>=64))continue;","const x=tx+i,y=ty+j;if(!freeT(x,y)||(WORLD!==2&&x>=64)||(WORLD===2&&x>=CV_X0&&x<CV_X0+CV_W&&y>=CV_Y0&&y<CV_Y0+CV_H))continue;")
rep("const fishNear=S.flags.lenza&&nearSea()<1.3*TS,SOFT=","const inC=inCave(),fishNear=!inC&&S.flags.lenza&&nearSea()<1.3*TS,SOFT=")
rep("  const dp=nearPond();\n  if(dp<1.55*TS)","  const dp=inC?1e9:nearPond();\n  if(dp<1.55*TS)")
rep("  else if(S.flags.lenza){const ds=nearSea();","  else if(S.flags.lenza&&!inC){const ds=nearSea();")
rep("case'deco':if(e.spr==='sign')return{l:'Leggi',i:'eye'};","case'deco':if(e.id==='cave')return{l:'Entra',i:'hand'};if(e.id==='cavex')return{l:'Esci',i:'hand'};if(e.spr==='sign')return{l:'Leggi',i:'eye'};")
rep("  if(WORLD===2&&!forceHome&&spot&&Ch2.mainLand(spot)){forceHome=true;UI.toast('La zattera torna alla spiaggia di casa.')}\n","")
rep("function shelterNow(){   // 2 = capanna, 1 = sotto un albero fitto, 0 = scoperto\n  if(P.mode==='raft')return 0;","function shelterNow(){   // 2 = capanna, 1 = sotto un albero fitto, 0 = scoperto\n  if(P.mode==='raft')return 0;\n  if(inCave())return 1;")
rep("else if(n==='splash'){","else if(n==='drip'){tone(1500,620,.11,'sine',.05);tone(2100,900,.08,'sine',.025,.09)}\n  else if(n==='splash'){")
# Ch2.look: grotta
a=s.index("  if(e.id==='cave'){\n    if(c.parts.rudder)")
b=s.index("  if(e.id==='nave'){",a)
new="""  if(e.id==='cave'){caveEnter();return true}
  if(e.id==='cavex'){caveExit();return true}
  if(e.id==='cvrudder'){
    if(c.parts.rudder){UI.dlg([D('hero',"Qui c'era il timone. Ora è sulla nave.")]);return true}
    if(!qAct('c8',2)){UI.dlg([D('hero',"Un fagotto avvolto in un telo cerato, legato con cura. Non è roba mia, per ora."),D('hero',"Prima devo capire di cosa si tratta. Magari Tito sa qualcosa.")]);return true}
    c.parts.rudder=1;c.ch.note=1;sfx('quest');
    UI.dlg([D('hero',"Il timone, avvolto in un telo cerato. E sopra, un biglietto con la grafia di Ferro."),D('hero',"«Otto posti. Tre nomi. Gli altri aspetteranno la prossima nave. — F.»"),D('hero',"«La prossima nave». Non ci sarà nessuna prossima nave."),D('hero',"Ferro non ha mai pensato di portarli tutti.")],()=>{checkAll()});return true}
"""
s=s[:a]+new+s[b:]
rep('txt:"Cerca il timone nella grotta (serve una torcia accesa)",hint:"La grotta è a sud-ovest del campo. Costruisci la Torcia nel Banco e accendila (pulsante a fiamma).",mark:()=>pt(EID.cave,100)',
    'txt:"Cerca il timone nella grotta (dentro è buio: porta la torcia)",hint:"La grotta è a sud-ovest del campo. Entra e cerca in fondo: lì dentro la torcia si accende anche di giorno (pulsante a fiamma).",mark:()=>pt(EID.cave,100)')
rep("  tileInfo(x,y){","  cave:{inside:()=>inCave(),enter:()=>caveEnter(),exit:()=>caveExit(),get G(){return CVX&&CVX.G},X0:CV_X0,Y0:CV_Y0},\n  tileInfo(x,y){")
rep("#hud #mini{pointer-events:auto;cursor:pointer}","#hud #mini{pointer-events:auto;cursor:pointer}\nbody.incave #mini{display:none}")
# changelog
k='    "Pappagallo: nuovo verso pulito'
rep(k,'    "La grotta ora si può esplorare: dentro è una mappa buia con rami, una pozza, cristalli che brillano appena e, in fondo, il timone nascosto. Con la torcia si vede; dentro la grotta la torcia si accende anche di giorno.",\n    "La zattera resta sempre dove scendi, su entrambe le isole: non torna più da sola alla spiaggia di casa.",\n'+k)
# PACK rows
rows=[
["Cerca il timone nella grotta (dentro è buio: porta la torcia)","Look for the rudder in the cave (it's dark inside: bring the torch)","Suche das Ruder in der Höhle (drinnen ist es dunkel: nimm die Fackel mit)","Busca el timón en la cueva (dentro está oscuro: lleva la antorcha)","Cherche le gouvernail dans la grotte (il fait noir dedans : prends la torche)"],
["La grotta è a sud-ovest del campo. Entra e cerca in fondo: lì dentro la torcia si accende anche di giorno (pulsante a fiamma).","The cave is south-west of the camp. Go in and search the far end: inside, the torch can be lit even in daytime (flame button).","Die Höhle liegt südwestlich des Lagers. Geh hinein und such ganz hinten: drinnen lässt sich die Fackel auch tagsüber anzünden (Flammenknopf).","La cueva está al suroeste del campamento. Entra y busca al fondo: dentro la antorcha se enciende incluso de día (botón de llama).","La grotte est au sud-ouest du camp. Entre et cherche au fond : à l'intérieur, la torche s'allume même de jour (bouton flamme)."],
["Qui dentro è buio pesto: accendi la torcia (pulsante a fiamma).","It's pitch dark in here: light the torch (flame button).","Hier drinnen ist es stockfinster: zünde die Fackel an (Flammenknopf).","Aquí dentro está oscuro como boca de lobo: enciende la antorcha (botón de llama).","Il fait noir comme dans un four ici : allume la torche (bouton flamme)."],
["Qui dentro è buio pesto. Una torcia si costruisce al Banco da lavoro.","It's pitch dark in here. A torch is built at the Workbench.","Hier drinnen ist es stockfinster. Eine Fackel baut man an der Werkbank.","Aquí dentro está oscuro como boca de lobo. Una antorcha se fabrica en el Banco de trabajo.","Il fait noir comme dans un four ici. Une torche se fabrique à l'établi."],
["Cra! Che buio! Accendi la torcia!","Squawk! So dark! Light the torch!","Kräh! So dunkel! Zünd die Fackel an!","¡Cra! ¡Qué oscuridad! ¡Enciende la antorcha!","Croa ! Quel noir ! Allume la torche !"],
["Cra! Buio fitto. Serve una torcia: si fa al Banco!","Squawk! Pitch black. You need a torch: make it at the Workbench!","Kräh! Stockdunkel. Du brauchst eine Fackel: baue sie an der Werkbank!","¡Cra! Oscuridad total. Hace falta una antorcha: ¡se fabrica en el Banco!","Croa ! Noir total. Il faut une torche : on la fabrique à l'établi !"],
["Entra","Enter","Eintreten","Entrar","Entrer"],
["Esci","Leave","Verlassen","Salir","Sortir"],
["Uscita","Exit","Ausgang","Salida","Sortie"],
["Fagotto","Bundle","Bündel","Fardo","Ballot"],
["Un fagotto avvolto in un telo cerato, legato con cura. Non è roba mia, per ora.","A bundle wrapped in oilcloth, carefully tied. Not mine to take, for now.","Ein Bündel in Wachstuch, sorgfältig verschnürt. Vorerst nicht meine Sache.","Un fardo envuelto en lona encerada, bien atado. De momento no es mío.","Un ballot enveloppé dans une toile cirée, soigneusement ficelé. Pas à moi, pour l'instant."],
["Prima devo capire di cosa si tratta. Magari Tito sa qualcosa.","First I need to work out what it is. Maybe Tito knows something.","Erst muss ich herausfinden, was es ist. Vielleicht weiß Tito etwas.","Primero debo averiguar qué es. Quizá Tito sepa algo.","Je dois d'abord comprendre ce que c'est. Tito sait peut-être quelque chose."],
["Qui c'era il timone. Ora è sulla nave.","The rudder was here. Now it's on the ship.","Hier lag das Ruder. Jetzt ist es auf dem Schiff.","Aquí estaba el timón. Ahora está en el barco.","Le gouvernail était ici. Maintenant il est sur le navire."],
]
i=s.index('var PACK=')
dec=json.JSONDecoder()
arr,end=dec.raw_decode(s[i+len('var PACK='):])
arr+=rows
s=s[:i]+'var PACK='+json.dumps(arr,ensure_ascii=False)+s[i+len('var PACK=')+end:]
open('base_index.html','w',encoding='utf8').write(s)
print('patched')
