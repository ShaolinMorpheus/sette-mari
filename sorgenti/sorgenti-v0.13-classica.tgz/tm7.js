const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch();
for(const [n,w,h] of [['land',844,390],['port',390,844]]){
const p=await b.newPage({viewport:{width:w,height:h},hasTouch:true,isMobile:true});
p.on('pageerror',e=>console.log('ERR',e.message));
await p.goto('file:///tmp/claude-0/-home-claude/85eb1f5d-bf1b-527c-90f0-e45f47afb559/scratchpad/w/index.html');
await p.waitForFunction(()=>window.Pirati&&window.Pirati.ready,null,{timeout:90000});
await p.evaluate(()=>{const P=Pirati;const s=P.newState('T','m');s.tutDone=0;s.tut=0;localStorage.setItem(P.saveKey(),JSON.stringify(s));P.startContinue('',null)});await p.waitForTimeout(1500);
await p.screenshot({path:'tm7_'+n+'.png'});
await p.evaluate(()=>Pirati.UI.tutSkip());
const r=await p.evaluate(async()=>{
 const cv=document.querySelector('canvas'),g=document.getElementById('joyGhost').getBoundingClientRect(),rot=document.body.classList.contains('rot');
 const ev=(t,x,y)=>cv.dispatchEvent(new PointerEvent(t,{pointerId:3,clientX:x,clientY:y,bubbles:true,pointerType:'touch'}));
 const x0=Pirati.P.x,y0=Pirati.P.y,sx=g.left+g.width/2-50,sy=g.top+g.height/2-40;
 ev('pointerdown',sx,sy);ev('pointermove',sx+40,sy);await new Promise(r=>setTimeout(r,600));
 const j=document.getElementById('joy'),q=j.getBoundingClientRect();
 const res={shown:!j.hidden,atTouch:[Math.round(q.left+q.width/2-sx),Math.round(q.top+q.height/2-sy)],ghostVisible:getComputedStyle(document.getElementById('joyGhost')).display,moved:Math.hypot(Pirati.P.x-x0,Pirati.P.y-y0)};
 ev('pointerup',sx,sy);res.hiddenAfter=j.hidden;return res});
console.log(n,JSON.stringify(r));await p.close()}
await b.close()})();
