/* ====== LA CAPANNA: interno con tre stanze (isola 1 e isola grande) ====== */
var HUT=null;
const HU_W=28,HU_H=9,HU_Y0=1;
const huX0=()=>WORLD===2?56:14;
const huReg=(x,y)=>(WORLD===1||WORLD===2)&&x>=huX0()&&x<huX0()+HU_W&&y>=HU_Y0&&y<HU_Y0+HU_H;
function inHut(){return !!HUT&&P.mode!=='raft'&&P.x>=HUT.x0*TS&&P.x<(HUT.x0+HU_W)*TS&&P.y>=HU_Y0*TS&&P.y<(HU_Y0+HU_H)*TS}
function inRoom(){return inCave()||inHut()}
function huGrid(){
  const G=[];for(let y=0;y<HU_H;y++)G.push(new Array(HU_W).fill(0));
  const fl=(x0,y0,x1,y1,v)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)G[y][x]=v==null?1:v};
  fl(1,1,8,7);fl(10,1,17,7);fl(19,1,26,7);   // le tre stanze
  fl(9,5,9,6);fl(18,5,18,6);                  // porte interne
  fl(13,8,14,8);                              // porta d'ingresso
  fl(1,1,3,2,3);fl(4,1,4,1,3);fl(7,1,8,1,3);fl(1,6,2,6,3);                                   // letto, comodino, armadio, baule da marinaio
  fl(10,1,11,1,3);fl(13,1,14,1,3);fl(12,4,15,4,3);fl(17,1,17,1,3);                           // libreria, camino, tavolo, appendiabiti
  fl(21,3,24,3,3);fl(26,2,26,2,3);fl(19,1,20,1,3);fl(25,6,26,6,3);                           // tavolo delle mappe, telescopio, barili, baule
  return G;
}
function hutBuild(){
  const x0=huX0(),G=huGrid();HUT={x0,G,fade:0,was:false,canvas:null};
  for(let y=0;y<HU_H;y++)for(let x=0;x<HU_W;x++)walkT[tIdx(x0+x,HU_Y0+y)]=G[y][x]===1?1:0;
  const hp=(id,gx,gy,w,label,h)=>ent({id,type:'deco',spr:'hut',x:(x0+gx)*TS,y:(HU_Y0+gy)*TS,inter:'look',hitw:w*TS,hith:h||100,label});
  hp('h_door',14,8.6,3,'Uscita',70);
  hp('h_bed',2.5,3.8,3.4,'Letto');hp('h_stand',4.5,2.7,1.6,'Comodino',80);hp('h_ward',7.5,2.7,2.8,'Armadio',80);hp('h_sea',1.9,7.8,2.8,'Baule da marinaio',90);
  hp('h_shelf',10.5,2.7,2.8,'Libreria',80);hp('h_hearth',13.5,2.8,3.2,'Camino',90);hp('h_table',13.5,5.7,4.4,'Tavolo',90);hp('h_coat',17.5,2.7,1.6,'Appendiabiti',80);
  hp('h_barrel',20,2.7,2.8,'Barili',80);hp('h_map',22.5,4.7,4.6,'Tavolo delle mappe',100);hp('h_tele',26.5,3.7,1.8,'Telescopio',90);hp('h_chest',25.5,7.8,2.8,'Baule',90);
}
function hutLbl(e){
  const L={h_door:['Esci','hand'],h_bed:['Riposa','bed'],h_stand:['Esamina','eye'],h_ward:['Apri','hand'],h_sea:['Apri','hand'],h_shelf:['Guarda','eye'],h_hearth:['Scaldati','fire'],h_table:['Siediti','hand'],h_coat:['Esamina','eye'],h_barrel:['Esamina','eye'],h_map:['Mappa','eye'],h_tele:['Guarda','eye'],h_chest:['Apri','hand']};
  const r=e&&L[e.id];return r?{l:r[0],i:r[1]}:null;
}
function hutPlace(x,y){P.x=x;P.y=y;P.rv=0;cam.x=P.x;cam.y=P.y;camClamp();if(typeof PAR!=='undefined'&&PAR){PAR.x=P.x+18;PAR.y=P.y-10}}
function hutEnter(){
  if(!HUT||P.mode==='raft')return;
  if(typeof cancelAct==='function')cancelAct();
  hutPlace((HUT.x0+14)*TS,(HU_Y0+6.5)*TS);HUT.fade=1;sfx('thud');
  if(!S.flags.hutIn){S.flags.hutIn=1;addXp(8);setTimeout(()=>{if(inHut()&&S.flags.parrot)say(PAR,"Cra! Tre stanze! Quasi una reggia. Con le tavole storte.",4.4)},900)}
  UI.sync();saveGame();
}
function hutExit(){
  if(!HUT)return;
  const c=EID.plot_capanna,fp=c&&c.fp?c.fp:[FIX.camp[0]-4,FIX.camp[1]-3,3,2];
  const f=nearestFree(Math.floor(fp[0]+fp[2]/2),Math.floor(fp[1]+fp[3])+1,7);
  if(f)hutPlace((f[0]+.5)*TS,(f[1]+.5)*TS);HUT.fade=1;P.hd=0;UI.sync();saveGame();
}
function hutSleep(){
  const can=S.tod>=19||S.tod<6;
  sheetFor('<h2>Capanna</h2><p>'+(can?'È notte: un sonno fino al mattino fa bene. Dormire costa un po\' di sete e di fame.':"Non hai sonno. Si può dormire dalle 19:00 alle 06:00.")+'</p><div class="row"><button class="btn gold" id="shGo"'+(can?'':' disabled')+'>Dormi fino al mattino</button><button class="btn" id="shNo">Chiudi</button></div>',c=>{c.querySelector('#shGo').onclick=()=>{closeSheet();UI.sleep()}});
}
const HUT_TXT={
  h_stand:"Un comodino con una candela mezza consumata e un diario senza pagine scritte. Ancora.",
  h_ward:"L'armadio: una camicia a righe, un cappello di ricambio e un paio di calzoni che hanno visto giorni migliori.",
  h_sea:"Un baule da marinaio, vuoto. Per ora ci tengo i ricordi.",
  h_shelf:"Libri gonfi d'acqua, qualche mappa incompleta e una conchiglia che fa da fermalibri.",
  h_coat:"Il mio cappotto e il cappello a tre punte. Quando c'è bel tempo li lascio qui a prendere aria.",
  h_barrel:"Barili vuoti. Ottimi da usare come sgabelli o come scuse.",
  h_tele:"Un telescopio ottone e fortuna. Dalla finestra vedo solo mare e nuvole, per ora."
};
function hutLook(e){
  const id=e.id;
  if(id==='h_door'){hutExit();return}
  if(id==='h_bed'){hutSleep();return}
  if(id==='h_map'){UI.openBigMap();return}
  if(id==='h_hearth'){UI.dlg([D('hero',S.wx&&S.wx.k!=='clear'?"Il camino scoppietta. Qui dentro la pioggia sembra lontana.":"Il camino scoppietta piano. Che bel posto.")]);return}
  if(id==='h_table'){UI.toast(S.vit.h<60?"Ti siedi a tavolo: mangiare per terra era peggio. Premi «Mangia» o cucina al falò.":"Un tavolo vero, con due sgabelli. Il Cormorano non ne aveva uno migliore.");return}
  if(id==='h_chest'){UI.dlg([D('hero',"Il baule dei ricordi: un giorno dopo l'altro, qui dentro tengo il conto.")],()=>UI.toast("Giorno "+S.day+" · "+Object.keys(S.rec||{}).length+" ricette provate."));return}
  const T=HUT_TXT[id];if(T){S.flags.hutLk=S.flags.hutLk||{};if(!S.flags.hutLk[id]){S.flags.hutLk[id]=1;sfx('ok');addXp(3);float(P.x,P.y-80,'+3 XP','#ffe27a')}UI.dlg([D('hero',T)])}
}
function hutStep(dt){
  if(!HUT)return;
  const on=inHut();
  if(on!==HUT.was){HUT.was=on;document.body.classList.toggle('inhut',on);UI.sync()}
  if(on&&HUT.fade>0)HUT.fade=Math.max(0,HUT.fade-dt*1.8);
}
/* ---- disegno ---- */
function huRR(g,x,y,w,h,r,f,s){g.beginPath();g.roundRect(x,y,w,h,r);if(f){g.fillStyle=f;g.fill()}if(s){g.strokeStyle=s;g.lineWidth=1.5;g.stroke()}}
function hutBake(){
  const G=HUT.G,W=HU_W*TS,H=HU_H*TS,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d'),r=mulberry(777);
  g.fillStyle='#120b07';g.fillRect(0,0,W,H);
  // pavimento
  for(let y=0;y<HU_H;y++)for(let x=0;x<HU_W;x++){
    if(G[y][x]===0)continue;
    const px=x*TS,py=y*TS,base=x<9?[158,104,60]:x<18?[172,120,70]:[142,98,58];
    for(let k=0;k<2;k++){
      const v=(r()*18-9)|0,yy=py+k*22;
      g.fillStyle=`rgb(${base[0]+v},${base[1]+v},${base[2]+v})`;g.fillRect(px,yy,TS,22);
      g.fillStyle='rgba(40,22,10,.55)';g.fillRect(px,yy+(k?20:0),TS,2);
      g.fillStyle='rgba(255,230,180,.10)';g.fillRect(px,yy+(k?0:2),TS,2);
      const sx=px+((r()*34)|0)+4;g.fillStyle='rgba(40,22,10,.5)';g.fillRect(sx,yy,2,22);
      if(r()<.4){g.fillStyle='rgba(60,34,16,.35)';g.beginPath();g.ellipse(px+r()*TS,yy+11,4+r()*6,1.5,0,0,7);g.fill()}
      g.fillStyle='rgba(30,18,8,.7)';g.fillRect(sx+3,yy+4,2,2);g.fillRect(sx+3,yy+16,2,2);
    }
  }
  // pareti
  for(let y=0;y<HU_H;y++)for(let x=0;x<HU_W;x++){
    if(G[y][x]!==0)continue;
    const px=x*TS,py=y*TS,face=y===0||y===HU_H-1;
    if(face){
      const q=g.createLinearGradient(0,py,0,py+TS);q.addColorStop(0,'#86592f');q.addColorStop(1,'#4d311a');g.fillStyle=q;g.fillRect(px,py,TS,TS);
      for(let i=0;i<4;i++){g.fillStyle='rgba(30,16,6,.5)';g.fillRect(px+i*11,py,2,TS);g.fillStyle='rgba(255,220,160,.08)';g.fillRect(px+i*11+2,py,2,TS)}
      g.fillStyle='#3a2312';g.fillRect(px,py+TS-8,TS,8);g.fillStyle='rgba(255,220,160,.18)';g.fillRect(px,py+TS-8,TS,2);
    }else{
      g.fillStyle='#4a2f1a';g.fillRect(px,py,TS,TS);
      for(let i=0;i<3;i++){g.fillStyle='rgba(30,16,6,.5)';g.fillRect(px+4+i*14,py,2,TS)}
      g.fillStyle='#7a5430';g.fillRect(px,py,3,TS);g.fillRect(px+TS-3,py,3,TS);
    }
  }
  // ombra delle pareti sul pavimento
  for(let y=0;y<HU_H;y++)for(let x=0;x<HU_W;x++){
    if(G[y][x]===0)continue;const px=x*TS,py=y*TS;
    if(G[y-1]&&G[y-1][x]===0){const q=g.createLinearGradient(0,py,0,py+18);q.addColorStop(0,'rgba(0,0,0,.42)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(px,py,TS,18)}
    if(G[y][x-1]===0){const q=g.createLinearGradient(px,0,px+12,0);q.addColorStop(0,'rgba(0,0,0,.32)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(px,py,12,TS)}
    if(G[y][x+1]===0){const q=g.createLinearGradient(px+TS,0,px+TS-12,0);q.addColorStop(0,'rgba(0,0,0,.32)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(px+TS-12,py,12,TS)}
  }
  // soglie delle porte interne
  for(const gx of[9,18])for(const gy of[5,6]){g.fillStyle='#5a3a1e';g.fillRect(gx*TS+14,gy*TS,16,TS);g.fillStyle='rgba(255,220,160,.2)';g.fillRect(gx*TS+14,gy*TS,3,TS)}
  // porta d'ingresso: spiraglio di luce con mare e palme
  {const px=13*TS,py=8*TS;
    const q=g.createLinearGradient(0,py,0,py+TS);q.addColorStop(0,'#bfe6f2');q.addColorStop(.6,'#7fc3d8');q.addColorStop(1,'#d8c28a');g.fillStyle=q;g.fillRect(px,py,TS*2,TS);
    g.fillStyle='#3d7a3a';g.beginPath();g.ellipse(px+TS*1.5,py+TS-6,22,12,0,0,7);g.fill();
    g.fillStyle='#2e1b0c';g.fillRect(px-6,py-4,8,TS+4);g.fillRect(px+TS*2-2,py-4,8,TS+4);
    // stuoia
    huRR(g,px+6,7*TS+10,TS*2-12,TS-16,6,'#5f7a3a','#2f4a1f');for(let i=0;i<5;i++){g.fillStyle='rgba(255,255,255,.12)';g.fillRect(px+12,7*TS+14+i*5,TS*2-24,1.5)}}
  // finestre sul muro nord
  for(const gx of[4.5,22]){const px=gx*TS-26,py=3;
    huRR(g,px-4,py-2,60,38,5,'#3a2312');
    const q=g.createLinearGradient(0,py,0,py+32);q.addColorStop(0,'#bfe6f4');q.addColorStop(1,'#78bdd3');huRR(g,px,py+2,52,32,3,q);
    g.fillStyle='rgba(255,255,255,.55)';g.beginPath();g.ellipse(px+14,py+12,9,3.5,0,0,7);g.fill();g.beginPath();g.ellipse(px+36,py+20,7,2.5,0,0,7);g.fill();
    g.fillStyle='#4a2c15';g.fillRect(px+24,py+2,4,32);g.fillRect(px,py+16,52,3)}
  // quadri e trofei sul muro
  {const px=6.3*TS,py=4;g.fillStyle='#17181f';g.beginPath();g.moveTo(px,py+2);g.lineTo(px+26,py+2);g.lineTo(px+22,py+22);g.lineTo(px+4,py+22);g.closePath();g.fill();g.strokeStyle='#e9e2cf';g.lineWidth=2.4;g.beginPath();g.arc(px+13,py+11,4,0,7);g.stroke();g.beginPath();g.moveTo(px+7,py+16);g.lineTo(px+19,py+6);g.moveTo(px+19,py+16);g.lineTo(px+7,py+6);g.stroke();g.fillStyle='#6a4426';g.fillRect(px-1,py-2,28,3)}
  {const px=16.1*TS,py=6;g.strokeStyle='#4a2c15';g.lineWidth=5;g.beginPath();g.arc(px,py+14,13,0,7);g.stroke();g.strokeStyle='#8a5a2c';g.lineWidth=3;for(let i=0;i<8;i++){const a=i*Math.PI/4;g.beginPath();g.moveTo(px+Math.cos(a)*5,py+14+Math.sin(a)*5);g.lineTo(px+Math.cos(a)*19,py+14+Math.sin(a)*19);g.stroke()}g.fillStyle='#c79a3a';g.beginPath();g.arc(px,py+14,4,0,7);g.fill()}
  {const px=19.4*TS,py=4;huRR(g,px,py,34,28,2,'#e4d2a0','#6a4426');g.strokeStyle='#8a6a3a';g.lineWidth=1.2;g.beginPath();g.moveTo(px+4,py+20);g.quadraticCurveTo(px+14,py+4,px+30,py+14);g.stroke();g.fillStyle='#b3392b';g.fillRect(px+22,py+8,6,2);g.fillRect(px+24,py+6,2,6)}
  // tappeti
  g.save();g.translate(5*TS,5.2*TS);g.scale(1,.55);g.fillStyle='#7a2a22';g.beginPath();g.arc(0,0,86,0,7);g.fill();g.fillStyle='#d9b26a';g.beginPath();g.arc(0,0,76,0,7);g.fill();g.fillStyle='#9c3a2e';g.beginPath();g.arc(0,0,66,0,7);g.fill();g.strokeStyle='#e9d9a8';g.lineWidth=3;g.setLineDash([8,6]);g.beginPath();g.arc(0,0,48,0,7);g.stroke();g.restore();
  g.save();g.translate(13.9*TS,5.9*TS);g.scale(1,.5);for(let i=0;i<6;i++){g.fillStyle=['#6b4a2a','#d8c08a'][i%2];g.beginPath();g.arc(0,0,120-i*16,0,7);g.fill()}g.restore();
  huRR(g,19.9*TS,4.4*TS,5.4*TS,2.2*TS,10,'#2f5576','#e0cf9a');huRR(g,20.3*TS,4.7*TS,4.6*TS,1.6*TS,6,null,'#e0cf9a');
  HUT.canvas=c;
}
function hutProp(g,k,t){
  const x0=HUT.x0*TS,Y=gy=>(HU_Y0+gy)*TS,X=gx=>x0+gx*TS;
  const sh=(cx,cy,rx)=>{g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(cx,cy,rx,7,0,0,7);g.fill()};
  g.save();
  if(k==='bed'){
    g.translate(X(1),Y(1));sh(68,86,70);
    huRR(g,0,4,132,80,8,'#4a2b14');huRR(g,3,8,126,70,6,'#efe3c6');
    huRR(g,4,13,32,26,9,'#fffaf0','#c9b992');huRR(g,4,43,32,26,9,'#fffaf0','#c9b992');
    huRR(g,44,8,85,70,7,'#b03a2c');
    for(let i=0;i<5;i++){g.fillStyle='rgba(240,225,185,.55)';g.fillRect(52+i*16,8,5,70)}
    huRR(g,40,8,12,70,5,'#e6dcc0');g.fillStyle='rgba(0,0,0,.14)';g.fillRect(52,8,4,70);
    huRR(g,-2,0,9,86,3,'#3a200f');
  }else if(k==='stand'){
    g.translate(X(4),Y(1));sh(22,44,20);huRR(g,4,14,36,30,4,'#6a4426','#3a2312');huRR(g,8,20,28,10,2,'#523318');g.fillStyle='#d8c08a';g.fillRect(14,2,8,16);g.fillStyle='#fff3cf';g.fillRect(14,2,8,4);
    drawFlame(g,18,3,t+1.3,.38);
  }else if(k==='ward'){
    g.translate(X(7),Y(1));sh(44,66,42);huRR(g,0,-34,88,100,5,'#5a381c','#2c1a0c');huRR(g,5,-28,38,88,3,'#7a5028');huRR(g,45,-28,38,88,3,'#7a5028');g.fillStyle='#d6a83e';g.beginPath();g.arc(38,22,3.4,0,7);g.arc(50,22,3.4,0,7);g.fill();g.fillStyle='rgba(255,230,170,.18)';g.fillRect(8,-24,3,78);g.fillRect(48,-24,3,78);
  }else if(k==='sea'){
    g.translate(X(1),Y(6));sh(44,40,42);huRR(g,0,10,88,34,5,'#6b4426','#2c1a0c');huRR(g,0,4,88,16,7,'#855a30','#2c1a0c');g.fillStyle='#b89a4a';g.fillRect(0,18,88,3);g.fillRect(40,4,8,38);g.fillStyle='#d6a83e';g.fillRect(41,22,6,8);
  }else if(k==='shelf'){
    g.translate(X(10),Y(1));sh(44,48,40);huRR(g,0,-34,88,84,4,'#5a381c','#2c1a0c');
    for(let r=0;r<3;r++){const yy=-28+r*26;g.fillStyle='#3a2312';g.fillRect(4,yy+20,80,5);let x=6;const cols=['#a0402e','#2f5576','#6b8a3a','#caa24a','#7a3f7a','#c76a2a'];for(let i=0;i<9&&x<78;i++){const w=6+((i*5+r*3)%5),h=14+((i*7+r)%6);g.fillStyle=cols[(i+r*2)%6];g.fillRect(x,yy+20-h,w,h);g.fillStyle='rgba(255,255,255,.15)';g.fillRect(x,yy+20-h,1.5,h);x+=w+1}}
    g.fillStyle='#efe3c6';g.beginPath();g.ellipse(70,-8,6,4,.3,0,7);g.fill();
  }else if(k==='hearth'){
    g.translate(X(13),Y(1));g.fillStyle='rgba(0,0,0,.3)';g.beginPath();g.ellipse(44,46,50,7,0,0,7);g.fill();
    huRR(g,-6,-44,100,92,5,'#8a8d92','#3d4045');
    for(let r=0;r<6;r++)for(let c=0;c<5;c++){const o=(r%2)*9;g.fillStyle=`rgb(${130+((r*31+c*17)%28)},${132+((r*13+c*29)%26)},${136+((r*7+c*11)%24)})`;huRR(g,-4+c*19+o-5,-42+r*15,17,13,3,null);g.fill()}
    huRR(g,10,-16,68,60,10,'#120a06');huRR(g,10,-16,68,60,10,null,'#2b2d31');
    g.fillStyle='#3a2312';g.fillRect(20,36,48,8);g.fillStyle='#5a381c';g.beginPath();g.ellipse(32,38,16,5,.1,0,7);g.ellipse(58,38,16,5,-.1,0,7);g.fill();
    drawFlame(g,44,40,t,1.55);drawFlame(g,28,40,t+1.7,1.05);drawFlame(g,60,40,t+3.1,1.1);
    huRR(g,-10,-50,108,10,3,'#6a4426','#2c1a0c');g.fillStyle='#d8c08a';g.fillRect(12,-60,6,10);g.fillRect(70,-58,6,8);drawFlame(g,15,-60,t+.4,.3);drawFlame(g,73,-58,t+2.2,.3);
  }else if(k==='table'){
    g.translate(X(12),Y(4));sh(88,62,92);
    for(const lx of[10,160]){g.fillStyle='#3a2312';g.fillRect(lx,30,8,30)}
    huRR(g,0,0,176,48,6,'#8a5a2c','#3a2312');huRR(g,3,3,170,38,4,'#a8743a');for(let i=1;i<4;i++){g.fillStyle='rgba(60,34,16,.45)';g.fillRect(4,i*10+2,168,1.6)}
    g.fillStyle='#eadcb8';g.beginPath();g.ellipse(52,24,13,6,0,0,7);g.ellipse(112,24,13,6,0,0,7);g.fill();g.strokeStyle='#8a7a52';g.lineWidth=1.2;g.stroke();
    g.fillStyle='#b9792e';g.fillRect(80,12,10,12);g.fillStyle='#d8c08a';g.fillRect(146,10,6,12);drawFlame(g,149,10,t+.9,.3);
  }else if(k==='stool1'||k==='stool2'){
    const sx=k==='stool1'?X(12)+8:X(15)-6;g.translate(sx,Y(5)+8);sh(18,26,18);g.fillStyle='#4a2b14';g.fillRect(4,12,5,14);g.fillRect(26,12,5,14);huRR(g,0,4,36,14,6,'#8a5a2c','#3a2312');
  }else if(k==='coat'){
    g.translate(X(17),Y(1));sh(22,44,16);g.fillStyle='#3a2312';g.fillRect(19,-28,5,72);huRR(g,6,-26,32,5,2,'#3a2312');
    g.fillStyle='#2e3d5a';g.beginPath();g.moveTo(12,-22);g.lineTo(34,-22);g.lineTo(38,26);g.lineTo(8,26);g.closePath();g.fill();g.fillStyle='#d6a83e';g.fillRect(21,-10,3,3);g.fillRect(21,0,3,3);
    g.fillStyle='#1d1d24';g.beginPath();g.moveTo(8,-30);g.lineTo(22,-42);g.lineTo(36,-30);g.lineTo(22,-26);g.closePath();g.fill();g.fillStyle='#d6a83e';g.fillRect(8,-30,28,2);
  }else if(k==='barrels'){
    g.translate(X(19),Y(1));sh(44,46,44);
    for(const[bx,by]of[[0,0],[44,0]]){const q=g.createLinearGradient(bx,0,bx+44,0);q.addColorStop(0,'#5a381c');q.addColorStop(.5,'#8a5a2c');q.addColorStop(1,'#4a2b14');huRR(g,bx+3,-18,38,60,12,q,'#2c1a0c');g.fillStyle='#2c1a0c';g.fillRect(bx+3,-4,38,4);g.fillRect(bx+3,22,38,4);g.fillStyle='#caa24a';g.beginPath();g.ellipse(bx+22,-18,19,6,0,0,7);g.fill();g.strokeStyle='#4a2b14';g.stroke()}
  }else if(k==='map'){
    g.translate(X(21),Y(3));sh(88,60,92);
    for(const lx of[10,160]){g.fillStyle='#3a2312';g.fillRect(lx,30,8,30)}
    huRR(g,0,-8,176,56,6,'#7a5028','#2c1a0c');huRR(g,10,-4,156,46,3,'#e6d3a0','#8a6a3a');
    g.strokeStyle='rgba(120,90,50,.7)';g.lineWidth=1.4;g.beginPath();g.moveTo(26,24);g.quadraticCurveTo(44,6,64,20);g.quadraticCurveTo(84,34,98,16);g.quadraticCurveTo(120,2,146,18);g.stroke();
    g.fillStyle='#b03a2c';g.fillRect(104,16,12,3);g.fillRect(108,12,3,11);
    g.strokeStyle='#c79a3a';g.lineWidth=2.2;g.beginPath();g.arc(140,10,9,0,7);g.stroke();g.fillStyle='#b03a2c';g.beginPath();g.moveTo(140,3);g.lineTo(143,10);g.lineTo(140,17);g.lineTo(137,10);g.closePath();g.fill();
    g.fillStyle='#1d1d24';g.fillRect(24,34,12,6);g.strokeStyle='#e9e2cf';g.lineWidth=1.6;g.beginPath();g.moveTo(40,36);g.lineTo(56,28);g.stroke();
    huRR(g,6,40,28,8,4,'#e6d3a0','#8a6a3a');
  }else if(k==='tele'){
    g.translate(X(26),Y(2));sh(22,44,18);
    g.strokeStyle='#4a2b14';g.lineWidth=4;g.beginPath();g.moveTo(22,10);g.lineTo(8,44);g.moveTo(22,10);g.lineTo(36,44);g.moveTo(22,10);g.lineTo(22,42);g.stroke();
    g.save();g.translate(22,8);g.rotate(-.55);huRR(g,-30,-6,60,12,4,'#b98a2c','#6a4a10');huRR(g,-34,-8,10,16,3,'#6a4426');huRR(g,18,-5,16,10,3,'#d6a83e');g.restore();
  }else if(k==='chest'){
    g.translate(X(25),Y(6));sh(44,40,42);huRR(g,0,10,88,34,5,'#5a3a1e','#2c1a0c');huRR(g,0,2,88,18,9,'#7a5028','#2c1a0c');g.fillStyle='#caa24a';g.fillRect(0,18,88,3);g.fillRect(14,2,6,40);g.fillRect(68,2,6,40);g.fillStyle='#e8c25a';huRR(g,38,18,12,14,2,'#e8c25a','#8a6a1a');
  }
  g.restore();
}
function renderHut(t){
  const g=ctx,z=camZoom();
  g.setTransform(1,0,0,1,0,0);g.fillStyle='#050406';g.fillRect(0,0,cv.width,cv.height);
  if(!HUT)return;if(!HUT.canvas)hutBake();
  g.setTransform(DPR*z,0,0,DPR*z,DPR*(VW/2-cam.x*z),DPR*(VH/2-cam.y*z));
  g.imageSmoothingEnabled=true;
  const x0=HUT.x0*TS,Y=gy=>(HU_Y0+gy)*TS,X=gx=>x0+gx*TS;
  g.drawImage(HUT.canvas,x0,HU_Y0*TS);
  const list=[];
  for(const k of['bed','stand','ward','sea','shelf','hearth','coat','barrels','map','tele','chest'])list.push({y:k==='hearth'?Y(1.9):k==='ward'||k==='shelf'?Y(1.9):Y(({bed:3,stand:2,sea:7,coat:2,barrels:2,map:4,tele:3,chest:7})[k]),d:()=>hutProp(g,k,t)});
  list.push({y:Y(5.0),d:()=>hutProp(g,'table',t)});list.push({y:Y(5.9),d:()=>hutProp(g,'stool1',t)});list.push({y:Y(5.9),d:()=>hutProp(g,'stool2',t)});
  list.push({y:P.y,d:()=>drawPlayer(g,t)});
  if(S.flags.parrot)list.push({y:PAR.y+4,d:()=>drawParrotEnt(g,t)});
  list.sort((a,b)=>a.y-b.y);for(const o of list)o.d();
  drawHeading(g,t);drawParts(g);
  // luce: ambiente in base all'ora e al meteo, più camino, candele e lanterna
  const dk=Math.min(1,skyLight(S.tod).dark/.5),fl=WX.flash>0?Math.min(1,WX.flash):0;
  const base=mixc([238,228,212],[56,50,72],dk),amb=[Math.min(255,base[0]+fl*70),Math.min(255,base[1]+fl*70),Math.min(255,base[2]+fl*80)];
  // fasci di sole dalle finestre
  const sun=(1-dk)*(S.wx&&S.wx.k==='clear'?1:.45);
  if(sun>.05){g.save();g.globalCompositeOperation='lighter';for(const gx of[4.5,22]){const wx=X(gx),wy=Y(0)+30,q=g.createLinearGradient(wx,wy,wx+60,wy+170);q.addColorStop(0,`rgba(255,240,190,${.28*sun})`);q.addColorStop(1,'rgba(255,240,190,0)');g.fillStyle=q;g.beginPath();g.moveTo(wx-24,wy);g.lineTo(wx+24,wy);g.lineTo(wx+110,wy+190);g.lineTo(wx+20,wy+190);g.closePath();g.fill()}g.restore()}
  const lights=[[X(14),Y(2.6),360,1,true,[255,170,90]],[X(4.5),Y(1.5),150,.7,true,[255,200,120]],[X(14),Y(4.2),200,.55,true,[255,210,140]],[X(15.2),Y(4.2),120,.4,true,[255,210,140]],[X(15),Y(2.2),100,.5,true,[255,200,120]],[P.x,P.y-28,56,.16,false,[255,230,190]]];
  if(!LCV)LCV=document.createElement('canvas');
  if(LCV.width!==cv.width||LCV.height!==cv.height){LCV.width=cv.width;LCV.height=cv.height}
  const lg=LCV.getContext('2d'),M=g.getTransform();
  lg.setTransform(1,0,0,1,0,0);lg.globalCompositeOperation='source-over';lg.fillStyle=rgbs(amb);lg.fillRect(0,0,LCV.width,LCV.height);
  lg.setTransform(M);lg.globalCompositeOperation='lighter';
  for(const l of lights){
    const col=l[5],ad=[Math.max(0,col[0]-amb[0]),Math.max(0,col[1]-amb[1]),Math.max(0,col[2]-amb[2])];
    const f=l[4]?(.93+.07*Math.sin(t*12+l[0])+.03*Math.sin(t*7.3)):1,R=l[2]*f,k=Math.min(1,l[3]);
    const q=lg.createRadialGradient(l[0],l[1],R*.08,l[0],l[1],R);
    for(const[o,a]of[[0,1],[.45,.85],[.7,.4],[.9,.12],[1,0]])q.addColorStop(o,`rgba(${ad[0]|0},${ad[1]|0},${ad[2]|0},${a*k})`);
    lg.fillStyle=q;lg.fillRect(l[0]-R,l[1]-R,R*2,R*2);
  }
  g.save();g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='multiply';g.drawImage(LCV,0,0);g.restore();
  g.setTransform(DPR,0,0,DPR,0,0);
  drawScreenFx(g);drawProgress(g,t);
  if(HUT.fade>0){g.fillStyle=`rgba(0,0,0,${HUT.fade})`;g.fillRect(0,0,VW,VH)}
}

