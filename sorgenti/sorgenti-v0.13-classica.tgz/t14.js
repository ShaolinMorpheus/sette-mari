const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1100,height:620}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/claude/out/nave_spagnola.html');await p.waitForTimeout(1200);
const r=await p.evaluate(()=>{const C=Ch4,K=C.K,P=C.P,o=[];K.inv=999;K.key1=true;
 const near=id=>{const ob=K.objs.find(q=>q.id===id);P.x=ob.x;P.y=ob.y+10;C.step(.02);ob.use()};
 near('sd');near('cell');near('su');C.tp(5,9);
 const pip=K.fol.find(f=>f.who==='pip');
 for(let i=0;i<900;i++){ if(i%60===0)o.push(Math.round(Math.hypot(pip.x-P.x,pip.y-P.y))+(pip.go?'g':'')+(pip.busy?'b':''));P.x+=Math.sin(i/40)*1.5;C.step(1/30)}
 return o});
console.log(JSON.stringify(r),errs);await b.close()})()
